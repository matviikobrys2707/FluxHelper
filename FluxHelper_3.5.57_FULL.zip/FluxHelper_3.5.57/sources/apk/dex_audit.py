#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Статичний аудит dex-джерел (smali): перехресний доступ до private-членів.

ART жорстко перевіряє доступ: invoke-direct на private-метод ІНШОГО класу
= IllegalAccessError у рантаймі (краш входу 3.5.53 «Заходимо в акаунт…»).
smali/baksmali цього НЕ перевіряють при асемблюванні. Скрипт ловить усі
такі місця ДО збірки APK.

Перевірки:
  V1: invoke-* на private-метод іншого класу
  V2: invoke-direct на НЕконструктор іншого класу
  V3: field-op на private-поле іншого класу
Синтетики access$NN, <init>, <clinit> — дозволені (патерн javac).
Використання: python3 dex_audit.py [корінь-smali]
"""
import os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else \
    '/home/z/my-project/work/src/3.5.53/apk/dex_src'

RE_METHOD = re.compile(
    r'^\.method\s+((?:[\w-]+\s+)*)([\w$<>]+)\((.*?)\)(.*)$')
RE_FIELD = re.compile(
    r'^\.field\s+((?:[\w-]+\s+)*)([\w$]+):(\S+?)\s*(=.*)?$')
RE_CLASS = re.compile(r'^\.class\s+((?:[\w-]+\s+)*)L([^;]+);')
RE_INVOKE = re.compile(
    r'^\s*invoke-(direct|virtual|static|super)(?:/range)?\s+\{[^}]*\},\s*'
    r'L([^;]+);->([\w$<>]+)\((.*?)\)(\S*)')
RE_FLDOP = re.compile(
    r'^\s*((?:[sj]get|iput|sput|iget)[-\w]*)\s+\{[^}]*\},\s*'
    r'L([^;]+);->([\w$]+):(\S+)')

def parse_flags(s):
    return set(s.split())

def main():
    methods = {}
    fields = {}
    classes = {}
    per_file = {}
    for dp, _, fns in os.walk(ROOT):
        for fn in fns:
            if not fn.endswith('.smali'):
                continue
            p = os.path.join(dp, fn)
            txt = open(p, encoding='utf-8', errors='replace').read()
            per_file[p] = txt
            m = RE_CLASS.match(txt.lstrip())
            if not m:
                continue
            cls = 'L' + m.group(2) + ';'
            classes[p] = cls
            md, fd = methods.setdefault(cls, {}), fields.setdefault(cls, {})
            for line in txt.splitlines():
                mm = RE_METHOD.match(line.strip())
                if mm:
                    fl = parse_flags(mm.group(1))
                    md[mm.group(2) + '(' + mm.group(3) + ')' + mm.group(4)] = \
                        'private' if 'private' in fl else 'other'
                    continue
                fm = RE_FIELD.match(line.strip())
                if fm:
                    fl = parse_flags(fm.group(1))
                    fd[fm.group(2)] = 'private' if 'private' in fl else 'other'

    violations = []
    for p, txt in sorted(per_file.items()):
        me = classes.get(p)
        if not me:
            continue
        for i, line in enumerate(txt.splitlines(), 1):
            im = RE_INVOKE.match(line)
            if im:
                kind, tcls, tname, tpar, tret = im.groups()
                sig = tname + '(' + tpar + ')' + tret
                tgt = 'L' + tcls + ';'
                if tgt == me or tname.startswith('access$'):
                    continue
                vis = methods.get(tgt, {}).get(sig)
                if vis == 'private':
                    violations.append(
                        f'V1 {os.path.relpath(p, ROOT)}:{i} {kind} private '
                        f'{tgt}->{sig} (from {me})')
                if kind == 'direct' and tname not in ('<init>', '<clinit>'):
                    violations.append(
                        f'V2 {os.path.relpath(p, ROOT)}:{i} invoke-direct '
                        f'non-ctor {tgt}->{sig} (from {me})')
                continue
            fm = RE_FLDOP.match(line)
            if fm:
                _, tcls, tname, _t = fm.groups()
                tgt = 'L' + tcls + ';'
                if tgt == me or tname.startswith('access$'):
                    continue
                if fields.get(tgt, {}).get(tname) == 'private':
                    violations.append(
                        f'V3 {os.path.relpath(p, ROOT)}:{i} field-op private '
                        f'{tgt}->{tname} (from {me})')

    if violations:
        print(f'!!! {len(violations)} ПОРУШЕНЬ ДОСТУПУ:')
        for v in violations:
            print('  ' + v)
        sys.exit(1)
    print('OK: 0 перехресних private-порушень у', ROOT)

if __name__ == '__main__':
    main()
