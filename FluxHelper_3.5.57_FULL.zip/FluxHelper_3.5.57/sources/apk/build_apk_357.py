#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.57 (versionCode 30557).
База: 3.5.56 APK. Змінено ТІЛЬКИ:
  • classes.dex — діагностика помилок Credential Manager у JS
    (credentialFail → localStorage.fh_gcm_err + console.log '[gcm]');
  • AXML versionCode 30557 / versionName 3.5.57;
  • assets/www/* — без змін (сайт живе на Pages, оновлюється окремо).
"""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/work/repo_pub/versions/beta/3.5.56/FluxHelper.apk'
DEX    = '/tmp/classes57.dex'
OUTDIR = '/home/z/my-project/work/build357'
BT     = '/home/z/my-project/work/android/bt34'
KEYS   = '/home/z/my-project/work/src/keys/fluxhelper.keystore.OFFICIAL-6871F0'

os.makedirs(OUTDIR, exist_ok=True)
UNSIGNED = f'{OUTDIR}/FluxHelper_357_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_357_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper_357.apk'

def zlib_read(apk, name):
    with zipfile.ZipFile(apk) as z:
        return z.read(name)

assert os.path.exists(DEX), 'classes57.dex не зібрано!'
assert os.path.getsize(DEX) > 5_000_000, 'dex підозріло малий'
assert os.path.exists(f'{BT}/zipalign'), 'немає zipalign'
assert os.path.exists(f'{BT}/lib/apksigner.jar'), 'немає apksigner.jar'

with zipfile.ZipFile(BASE) as z:
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue  # стара підписа
    if n == 'AndroidManifest.xml':
        ax = bytearray(zlib_read(BASE, n))
        vc_old = (30556).to_bytes(4, 'little'); vc_new = (30557).to_bytes(4, 'little')
        i = ax.find(vc_old); assert i > 0, 'versionCode 30556 not found'
        ax[i:i+4] = vc_new
        vn_old = '3.5.56'.encode('utf-16-le'); vn_new = '3.5.57'.encode('utf-16-le')
        j = ax.find(vn_old); assert j > 0, 'versionName 3.5.56 not found'
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0, 'versionName duplicated!'
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: versionCode 30557, versionName 3.5.57')
    elif n == 'classes.dex':
        with open(DEX, 'rb') as d:
            zf.writestr(n, d.read(), compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: classes57.dex,', os.path.getsize(DEX), 'bytes')
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:600])
assert '6871f0d5' in r.stdout.lower().replace('\n', ''), 'SHA-1 mismatch!'

with zipfile.ZipFile(SIGNED) as z:
    d = z.read('classes.dex')
assert hashlib.md5(d).hexdigest() == hashlib.md5(open(DEX, 'rb').read()).hexdigest(), \
    'dex всередині APK не збігається!'
print('dex-in-apk md5 OK')

with zipfile.ZipFile(SIGNED) as z:
    ax = z.read('AndroidManifest.xml')
assert (30557).to_bytes(4, 'little') in ax and '3.5.57'.encode('utf-16-le') in ax
print('AXML-in-apk version OK')

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
