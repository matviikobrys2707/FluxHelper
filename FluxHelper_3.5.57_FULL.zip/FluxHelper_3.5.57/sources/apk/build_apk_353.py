#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.53 (versionCode 30553).
База: 3.5.52 APK. Змінено:
  • classes.dex — ПЕРЕЗБІРКА з smali-джерел 3.5.53 (нове правило власника:
    Firebase тільки для автентифікації → fbExchangeRelay через Backend;
    плитки недавніх акаунтів = тихий AccountManager-вхід БЕЗ меню CM);
  • assets/www/{index.html,ui.css,ui.js} — iphone 3.5.53;
  • AXML versionCode 30553 / versionName 3.5.53.
"""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/work/site/versions/beta/3.5.52/FluxHelper.apk'
SRC    = '/home/z/my-project/work/site/iphone'
DEX    = '/tmp/classes53.dex'
OUTDIR = '/home/z/my-project/work/build353'
BT     = '/home/z/my-project/work/android/android-14'
KEYS   = '/home/z/my-project/work/src/keys/fluxhelper.keystore.OFFICIAL-6871F0'

os.makedirs(OUTDIR, exist_ok=True)
UNSIGNED = f'{OUTDIR}/FluxHelper_353_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_353_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper.apk'

def zlib_read(apk, name):
    with zipfile.ZipFile(apk) as z:
        return z.read(name)

assert os.path.exists(DEX), 'classes53.dex не зібрано!'
assert os.path.getsize(DEX) > 5_000_000, 'dex підозріло малий'

with zipfile.ZipFile(BASE) as z:
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue  # стара підписа
    if n == 'AndroidManifest.xml':
        ax = bytearray(zlib_read(BASE, n))
        vc_old = (30552).to_bytes(4, 'little'); vc_new = (30553).to_bytes(4, 'little')
        i = ax.find(vc_old); assert i > 0, 'versionCode 30552 not found'
        ax[i:i+4] = vc_new
        vn_old = '3.5.52'.encode('utf-16-le'); vn_new = '3.5.53'.encode('utf-16-le')
        j = ax.find(vn_old); assert j > 0, 'versionName 3.5.52 not found'
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0, 'versionName duplicated!'
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: versionCode 30553, versionName 3.5.53')
    elif n == 'classes.dex':
        with open(DEX, 'rb') as d:
            zf.writestr(n, d.read(), compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: новий classes53.dex,', os.path.getsize(DEX), 'bytes')
    elif n == 'assets/www/index.html':
        zf.writestr(n, open(f'{SRC}/index.html','rb').read(), compress_type=zipfile.ZIP_DEFLATED)
    elif n == 'assets/www/ui.js':
        zf.writestr(n, open(f'{SRC}/ui.js','rb').read(), compress_type=zipfile.ZIP_DEFLATED)
    elif n == 'assets/www/ui.css':
        zf.writestr(n, open(f'{SRC}/ui.css','rb').read(), compress_type=zipfile.ZIP_DEFLATED)
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:600])
assert '6871f0d5' in r.stdout.lower().replace('\n',''), 'SHA-1 mismatch!'

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
