FluxHelper 3.5.58 (beta) — ПОВНИЙ ПАКЕТ
=========================================
Дата: 17.11.2026 · GitHub main: f0cea05 + фікс zoom be901f7 · Канал: beta

У пакеті — ВСЕ САМЕ ПОТРІБНЕ по версії 3.5.58: готові застосунки, джерела сайту
гілки main (у тому числі фікс zoom: урок на мобільній версії відкриває
конференцію з кодом), smali-джерела APK та патч-скрипти EXE.

СКЛАД ПАКЕТА
------------
app/
  FluxHelper_3.5.58.apk — Android, versionCode 30558, офіційний підпис
                          SHA-1 6871f0d5fadac10933492095bd322d4bf81a8373
  FluxHelper_3.5.58.exe — Windows, розмір і структура як у 3.5.55 (піднято тільки номер версії)
changelog.txt           — що нового у 3.5.58
latest.json             — маніфест бета-каналу (apk_md5/exe_md5 для перевірки оновлень)
website/                — джерела сайту 3.5.58 (29 файлів):
  index.html (головна), auth.html + fbauth.html (вхід Google, deep-link
  fluxhelper://auth?done=1), _headers (CSP), main/ (спільна версія), iphone/,
  mac/, b/ (бета-сторінка без індексації), manifest.json, latest.json (release-канал), іконки
sources/apk/            — smali-джерела APK: dex_src (5330 класів), інструменти
  smali/baksmali 2.5.2 (antlr-runtime-3.5.2.jar, baksmali-2.5.2.jar, dexlib2-2.5.2.jar, guava-14.0.jar, jcommander-1.82.jar, jsr305-3.0.2.jar, smali-2.5.2.jar, util-2.5.2.jar), dex_audit.py,
  build_apk_353/354/357.py, website-src (дзеркало сайту для assets APK).
  БАЗА — 3.5.56: патч 3.5.58 (таймаут токена, захищений обмін, CM-колбеки на main thread) вже вшитий
  в опублікований APK; точковий smali-диф — у приватному репо FluxHelper_SRC.
sources/exe/            — exe_src, patch_exe_352/353/354/357.py (EXE не перезбирається —
  тільки same-length патч номера версії), ui_current (UI попередніх версій)

ЯК ВСТАНОВИТИ
-------------
Android: перекиньте app/FluxHelper_3.5.58.apk на телефон і відкрийте → дозвольте
  встановлення. Ставиться ПОВЕРХ 3.5.55 (підпис той самий, дані не губляться).
Windows: запустіть app/FluxHelper_3.5.58.exe.
Сайт: https://fluxhelper.pages.dev (бета — перемикач «Бета-версії» в профілі адміна).

ПЕРЕВІРКА ЦІЛІСНОСТІ
--------------------
md5/sha256 ключових файлів — у HASHES.txt. Контрольні md5:
  APK = 050f2effe1443120551483d3291d9cfe
  EXE = 3c00da5841b0bb9c940333e90e2d5472
Якщо суми збігаються — файли справжні (офіційна збірка).

БЕЗПЕКА
-------
Пароль keystore у build_apk_353/354/357.py ВИЛУЧЕНО (замінено на ***REMOVED***),
бо пакет публічний. Файл ключа fluxhelper.keystore.OFFICIAL-6871F0 до пакета
не входить; пароль зберігається у приватному репозиторії FluxHelper_SRC.
Firebase-ключ Android (AIza…) у smali — це публічна конфігурація самого APK.
