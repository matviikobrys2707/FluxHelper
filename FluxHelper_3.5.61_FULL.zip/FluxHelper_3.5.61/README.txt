FluxHelper 3.5.61 (beta) — ПОВНИЙ ПАКЕТ
=========================================
Дата: 17.11.2026 · GitHub main: bf8852e · Канал: beta

У пакеті — ВСЕ САМЕ ПОТРІБНЕ по версії 3.5.61: готові застосунки, джерела сайту
гілки main, ПОВНІ smali-джерела APK (5330 класів — нативний Google-вхід через
Credential Manager та УСІ бібліотеки) і скрипти збірки.

3.5.61 = ВІДНОВЛЕННЯ НАТИВНОГО GOOGLE-ВХОДУ (як в інструкції): тап «Увійти» →
рідне меню вибору акаунта Google всередині застосунку → вхід без браузера.
classes.dex = подлинний shipped 3.5.58 БАЙТ-В-БАЙТ (нічого не перезбиралося) —
усі фікси «вічного завантаження» 3.5.58 включно, краш-баг 3.5.59 (credLock)
відсутній за конструкцією. APK знову ~2.48 МБ, бо повернулися бібліотеки
(androidx.credentials, googleid, Firebase Auth, Play services, kotlin-корутини).

СКЛАД ПАКЕТА
------------
app/
  FluxHelper_3.5.61.apk — Android, versionCode 30561, офіційний підпис
                          SHA-1 6871f0d5fadac10933492095bd322d4bf81a8373
                          (нативний CM-вхід + усі бібліотеки, ~2.48 МБ)
  FluxHelper_3.5.61.exe — Windows, розмір 1:1 як у попередніх (піднято тільки номер версії)
changelog.txt           — що нового у 3.5.61 (нативний вхід повернуто)
latest.json             — маніфест бета-каналу (apk_md5/exe_md5 для перевірки оновлень)
website/                — джерела сайту 3.5.61 (29 файлів):
  index.html (головна), auth.html (вхід Google; mobile deep link
  fluxhelper://auth?s=&d= — сумісний і з резервним ланцюгом 3.5.61),
  _headers (CSP), main/ (спільна версія), iphone/ (ui.js), mac/, b/,
  manifest.json, latest.json (release-канал), іконки
sources/apk/            — ПОВНІ smali-джерела APK 3.5.61: dex_src (5330 класів —
  повний склад classes.dex, нативний Credential Manager + всі бібліотеки),
  інструменти smali/baksmali 2.5.2 (antlr-runtime-3.5.2.jar, baksmali-2.5.2.jar, dexlib2-2.5.2.jar, failureaccess-1.0.1.jar, guava-27.1-android.jar, jcommander-1.64.jar, smali-2.5.2.jar, util-2.5.2.jar),
  build_apk_361.py (збірка: база shipped 3.5.58 + AXML версії + підпис),
  patch_exe_361.py (EXE), dex_integrity_check.py (перевірка цілісності dex).
  dex 3.5.61 = ТОЙ САМИЙ байт-в-байт, що працював у shipped 3.5.57/3.5.58.
sources/exe/            — patch_exe_361.py (EXE не перезбирається —
  тільки same-length патч номера версії 3.5.60 → 3.5.61)

ЯК ВСТАНОВИТИ
-------------
Android: перекиньте app/FluxHelper_3.5.61.apk на телефон і відкрийте → дозвольте
  встановлення. Ставиться ПОВЕРХ будь-якої 3.5.x (підпис той самий, дані не губляться).
Windows: запустіть app/FluxHelper_3.5.61.exe.
Сайт: https://fluxhelper.pages.dev (бета — перемикач «Бета-версії» в профілі адміна).

ПЕРЕВІРКА ЦІЛІСНОСТІ
--------------------
md5/sha256 ключових файлів — у HASHES.txt. Контрольні md5:
  APK = 1a86cc438e81fe47cf3d697debd12248
  EXE = 65cee3fbd5dbb3f05f51552de82c9f35
Якщо суми збігаються — файли справжні (офіційна збірка).

БЕЗПЕКА
-------
Пароль keystore у build_apk_361.py ВИЛУЧЕНО (замінено на ***REMOVED***),
бо пакет публічний. Файл ключа fluxhelper.keystore.OFFICIAL-6871F0 до пакета
не входить; пароль зберігається у приватному репозиторії FluxHelper_SRC.
