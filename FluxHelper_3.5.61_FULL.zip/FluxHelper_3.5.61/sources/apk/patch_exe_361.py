#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EXE 3.5.61: только номер версии 3.5.60 → 3.5.61 (логика не тронута)."""
import hashlib, os

BASE = '/home/z/my-project/work/build360/FluxHelper_360.exe'
OUT  = '/home/z/my-project/work/build61/FluxHelper_361.exe'
BASE_MD5 = '02ece6f2e1bf7b69acef78b3a942d126'

old_a, new_a = b'3.5.60', b'3.5.61'
old_u, new_u = '3.5.60'.encode('utf-16-le'), '3.5.61'.encode('utf-16-le')
assert len(old_a) == len(new_a) and len(old_u) == len(new_u)

def replace_all(buf, old, new):
    out, i, cnt = [], 0, 0
    while True:
        j = buf.find(old, i)
        if j < 0:
            out.append(buf[i:]); break
        out.append(buf[i:j]); out.append(new)
        i = j + len(old); cnt += 1
    return b''.join(out), cnt

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

assert md5(BASE) == BASE_MD5, 'база EXE 3.5.60 не совпадает!'
data = open(BASE, 'rb').read()
data, n_a = replace_all(data, old_a, new_a)
data, n_u = replace_all(data, old_u, new_u)
assert n_a >= 1 and n_u >= 1, 'не найдено ни одного вхождения версии'
assert data.find(new_a) >= 0 and data.find(new_u) >= 0
assert data.find(old_a) == -1 and data.find(old_u) == -1, 'остались старые вхождения!'
assert len(data) == os.path.getsize(BASE), 'размер изменился!'
os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, 'wb').write(data)
print('EXE 3.5.61:', OUT)
print('ascii replacements:', n_a, '| utf16 replacements:', n_u)
print('size:', len(data))
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
