#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Детермінована перевірка цілісності classes.dex (без baksmali):

  1. field_ids: кожен field_id, що вказує на клас com/fluxhelper/**,
     МАЄ відповідати оголошеному (.field) у class_data цього класу.
     Порушення = NoSuchFieldError під час виконання (краш зі скриншота).
  2. method_ids: аналогічно для методів → NoSuchMethodError.
  3. Усі класи-посилання мають бути: серед збережених, у [ масивах,
     або android/**/java/** платформних → інакше NoClassDefFoundError.
  4. Рядковий пошук заданих маркерів ("credLock") у string-таблиці.

Запуск: python3 dex_integrity_check.py <apk1> [<apk2> ...]
"""
import struct, sys, zipfile, io, os

def uleb(buf, pos):
    result = 0; shift = 0
    while True:
        b = buf[pos]; pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80): return result, pos
        shift += 7

class Dex:
    def __init__(self, data):
        self.data = data
        (self.string_ids_size, self.string_ids_off,
         self.type_ids_size, self.type_ids_off,
         self.proto_ids_size, self.proto_ids_off,
         self.field_ids_size, self.field_ids_off,
         self.method_ids_size, self.method_ids_off,
         self.class_defs_size, self.class_defs_off) = struct.unpack_from(
            '<12I', data, 0x38)

    def string(self, idx):
        off = struct.unpack_from('<I', self.data, self.string_ids_off + idx * 4)[0]
        n, p = uleb(self.data, off)
        raw = self.data[p:p + n]  # MUTF-8; для ASCII-маркерів достатньо
        return raw.decode('utf-8', errors='replace')

    def type(self, idx):
        d = struct.unpack_from('<I', self.data, self.type_ids_off + idx * 4)[0]
        return self.string(d)

    def field_ids(self):
        for i in range(self.field_ids_size):
            c, t, n = struct.unpack_from('<HHI', self.data, self.field_ids_off + i * 8)
            yield i, self.type(c), self.type(t), self.string(n)

    def method_ids(self):
        for i in range(self.method_ids_size):
            c, p, n = struct.unpack_from('<HHI', self.data, self.method_ids_off + i * 8)
            yield i, self.type(c), self.string(n)

    def classes(self):
        """class_name -> (super_name, declared_fields, declared_methods)"""
        out = {}
        for i in range(self.class_defs_size):
            base = self.class_defs_off + i * 32
            class_idx, _, sup_idx, _, _, _, cd_off, _ = struct.unpack_from('<8I', self.data, base)
            cname = self.type(class_idx)
            sup = self.type(sup_idx) if sup_idx != 0xFFFFFFFF else None
            fields, methods = set(), set()
            if cd_off:
                pos = cd_off
                sf, pos = uleb(self.data, pos)
                iff, pos = uleb(self.data, pos)
                dm, pos = uleb(self.data, pos)
                vm, pos = uleb(self.data, pos)
                idx = 0
                for _ in range(sf):
                    d, pos = uleb(self.data, pos); idx += d
                    fields.add(idx); _, pos = uleb(self.data, pos)
                idx = 0
                for _ in range(iff):
                    d, pos = uleb(self.data, pos); idx += d
                    fields.add(idx); _, pos = uleb(self.data, pos)
                idx = 0
                for _ in range(dm):
                    d, pos = uleb(self.data, pos); idx += d
                    _, pos = uleb(self.data, pos)   # access_flags
                    _, pos = uleb(self.data, pos)   # code_off
                    methods.add(idx)
                idx = 0
                for _ in range(vm):
                    d, pos = uleb(self.data, pos); idx += d
                    _, pos = uleb(self.data, pos)   # access_flags
                    _, pos = uleb(self.data, pos)   # code_off
                    methods.add(idx)
            out[cname] = (sup, fields, methods)
        return out

def kept_class(c):
    if c.startswith('L') and c.endswith(';'):
        c = c[1:-1]
    return c

PLATFORM_PREFIXES = ('Ljava/', 'Ljavax/', 'Landroid/', 'Ldalvik/', 'Lcom/android/',
                     'Lorg/apache/', 'Lorg/json/', 'Lorg/xmlpull/', 'Ljavax/', 'Lkotlin/')

def check_apk(path):
    name = os.path.basename(path)
    if path.endswith('.dex'):
        with open(path, 'rb') as f:
            dex_data = f.read()
    else:
        with zipfile.ZipFile(path) as z:
            dex_data = z.read('classes.dex')
    dx = Dex(dex_data)
    print(f'\n===== {name} =====')
    print(f'dex: {len(dex_data)} B, strings={dx.string_ids_size}, types={dx.type_ids_size}, '
          f'fields={dx.field_ids_size}, methods={dx.method_ids_size}, classes={dx.class_defs_size}')

    cls = dx.classes()
    print(f'class_defs parsed: {len(cls)}')

    # рядковий пошук маркерів (з друком самих рядків)
    markers = ['credLock', 'credentialLogin', 'prewarmCred']
    for m in markers:
        hits = [dx.string(i) for i in range(dx.string_ids_size) if m in dx.string(i)]
        print(f'string-table "{m}": {len(hits)} входжень: {hits[:5]}')

    # 1) поля (з урахуванням наслідування: поле може оголошувати суперклас)
    flux_fields = {}
    for fid, c, t, n in dx.field_ids():
        if c.startswith('Lcom/fluxhelper/'):
            flux_fields[fid] = (c, t, n)
    print(f'field_ids -> com/fluxhelper/**: {len(flux_fields)}')
    def resolve_in_chain(cname, idx, kind):
        """Чи оголошує клас-ціль (або його in-dex суперкласи) field/method idx.
        Повертає (ok, reason). Якщо ланцюг виходить у платформу — вважаємо OK."""
        c = cname
        seen = 0
        while c in cls and seen < 16:
            _, fields, methods = cls[c]
            s = fields if kind == 'field' else methods
            if idx in s:
                return True, ''
            c = cls[c][0]  # superclass
            seen += 1
        if c not in cls:
            return True, 'platform-super'   # суперклас поза dex (платформа)
        return False, f'не знайдено в ланцюгу {cname}'

    errors = []
    for fid, (c, t, n) in flux_fields.items():
        if c not in cls:
            errors.append(f'FIELD {c}->{n}:{t}: клас-ціль НЕ в dex (видалений?)')
            continue
        ok, why = resolve_in_chain(c, fid, 'field')
        if not ok:
            errors.append(f'FIELD {c}->{n}:{t}: field_id Є, а оголошення НЕМА (NoSuchFieldError!)')

    # 2) методи (з урахуванням наслідування)
    flux_methods = {}
    for mid, c, n in dx.method_ids():
        if c.startswith('Lcom/fluxhelper/'):
            flux_methods[mid] = (c, n)
    print(f'method_ids -> com/fluxhelper/**: {len(flux_methods)}')
    for mid, (c, n) in flux_methods.items():
        if c not in cls:
            errors.append(f'METHOD {c}->{n}: клас-ціль НЕ в dex (видалений?)')
            continue
        ok, why = resolve_in_chain(c, mid, 'method')
        if not ok:
            errors.append(f'METHOD {c}->{n}: method_id Є, а оголошення НЕМА (NoSuchMethodError!)')
    # 3) класи-посилання
    kept = set(cls.keys())
    external = set()
    for _, c, _, _ in dx.field_ids():
        external.add(c)
    for _, c, _ in dx.method_ids():
        external.add(c)
    for c in cls.values():
        sup = c[0]
        if sup: external.add(sup)
    bad_cls = set()
    for c in external:
        if c in kept: continue
        if c.startswith('['): continue
        if c.startswith(PLATFORM_PREFIXES): continue
        bad_cls.add(c)
    print(f'зовнішніх класів-посилань поза платформою: {len(bad_cls)}')
    for c in sorted(bad_cls):
        errors.append(f'CLASS {c}: посилання на видалений клас (NoClassDefFoundError-ризик!)')

    if errors:
        print(f'\n!! ЗНАЙДЕНО ПРОБЛЕМ: {len(errors)}')
        for e in errors[:30]:
            print('  -', e)
        return False
    print('\nOK: field/method/class-посилання цілісні — NoSuchFieldError/NoSuchMethodError/'
          'NoClassDefFoundError у com/fluxhelper/** неможливі.')
    return True

if __name__ == '__main__':
    ok_all = True
    for p in sys.argv[1:]:
        ok_all &= check_apk(p)
    sys.exit(0 if ok_all else 1)
