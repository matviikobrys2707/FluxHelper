#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.61 (versionCode 30561).

ВОССТАНОВЛЕНИЕ НАТИВНОГО GOOGLE-ВХОДА (по требованию владельца):
3.5.59/3.5.60 имели вход только через браузер (native CM-цепочка была
вырезана по просьбе «переделай с нуля»). Владелец вернулся: нужно меню
выбора аккаунта Google ВНУТРИ приложения, как в инструкции (Credential
Manager), и все библиотеки на месте (APK снова ~2.48 МБ).

База: подлинный shipped 3.5.58 APK (md5 050f2effe1443120551483d3291d9cfe,
скачан с fluxhelper.pages.dev/versions/beta/3.5.58/FluxHelper.apk) —
в нём нативная CM-цепочка + ВСЕ фиксы вечного зависания (3.5.58) +
declared credLock (нет краша 3.5.59). dex НЕ пересобирается — байт-в-байт.
Меняется ТОЛЬКО AXML: versionCode 30558→30561, versionName 3.5.58→3.5.61.
"""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/work/build61/FluxHelper_358_ref.apk'
OUTDIR = '/home/z/my-project/work/build61'
BT     = '/home/z/my-project/work/android/bt34/android-14'
KEYS   = 'fluxhelper.keystore.OFFICIAL-6871F0 (файл ключа не публікується)'
BASE_MD5 = '050f2effe1443120551483d3291d9cfe'

UNSIGNED = f'{OUTDIR}/FluxHelper_361_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_361_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper_361.apk'

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

assert md5(BASE) == BASE_MD5, 'база 3.5.58 не совпадает с shipped md5!'
assert os.path.exists(f'{BT}/zipalign') and os.path.exists(f'{BT}/lib/apksigner.jar')

with zipfile.ZipFile(BASE) as z:
    dex_base = z.read('classes.dex')
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue  # старая подпись
    if n == 'AndroidManifest.xml':
        ax = bytearray(zipfile.ZipFile(BASE).read(n))
        vc_old = (30558).to_bytes(4, 'little'); vc_new = (30561).to_bytes(4, 'little')
        assert ax.count(vc_old) == 1, f'versionCode 30558: не единственное вхождение ({ax.count(vc_old)})'
        i = ax.find(vc_old); assert i > 0
        ax[i:i+4] = vc_new
        vn_old = '3.5.58'.encode('utf-16-le'); vn_new = '3.5.61'.encode('utf-16-le')
        assert ax.count(vn_old) == 1, f'versionName 3.5.58: не единственное вхождение ({ax.count(vn_old)})'
        j = ax.find(vn_old); assert j > 0
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0, 'осталось старое versionName!'
        assert ax.find(vn_new) >= 0
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: versionCode 30561, versionName 3.5.61')
    elif n == 'classes.dex':
        zf.writestr(n, dex_base, compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: байт-в-байт из shipped 3.5.58 (нативная CM-цепочка),', len(dex_base), 'bytes')
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:600])
assert '6871f0d5' in r.stdout.lower().replace('\n', ''), 'SHA-1 mismatch!'

# dex внутри подписанного == базе 3.5.58 (байт-в-байт)
with zipfile.ZipFile(SIGNED) as z:
    d = z.read('classes.dex')
dex_md5 = hashlib.md5(dex_base).hexdigest()
assert hashlib.md5(d).hexdigest() == dex_md5, 'dex внутри APK не совпадает с базой 3.5.58!'
print('dex-in-apk md5 = базе 3.5.58 OK:', dex_md5)

with zipfile.ZipFile(SIGNED) as z:
    ax = z.read('AndroidManifest.xml')
assert (30561).to_bytes(4, 'little') in ax and '3.5.61'.encode('utf-16-le') in ax
assert (30558).to_bytes(4, 'little') not in ax
print('AXML-in-apk version OK: 30561 / 3.5.61')

# ui.js в APK = нативный вход (маркеры CM-цепочки 3.5.58)
with zipfile.ZipFile(SIGNED) as z:
    ujs = z.read('assets/www/ui.js').decode('utf-8')
for marker in ('AndroidHost.login', '__fhAgTs', 'rescue20', 'authPollDb'):
    assert marker in ujs, f'ui.js потерял маркер {marker}!'
print('asset ui.js: нативный вход (CM) + rescue на месте')

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
