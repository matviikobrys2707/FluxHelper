// ============================================================
//  FluxHelper 2.4.1 — ІНТЕРФЕЙС ДЛЯ ПК (цей файл вбудовується в exe)
//  ВІДНОВЛЕНО З РЕЛІЗНОГО EXE 2.4.1 (вбудований ресурс — байт-в-байт).
//  Плейсхолдери, які підставляє main.cpp:
//  __LOGO_B64__        -> base64 логотипа
//  __SETTINGS_JSON__   -> {"ang":1,...} або null
//  __APP_VER__         -> версія з version.h
//  __DEVINFO_JSON__    -> JSON інформації про пристрій (2.4.1)
// ============================================================
static const char kUiHtmlDesktop[] = R"HTML(<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>FluxHelper</title>
<style>

*{margin:0;padding:0;box-sizing:border-box;-webkit-user-select:none;user-select:none;-webkit-user-drag:none}
/* 2.8.0: виділення/копіювання тексту вимкнено скрізь — звичайна програма, а не браузер
   (текст у полях, що редагуються, за потреби все одно вводиться) */
::selection{background:transparent}
::-moz-selection{background:transparent}
/* гарний скролбар скрізь (тонкий, округлий, у тоні градієнта) */
::-webkit-scrollbar{width:9px;height:9px}
::-webkit-scrollbar-thumb{background:rgba(139,92,246,.35);border-radius:99px}
::-webkit-scrollbar-thumb:hover{background:rgba(139,92,246,.6)}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-corner{background:transparent}
html,body{height:100%;overflow:hidden}
#app{flex:1;min-height:0;display:flex;flex-direction:column}
/* 2.9.0: панель — дитина body (поза #app): ніколи не масштабується zoom'ом
   і завжди над гейтом входу/сплешем — кнопки вікна однакові всюди */
#tbar{flex:none}
body{
  font-family:'Segoe UI Variable','Segoe UI',system-ui,-apple-system,sans-serif;
  color:#f4f4f8;-webkit-font-smoothing:antialiased;
  background:
    radial-gradient(540px 360px at 14% -10%, rgba(124,58,237,.17), transparent 68%),
    radial-gradient(580px 400px at 88% 114%, rgba(79,70,229,.14), transparent 66%),
    #050508;
  display:flex;flex-direction:column;
}
button{font-family:inherit}
.hidden{display:none!important}

/* ---------- титульна панель ---------- */
/* 2.8.1: ЖОДНОГО розділення між панеллю і контентом (без border/фону) —
   панель «розчиняється» у фоні програми, як просив власник */
#tbar{height:50px;flex:none;display:flex;align-items:center;justify-content:space-between;
  padding-left:14px;padding-right:7px;user-select:none;-webkit-user-select:none;
  app-region:drag;-webkit-app-region:drag;
  border-bottom:0;background:transparent;position:relative;z-index:5}
.tb-l{display:flex;align-items:center;gap:10px;position:relative;z-index:2;transition:transform .3s ease,opacity .25s ease}
.lmark{display:grid;place-items:center;pointer-events:none}
.lmark svg{display:block}
#tbar .lmark{box-shadow:0 4px 14px rgba(99,102,241,.45);border-radius:9px}
.tb-name{font-size:14.5px;font-weight:700;letter-spacing:.3px;color:#fff}
.tb-ver{font-size:9.5px;font-weight:800;letter-spacing:1.2px;color:#a5b4fc;text-transform:uppercase;opacity:.85}
.tb-r{display:flex;height:100%;align-items:center}
/* 2.8.1: кнопки вікна — БЕЗ рамки (просто іконки), при наведенні — тонка
   підсвічена рамочка навколо (мінімалістично, як просив власник) */
.tb-btn{width:34px;height:29px;margin:0 2px;display:grid;place-items:center;background:transparent;
  border:1px solid transparent;border-radius:9px;cursor:pointer;color:#a9adbf;
  transition:background .15s ease,color .15s ease,border-color .15s ease,transform .1s ease;
  app-region:no-drag;-webkit-app-region:no-drag}
.tb-btn:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.17);color:#fff}
.tb-btn:active{transform:scale(.9)}
.tb-btn.tb-x{margin-right:4px}
.tb-btn.tb-x:hover{background:rgba(244,63,94,.14);border-color:rgba(244,63,94,.55);color:#fb7185}
.tb-btn.tb-x:active{transform:scale(.9)}
/* 2.8.0: кнопка акаунта в титульній панелі — аватар + ім'я + пошта (дрібним шрифтом),
   ОДНАЙМАЛися на одному рівні з лого/назвою/вкладками/кнопками вікна */
.tb-acc{display:flex;align-items:center;gap:9px;height:34px;margin-right:8px;padding:0 13px 0 5px;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:12px;cursor:pointer;
  app-region:no-drag;-webkit-app-region:no-drag;font-family:inherit;text-align:left;
  transition:background .15s ease,border-color .15s ease,transform .1s ease}
.tb-acc:hover{background:rgba(255,255,255,.1);border-color:rgba(139,92,246,.4)}
.tb-acc:active{transform:scale(.97)}
.tb-acc .tb-acc-i{width:24px;height:24px;border-radius:50%;flex:none;display:grid;place-items:center;
  font-size:11px;font-weight:800;color:#fff;background:linear-gradient(135deg,#8b5cf6,#6366f1);overflow:hidden}
.tb-acc .tb-acc-i img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.tb-acc .tb-acc-t{min-width:0;display:flex;flex-direction:column;line-height:1.15}
.tb-acc .tb-acc-t b{font-size:11.5px;font-weight:700;color:#f0f1f7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:150px}
.tb-acc .tb-acc-t span{font-size:9.5px;color:#8b8fa3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:150px}
/* 2.8.1: СТАРТОВИЙ СТАН: сплеш УЖЕ показує великий логотип по центру екрана —
   дублювати лого в панелі НЕ треба. У панелі тільки кнопки вікна справа,
   вкладок і акаунта немає */
body.booting .tb-seg,body.booting .tb-acc{opacity:0;visibility:hidden;pointer-events:none}
body.booting .tb-l{display:none}
body.booting #tbar{justify-content:flex-end}   /* кнопки вікна лишаються справа */
.tb-seg,.tb-acc{transition:opacity .3s ease,visibility .3s ease}
/* 2.8.8: ФІКС «вкладки ще висять після виходу» — transition на visibility
   малював вкладки ще ~0.3 с після кліку «Вийти». На гейті перемикання
   миттєве, без плавного зникнення */
body.gate-on .tb-seg,body.gate-on .tb-acc{transition:none;opacity:0;visibility:hidden;pointer-events:none}
/* 2.8.8: ФІКС «лого і назва зникають при виході»: після fh:logout хост
   перезбирає ui.html і сторінка стартує з body.booting (лого сховано).
   Якщо аккаунта немає (gate-on уже в HTML із першого кадру) — лого в
   панелі видно ВІДРАЗУ і він не зникає ні на один кадр */
body.booting.gate-on .tb-l{display:flex}
body.booting.gate-on #tbar{justify-content:space-between}
body.booting.gate-on .tb-seg,body.booting.gate-on .tb-acc{opacity:0;visibility:hidden;pointer-events:none}
/* на ПК титульна панель — ЗАВЖДИ найвища: згорнути/закрити/лого/назва видно
   навіть поверх екранів оновлення і «немає з'єднання» (модалка нижче панелі).
   2.8.1: z 400 — запас понад будь-які оверлеї (гейт 230, модалки 118/120) */
body.upd-lock #tbar,body.net-lock #tbar{z-index:400;background:transparent}
body.upd-lock .tb-seg{visibility:hidden}
body.upd-lock .tb-ver,body.net-lock .tb-ver{visibility:hidden}
body.upd-lock #upd{top:50px}
body.net-lock #neterr{top:50px}

/* перемикач вкладок у ЦЕНТРІ титульної панелі: Розклад | Налаштування.
   Кожна кнопка з іконкою (календар / шестерня). Окрема кнопка
   «Налаштування» біля «Згорнути» більше не потрібна */
.tb-seg{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;gap:3px;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:11px;padding:3px;
  box-shadow:0 6px 18px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.06);
  app-region:no-drag;-webkit-app-region:no-drag}
.tb-seg button{display:inline-flex;align-items:center;gap:7px;border:0;background:transparent;color:#9aa0b4;
  font-family:inherit;font-size:11.5px;font-weight:800;padding:5px 17px;border-radius:8px;cursor:pointer;
  transition:all .15s ease;letter-spacing:.2px;white-space:nowrap}
.tb-seg button svg{flex:none;opacity:.85;transition:opacity .15s ease,transform .2s ease}
.tb-seg button:hover{color:#e0e2f0;background:rgba(255,255,255,.06)}
.tb-seg button:hover svg{opacity:1;transform:rotate(-6deg) scale(1.08)}
.tb-seg button.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;box-shadow:0 4px 14px rgba(99,102,241,.4)}
.tb-seg button.on svg{opacity:1}
.tb-seg button:active{transform:scale(.96)}

/* ---------- головний екран ---------- */
.view{flex:1;min-height:0;display:flex;flex-direction:column;padding:16px 20px 14px;position:relative;z-index:1}
.view:not(.hidden){animation:viewIn .32s ease both}
@keyframes viewIn{from{opacity:0;transform:translateY(9px)}to{opacity:1;transform:none}}
header{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:11px;gap:10px}
.hd-row{display:flex;align-items:center;gap:10px;min-width:0}
.hd-ic{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;color:#fff;flex:none;
  background:linear-gradient(135deg,#8b5cf6,#6366f1);
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.16),0 6px 16px rgba(99,102,241,.35)}
h2{font-size:21px;font-weight:800;letter-spacing:.3px}
.chip{font-size:11.5px;color:#c7cbe0;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  padding:6px 12px;border-radius:999px;white-space:nowrap;display:inline-flex;align-items:center;gap:7px}
.chip svg{opacity:.75;flex:none}

nav{display:flex;gap:8px;margin-bottom:11px}
.tab{flex:1;display:flex;flex-direction:column;align-items:center;gap:1px;padding:7px 4px;border-radius:12px;
  cursor:pointer;user-select:none;-webkit-user-select:none;position:relative;
  background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07);transition:all .18s ease}
.tab .d{font-size:13px;font-weight:700}
.tab .dt{font-size:10px;color:#8b8fa3}
.tab:hover{transform:translateY(-1px);border-color:rgba(139,92,246,.35);background:rgba(255,255,255,.05)}
.tab:active{transform:scale(.97)}
.tab.on{background:linear-gradient(135deg,#8b5cf6,#6366f1,#8b5cf6);background-size:220% 100%;border-color:transparent;
  box-shadow:0 8px 22px rgba(99,102,241,.30);animation:tabg 3.4s ease infinite}
@keyframes tabg{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
.tab.on .dt{color:rgba(255,255,255,.85)}
.tab .tdot{position:absolute;top:6px;right:8px;width:6px;height:6px;border-radius:50%;background:#818cf8;box-shadow:0 0 8px #818cf8;display:none}
.tab.td .tdot{display:block}

main{flex:1;min-height:0;overflow-y:auto;padding-right:2px}
main::-webkit-scrollbar{width:8px}
main::-webkit-scrollbar-thumb{background:rgba(124,58,237,.35);border-radius:8px}
main::-webkit-scrollbar-thumb:hover{background:rgba(124,58,237,.55)}
main::-webkit-scrollbar-track{background:transparent}

.empty{display:flex;flex-direction:column;align-items:center;gap:10px;padding:60px 0;color:#8b8fa3;font-size:13px}
.empty svg{opacity:.5}

.card{position:relative;display:grid;grid-template-columns:46px minmax(0,1fr) auto;gap:13px;align-items:center;
  padding:13px 15px;border-radius:18px;margin-bottom:10px;cursor:pointer;overflow:hidden;
  background:rgba(255,255,255,.028);border:1px solid rgba(255,255,255,.075);
  transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease;animation:pop .3s ease both}
.card:hover{transform:translateY(-2px);border-color:rgba(139,92,246,.28);box-shadow:0 10px 34px -18px rgba(99,102,241,.5)}
.card:hover .ic{transform:scale(1.07) rotate(-2deg)}
@keyframes pop{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
main.still .card{animation:none!important}
.ic{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;color:#fff;flex:none;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14),0 4px 12px rgba(0,0,0,.3);transition:transform .25s ease}
.ic svg{display:block}
.ic.pic{padding:0;overflow:hidden}
.ic.pic img{width:100%;height:100%;object-fit:cover;display:block}
.mid{min-width:0}
.card h3{font-size:15px;font-weight:700;line-height:1.25;color:#f4f4f8}
.meta{display:flex;align-items:center;gap:11px;margin-top:5px;flex-wrap:wrap}
.tc{display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#9aa0b4;font-weight:600;white-space:nowrap}
.tc svg{opacity:.75;flex:none}
.card,.card *{user-select:none;-webkit-user-select:none;cursor:pointer}

.b-join{display:inline-flex;align-items:center;gap:7px;font-size:12.5px;font-weight:700;color:#fff;
  border:0;border-radius:13px;padding:10px 16px;cursor:pointer;white-space:nowrap;
  background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 8px 22px rgba(99,102,241,.28);transition:all .16s ease}
.b-join:hover{transform:translateY(-1px);filter:brightness(1.14);box-shadow:0 10px 26px rgba(99,102,241,.45)}
.b-join:active{transform:scale(.97)}
.b-join.starting{opacity:.55;pointer-events:none;filter:saturate(.5)}
.b-join.starting span::after{content:'…'}
/* блиск, що пробігає головними кнопками при наведенні */
.b-join,.b-save,.b-groups,.us-btn,.bn-btn{position:relative;overflow:hidden}
.b-join::after,.b-save::after,.b-groups::after,.us-btn::after,.bn-btn::after{content:'';position:absolute;top:0;left:-90%;
  width:55%;height:100%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.30),transparent);
  transform:skewX(-18deg);pointer-events:none}
.b-join:hover::after,.b-save:hover::after,.b-groups:hover::after,.us-btn:hover::after,.bn-btn:hover::after{animation:shine .75s ease}
@keyframes shine{from{left:-90%}to{left:140%}}

/* поточний (зелений) / наступний (жовтий) урок */
.now-chip{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:800;letter-spacing:1px;
  color:#34d399;margin-left:8px;vertical-align:1px}
.now-chip i,.next-chip i{width:6px;height:6px;border-radius:50%;animation:pulse 1.4s infinite}
.now-chip i{background:#34d399}
.next-chip{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:800;letter-spacing:1px;
  color:#fbbf24;margin-left:8px;vertical-align:1px}
.next-chip i{background:#fbbf24}
@keyframes pulse{0%,100%{opacity:1;transform:scale(.85)}50%{opacity:.45;transform:scale(1.12)}}
.card.now{border-color:rgba(52,211,153,.5);box-shadow:0 0 0 1px rgba(52,211,153,.2),0 14px 36px rgba(52,211,153,.09)}
.card.next{border-color:rgba(251,191,36,.5);box-shadow:0 0 0 1px rgba(251,191,36,.18),0 14px 36px rgba(251,191,36,.08)}
.prog{position:absolute;left:0;right:0;bottom:0;height:3px;border-radius:3px 3px 0 0;
  background:linear-gradient(90deg,#34d399,#10b981);box-shadow:0 0 14px rgba(52,211,153,.55)}
.today-dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:#34d399;margin-left:4px;vertical-align:1px;
  box-shadow:0 0 8px rgba(52,211,153,.9);animation:pulse 1.4s infinite}

/* ---------- ЕКРАН НАЛАШТУВАНЬ (ПК) ----------
   Окремий «десктопний» стиль: широкі картки у сітці, сегмент-кнопки
   груп (перемикання на місці, без вікон), рядки як у Windows 11.
   Це НЕ той самий дизайн, що на телефоні (там — великий список і
   шторка знизу). */
#vSetup{display:block;overflow-y:auto;padding:18px 24px 24px}
#vSetup::-webkit-scrollbar{width:8px}
#vSetup::-webkit-scrollbar-thumb{background:rgba(124,58,237,.35);border-radius:8px}
#vSetup::-webkit-scrollbar-track{background:transparent}
.sw-wrap{width:100%;max-width:780px;margin:0 auto}
.sw-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:16px}
.sw-title-row{display:flex;align-items:center;gap:10px}
.sw-title-row h2{font-size:24px}
.sw-sub{display:block;font-size:12px;color:#8b8fa3;margin-top:3px}
.sw-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}
.sw-card{position:relative;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.085);
  border-radius:18px;padding:15px 17px 14px;overflow:hidden;animation:secIn .4s ease both;
  transition:border-color .2s ease,box-shadow .2s ease}
.sw-card:hover{border-color:rgba(139,92,246,.30);box-shadow:0 18px 44px rgba(0,0,0,.35),0 0 34px rgba(99,102,241,.06)}
.sw-card.sw-wide{grid-column:1 / -1}
.sw-grid > .sw-card:nth-child(2){animation-delay:.05s}
.sw-grid > .sw-card:nth-child(3){animation-delay:.1s}
.sw-card::before{content:'';position:absolute;top:0;left:8%;right:8%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(139,92,246,.5),rgba(99,102,241,.5),transparent)}
@keyframes secIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.sw-c-head{display:flex;align-items:center;gap:11px;margin-bottom:12px}
.sw-c-ic{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;color:#fff;flex:none;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14),0 4px 12px rgba(0,0,0,.3)}
.sw-c-ic.grad{background:linear-gradient(135deg,#8b5cf6,#6366f1)}
.sw-c-ic.plain{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:#a5b4fc}
.sw-c-tt{flex:1;min-width:0}
.sw-c-tt b{display:block;font-size:14.5px;font-weight:800;color:#f4f4f8;letter-spacing:.2px}
.sw-c-tt span{display:block;font-size:11px;color:#8b8fa3;margin-top:1px;line-height:1.4}
/* сегмент-перемикач групи (1 | 2) — миттєве застосування */
.seg{display:inline-flex;flex:none;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:11px;padding:3px;gap:3px}
.seg button{border:0;background:transparent;color:#9aa0b4;font-family:inherit;font-size:11.5px;font-weight:800;
  padding:6px 14px;border-radius:8px;cursor:pointer;transition:all .15s ease;white-space:nowrap}
.seg button:hover{color:#e0e2f0;background:rgba(255,255,255,.06)}
.seg button.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;
  box-shadow:0 4px 14px rgba(99,102,241,.4)}
.sw-row{display:flex;align-items:center;gap:12px;padding:9px 10px;border-radius:13px;margin-bottom:7px;
  background:rgba(255,255,255,.028);border:1px solid rgba(255,255,255,.055);transition:all .16s ease}
.sw-row:last-child{margin-bottom:0}
.sw-row:hover{border-color:rgba(139,92,246,.3);background:rgba(255,255,255,.045)}
.sw-row .su-tile{width:34px;height:34px;border-radius:10px}
.sw-gname{flex:1;min-width:0}
.sw-gname b{display:block;font-size:12.5px;font-weight:700;color:#f0f1f7}
.sw-gname span{display:block;font-size:10.5px;color:#8b8fa3;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sum-tch{font-size:11px;color:#9aa0b4;line-height:1.4;margin-top:3px}
.sum-hint{font-size:11.5px;color:#8b8fa3;line-height:1.55;padding:2px 2px 4px}
.b-groups{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin-top:12px;
  font-size:12.5px;font-weight:800;color:#fff;border:0;border-radius:13px;padding:11px;cursor:pointer;
  background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 8px 22px rgba(99,102,241,.32);transition:all .18s ease}
.b-groups:hover{filter:brightness(1.14);transform:translateY(-1px)}
.b-groups:active{transform:scale(.98)}
.setup{width:100%;max-width:600px;background:rgba(255,255,255,.028);border:1px solid rgba(255,255,255,.09);
  border-radius:22px;padding:16px 18px 15px;box-shadow:0 24px 60px rgba(0,0,0,.45),0 0 44px rgba(99,102,241,.07);
  animation:pop .35s ease both;margin:auto;position:relative;overflow:hidden}
.setup::before{content:'';position:absolute;top:0;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(139,92,246,.8),rgba(99,102,241,.8),transparent)}
.su-head{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.su-gear{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,#8b5cf6,#6366f1);
  display:grid;place-items:center;color:#fff;flex:none;box-shadow:0 8px 24px rgba(99,102,241,.35)}
.su-head h2{font-size:18px}
.su-head .su-sub{font-size:11px;color:#8b8fa3;display:block;margin-top:1px}
.su-back{display:inline-flex;align-items:center;gap:7px;padding:9px 15px 9px 12px;border-radius:12px;flex:none;
  border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#e0e2f0;font-size:12.5px;font-weight:800;
  cursor:pointer;transition:all .18s ease}
.su-back:hover{background:linear-gradient(135deg,rgba(139,92,246,.38),rgba(99,102,241,.26));border-color:rgba(129,140,248,.55);
  color:#fff;transform:translateX(-2px);box-shadow:0 6px 18px rgba(99,102,241,.25)}
.su-back:active{transform:scale(.96)}
.su-back svg{flex:none}
/* рядки-налаштування (перемикачі) */
.su-item{display:flex;gap:12px;align-items:center;padding:10px 11px;margin-bottom:8px;border-radius:15px;
  background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);transition:all .18s ease}
.su-item:last-child{margin-bottom:0}
.su-item:hover{border-color:rgba(139,92,246,.35);background:rgba(255,255,255,.055);transform:translateX(3px)}
.su-tile{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;color:#fff;flex:none;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14),0 4px 12px rgba(0,0,0,.3);transition:transform .22s ease}
.su-item:hover .su-tile{transform:scale(1.08) rotate(-3deg)}
.su-tile svg{display:block}
.su-body{flex:1;min-width:0}
.su-name{font-weight:700;font-size:12.5px;margin-bottom:6px}
/* опції вибору групи (майстер груп): два стовпці «група 1 / група 2» */
.su-opts{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.su-opt{position:relative;text-align:left;cursor:pointer;border-radius:13px;padding:8px 30px 8px 30px;
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);color:#c7cbe0;transition:all .16s ease}
.su-opt b{display:block;font-size:11.5px;color:#fff;font-weight:700}
.su-opt span{font-size:10px;color:#8b8fa3;line-height:1.35;display:block;margin-top:2px}
.su-opt:hover{border-color:rgba(139,92,246,.45);background:rgba(255,255,255,.055);transform:translateY(-1px)}
.su-opt.on{background:linear-gradient(135deg,rgba(139,92,246,.32),rgba(99,102,241,.22));border-color:#818cf8;
  box-shadow:0 8px 22px rgba(99,102,241,.28)}
.su-opt.on span{color:#dfe3ff}
.su-opt::before{content:'';position:absolute;left:11px;top:14px;width:9px;height:9px;border-radius:50%;
  border:2px solid rgba(255,255,255,.3);transition:all .15s ease}
.su-opt.on::before{border-color:#c7d2fe;background:#818cf8;box-shadow:0 0 10px rgba(129,140,248,.9)}
.su-opt .ck{position:absolute;right:9px;top:10px;color:#c7d2fe;opacity:0;transform:scale(.5);transition:all .18s ease}
.su-opt.on .ck{opacity:1;transform:scale(1)}
.s-prog{font-size:10px;font-weight:800;letter-spacing:.6px;color:#a5b4fc;background:rgba(99,102,241,.12);
  border:1px solid rgba(99,102,241,.28);padding:3px 11px;border-radius:999px}
.sw-tog-row{display:flex;align-items:center;gap:12px;padding:2px 0}
.sw-tog-row.c-row{margin-top:12px;padding:11px 12px;border-radius:13px;background:rgba(255,255,255,.028);
  border:1px solid rgba(255,255,255,.055);transition:border-color .16s ease}
.sw-tog-row.c-row:hover{border-color:rgba(139,92,246,.3)}
.su-ic2{width:36px;height:36px;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
  display:grid;place-items:center;color:#a5b4fc;flex:none}
.su-body b{display:block;font-size:12.5px;font-weight:700;color:#f0f1f7}
.su-body > span{font-size:10.5px;color:#8b8fa3;display:block;margin-top:2px;line-height:1.4}
/* 2.8.4: СТАРЕ ВИЗНАЧЕННЯ .sw ВИДАЛЕНО — конфліктувало з новим (нижче):
   input:checked давав РАЗОМ left:22px (звідси) і translateX(20px) (звідти),
   через що кружок вилазив за доріжку. Єдине канонічне .sw — у блоці профілю. */
/* слайдер хвилин до уроку (1–15) */
.nslider{margin:11px 0 2px;padding:13px 15px 11px;border-radius:15px;background:rgba(255,255,255,.03);
  border:1px solid rgba(255,255,255,.07)}
.ns-top{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:11px}
.ns-lbl{font-size:11px;color:#8b8fa3;font-weight:700;letter-spacing:.3px}
.ns-val{font-size:14px;font-weight:800;background:linear-gradient(90deg,#a78bfa,#818cf8);
  -webkit-background-clip:text;background-clip:text;color:transparent}
input[type=range]#nMin{-webkit-appearance:none;appearance:none;width:100%;height:6px;border-radius:99px;outline:none;cursor:pointer;
  background:linear-gradient(90deg,#8b5cf6,#6366f1 var(--p,28.6%),rgba(255,255,255,.12) var(--p,28.6%))}
input[type=range]#nMin::-webkit-slider-thumb{-webkit-appearance:none;width:20px;height:20px;border-radius:50%;background:#fff;
  border:3px solid #818cf8;box-shadow:0 0 0 4px rgba(129,140,248,.20),0 4px 14px rgba(99,102,241,.45);
  cursor:pointer;transition:transform .15s ease,box-shadow .2s ease}
input[type=range]#nMin::-webkit-slider-thumb:hover{transform:scale(1.14)}
input[type=range]#nMin::-webkit-slider-thumb:active{transform:scale(1.26);box-shadow:0 0 0 7px rgba(129,140,248,.24),0 4px 18px rgba(99,102,241,.6)}
input[type=range]#nMin::-moz-range-thumb{width:16px;height:16px;border-radius:50%;background:#fff;border:3px solid #818cf8;cursor:pointer}
.ns-scale{display:flex;justify-content:space-between;margin-top:8px;font-size:9.5px;color:#6b6f85;font-weight:700;letter-spacing:.4px}
.su-perm{margin:10px 0 0;padding:8px 14px;font-size:11.5px;font-weight:700;color:#fde68a;background:rgba(245,158,11,.12);
  border:1px solid rgba(245,158,11,.4);border-radius:12px;cursor:pointer;width:100%;text-align:left}
.b-mini{font-size:11px;font-weight:700;color:#c7d2fe;background:rgba(99,102,241,.14);border:1px solid rgba(99,102,241,.35);
  padding:7px 13px;border-radius:10px;cursor:pointer;transition:all .15s ease;display:inline-flex;align-items:center;gap:6px;flex:none}
.b-mini:hover{background:rgba(99,102,241,.28);color:#fff}
.b-save{width:100%;margin-top:3px;font-size:13px;font-weight:800;color:#fff;border:0;border-radius:13px;padding:11px;
  cursor:pointer;background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 8px 22px rgba(99,102,241,.32);transition:all .18s ease}
.b-save:hover:not(:disabled){filter:brightness(1.14);transform:translateY(-1px)}
.b-save:active:not(:disabled){transform:scale(.98)}
.b-save:disabled{opacity:.35;cursor:not-allowed;box-shadow:none}
/* секція режиму розробника */
.sw-card.dev{border-color:rgba(251,191,36,.35);background:linear-gradient(180deg,rgba(251,191,36,.06),rgba(255,255,255,.02))}
.sw-card.dev::before{background:linear-gradient(90deg,transparent,rgba(251,191,36,.6),rgba(245,158,11,.5),transparent)}/* діалог підтвердження режиму розробника (по центру {position:fixed;inset:0;z-index:82;display:flex;align-items:center;justify-content:center;padding:20px}

/* ---------- модальне вікно копіювання (по центру екрана) ---------- */
#mwrap{position:fixed;inset:0;z-index:80;display:flex;align-items:center;justify-content:center;padding:20px}
/* 2.9.1: .mback БЕЗ backdrop-filter — повноекранний блюр під модалками
   просідав до 2 fps на слабких телефонах (той самий урок, що і #agate:
   композитор Chrome/WebView не витягує fullscreen blur). Фон трохи
   щільніший, щоб затемнення виглядало так само. */
.mback{position:absolute;inset:0;background:rgba(3,3,7,.78);
  animation:fdin .18s ease both}
@keyframes fdin{from{opacity:0}to{opacity:1}}
.modal{position:relative;width:min(432px,100%);background:rgba(17,17,26,.97);border:1px solid rgba(255,255,255,.1);
  border-radius:22px;padding:16px;box-shadow:0 30px 90px rgba(0,0,0,.65),0 0 0 1px rgba(99,102,241,.14);
  animation:mup .24s cubic-bezier(.2,.9,.3,1.15) both}
@keyframes mup{from{opacity:0;transform:scale(.9) translateY(16px)}to{opacity:1;transform:none}}
.m-head{display:flex;align-items:center;gap:11px;margin-bottom:13px}
.m-ic{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;color:#fff;flex:none;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.15)}
.m-ic svg{display:block}
.m-head .m-tt{min-width:0}
.m-head b{display:block;font-size:15px;color:#fff;line-height:1.25}
.m-head span{font-size:11px;color:#8b8fa3;display:block;margin-top:2px}
.m-x{margin-left:auto;width:32px;height:32px;border-radius:10px;border:1px solid rgba(255,255,255,.1);
  background:rgba(255,255,255,.04);color:#c8cad8;cursor:pointer;display:grid;place-items:center;transition:all .15s ease;flex:none}
.m-x:hover{background:rgba(255,255,255,.1);color:#fff}
.m-item{display:flex;align-items:center;gap:11px;width:100%;text-align:left;border:1px solid rgba(255,255,255,.09);
  background:rgba(255,255,255,.035);color:#e8eaf2;border-radius:15px;padding:11px 14px;cursor:pointer;
  margin-bottom:8px;transition:all .15s ease}
.m-item:last-child{margin-bottom:0}
.m-item:hover{background:linear-gradient(135deg,rgba(139,92,246,.32),rgba(99,102,241,.24));
  border-color:rgba(129,140,248,.5);transform:translateY(-1px)}
.m-item svg{flex:none;opacity:.8}
.m-item .m-l{min-width:0}
.m-item .m-lbl{font-weight:800;font-size:12.5px;color:#fff;display:block}
.m-item .m-t{font-size:11px;color:#9aa0b4;display:block;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.m-item small{margin-left:auto;font-size:9.5px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;
  color:#a5b4fc;display:inline-flex;align-items:center;gap:5px;flex:none}

/* ---------- модальне вікно налаштування груп ---------- */
#gwrap{position:fixed;inset:0;z-index:80;display:flex;align-items:center;justify-content:center;padding:20px}
.gmodal{width:min(524px,100%)}
.g-rows{max-height:min(56vh,470px);overflow-y:auto;margin:0 -3px;padding:0 3px}
.g-rows::-webkit-scrollbar{width:7px}
.g-rows::-webkit-scrollbar-thumb{background:rgba(124,58,237,.4);border-radius:8px}
.g-rows::-webkit-scrollbar-track{background:transparent}
.g-foot{display:flex;align-items:center;gap:9px;margin-top:13px}
/* підтвердження заходу на урок */
#cwrap{position:fixed;inset:0;z-index:82;display:flex;align-items:center;justify-content:center;padding:20px}
.cmodal{width:min(412px,100%)}
.c-info{display:flex;align-items:center;gap:11px;padding:11px 13px;border-radius:14px;
  background:rgba(139,92,246,.09);border:1px solid rgba(139,92,246,.28)}
.c-info .ci-tile{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;color:#fff;flex:none;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14)}
.c-info .ci-t{min-width:0}
.c-info .ci-t b{display:block;font-size:13.5px;color:#f0f1f7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c-info .ci-t span{display:block;font-size:11px;color:#9aa0b4;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cmodal .b-save{flex:1;padding:11px 16px}

/* ---------- банери на головному екрані (оновлення / сповіщення) ---------- */
.ban{display:flex;align-items:center;gap:11px;margin:0 0 11px;padding:11px 13px;border-radius:16px;
  background:linear-gradient(135deg,rgba(139,92,246,.17),rgba(99,102,241,.10));
  border:1px solid rgba(139,92,246,.42);box-shadow:0 10px 30px rgba(99,102,241,.15)}
.bn-ic{width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,#8b5cf6,#6366f1);
  display:grid;place-items:center;color:#fff;flex:none;box-shadow:0 6px 16px rgba(99,102,241,.35)}
.bn-t{flex:1;min-width:0}
.bn-t b{display:block;font-size:13px;color:#fff}
.bn-t span{display:block;font-size:11px;color:#c7cbe0;margin-top:2px;line-height:1.35}
.bn-btn{font-size:11.5px;font-weight:800;color:#fff;border:0;border-radius:11px;padding:9px 14px;cursor:pointer;
  background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 6px 18px rgba(99,102,241,.35);flex:none;
  white-space:nowrap;transition:all .15s ease}
.bn-btn:hover{filter:brightness(1.14);transform:translateY(-1px)}
.bn-x{width:30px;height:30px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);
  color:#c8cad8;cursor:pointer;display:grid;place-items:center;flex:none;transition:all .15s ease}
.bn-x:hover{background:rgba(255,255,255,.1);color:#fff}

/* ---------- тост ---------- */
/* 2.8.6: тост адаптується до теми через змінні --toast-* (раніше був
   жорстко зашитий зелений на чорному в УСІХ темах). Стандартна —
   фіолетова обводка + темне тло; світла — біле тло + фіолетовий текст;
   Liquid Glass — напівпрозоре скло з blur; кольорові — акцент теми. */
:root{--toast-bg:rgba(24,21,42,.97);--toast-bd:rgba(139,92,246,.55);--toast-tx:#ede9fe;--toast-sh:rgba(0,0,0,.5)}
body[data-theme="light"]{--toast-bg:rgba(255,255,255,.98);--toast-bd:rgba(124,58,237,.45);--toast-tx:#5b21b6;--toast-sh:rgba(28,33,74,.22)}
body[data-theme="glass"]{--toast-bg:rgba(30,26,58,.5);--toast-bd:rgba(167,139,250,.45);--toast-tx:#ede9fe;--toast-sh:rgba(0,0,0,.45)}
#toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(18px);z-index:90;
  background:var(--toast-bg);border:1px solid var(--toast-bd);color:var(--toast-tx);font-size:12.5px;font-weight:700;
  padding:10px 18px;border-radius:999px;box-shadow:0 12px 34px var(--toast-sh);opacity:0;pointer-events:none;
  transition:opacity .2s ease,transform .2s ease,background .3s ease,border-color .3s ease,color .3s ease;max-width:82vw;text-align:center;
  display:inline-flex;align-items:center;gap:8px}
body[data-theme="glass"] #toast{backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
#toast svg{flex:none;opacity:.9}
#toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

/* ---------- екран завантаження (2.8.8: повний редизайн) ----------
   Фон = фіолетовий градієнт, як в основному меню. Вгорі — міні-титулбар
   (маленька іконка + назва зліва, «Згорнути»/«Закрити» справа — працюють
   і під час завантаження). По центру — велика іконка, назва, смуга, %. */
#boot{position:fixed;inset:0;z-index:100;display:flex;flex-direction:column;transition:opacity .5s ease;
  background:
    radial-gradient(620px 420px at 50% -6%, rgba(124,58,237,.22), transparent 62%),
    radial-gradient(700px 500px at 88% 118%, rgba(79,70,229,.16), transparent 66%),
    linear-gradient(180deg,#0b0817 0%,#050508 72%)}
#boot.off{opacity:0;pointer-events:none}
/* міні-титулбар сплеша — такий самий, як у головній програмі */
.bt-tb{height:50px;flex:none;display:flex;align-items:center;justify-content:space-between;
  padding-left:14px;padding-right:7px;user-select:none;-webkit-user-select:none}
.bt-tb-l{display:flex;align-items:center;gap:10px}
.bt-tb-l img{display:block;border-radius:8px;box-shadow:0 4px 14px rgba(99,102,241,.45)}
.bt-tb-l span{font-size:14.5px;font-weight:700;letter-spacing:.3px;color:#fff}
.bt-tb-r{display:flex;align-items:center}
.bt-wbtn{width:34px;height:29px;margin:0 2px;display:grid;place-items:center;background:transparent;
  border:1px solid transparent;border-radius:9px;cursor:pointer;color:#a9adbf;padding:0;font-family:inherit;
  transition:background .15s ease,color .15s ease,border-color .15s ease,transform .1s ease}
.bt-wbtn:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.17);color:#fff}
.bt-wbtn:active{transform:scale(.9)}
.bt-wbtn.bt-x{margin-right:4px}
.bt-wbtn.bt-x:hover{background:rgba(244,63,94,.14);border-color:rgba(244,63,94,.55);color:#fb7185}
/* центральний блок: іконка + назва + смуга + відсотки */
.bt-mid{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:15px}
/* ФІКС «лого з'являється із затримкою»: поки PNG не декодовано — центральний
   блок приховано (фон і титулбар видно, під ними — такий самий GDI-сплеш).
   Щойно іконка готова — іконка/назва/смуга з'являються ОДНОЧАСНО */
#boot.pre .bt-mark,#boot.pre .bt-name,#boot.pre .bt-bar,#boot.pre .bt-pct{opacity:0}
#boot .bt-mark,#boot .bt-name,#boot .bt-bar,#boot .bt-pct{transition:opacity .15s ease}
/* 2.8.8: ВАЖЛИВИЙ ФІКС «іконки немає, з'являється через пару секунд»:
   filter:drop-shadow() на іконці rasterизувався окремим проходом композитора —
   на слабких GPU текст/смуга малювались одразу, а іконка з фільтром «доїжджала»
   пізніше. Тінь прибрано (радіус і так скруглений) — іконка малюється
   РАЗОМ із першим кадром */
.bt-mark img{display:block;border-radius:20px}
.bt-name{font-size:20px;font-weight:800;color:#fff;letter-spacing:.4px}
.bt-bar{width:198px;height:5px;border-radius:99px;background:rgba(255,255,255,.09);overflow:hidden;margin-top:4px}
.bt-bar i{display:block;height:100%;width:0%;border-radius:99px;
  background:linear-gradient(90deg,#8b5cf6,#6366f1);box-shadow:0 0 12px rgba(129,140,248,.85)}
.bt-pct{font-size:10.5px;color:#8b8fa3;font-weight:800;letter-spacing:1.5px}
/* --- 2.8.8: сплеш під тему аккаунта (хост підтягує тему з хмари ще ДО
   показу вікна і підставляє data-theme на <body>) --- */
body[data-theme="light"] #boot{
  background:
    radial-gradient(620px 420px at 50% -6%, rgba(139,92,246,.15), transparent 62%),
    radial-gradient(700px 500px at 88% 118%, rgba(99,102,241,.11), transparent 66%),
    linear-gradient(180deg,#f5f4fc 0%,#eef0f8 72%)}
body[data-theme="light"] #boot .bt-name{color:#1c1f33}
body[data-theme="light"] #boot .bt-tb-l span{color:#23263a}
body[data-theme="light"] .bt-wbtn{color:#3d4257}
body[data-theme="light"] .bt-wbtn:hover{background:rgba(20,24,46,.07);border-color:rgba(20,24,46,.16);color:#15172a}
body[data-theme="light"] .bt-wbtn.bt-x:hover{background:rgba(244,63,94,.1);border-color:rgba(244,63,94,.45);color:#e11d48}
body[data-theme="light"] #boot .bt-bar{background:rgba(20,24,46,.1)}
body[data-theme="light"] #boot .bt-pct{color:#6a7089}
body[data-theme="glass"] #boot{
  background:
    radial-gradient(760px 540px at 6% -10%, rgba(168,85,247,.5), transparent 62%),
    radial-gradient(820px 580px at 96% 4%, rgba(56,189,248,.32), transparent 58%),
    radial-gradient(880px 620px at 50% 118%, rgba(236,72,153,.3), transparent 62%),
    linear-gradient(160deg,#0e0a26 0%,#141033 45%,#1a0f2e 100%)}
body[data-theme="glass"] #boot .bt-name{color:#f2f3fa}
body[data-theme="glass"] #boot .bt-tb-l span{color:#f2f3fa}
body[data-theme="glass"] .bt-wbtn{color:#cfcbe8}
body[data-theme="glass"] .bt-wbtn:hover{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.25);color:#fff}
/* 2.8.1: АНІМАЦІЮ #app ПРИБРАНО (apin). Вона тримала #app у власному
   stacking-context (transform/opacity<1), і поки вона триває — а в WebView2
   вона може ЗАСТРЯГАТИ назавжди, доки вікно під GDI-сплешем — гейт входу
   (z 230, сусід на рівні body) малювався ПОВЕРХ титулбара: кнопки вікна
   зникали, вікно не перетягувалось, кліки по кнопках не працювали. */
.fld{margin-top:9px}
.fld label{display:block;font-size:11px;color:#8b8fa3;font-weight:700;margin:0 0 4px 2px}
.fld input{width:100%;box-sizing:border-box;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:10px;padding:9px 11px;color:#fff;font:inherit;font-size:12.5px;outline:none}
.fld input:focus{border-color:rgba(139,92,246,.55)}
.fld2{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.icon-grid{display:flex;gap:6px;flex-wrap:wrap}
.icon-grid button{width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.05);color:#c9cbe0;cursor:pointer;display:flex;align-items:center;justify-content:center}
.icon-grid button.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);border-color:transparent;color:#fff}
.b-save{padding:12px 22px;border:none;border-radius:12px;font-size:13px;font-weight:800;color:#fff;cursor:pointer;
  font-family:inherit;background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 8px 20px rgba(99,102,241,.3)}
.b-save:disabled{opacity:.5;cursor:default}
.b-mini{padding:12px 18px;border-radius:12px;border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.05);
  color:#c9cbe0;font:inherit;font-size:13px;font-weight:700;cursor:pointer}
.b-mini.danger{border-color:rgba(244,63,94,.35);color:#fda4af;background:rgba(244,63,94,.07)}
.b-mini:hover{background:rgba(255,255,255,.09)}
@keyframes shake{0%,100%{transform:none}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}

/* ---------- блокуючі екрани: оновлення / без інтернету ---------- */
#neterr,#upd{position:fixed;inset:0;z-index:118;background:rgba(3,3,7,.92);
  display:flex;align-items:center;justify-content:center;padding:20px}
#upd{z-index:120;padding:0}
#neterr.hidden,#upd.hidden{display:none}
.us-card{width:500px;max-width:min(94vw,560px);max-height:calc(92vh - 48px);overflow:auto;background:rgba(17,17,28,.97);
  border:1px solid rgba(139,92,246,.28);border-radius:22px;padding:26px 28px 22px;text-align:center;
  box-shadow:0 30px 80px rgba(0,0,0,.6);animation:usin .45s cubic-bezier(.16,1,.3,1) both}
@keyframes usin{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.us-logo img{width:74px;height:74px;border-radius:17px;display:block;margin:0 auto 10px;
  filter:drop-shadow(0 10px 26px rgba(99,102,241,.45))}
/* 2.8.2: на гейті логотип менший — картка входу компактніша за інші екрани */
#agate .us-logo img{width:56px;height:56px;border-radius:14px;margin:0 auto 6px}
#agate .us-chip{padding:3px 10px;margin-bottom:5px;font-size:9.5px}
#neterr h2,#upd h2{font-size:21px;color:#fff;margin:2px 0 5px;letter-spacing:.2px}
#upd h2 b{background:linear-gradient(90deg,#a78bfa,#818cf8);-webkit-background-clip:text;background-clip:text;color:transparent}
.us-chip{display:inline-block;font-size:10px;font-weight:800;letter-spacing:1.6px;text-transform:uppercase;
  color:#c4b5fd;background:rgba(139,92,246,.16);border:1px solid rgba(139,92,246,.35);border-radius:99px;
  padding:4px 12px;margin-bottom:8px}
.us-sub{font-size:12.5px;color:#8b8fa3;margin:0 0 14px;line-height:1.5}
.us-prog{display:none;height:6px;border-radius:99px;background:rgba(255,255,255,.09);overflow:hidden;margin:2px 0 8px}
.us-prog.on{display:block}
.us-prog i{display:block;height:100%;width:0%;border-radius:99px;background:linear-gradient(90deg,#8b5cf6,#6366f1);
  box-shadow:0 0 12px rgba(129,140,248,.85);transition:width .25s ease}
.us-row{display:flex;justify-content:space-between;gap:10px;font-size:11px;color:#8b8fa3;font-weight:700;margin:0 2px 14px;min-height:14px}
.us-btn{width:100%;padding:13px;border:none;border-radius:14px;font-size:14px;font-weight:800;color:#fff;cursor:pointer;
  font-family:inherit;background:linear-gradient(135deg,#8b5cf6,#6366f1);
  box-shadow:0 10px 26px rgba(99,102,241,.35);transition:transform .15s ease,box-shadow .2s ease,opacity .2s}
.us-btn:hover{transform:translateY(-1px);box-shadow:0 14px 30px rgba(99,102,241,.45)}
.us-btn:disabled{opacity:.55;cursor:default;transform:none}

/* ---------- анімації зміни дня (свайп/клік) ---------- */
#list.slide-l{animation:slideL .28s cubic-bezier(.2,.9,.3,1) both}
#list.slide-r{animation:slideR .28s cubic-bezier(.2,.9,.3,1) both}
@keyframes slideL{from{opacity:0;transform:translateX(28px)}to{opacity:1;transform:none}}
@keyframes slideR{from{opacity:0;transform:translateX(-28px)}to{opacity:1;transform:none}}
.dchg{animation:dchg .32s ease}
@keyframes dchg{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}
}

/* ================================================================
   ТЕМИ ОФОРМЛЕННЯ (2.1.0): standard · light · glass
   ================================================================ */
body[data-theme="light"]{
  color:#23263a;
  background:
    radial-gradient(700px 460px at 10% -12%, rgba(139,92,246,.14), transparent 66%),
    radial-gradient(760px 520px at 92% 114%, rgba(99,102,241,.12), transparent 64%),
    #eef0f8;
}
body[data-theme="light"] #tbar{background:transparent;border-bottom:0}
body[data-theme="light"] #tbar .tb-name{color:#23263a}
body[data-theme="light"] .tb-btn{color:#3d4257;background:transparent;border-color:transparent}
body[data-theme="light"] .tb-btn:hover{background:rgba(20,24,46,.07);border-color:rgba(20,24,46,.16);color:#15172a}
body[data-theme="light"] .tb-seg{background:rgba(20,24,46,.06);border-color:rgba(20,24,46,.1)}
body[data-theme="light"] .tb-seg button{color:#4b5069}
body[data-theme="light"] .tb-seg button:hover{color:#15172a;background:rgba(20,24,46,.06)}
body[data-theme="light"] .tb-seg button.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff}
body[data-theme="light"] .card{background:#ffffff;border:1px solid rgba(20,24,46,.08);
  box-shadow:0 3px 14px rgba(28,33,74,.07)}
body[data-theme="light"] .card:hover{border-color:rgba(124,58,237,.35);box-shadow:0 10px 26px rgba(99,102,241,.16)}
body[data-theme="light"] .card h3{color:#1c1f33}
body[data-theme="light"] .card .meta{color:#6a7089}
body[data-theme="light"] .card .b-join{background:rgba(99,102,241,.1);color:#4f46e5;border:1px solid rgba(99,102,241,.25)}
body[data-theme="light"] .card .b-join:hover{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;border-color:transparent}
body[data-theme="light"] .card.now{background:linear-gradient(135deg,#f4f1ff,#eef2ff);border-color:rgba(124,58,237,.4)}
body[data-theme="light"] .card.next{background:linear-gradient(135deg,#fffbeb,#fef3c7);border-color:rgba(217,119,6,.35)}
body[data-theme="light"] .tab{background:rgba(20,24,46,.05);border-color:rgba(20,24,46,.1);color:#4b5069}
body[data-theme="light"] .tab.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);border-color:transparent;color:#fff}
body[data-theme="light"] header h2{color:#1c1f33}
body[data-theme="light"] .chip{background:rgba(20,24,46,.06);color:#4b5069;border:1px solid rgba(20,24,46,.09)}
body[data-theme="light"] .empty{color:#6a7089}body[data-theme="light"] #vSetup {color:#23263a}
body[data-theme="light"] .sw-sub,body[data-theme="light"] .sw-c-tt span{color:#6a7089}
body[data-theme="light"] .sw-c-tt b,body[data-theme="light"] .su-body b{color:#1c1f33}
body[data-theme="light"] .sw-card{background:#ffffff;border:1px solid rgba(20,24,46,.1);
  box-shadow:0 10px 30px rgba(28,33,74,.09)}
body[data-theme="light"] .modal{background:#ffffff;border:1px solid rgba(20,24,46,.12);
  box-shadow:0 24px 70px rgba(28,33,74,.25)}
body[data-theme="light"] .m-head b{color:#1c1f33}
body[data-theme="light"] .m-head span,body[data-theme="light"] .m-item .m-t{color:#6a7089}
body[data-theme="light"] .m-item{background:rgba(20,24,46,.04);border-color:rgba(20,24,46,.1);color:#23263a}
body[data-theme="light"] .m-item .m-lbl{color:#1c1f33}
body[data-theme="light"] .m-item small{color:#4f46e5}
body[data-theme="light"] .mback{background:rgba(28,33,74,.4)}
body[data-theme="light"] .sum-hint{color:#5b6172}
body[data-theme="light"] .ms-row{background:rgba(20,24,46,.04);color:#23263a}
body[data-theme="light"] .ms-row b{color:#1c1f33}
/* десктопні рядки груп (.sw-row/.sw-gname) у світлій темі */
body[data-theme="light"] .sw-row{background:rgba(20,24,46,.03);border:1px solid rgba(20,24,46,.07)}
body[data-theme="light"] .sw-row:hover{background:rgba(20,24,46,.055);border-color:rgba(124,58,237,.3)}
body[data-theme="light"] .sw-gname b{color:#1c1f33}
body[data-theme="light"] .sw-gname span,body[data-theme="light"] .sum-tch{color:#6a7089}
body[data-theme="light"] .seg button{color:#5b6172}
body[data-theme="light"] .seg button:hover{color:#15172a;background:rgba(20,24,46,.07)}
body[data-theme="light"] .ms-badge{background:rgba(99,102,241,.1);color:#4f46e5;border-color:rgba(99,102,241,.3)}
body[data-theme="light"] .su-opt{background:rgba(20,24,46,.04);border-color:rgba(20,24,46,.1);color:#3d4257}
body[data-theme="light"] .su-opt b{color:#1c1f33}
body[data-theme="light"] .su-opt.on{background:linear-gradient(135deg,rgba(139,92,246,.18),rgba(99,102,241,.12));
  border-color:rgba(99,102,241,.5)}
/* 2.8.8: стилі сплеша для світлої теми перенесено вгору, до решти #boot */
body[data-theme="light"] #neterr,body[data-theme="light"] #upd{background:rgba(238,240,248,.88)}
body[data-theme="light"] .us-card{background:#ffffff;border-color:rgba(124,58,237,.3)}
body[data-theme="light"] #neterr h2,body[data-theme="light"] #upd h2{color:#1c1f33}
body[data-theme="light"] .us-sub,body[data-theme="light"] #uStat{color:#5b6172}
body[data-theme="light"] .us-chip{color:#6d28d9;background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.35)}
body[data-theme="light"] .fld input {background:#f3f4f9;border:1px solid rgba(20,24,46,.14);color:#1c1f33}body[data-theme="light"] .fld label {color:#6a7089}
body[data-theme="light"] .b-mini{background:rgba(99,102,241,.08);border-color:rgba(99,102,241,.3);color:#4f46e5}
body[data-theme="light"] .c-info{background:rgba(99,102,241,.07);border-color:rgba(99,102,241,.25)}
body[data-theme="light"] .c-info .ci-t b{color:#1c1f33}
body[data-theme="light"] .c-info .ci-t span{color:#6a7089}
body[data-theme="light"] ::-webkit-scrollbar-thumb{background:rgba(99,102,241,.4)}

/* ---- ДОПОВНЕННЯ 2.2.0: перемикачі/контраст у світлій темі ---- */
body[data-theme="light"] .sw i{background:rgba(20,24,46,.16);border-color:rgba(20,24,46,.2);
  box-shadow:inset 0 1px 3px rgba(20,24,46,.12)}
body[data-theme="light"] .sw i::after{background:#ffffff;box-shadow:0 2px 6px rgba(20,24,46,.35)}
body[data-theme="light"] .sw input:checked + i{background:linear-gradient(135deg,#8b5cf6,#6366f1);
  border-color:transparent;box-shadow:0 4px 14px rgba(99,102,241,.4)}
body[data-theme="light"] .sw input:checked + i::after{background:#fff;box-shadow:0 2px 6px rgba(76,29,149,.35)}
body[data-theme="light"] .ms-lbl{color:#5f6579}
/* ==== 2.8.6: СВІТЛА ТЕМА — профіль, розробник, службові тексти ====
   Раніше більшість сірих підписів залишались «темними» (#8b8fa3/#9aa0b4)
   і на світлому тлі ставали майже невидимими. Тут — повний набір
   переозначень для вкладки профілю (acc-*), службових карток (ms-*),
   вкладки розробника (dv-*) і кнопок назад. */
body[data-theme="light"] .back-btn{background:rgba(20,24,46,.05);border-color:rgba(20,24,46,.14);color:#3d4257}
body[data-theme="light"] .back-btn:hover{background:rgba(20,24,46,.1);color:#15172a}
body[data-theme="light"] .acc-hero-card{background:linear-gradient(165deg,rgba(124,58,237,.88),rgba(99,102,241,.72) 52%,rgba(79,70,229,.6));border-color:rgba(124,58,237,.5)}
body[data-theme="light"] .acc-hero-card::before{background:radial-gradient(closest-side,rgba(255,255,255,.35),transparent)}
body[data-theme="light"] .acc-id b{color:#fff}
body[data-theme="light"] .acc-mail{color:rgba(255,255,255,.82)}
body[data-theme="light"] .ms-body > span{color:#6a7089}
body[data-theme="light"] .ms-card{background:rgba(20,24,46,.035);border-color:rgba(20,24,46,.1)}
body[data-theme="light"] .ms-row + .ms-row::before{background:rgba(20,24,46,.08)}
body[data-theme="light"] .ms-lbl::after{background:linear-gradient(90deg,rgba(20,24,46,.18),transparent)}
body[data-theme="light"] .ac-note{color:#5b6172}
body[data-theme="light"] .dv-v{color:#1c1f33}
body[data-theme="light"] .dv-cur{color:#6a7089}
body[data-theme="light"] .dv-row{border-bottom-color:rgba(20,24,46,.09)}
body[data-theme="light"] .dv-row span.dv-chip.rel{color:#1d4ed8}
body[data-theme="light"] .dv-row span.dv-chip.bet{color:#b45309}
body[data-theme="light"] .sw-about{background:rgba(20,24,46,.04);border-color:rgba(20,24,46,.1)}
/* 2.8.6: «Вийти з акаунта» — колір через клас (світла тема: темніший червоний) */
.danger-t{color:#fda4af}
body[data-theme="light"] .danger-t{color:#dc2626}
body[data-theme="light"] .ac-role.r-user{color:#fff;background:rgba(255,255,255,.16);border-color:rgba(255,255,255,.42)}
body[data-theme="light"] .ac-role.r-admin{color:#fff;background:rgba(255,255,255,.16);border-color:rgba(255,255,255,.42)}
body[data-theme="light"] .ac-role.r-developer{color:#fde68a;background:rgba(255,255,255,.14);border-color:rgba(253,230,138,.5)}
body[data-theme="light"] .tb-acc{background:rgba(20,24,46,.05);border-color:rgba(20,24,46,.12)}
body[data-theme="light"] .tb-acc .tb-acc-t b{color:#1c1f33}
body[data-theme="light"] .tb-acc .tb-acc-t span{color:#6a7089}
body[data-theme="light"] .tab .dt{color:#5f6579}
body[data-theme="light"] .bn-t span{color:#4b5069}
body[data-theme="light"] .chip{color:#4b5069;background:rgba(20,24,46,.06);border-color:rgba(20,24,46,.12)}
body[data-theme="light"] .su-perm{color:#92400e;background:rgba(245,158,11,.14);border-color:rgba(180,83,9,.35)}

/* ---------- LIQUID GLASS — 2.8.5 ОПТИМІЗОВАНО ДЛЯ СЛАБКИХ ПК ----------
   Чому лагало: backdrop-filter стояв на КОЖНІЙ картці уроку (25 шт.), кожній
   вкладці дня й дрібних елементах. Композитор перераховує всі блюри на КОЖЕН
   кадр (скрол, поява, hover, анімація .tab.on tabg 3.4s infinite) — старий
   iGPU не витягує. За картками уроків лише СТАТИЧНИЙ градієнт, тож блюр там
   візуально нічого не дає: знімаємо блюр, трохи піднімаємо тінт — вигляд той
   самий. Блюр лишається ТІЛЬКИ де під ним справжній контент (модалки/тости).
   Для дуже слабких машин watchdog вмикає body.lite-glass — мінус і ці блюри. */
body[data-theme="glass"]{
  color:#f2f3fa;
  background:
    radial-gradient(760px 540px at 6% -10%, rgba(168,85,247,.5), transparent 62%),
    radial-gradient(820px 580px at 96% 4%, rgba(56,189,248,.32), transparent 58%),
    radial-gradient(880px 620px at 50% 118%, rgba(236,72,153,.3), transparent 62%),
    linear-gradient(160deg,#0e0a26 0%,#141033 45%,#1a0f2e 100%);
  background-attachment:fixed;
}
body[data-theme="glass"] #tbar{background:transparent;border-bottom:0;backdrop-filter:none;-webkit-backdrop-filter:none}
body[data-theme="glass"] .tb-seg{background:rgba(255,255,255,.09);border-color:rgba(255,255,255,.18)}
body[data-theme="glass"] .card{background:rgba(255,255,255,.10);
  border:1px solid rgba(255,255,255,.17);
  box-shadow:0 10px 34px rgba(10,6,40,.4),inset 0 1px 0 rgba(255,255,255,.22)}
body[data-theme="glass"] .card.now{background:linear-gradient(135deg,rgba(139,92,246,.34),rgba(99,102,241,.18));
  border-color:rgba(196,181,253,.5)}
body[data-theme="glass"] .tab{background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.16)}
body[data-theme="glass"] .tab.on{background:linear-gradient(135deg,rgba(139,92,246,.65),rgba(99,102,241,.6));
  border-color:rgba(255,255,255,.35);animation:none}   /* tabg 3.4s infinite на склі = 60fps repaint -> вимкнено */
body[data-theme="glass"] .sw-card{background:rgba(255,255,255,.11);
  border:1px solid rgba(255,255,255,.2);
  box-shadow:0 24px 70px rgba(5,3,24,.5),inset 0 1px 0 rgba(255,255,255,.22)}
body[data-theme="glass"] .modal{background:rgba(24,20,52,.74);backdrop-filter:blur(16px) saturate(1.7);
  -webkit-backdrop-filter:blur(16px) saturate(1.7);border:1px solid rgba(255,255,255,.22);
  box-shadow:0 30px 90px rgba(5,3,24,.6),inset 0 1px 0 rgba(255,255,255,.25)}
body[data-theme="glass"] .mback{background:rgba(10,6,34,.72)}/* 2.9.1: без блюру — лагало на слабких телефонах */body[data-theme="glass"] .su-opt,body[data-theme="glass"] .m-item,body[data-theme="glass"] .ms-row,
body[data-theme="glass"] .c-info {background:rgba(255,255,255,.11);
  border:1px solid rgba(255,255,255,.16)}
body[data-theme="glass"] .su-opt.on{background:linear-gradient(135deg,rgba(139,92,246,.5),rgba(99,102,241,.4));
  border-color:rgba(196,181,253,.6)}
body[data-theme="glass"] .m-item:hover{background:linear-gradient(135deg,rgba(139,92,246,.4),rgba(99,102,241,.3))}body[data-theme="glass"] .fld input {background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.2)}
body[data-theme="glass"] .us-card{background:rgba(26,22,54,.76);backdrop-filter:blur(16px) saturate(1.7);
  -webkit-backdrop-filter:blur(16px) saturate(1.7);border:1px solid rgba(255,255,255,.22)}
/* 2.8.6: glass-тост тепер через --toast-* (прозоріше скло + blur) */
body[data-theme="glass"] ::-webkit-scrollbar-thumb{background:rgba(255,255,255,.28)}
/* --- 2.8.5: lite-glass — на слабких GPU знімає блюр модалок/тостів --- */
body.lite-glass[data-theme="glass"] .modal,body.lite-glass[data-theme="glass"] .mback,
body.lite-glass[data-theme="glass"] .us-card{backdrop-filter:none;-webkit-backdrop-filter:none}
body.lite-glass[data-theme="glass"] .modal,body.lite-glass[data-theme="glass"] .us-card{background:rgba(26,22,54,.97)}
body.lite-glass[data-theme="glass"] .mback{background:rgba(8,5,26,.75)}
body.lite-glass .ac-hero-card::before{animation:none!important}
body.lite-glass .now-chip i,body.lite-glass .next-chip i{animation:none!important}

/* ---------- 2.3.9: сегмент-перемикач «Запуск Zoom» ---------- */
.seg-z{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:14px;padding:4px;border-radius:14px;
  background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.09)}
.seg-z-b{display:flex;align-items:center;justify-content:center;gap:8px;padding:11px 8px;border-radius:11px;
  border:1px solid transparent;background:transparent;color:#9aa0b4;cursor:pointer;font-family:inherit;
  transition:background .16s ease,color .16s ease,box-shadow .16s ease}
.seg-z-b svg{flex:none}
.seg-z-b b{font-size:12.5px;font-weight:800;letter-spacing:.2px}
.seg-z-b:hover{color:#e8eaf2;background:rgba(255,255,255,.06)}
.seg-z-b.on{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;box-shadow:0 6px 18px rgba(99,102,241,.38)}
body[data-theme="light"] .seg-z{background:rgba(20,24,46,.05);border-color:rgba(20,24,46,.1)}
body[data-theme="light"] .seg-z-b{color:#6a7089}
body[data-theme="light"] .seg-z-b:hover{color:#1c1f33;background:rgba(20,24,46,.06)}
body[data-theme="glass"] .seg-z{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.18)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .seg-z{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.13)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .seg-z-b.on{background:linear-gradient(135deg,var(--ac1),var(--ac2));box-shadow:0 6px 18px var(--acShadow)}
.sw-tog-row.c-row .su-ic2{width:36px;height:36px;border-radius:11px;flex:none;display:grid;place-items:center;
  background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.16),0 6px 16px rgba(99,102,241,.4)}
.sw-tog-row.c-row .su-ic2 svg{stroke:#fff}

/* ---------- вибір теми (2.3.9: витягнуті рядки) ---------- */
.theme-rows{display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px}
.theme-tile{position:relative;text-align:left;border-radius:14px;padding:9px 10px 8px;cursor:pointer;
  border:1.5px solid rgba(255,255,255,.12);background:rgba(255,255,255,.045);transition:all .16s ease;
  color:inherit;font-family:inherit}
.theme-tile .tp{display:block;height:34px;border-radius:9px;margin-bottom:7px;border:1px solid rgba(255,255,255,.14)}
.theme-tile .tp.std{background:linear-gradient(135deg,#0b0b14,#221a3f)}
.theme-tile .tp.lit{background:linear-gradient(135deg,#eef0f8,#dfe3f4)}
.theme-tile .tp.gls{background:linear-gradient(135deg,#2b1a5e,#7c3aed 55%,#38bdf8)}
.theme-tile b{display:block;font-size:11.5px;color:#e8eaf2;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.theme-tile > span:not(.tp){display:block;font-size:9.5px;color:#8b8fa3;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.theme-tile:hover{transform:translateY(-1px);border-color:rgba(129,140,248,.45)}
.theme-tile.on{border-color:#818cf8;background:linear-gradient(135deg,rgba(139,92,246,.3),rgba(99,102,241,.18));
  box-shadow:0 8px 22px rgba(99,102,241,.26)}
.theme-tile.on b{color:#fff}
body[data-theme="light"] .theme-tile{background:#ffffff;border-color:rgba(20,24,46,.1);box-shadow:0 1px 3px rgba(20,24,46,.05)}
body[data-theme="light"] .theme-tile b{color:#1c1f33}
body[data-theme="light"] .theme-tile > span:not(.tp){color:#6a7089}
body[data-theme="light"] .theme-tile.on{border-color:#6366f1;background:linear-gradient(135deg,rgba(139,92,246,.15),rgba(99,102,241,.1))}
body[data-theme="light"] .theme-tile.on b{color:#1c1f33}

/* ---------- 2.3.10: рамка «Про програму» (повернена) ---------- */
.sw-about{display:flex;align-items:center;gap:12px;margin-top:16px;padding:14px 16px;border-radius:20px;
  grid-column:1 / -1;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.1)}
.sw-about .lmark img{display:block;border-radius:11px}
.sw-about .ab-t{flex:1;min-width:0}
.sw-about .ab-t b{display:block;font-size:14px;color:#e8eaf2;letter-spacing:.3px;font-weight:700}
.sw-about .ab-t span{display:block;font-size:11px;color:#8b8fa3;margin-top:2px}
.sw-about .ab-ver{font-size:10px;font-weight:700;letter-spacing:.4px;color:#9aa0b4;flex:none;
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:999px;padding:4px 11px}
body[data-theme="light"] .sw-about{background:#ffffff;border:1px solid rgba(20,24,46,.09)}
body[data-theme="light"] .sw-about .ab-t b{color:#1c1f33}
body[data-theme="light"] .sw-about .ab-t span{color:#6a7089}
body[data-theme="glass"] .sw-about{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.18)}/* ================================================================
   2.2.0 — плюшки авторизації, конфіг хмари, довідка входу {min-width:64px;max-width:64px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ---------- 2.3.6: КОЛЬОРОВІ ТЕМИ НА ПК (Океан / Захід / Ліс / Аврора) ----------
   Ті самі палітри, що й на телефоні. Змінні --ac* задають акцент, спільні
   :is()-правила перефарбовують компоненти вікна — синхронізація теми з
   телефона тепер працює в обидва боки. */
body[data-theme="ocean"]{--ac1:#38bdf8;--ac2:#2563eb;--acT:#7dd3fc;--acSoft:rgba(56,189,248,.17);--acShadow:rgba(37,99,235,.34);
  color:#dfe9f5;
  background:radial-gradient(700px 460px at 10% -12%,rgba(14,165,233,.22),transparent 66%),
             radial-gradient(760px 520px at 92% 114%,rgba(37,99,235,.18),transparent 64%),#030b16}
body[data-theme="sunset"]{--ac1:#fb923c;--ac2:#e11d48;--acT:#fda4af;--acSoft:rgba(251,113,133,.17);--acShadow:rgba(225,29,72,.30);
  color:#f7e4e6;
  background:radial-gradient(700px 460px at 10% -12%,rgba(244,63,94,.19),transparent 66%),
             radial-gradient(760px 520px at 92% 114%,rgba(249,115,22,.17),transparent 64%),#0d0509}
body[data-theme="forest"]{--ac1:#34d399;--ac2:#059669;--acT:#6ee7b7;--acSoft:rgba(52,211,153,.15);--acShadow:rgba(5,150,105,.30);
  color:#ddefe7;
  background:radial-gradient(700px 460px at 10% -12%,rgba(16,185,129,.18),transparent 66%),
             radial-gradient(760px 520px at 92% 114%,rgba(5,150,105,.16),transparent 64%),#03100a}
body[data-theme="aurora"]{--ac1:#2dd4bf;--ac2:#0284c7;--acT:#5eead4;--acSoft:rgba(45,212,191,.16);--acShadow:rgba(2,132,199,.32);
  color:#ddeef0;
  background:radial-gradient(700px 460px at 10% -12%,rgba(20,184,166,.20),transparent 66%),
             radial-gradient(760px 520px at 92% 114%,rgba(14,165,233,.16),transparent 64%),
             radial-gradient(900px 600px at 78% -6%,rgba(45,212,191,.10),transparent 60%),#02100e}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #tbar{background:transparent;border-bottom:0}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #tbar .tb-name{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-btn{color:var(--acT);border-color:transparent;background:transparent}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-btn:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2);color:#fff}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-acc{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.18)}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-acc .ta-n{color:#fff}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-acc .ta-mail,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-head span,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item .m-t{color:rgba(255,255,255,.62)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-seg{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.14)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-seg button{color:var(--acT)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tb-seg button.on{background:linear-gradient(135deg,var(--ac1),var(--ac2));color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.13);box-shadow:0 10px 30px rgba(0,0,0,.32)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card h3{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card .meta{color:rgba(255,255,255,.62)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card .b-join{background:var(--acSoft);color:var(--acT);border:1px solid var(--acSoft)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card .b-join:hover{background:linear-gradient(135deg,var(--ac1),var(--ac2));color:#fff;border-color:transparent}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card.now{background:var(--acSoft);border-color:var(--ac1)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .card.next{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.18)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tab{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.13);color:var(--acT)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .tab.on{background:linear-gradient(135deg,var(--ac1),var(--ac2));border-color:transparent;color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) header h2{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .chip{background:rgba(255,255,255,.06);color:var(--acT);border:1px solid rgba(255,255,255,.12)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .empty,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .empty{color:rgba(255,255,255,.55)}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #vSetup,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #vSetup,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #vSetup,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) #vDev{color:#e6ecf5}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .sw-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.13);box-shadow:0 18px 50px rgba(0,0,0,.38)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .sw-c-tt b,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-body b{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .sw-c-tt span,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .sw-sub{color:rgba(255,255,255,.6)}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .ms-row,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .c-info,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .ms-row,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .c-info,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .ms-row,:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .c-info,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .dv-acc{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt.on{background:var(--acSoft);border-color:var(--ac1)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt.on b,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .su-opt.on span{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item:hover{background:var(--acSoft)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .modal{background:#0b101c;border:1px solid rgba(255,255,255,.15);box-shadow:0 30px 90px rgba(0,0,0,.6),0 0 0 1px var(--acSoft)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .mback{background:rgba(2,6,12,.62)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-head b{color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-head span,
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .m-item .m-t{color:rgba(255,255,255,.62)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .b-save{background:linear-gradient(135deg,var(--ac1),var(--ac2));border-color:transparent;color:#fff}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .theme-tile.on{border-color:var(--ac1);background:var(--acSoft)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .us-card{background:#0b101c;border:1px solid rgba(255,255,255,.14);box-shadow:0 30px 90px rgba(0,0,0,.6)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .us-btn{background:linear-gradient(135deg,var(--ac1),var(--ac2))}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]){--toast-bg:rgba(8,12,22,.97);--toast-bd:var(--ac1);--toast-tx:var(--acT)}
:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .theme-tile b{color:#fff}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .a-perk{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.13)}:is(body[data-theme="ocean"],body[data-theme="sunset"],body[data-theme="forest"],body[data-theme="aurora"]) .a-perk b{color:#fff}
/* плитки-мініатюри нових тем */
.theme-tile .tp.oce{background:linear-gradient(135deg,#03102a,#0e3a6e 60%,#38bdf8)}
.theme-tile .tp.sun{background:linear-gradient(135deg,#1c060c,#7a1024 55%,#fb923c)}
.theme-tile .tp.for{background:linear-gradient(135deg,#02110a,#065f46 55%,#34d399)}
.theme-tile .tp.aur{background:linear-gradient(135deg,#02100e,#0b4a5e 50%,#2dd4bf)}
body[data-theme="light"] .theme-tile .tp.oce,body[data-theme="light"] .theme-tile .tp.sun,
body[data-theme="light"] .theme-tile .tp.for,body[data-theme="light"] .theme-tile .tp.aur{border-color:rgba(20,24,46,.2)}
/* ===== 2.7.2: гейт входу, акаунт, вкладка розробника ===== */
.spin{display:inline-block;width:11px;height:11px;border:2px solid rgba(196,181,253,.35);border-top-color:#c4b5fd;border-radius:50%;vertical-align:-2px;margin-right:6px;animation:fhsp .8s linear infinite}
@keyframes fhsp{to{transform:rotate(360deg)}}
/* 2.8.1: КРИТИЧНЕ — БЕЗ backdrop-filter на #agate! Через нього композитор
   Chrome/WebView2 «підіймав» гейт ПОВЕРХ титулбара (z-index ігнорувався):
   після показу розкладу кнопки вікна і перетягування зникали — саме це
   бачив власник на екрані входу. Фон майже непрозорий — блюр і не видно. */
#agate{position:fixed;inset:0;z-index:230;background:radial-gradient(120% 90% at 50% 0%,rgba(72,58,148,.45),transparent 55%),rgba(7,7,13,.985);display:flex;align-items:center;justify-content:center;padding:20px;overflow:auto}
#agate.hidden{display:none}
body.gate-on .tb-seg{visibility:hidden}   /* 2.7.3: вкладок взагалі немає, доки немає входу */
/* 2.8.2: на екрані входу панель ПОВНОЦІННА — іконка + назва зліва, кнопки
   вікна справа (як просив власник). Вкладки/версію/акаунт ховаємо */
body.gate-on #tbar{position:relative;z-index:400;background:transparent;border-bottom-color:transparent}
body.gate-on .tb-ver{visibility:hidden}
body.gate-on .tb-acc{visibility:hidden}
/* ===== 2.8.2: ГЕЙТ ВХОДУ — ЩЕ КОМПАКТНІШИЙ =====
   Прибрано зайві повітряні відступи: щільніша картка, менший логотип,
   коротші проміжки між блоками — рамка помітно нижча за 2.8.1 */
.ag-card{position:relative;width:100%;max-width:352px;text-align:center;background:linear-gradient(180deg,rgba(30,31,52,.98),rgba(19,20,36,.98));border:1px solid rgba(139,92,246,.3);border-radius:22px;padding:18px 20px 12px;box-shadow:0 32px 90px rgba(0,0,0,.66),0 16px 44px rgba(99,102,241,.18);animation:usin .45s cubic-bezier(.16,1,.3,1) both;overflow:hidden}
.ag-card::before{content:'';position:absolute;inset:0;border-radius:22px;padding:1px;background:linear-gradient(135deg,rgba(167,139,250,.5),rgba(129,140,248,.05) 35%,rgba(129,140,248,.05) 65%,rgba(167,139,250,.35));-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none}
.ag-glow{position:absolute;top:-64px;left:50%;transform:translateX(-50%);width:220px;height:100px;background:radial-gradient(closest-side,rgba(139,92,246,.35),transparent);pointer-events:none}
.ag-card h2{font-size:17px;color:#fff;margin:8px 0 4px;letter-spacing:.2px}
.ag-sub{font-size:11.5px;color:#9aa0b4;line-height:1.45;margin:0 4px 10px}
.ag-mini{display:flex;justify-content:center;gap:6px;margin:0 0 12px;flex-wrap:wrap}
.ag-mini span{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;color:#a7abc2;background:rgba(148,163,184,.07);border:1px solid rgba(148,163,184,.13);border-radius:99px;padding:4.5px 10px}
.ag-mini span svg{opacity:.8;flex:none}
/* 2.7.5: біла кнопка Google — офіційний логотип G, чорний текст, як на справжніх
   сайтах Google (власник: «біла кнопка, іконка Google і чорний текст») */
.ag-go{width:100%;justify-content:center;display:flex;align-items:center;gap:10px;height:43px;border-radius:13px;font-size:13.5px;font-weight:700;letter-spacing:.1px;background:#fff;box-shadow:0 10px 26px rgba(0,0,0,.45),0 1px 0 rgba(255,255,255,.25) inset;border:0;color:#1f2937;transition:transform .12s ease,box-shadow .2s ease}
.ag-go:hover{transform:translateY(-1px);box-shadow:0 14px 32px rgba(0,0,0,.5),0 1px 0 rgba(255,255,255,.25) inset}
.ag-go:active{transform:scale(.985)}
.ag-go:disabled{opacity:.62;cursor:default;transform:none;filter:none}
.ag-go svg{flex:none}
.ag-stat{min-height:16px;font-size:11.5px;color:#9aa0b4;margin-top:8px;line-height:1.45}
.ag-stat.err{color:#fda4af}
.ag-foot{font-size:10px;color:#6b7086;margin-top:7px;letter-spacing:.3px}
.tb-ava{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:12px;font-weight:800;color:#fff;background:linear-gradient(135deg,#8b5cf6,#6366f1);overflow:hidden}
.tb-ava img{width:100%;height:100%;object-fit:cover;border-radius:50%}
/* ==== 2.8.3: ПРОФІЛЬ — новий дизайн (герой-картка, сірі сегменти) ==== */
/* 2.8.6: у профілі вкладки виглядають ЦІЛКОМ ЗВИЧАЙНО — правило
   body[data-view="acc"] .tb-seg button.on ВИДАЛЕНО. Воно мало вищу
   специфічність за :hover, тому «Розклад» (який залишався .on) не
   підсвічувався при наведенні, і жорстко зашивало колір #9aa0b4 —
   він не змінювався зі темою (у світлій темі текст бив «сірішим»).
   Тепер showAcc() сам знімає .on (setSeg('acc')) — обидві кнопки
   мають звичайний колір теми, обидві підсвічуються при наведенні. */
#vAcc{display:block;overflow:auto;padding:22px 26px 30px}
.acc-wrap{max-width:480px;margin:0 auto}
.back-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid rgba(148,163,184,.2);background:rgba(148,163,184,.07);color:#c9cddb;border-radius:12px;padding:8px 15px;font-size:12.5px;font-weight:700;cursor:pointer;margin-bottom:16px;font-family:inherit;transition:background .18s ease,color .18s ease,transform .12s ease;animation:accIn .4s cubic-bezier(.16,1,.3,1) both}
.back-btn:hover{background:rgba(148,163,184,.14);color:#fff}
.back-btn:active{transform:scale(.96)}
.acc-hero-card{position:relative;overflow:hidden;border-radius:24px;padding:28px 20px 22px;text-align:center;margin:0 0 16px;
  background:linear-gradient(165deg,rgba(124,58,237,.30),rgba(99,102,241,.16) 52%,rgba(255,255,255,.045));
  border:1px solid rgba(148,163,184,.17);animation:accIn .55s cubic-bezier(.16,1,.3,1) both}
.acc-hero-card::before{content:'';position:absolute;top:-90px;left:50%;transform:translateX(-50%);width:300px;height:160px;border-radius:50%;
  background:radial-gradient(closest-side,rgba(139,92,246,.45),transparent);filter:blur(8px);pointer-events:none;animation:acGlow 6s ease-in-out infinite alternate}
@keyframes acGlow{from{opacity:.6;transform:translateX(-50%) scale(1)}to{opacity:1;transform:translateX(-50%) scale(1.14)}}
@keyframes accIn{from{opacity:0;transform:translateY(16px) scale(.98)}to{opacity:1;transform:none}}
.acc-hero-card .acc-ava-big{width:82px;height:82px;font-size:32px;margin:0 auto}
.acc-ava-big{width:62px;height:62px;border-radius:50%;flex:none;display:grid;place-items:center;font-size:26px;font-weight:800;color:#fff;background:linear-gradient(135deg,#8b5cf6,#6366f1);overflow:hidden;box-shadow:0 12px 32px rgba(99,102,241,.45),0 0 0 3px rgba(139,92,246,.28)}
.acc-ava-big img{width:100%;height:100%;object-fit:cover}
.acc-id{margin-top:13px}
.acc-id b{display:block;font-size:19px;color:#fff;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.acc-mail{display:block;font-size:12.5px;color:#b3b8cc;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ac-role{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.8px;text-transform:uppercase;padding:4.5px 12px;border-radius:99px;border:1px solid;margin-top:11px}
.ac-role.r-user{color:#a7abc2;background:rgba(148,163,184,.1);border-color:rgba(148,163,184,.35)}
.ac-role.r-admin{color:#c4b5fd;background:rgba(139,92,246,.12);border-color:rgba(139,92,246,.45)}
.ac-role.r-developer{color:#fde68a;background:rgba(245,158,11,.12);border-color:rgba(245,158,11,.45)}
.ac-uid{display:inline-flex;align-items:center;gap:6px;max-width:100%;margin:13px auto 0;font-size:10.5px;color:#8b8fa3;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:99px;padding:5px 13px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer;transition:background .18s ease,border-color .18s ease,transform .12s ease;font-family:inherit}
.ac-uid:hover{background:rgba(139,92,246,.14);border-color:rgba(139,92,246,.4)}
.ac-uid:active{transform:scale(.97)}
.ac-uid svg{flex:none;opacity:.75}
.ac-uid b{color:#c7cbe0;font-weight:700;overflow:hidden;text-overflow:ellipsis;max-width:280px}
/* ==== 2.8.4: СЕКЦІЯ «АКАУНТ І СИНХРОНІЗАЦІЯ» — портовано 1:1 з ТЕЛЕФОНА:
   ms-lbl (підпис) + ms-card (картка) + ms-row (рядки з плитками) + ac-note ==== */
#vAcc .ms-sec{animation:accIn .5s cubic-bezier(.16,1,.3,1) both;animation-delay:.08s;margin:2px 0 4px}
.ms-lbl{display:flex;align-items:center;gap:8px;font-size:10.5px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:#8b8fa3;margin:6px 2px 8px}
.ms-lbl::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,rgba(148,163,184,.25),transparent)}
.ms-card{background:rgba(148,163,184,.055);border:1px solid rgba(148,163,184,.13);border-radius:20px;padding:6px;overflow:hidden}
.ms-row{position:relative;display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:14px;transition:background .16s ease,transform .12s ease}
.ms-row:hover{background:rgba(148,163,184,.07)}
.ms-row[role="button"]{cursor:pointer}
.ms-row[role="button"]:active{transform:scale(.985)}
.ms-row + .ms-row::before{content:'';position:absolute;top:-6px;left:54px;right:12px;height:1px;background:rgba(148,163,184,.09)}
.ms-tile{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;color:#fff;flex:none;box-shadow:0 4px 14px rgba(0,0,0,.28)}
.ms-body{min-width:0;flex:1}
.ms-body b{display:block;font-size:13.5px;font-weight:800;color:#f0f1f7;letter-spacing:.2px}
.ms-body > span{display:block;font-size:11px;color:#8b8fa3;margin-top:2px;line-height:1.45}
/* 2.8.4: ЄДИНИЙ канонічний перемикач — фіксована геометрія, пружинна анімація.
   (старе 44x25-визначення видалено: воно давало подвійний зсув кружка) */
.sw{position:relative;flex:none;width:46px;height:26px;cursor:pointer;display:inline-block}
.sw input{position:absolute;opacity:0;left:0;top:0;width:100%;height:100%;margin:0;cursor:pointer;z-index:2}
.sw i{position:absolute;left:0;top:0;right:0;bottom:0;border-radius:99px;background:rgba(148,163,184,.3);transition:background .2s ease,box-shadow .2s ease}
.sw i::after{content:'';position:absolute;top:50%;left:3px;margin-top:-9.5px;width:19px;height:19px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.35);transition:transform .3s cubic-bezier(.34,1.56,.64,1)}
.sw input:checked + i{background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 3px 12px rgba(99,102,241,.4)}
.sw input:checked + i::after{transform:translateX(20px)}
.sw:active input:checked + i::after{transform:translateX(20px) scale(.88)}
.sw:active input:not(:checked) + i::after{transform:scale(.88)}
#vAcc .ac-note{animation:accIn .5s cubic-bezier(.16,1,.3,1) both;animation-delay:.2s}
.ac-note{font-size:11px;color:#7c8199;line-height:1.55;margin-top:10px;padding:0 4px}
#secDev{display:none}
#secDev.show{display:block}
.dv-row{display:flex;align-items:center;gap:10px;padding:9px 2px;border-bottom:1px solid rgba(148,163,184,.09)}
.dv-row:last-child{border-bottom:0}
.dv-v{font-weight:800;font-size:13px;color:#e8eaf2;min-width:64px}
.dv-chip{font-size:9.5px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;padding:3px 8px;border-radius:99px}
.dv-chip.rel{color:#93c5fd;background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.3)}
.dv-chip.bet{color:#fde68a;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3)}
.dv-cur{margin-left:auto;font-size:10.5px;color:#8b8fa3}
.dv-inst{margin-left:auto}
/* ---------- 2.7.6: акаунт у налаштуваннях ---------- */
.ac2-row{display:flex;align-items:center;gap:12px;padding:4px 2px 2px}
.ac2-ava{width:44px;height:44px;border-radius:14px;flex:none;display:grid;place-items:center;
  background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;font-weight:800;font-size:17px;overflow:hidden}
.ac2-ava img{width:100%;height:100%;object-fit:cover;display:block}
.ac2-info{flex:1;min-width:0;text-align:left}
.ac2-info b{display:block;font-size:13.5px;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ac2-info span{display:block;font-size:11.5px;color:#8b8fa3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ac2-go{border:1px solid rgba(139,92,246,.35);background:rgba(139,92,246,.12);color:#c4b5fd;border-radius:11px;
  padding:8px 14px;font-family:inherit;font-size:12px;font-weight:800;cursor:pointer;transition:background .15s ease}
.ac2-go:hover{background:rgba(139,92,246,.22)}
</style>
</head>
<body class="booting" data-theme="__BOOT_THEME__">
<script>
/* тема ДО першого кадру, без спалаху. Пріоритет 2.8.8:
   1) data-theme на <body>, який хост підставив із __BOOT_THEME__ (тема
      цього аккаунта, свіжозавантажена з хмари ще ДО показу вікна);
   2) localStorage (тема з минулого запуску на цьому пристрої);
   3) standard. Обраний варіант пишемо назад у body + localStorage */
try{
  var _t=document.body.getAttribute('data-theme')||'';
  if(['standard','light','glass','ocean','sunset','forest','aurora'].indexOf(_t)<0){
    _t=localStorage.getItem('fh_theme')||'';
    if(['standard','light','glass','ocean','sunset','forest','aurora'].indexOf(_t)<0)_t='standard';
  }
  document.body.setAttribute('data-theme',_t);
  localStorage.setItem('fh_theme',_t);
}catch(e){try{document.body.setAttribute('data-theme','standard')}catch(e2){}}
</script>
<!-- 2.9.0: ТИТУЛЬНУ ПАНЕЛЬ ВИНЕСЕНО З #app (тепер #tbar — безпосередня дитина body).
     Чому: applyScale() ставить CSS zoom на #app, і WebView2 у цьому випадку малює
     #agate (гейт входу) ПОВЕРХ панелі — власник бачив екран входу БЕЗ лого і кнопок.
     Панель поза #app = не масштабується і завжди верхня (z 400 > гейт 230):
     лого + «Згорнути»/«Закрити» — ПІКСЕЛЬ-У-ПІКСЕЛЬ ті самі на всіх екранах
     (сплеш/гейт/меню/помилка мережі/оновлення), як просив власник. -->
<div id="tbar">
  <div class="tb-l">
    <span class="lmark" id="logo" aria-hidden="true"><img src="data:image/png;base64,__LOGO_B64__" width="27" height="27" alt="" decoding="sync" style="display:block;border-radius:8px"></span>
    <span class="tb-name">FluxHelper</span>
  </div>
  <div class="tb-seg" role="tablist">
    <button id="segSched" title="Розклад">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="17" rx="2.5"/><line x1="3" y1="9.5" x2="21" y2="9.5"/><line x1="8" y1="2.5" x2="8" y2="6.5"/><line x1="16" y1="2.5" x2="16" y2="6.5"/><path d="M8 14h3M8 17.5h5"/></svg>
      <span>Розклад</span>
    </button>
    <button id="segSetup" title="Налаштування">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      <span>Налаштування</span>
    </button>
    <button id="segDev" title="Розробник" style="display:none">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
      <span>Розробник</span>
    </button>
  </div>
    <div class="tb-r">
    <button class="tb-acc win-only" id="tbAcc" title="Акаунт" style="display:none" type="button">
      <span class="tb-acc-i" id="tbAccAva"></span>
      <span class="tb-acc-t"><b id="tbAccName">—</b><span id="tbAccMail"></span></span>
    </button>
    <button class="tb-btn win-only" id="bMin" title="Згорнути">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
    </button>
    <button class="tb-btn tb-x win-only" id="bClose" title="Закрити">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
    </button>
  </div>
</div>

<div id="app">

<div id="vMain" class="view">
  <div id="nban" class="ban hidden">
    <div class="bn-ic">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
    </div>
    <div class="bn-t"><b>Сповіщення про початок уроку</b><span>підкажемо завчасно — щоб ти не запізнився</span></div>
    <button class="bn-btn" id="nbOn">Увімкнути</button>
    <button class="bn-x" id="nbX" title="Сховати">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
    </button>
  </div>
  <header>
    <div class="hd-row">
      <div class="hd-ic" aria-hidden="true">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="17" rx="2.5"/><line x1="3" y1="9.5" x2="21" y2="9.5"/><line x1="8" y1="2.5" x2="8" y2="6.5"/><line x1="16" y1="2.5" x2="16" y2="6.5"/></svg>
      </div>
      <h2 id="dayName">Понеділок</h2>
    </div>
    <div class="chip" id="chip"></div>
  </header>
  <nav id="tabs"></nav>
  <main id="list"></main>
</div>

<div id="vSetup" class="view hidden">
  <div class="sw-wrap">
    <div class="sw-head">
      <div class="sw-head-l">
        <div class="sw-title-row">
          <h2>Налаштування</h2>
        </div>
        <span class="sw-sub">групи · сповіщення · запуск Zoom</span>
      </div>
    </div>

    <div class="sw-grid">
      <section class="sw-card sw-wide">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
          <div class="sw-c-tt">
            <b>Мої групи</b>
            <span>твій вчитель і посилання підставляться скрізь одразу</span>
          </div>
        </div>
        <div id="sumRows"></div>
      </section>

      <section class="sw-card">
        <div class="sw-c-head">
          <span class="sw-c-ic plain"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg></span>
          <div class="sw-c-tt"><b>Сповіщення</b><span>нагадаємо до дзвінка</span></div>
        </div>
        <div class="sw-tog-row">
          <div class="su-ic2">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
          </div>
          <div class="su-body">
            <b>Повідомити про початок уроку</b>
            <span>сповіщення Windows з назвою уроку</span>
          </div>
          <label class="sw"><input type="checkbox" id="nOn"><i></i></label>
        </div>
        <div class="nslider hidden" id="nMinRow">
          <div class="ns-top"><span class="ns-lbl">повідомити за</span><span class="ns-val" id="nMinVal">5 хв</span></div>
          <input type="range" id="nMin" min="1" max="15" step="1" value="5" aria-label="Хвилин до уроку">
          <div class="ns-scale"><span>1 хв</span><span>5</span><span>10</span><span>15 хв</span></div>
        </div>
        <div class="sw-tog-row" id="nSndRow">
          <div class="su-ic2">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>
          </div>
          <div class="su-body">
            <b>Звук сповіщень</b>
            <span>мелодія-дзвіночок разом із повідомленням</span>
          </div>
          <label class="sw"><input type="checkbox" id="nSnd"><i></i></label>
        </div>
        <button class="su-perm" id="bTestN" type="button">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:7px;vertical-align:-2px"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>
          Тестове сповіщення
        </button>
        <button class="su-perm hidden" id="bPerm">Надати дозвіл на сповіщення</button>
      </section>

            <!-- 2.3.8: картку «Акаунт і синхронізація» прибрано -->


<section class="sw-card">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg></span>
          <div class="sw-c-tt"><b>Запуск Zoom</b></div>
        </div>
        <div class="seg-z" role="tablist">
          <button class="seg-z-b" id="zApp" type="button">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="5" width="15" height="14" rx="2"/><path d="M16 10l7-3v10l-7-3z"/></svg>
            <b>Додаток</b>
          </button>
          <button class="seg-z-b" id="zWeb" type="button">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            <b>Браузер</b>
          </button>
        </div>
        <div class="sw-tog-row c-row">
          <div class="su-body">
            <b>Підтверджувати захід на урок</b>
          </div>
          <label class="sw"><input type="checkbox" id="cOn"><i></i></label>
        </div>
      </section>

      <section class="sw-card sw-wide">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18z"/></svg></span>
          <div class="sw-c-tt"><b>Тема оформлення</b><span>як виглядає застосунок</span></div>
        </div>
        <div class="theme-rows" id="themeRows">
          <button class="theme-tile" data-t="standard" type="button"><span class="tp std"></span><b>Стандарт</b><span>темна, фірмова</span></button>
          <button class="theme-tile" data-t="light" type="button"><span class="tp lit"></span><b>Світла</b><span>денне світло</span></button>
          <button class="theme-tile" data-t="glass" type="button"><span class="tp gls"></span><b>Liquid Glass</b><span>прозоре скло</span></button>
        </div>
      </section>

      <!-- 2.9.1: ПУСТИЙ КВАДРАТ ПІСЛЯ РАМКИ ТЕМИ ПРИБРАНО — секцію #ac2Card
           (залишок 2.8.0: вміст давно видалено, а секція показувалась після
           входу) знесено повністю -->

      <section class="sw-card sw-wide" id="secUpd">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span>
          <div class="sw-c-tt"><b>Оновлення</b><span>перевірка і встановлення нової версії</span></div>
        </div>
        <div class="sw-tog-row c-row">
          <div class="su-body">
            <b>Перевірити оновлення</b>
            <span>нова версія встановиться прямо в програмі</span>
          </div>
          <button class="b-mini" id="bUpdNow" type="button">Перевірити</button>
        </div>
      </section>

      <!-- 2.3.10: рамка «Про програму» ПОВЕРНЕНА (власник попросив) -->
      <div class="sw-about" id="aboutBox">
        <span class="lmark" id="abLogo" aria-hidden="true"></span>
        <div class="ab-t"><b>FluxHelper</b><span>розклад 8-го Б класу</span></div>
        <span class="ab-ver" id="abVer">версія</span>
      </div>

    </div>

  </div>
</div>

<!-- 2.3.8: СТОРІНКА ПРОФІЛЮ — акаунт + синхронізація + вихід живуть тут,
     у «Налаштуваннях» їх більше немає (власник попросив окрему сторінку) -->

<!-- 2.8.3: сторінка акаунта — профіль + синхронізація. Всередині #app
     (раніше була зовні й ділила екран навпіл із розкладом) -->
<div id="vAcc" class="view hidden">
  <div class="acc-wrap">
    <button class="back-btn" id="accBack" type="button">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      Назад
    </button>
    <div class="acc-hero-card">
      <span class="acc-ava-big" id="acAva">?</span>
      <div class="acc-id">
        <b id="acName">—</b>
        <span class="acc-mail" id="acMail"></span>
      </div>
      <span class="ac-role r-user" id="acRole">—</span>
    </div>
    <div class="ms-sec">
      <div class="ms-lbl"><span>Акаунт і синхронізація</span></div>
      <div class="ms-card">
        <div class="ms-row">
          <div class="ms-body" style="flex:1">
            <b>Синхронізація</b>
            <span>налаштування на сервері й однакові на всіх пристроях. Вимкнена — теж зберігаються (копія), але не підтягуються.</span>
          </div>
          <label class="sw" title="Увімкнути/вимкнути синхронізацію" style="flex:none"><input type="checkbox" id="acSync"><i></i></label>
        </div>
        <!-- 2.8.6: кнопку «Завантажити з хмари» прибрано — налаштування
             підтягуються з акаунта АВТОМАТИЧНО (під час входу і далі
             в реальному часі, див. syncWatch) -->
        <div class="ms-row" id="acOut" role="button" title="Вийти з акаунта Google">
          <span class="ms-tile" style="background:linear-gradient(135deg,#f43f5e,#b91c1c)">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          </span>
          <div class="ms-body"><b class="danger-t">Вийти з акаунта</b><span>вхід буде потрібен знову</span></div>
        </div>
      </div>
      <div class="ac-note" id="accNote">Синхронізуються: групи предметів, сповіщення про уроки, режим Zoom і тема. Розклад завжди спільний для всього класу.</div>
    </div>
  </div>
</div>

<!-- 2.7.3: окрема вкладка «Розробник» — видно лише Адміну/Розробнику ПІСЛЯ входу -->
<div id="vDev" class="view hidden">
  <div class="sw-wrap">
    <div class="sw-head">
      <div class="sw-head-l">
        <div class="sw-title-row"><h2>Розробник</h2></div>
        <span class="sw-sub">бета-оновлення · версії · тест сповіщень</span>
      </div>
    </div>
    <div class="sw-grid">
      <section class="sw-card sw-wide">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span>
          <div class="sw-c-tt"><b>Бета-оновлення</b><span>бети не приходять через авто-оновлення — ставляться звідси вручну</span></div>
        </div>
        <div class="sw-tog-row c-row">
          <div class="su-body"><b>Бета-канал</b><span>пропонувати бета-версії разом із релізними</span></div>
          <label class="sw"><input type="checkbox" id="devBeta"><i></i></label>
        </div>
      </section>
      <section class="sw-card sw-wide">
        <div class="sw-c-head">
          <span class="sw-c-ic grad"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="17" rx="2.5"/><line x1="3" y1="9.5" x2="21" y2="9.5"/><line x1="8" y1="2.5" x2="8" y2="6.5"/><line x1="16" y1="2.5" x2="16" y2="6.5"/></svg></span>
          <div class="sw-c-tt"><b>Встановлення версії</b><span>обери реліз або бету — встановиться прямо в програмі</span></div>
        </div>
        <div class="sw-tog-row c-row">
          <div class="su-body"><b>Список версій</b><span>завантажується з GitHub</span></div>
          <button class="b-mini" id="devRef" type="button">Оновити список</button>
        </div>
        <div id="devVers"></div>
        <div class="sw-tog-row c-row" style="border-top:1px solid rgba(148,163,184,.09);margin-top:4px;padding-top:12px">
          <div class="su-body"><b>Тестове сповіщення</b><span>перевір, як виглядає сповіщення про урок</span></div>
          <button class="b-mini" id="devNotif" type="button">Показати</button>
        </div>
      </section>
      <div class="sw-about" id="devAbout">
        <span class="lmark" id="devLogo" aria-hidden="true"></span>
        <div class="ab-t"><b>Режим розробника</b><span>лише для Адміна та Розробника</span></div>
        <span class="ab-ver" id="devVer">версія</span>
      </div>
    </div>
  </div>
</div>
</div><!-- /#app -->

<div id="mwrap" class="hidden">
  <div class="mback" id="mback"></div>
  <div class="modal">
    <div class="m-head">
      <div class="m-ic" id="mIc"></div>
      <div class="m-tt"><b id="mName"></b><span id="mSub">обери групу — скопіюємо посилання</span></div>
    </div>
    <div id="mItems"></div>
  </div>
</div>

<div id="gwrap" class="hidden">
  <div class="mback" id="gback"></div>
  <div class="modal gmodal">
    <div class="m-head">
      <div class="m-ic" style="background:linear-gradient(135deg,#8b5cf6,#6366f1)">
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <div class="m-tt"><b>Мої групи</b><span id="gSub">обери групу для кожного предмета</span></div>
    </div>
    <div class="g-rows" id="gRows"></div>
    <div class="g-foot">
      <button class="b-mini" id="gCancel">Скасувати</button>
      <button class="b-save" id="gSave" disabled>Зберегти</button>
    </div>
  </div>
</div>

<div id="toast"></div>

<!-- підтвердження заходу на урок (можно ввімкнути в налаштуваннях) -->
<div id="cwrap" class="hidden">
  <div class="mback" id="cback"></div>
  <div class="modal cmodal">
    <div class="m-head">
      <div class="m-ic" id="cIc" style="background:linear-gradient(135deg,#8b5cf6,#6366f1)"></div>
      <div class="m-tt"><b id="cTitle">Приєднатися до уроку?</b><span id="cSub">захід у Zoom — підтверди, щоб випадково не зайти</span></div>
    </div>
    <div class="c-info" id="cInfo"></div>
    <div class="g-foot" style="margin-top:2px">
      <button class="b-mini" id="cNo">Ні, скасувати</button>
      <button class="b-save" id="cYes" style="width:auto">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 5v14l11-7z"/></svg>
        Так, приєднатися
      </button>
    </div>
  </div>
</div>

<!-- 2.7.3: гейт входу — закрити неможливо, доки не увійдеш; вкладки сховані -->
<div id="agate" class="hidden">
  <div class="ag-card">
    <div class="ag-glow"></div>
    <div class="us-logo" id="agLogo"></div>
    <div class="us-chip">особистий кабінет</div>
    <h2>Вітаємо у FluxHelper</h2>
    <p class="ag-sub">Увійди в акаунт Google — розклад, групи та налаштування житимуть на всіх твоїх пристроях.</p>
    <div class="ag-mini">
      <span><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9"/><polyline points="21 3 21 9 15 9"/></svg>синхронізація</span>
      <span><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>безпечно</span>
      <span><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>нічого не губиться</span>
    </div>
    <button class="us-btn ag-go" id="agGo" type="button">
      <svg width="17" height="17" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6.1 29.4 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6.1 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.7l6.2 5.2C40.9 35.6 44 30.3 44 24c0-1.3-.1-2.6-.4-3.9z"/></svg>
      <span id="agGoT">Увійти через Google</span>
    </button>
    <div class="ag-stat" id="agStat"></div>
    <div class="ag-foot">FluxHelper __APP_VER__ · вхід захищає Google</div>
  </div>
</div>

<div id="boot" class="pre">
  <div class="bt-tb" id="btTb">
    <div class="bt-tb-l"><img src="data:image/png;base64,__LOGO_B64__" width="27" height="27" alt="" decoding="sync" style="display:block;border-radius:8px"><span>FluxHelper</span></div>
    <div class="bt-tb-r">
      <button class="bt-wbtn win-only" id="btMin" type="button" aria-label="Згорнути">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <button class="bt-wbtn bt-x win-only" id="btClose" type="button" aria-label="Закрити">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
      </button>
    </div>
  </div>
  <div class="bt-mid">
    <div class="bt-mark" id="btMark"><img src="data:image/png;base64,__LOGO_B64__" width="92" height="92" alt="" decoding="sync" fetchpriority="high" style="display:block;border-radius:20px"></div>
    <div class="bt-name">FluxHelper</div>
    <div class="bt-bar"><i id="btFill"></i></div>
    <div class="bt-pct" id="btPct">0%</div>
  </div>
</div>

<div id="neterr" class="hidden">
  <div class="us-card">
    <div class="us-logo" id="neLogo"></div>
    <h2>Немає з'єднання</h2>
    <p class="us-sub" id="neStat">FluxHelper бере розклад з інтернету — увімкни мережу і спробуй ще раз.</p>
    <button class="us-btn" id="neRetry">Спробувати ще раз</button>
  </div>
</div>

<div id="upd" class="hidden">
  <div class="us-card">
    <div class="us-logo" id="upLogo"></div>
    <div class="us-chip" id="updChip">доступне оновлення</div>
    <h2><span id="updOld"></span> → <b id="updNew"></b></h2>
    <p class="us-sub">щоб користуватися програмою, спершу встанови нову версію</p>
    <div class="us-prog" id="updProg"><i id="upFill"></i></div>
    <div class="us-row"><span id="uStat">готово до встановлення</span><span id="upPct"></span></div>
    <button class="us-btn" id="updGo">Оновити</button>
  </div>
</div>

<script>
"use strict";
const LOGO = "data:image/png;base64,__LOGO_B64__";
try{window.__fhDevInfo=__DEVINFO_JSON__;}catch(e){window.__fhDevInfo=null;}
/* налаштування груп з попереднього запуску підставляє main.cpp;
   у сирому файлі (браузер/тести) плейсхолдер не визначений -> null */
try{window.__FH_SETTINGS=__SETTINGS_JSON__;}catch(e){window.__FH_SETTINGS=null;}
const SETTINGS0 = window.__FH_SETTINGS;

// ---------------- Firebase Realtime Database ----------------
const DB_URL = 'https://fluxhelper-1-default-rtdb.europe-west1.firebasedatabase.app';

// ---------------- ВБУДОВАНІ ДАНІ (офлайн-fallback) ----------------
// Структура = структура Firebase: teachers (предмет -> вчитель групи),
// subjects (предмет -> іконка/посилання), schedule (день -> уроки {t, e, s}).
// Розклад містить ТІЛЬКИ назву предмета — вчитель і посилання підтягуються автоматично.
const BUILTIN = {
  teachers: {
    'англійська мова':         { '1': "Орловська Дар'я Миколаївна", '2': 'Юхименко Антоніна Євгеніївна' },
    'німецька мова':           { '1': 'Троцька Оксана Михайлівна', '2': 'Шнайдер Аліна Василівна' },
    'українська мова':         { '1': 'Чеснок Юлія Василівна', '2': 'Яковенко Алла Михайлівна' },
    'українська література':   { '1': 'Чеснок Юлія Василівна' },
    'інформатика':             { '1': 'Авраменко Тетяна Анатоліївна', '2': 'Захарова Олена Вікторівна' },
    'трудове навчання':        { '1': 'Таран Тетяна Володимирівна', '2': 'Іванченко Юрій Вікторович' },
    'алгебра':                 { '1': 'Кушнаренко Інна Іванівна' },
    'геометрія':               { '1': 'Кушнаренко Інна Іванівна' },
    'зарубіжна література':    { '1': 'Троцька Оксана Михайлівна' },
    'основи медіаграмотності': { '1': 'Швець Марина Юріївна' },
    'історія україни':         { '1': 'Глушко Вікторія Анатоліївна' },
    'фізика':                  { '1': 'Дікарєва Валерія Володимирівна' },
    'хімія':                   { '1': 'Вязова Лідія Михайлівна' },
    'громадянська освіта':     { '1': 'Ігнатенко Наталія Миколаївна' },
    'фізична культура':        { '1': 'Пупко Андрій Іванович' },
    'географія':               { '1': 'Запорізька Алла Іванівна' },
    'біологія':                { '1': 'Тесленко Наталія Борисівна' }
  },
  subjects: {
    'алгебра':                 { icon: 'mathf',     link: 'https://us04web.zoom.us/j/74715960561?pwd=lzq3MwKhbj9g29rudFrXzaahMwqMkK.1' },
    'геометрія':               { icon: 'shapef',    link: 'https://us04web.zoom.us/j/74715960561?pwd=lzq3MwKhbj9g29rudFrXzaahMwqMkK.1' },
    'зарубіжна література':    { icon: 'bookopenf', link: 'https://us05web.zoom.us/j/3362996170?pwd=UDFMbkRaU3BRaDF5UUxhcWY1NTIxUT09' },
    'основи медіаграмотності': { icon: 'filmf',     link: 'https://us04web.zoom.us/j/3087220547?pwd=OHFkb3RuZHFEc2hFbUdpQ09UazFydz09' },
    'англійська мова':         { icon: 'msgf',      links: { '1': 'https://us04web.zoom.us/j/78501670655?pwd=jvkDLg5Zr0yftjC45RshgmVk1DI71b.1', '2': 'https://us04web.zoom.us/j/2789884374?pwd=40c3JMgJgB7Af9fO3iMAab1yKsDD1Q.1' } },
    'німецька мова':           { icon: 'msgd',      links: { '1': 'https://us05web.zoom.us/j/3362996170?pwd=UDFMbkRaU3BRaDF5UUxhcWY1NTIxUT09', '2': 'https://us04web.zoom.us/j/7383966360?pwd=aTVZcUdMNW15R3pOa09YVnZXY1h4QT09' } },
    'українська мова':         { icon: 'bookf',     links: { '1': 'https://us05web.zoom.us/j/7865109402?pwd=Z2NSY0g4eGtYUGpEM1Y3OUF6c3o2QT09', '2': 'https://us05web.zoom.us/j/8988356507?pwd=OXFEU1lucjBHcEhYNXdZL1p0UThMUT09' } },
    'українська література':   { icon: 'bookopenf', link: 'https://us05web.zoom.us/j/7865109402?pwd=Z2NSY0g4eGtYUGpEM1Y3OUF6c3o2QT09' },
    'історія україни':         { icon: 'landmarkf', link: 'https://us05web.zoom.us/j/3749252625?pwd=n9BlQwCIZnBHwKabIs7EtF9EKaSdbk.1' },
    'фізика':                  { icon: 'atomf',     link: 'https://us05web.zoom.us/j/2891383331?pwd=F0jxnmfiTOxydHzcOLugDXOPsR7AN9.1' },
    'фізична культура':        { icon: 'run',       link: 'https://us04web.zoom.us/j/7328694112?pwd=T2NucVJwS21UbHhubE9yL3BpcytyUT09' },
    'хімія':                   { icon: 'flaskf',    link: 'https://us04web.zoom.us/j/2229570959?pwd=aWV5enFmN3BLVlgvUHU1ckFJelpHUT09' },
    'громадянська освіта':     { icon: 'usersf',    link: 'https://us04web.zoom.us/j/8101017692?pwd=ajEvMHVvZmsycjc5SFhGeDNHNzgvZz09' },
    'інформатика':             { icon: 'monitorf',  links: { '1': 'https://us05web.zoom.us/j/2621050038?pwd=S2xMWTJ4ZnFWeW9pZDRDRkZKSzI5UT09', '2': 'https://us04web.zoom.us/j/73998115709?pwd=BEwuKbgpHj0GKDQYf8wWb8simysaJS.1' } },
    'географія':               { icon: 'globef',    link: 'https://us05web.zoom.us/j/7923390560?pwd=clJYM3FiN2xISi9lRk1xMFMwcDB3QT09' },
    'трудове навчання':        { icon: 'buildf',    lbl: ['Дівчата', 'Хлопці'], links: { '1': 'https://us04web.zoom.us/j/9260090464?pwd=cTZzMlRjTWpqUHVyeU0xZWw5QkxaUT09', '2': 'https://us04web.zoom.us/j/5931128404?pwd=ARgqPxXvvs7WVlSJuLbMXHHfdmvxqv.1' } },
    'біологія':                { icon: 'ecof',      link: 'https://us05web.zoom.us/j/6689709542?pwd=SFZjTDQ1eU1uQlppSCt1UGhlYXNGUT09&omn=85627260742' },
    'мистецтво':               { icon: 'palettef' },
    'музика':                  { icon: 'musicf' }
  },
  schedule: {
    mon: [
      { t: '08:00', e: '08:45', s: 'Зарубіжна література' },
      { t: '08:55', e: '09:40', s: 'Основи медіаграмотності' },
      { t: '09:50', e: '10:35', s: 'Англійська мова' },
      { t: '10:45', e: '11:30', s: 'Українська мова' },
      { t: '11:50', e: '12:35', s: 'Алгебра' }
    ],
    tue: [
      { t: '08:00', e: '08:45', s: 'Історія України' },
      { t: '08:55', e: '09:40', s: 'Геометрія' },
      { t: '09:50', e: '10:35', s: 'Фізика' },
      { t: '10:45', e: '11:30', s: 'Англійська мова' },
      { t: '11:50', e: '12:35', s: 'Фізична культура' }
    ],
    wed: [
      { t: '08:00', e: '08:45', s: 'Німецька мова' },
      { t: '08:55', e: '09:40', s: 'Хімія' },
      { t: '09:50', e: '10:35', s: 'Громадянська освіта' },
      { t: '10:45', e: '11:30', s: 'Алгебра' },
      { t: '11:50', e: '12:35', s: 'Англійська мова' }
    ],
    thu: [
      { t: '08:00', e: '08:45', s: 'Фізична культура' },
      { t: '08:55', e: '09:40', s: 'Українська мова' },
      { t: '09:50', e: '10:35', s: 'Англійська мова' },
      { t: '10:45', e: '11:30', s: 'Алгебра' },
      { t: '11:50', e: '12:35', s: 'Інформатика' }
    ],
    fri: [
      { t: '08:00', e: '08:45', s: 'Геометрія' },
      { t: '08:55', e: '09:40', s: 'Географія' },
      { t: '09:50', e: '10:35', s: 'Трудове навчання' },
      { t: '10:45', e: '11:30', s: 'Українська література' },
      { t: '11:50', e: '12:35', s: 'Біологія' }
    ]
  }
};
const DAYDEFS = [
  ['mon', 'Пн', 'Понеділок'],
  ['tue', 'Вт', 'Вівторок'],
  ['wed', 'Ср', 'Середа'],
  ['thu', 'Чт', 'Четвер'],
  ['fri', 'Пт', 'П\u2019ятниця']
];

// ---------------- групи (S: ключ предмета -> 1|2) ----------------
const OLDKEY = { ang: 'англійська мова', nim: 'німецька мова', ukr: 'українська мова', inf: 'інформатика', trud: 'трудове навчання' };
const CORESPLIT = [OLDKEY.ang, OLDKEY.nim, OLDKEY.ukr, OLDKEY.inf, OLDKEY.trud];
let S = null;
function validS(x) {
  if (!x || typeof x !== 'object') return false;
  return CORESPLIT.every(function (k) { return x[k] === 1 || x[k] === 2; });
}
(function initS() {
  if (SETTINGS0 && typeof SETTINGS0 === 'object') {
    S = {};
    for (const ok in OLDKEY) { const v = SETTINGS0[ok]; if (v === 1 || v === 2) S[OLDKEY[ok]] = v; }
  }
  if (!validS(S)) {
    S = null;
    try {
      const ls = JSON.parse(localStorage.getItem('fh_groups2') || 'null');
      if (validS(ls)) S = ls;
    } catch (e) {}
  }
  if (!validS(S)) {
    // міграція з дуже старих версій (fh_groups = {ang:1,...}) -> fh_groups2
    try {
      const o = JSON.parse(localStorage.getItem('fh_groups') || 'null');
      if (o && typeof o === 'object') {
        const m = {};
        for (const ok in OLDKEY) { const v = o[ok]; if (v === 1 || v === 2) m[OLDKEY[ok]] = v; }
        if (validS(m)) {
          S = m;
          try { localStorage.setItem('fh_groups2', JSON.stringify(S)); } catch (e2) {}
        }
      }
    } catch (e) {}
  }
})();

// ---------------- версія + перший запуск ----------------
const APP_VER = '__APP_VER__';                  // версія X.Y.Z — з version.h (див. main.cpp)
// 2.4.1: «перший запуск» на ПК вирішує ЛИШЕ settings.json у папці даних
// (%APPDATA%\FluxHelper). localStorage (кеш WebView2) більше НЕ може сховати
// майстер: якщо файлу налаштувань немає або він пошкоджений — майстер груп
// ОБОВ'ЯЗКОВИЙ, навіть якщо групи лишились у старому кеші браузера.
// На мобайлі свого файлу налаштувань немає (SETTINGS0 = null) — там, як і
// раніше, вирішує localStorage приватної пам'яті застосунку.
// (ANDROID тут ще не визначений — дивимося на window.AndroidHost напряму.)
let FIRST = (window.AndroidHost && window.AndroidHost.open) ? !S : !(SETTINGS0 && typeof SETTINGS0 === 'object' &&
  ['ang', 'nim', 'ukr', 'inf', 'trud'].every(function (k) {
    return SETTINGS0[k] === 1 || SETTINGS0[k] === 2;
  }));   // групи ще не налаштовані -> майстер обов'язковий

// ---------------- сповіщення ----------------
let NOTIF = { on: false, min: 5, snd: true };   // 2.9.0: snd — звук; СПОВІЩЕННЯ ВИМКНЕНІ за замовчуванням
try {
  const n = JSON.parse(localStorage.getItem('fh_notif') || 'null');
  if (n && typeof n === 'object') {
    if (typeof n.on === 'boolean') NOTIF.on = n.on;
    if (typeof n.min === 'number' && n.min >= 1 && n.min <= 15) NOTIF.min = n.min;
    if (typeof n.snd === 'boolean') NOTIF.snd = n.snd;   // нове поле — старі збірки його просто не читають
  }
} catch (e) {}
function saveNotif() { try { localStorage.setItem('fh_notif', JSON.stringify(NOTIF)); } catch (e) {} }

// ---------------- дані з Firebase (поверх вбудованих) ----------------
let DBD = { teachers: null, subjects: null, schedule: null };
function teachFor(key) { return DBD.teachers ? (DBD.teachers[key] || null) : (BUILTIN.teachers[key] || null); }
function subjFor(key) { return DBD.subjects ? (DBD.subjects[key] || null) : (BUILTIN.subjects[key] || null); }
function schedFor(dk) { const a = DBD.schedule ? DBD.schedule[dk] : BUILTIN.schedule[dk]; return Array.isArray(a) ? a : null; }

// нормалізація назви предмета: "англ мова" / "Укр.мова" / "фізра" -> канонічний ключ
function normSubj(s) {
  let t = String(s || '').toLowerCase()
    .replace(/[\u2019'`\u00B4]/g, "'")
    .replace(/[.,;:!]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (BUILTIN.subjects[t] || (DBD.subjects && DBD.subjects[t])) return t;
  const A = [
    [/^англ/, 'англійська мова'],
    [/^нім/, 'німецька мова'],
    [/^укр\s*літ|^українська літ/, 'українська література'],
    [/^укр/, 'українська мова'],
    [/^інф/, 'інформатика'],
    [/^труд/, 'трудове навчання'],
    [/^технолог/, 'трудове навчання'],
    [/^зар/, 'зарубіжна література'],
    [/^алг/, 'алгебра'],
    [/^геом/, 'геометрія'],
    [/^геогр/, 'географія'],
    [/^фіз\s*ра|^фізра|^фізичн/, 'фізична культура'],
    [/^фіз/, 'фізика'],
    [/^хім/, 'хімія'],
    [/^біо/, 'біологія'],
    [/^істор/, 'історія україни'],
    [/^гром/, 'громадянська освіта'],
    [/^мед/, 'основи медіаграмотності']
  ];
  for (const a of A) if (a[0].test(t)) return a[1];
  for (const k in BUILTIN.subjects) if (t && k.indexOf(t) === 0) return k;
  return t;
}

function isSplit(key) {
  const s = subjFor(key), t = teachFor(key);
  return !!(s && s.links && s.links['1'] && s.links['2'] && t && t['1'] && t['2']);
}
function splitKeys() {
  const keys = [];
  CORESPLIT.forEach(function (k) { if (isSplit(k)) keys.push(k); });
  const pool = DBD.subjects || BUILTIN.subjects;
  for (const k in pool) if (keys.indexOf(k) === -1 && isSplit(k)) keys.push(k);
  return keys;
}

// розв'язання уроків: назва предмета -> вчитель вибраної групи + посилання
let RES = [];
function resolveLessons() {
  RES = DAYDEFS.map(function (def) {
    const arr = schedFor(def[0]) || [];
    return arr.slice(0, 9).map(function (it) {
      const name = String(it.s || '').trim();
      const key = normSubj(name);
      const sub = subjFor(key) || {};
      const tch = teachFor(key) || {};
      const l1 = sub.links && sub.links['1'] ? String(sub.links['1']) : null;
      const l2 = sub.links && sub.links['2'] ? String(sub.links['2']) : null;
      const t1 = tch['1'] ? String(tch['1']) : null;
      const t2 = tch['2'] ? String(tch['2']) : null;
      const split = !!(l1 && l2 && t1 && t2);
      const gi = (S && (S[key] === 1 || S[key] === 2)) ? S[key] : 1;
      const url = split ? (S ? (gi === 2 ? l2 : l1) : l1)
                        : (sub.link ? String(sub.link) : (it.u ? String(it.u) : null));
      const teacher = split ? (gi === 2 ? t2 : t1)
        : ((tch['1'] || tch['2']) ? String(tch['1'] || tch['2'])
          : (sub.tc ? String(sub.tc) : (it.tc ? String(it.tc) : '')));
      const icon = sub.icon ? String(sub.icon) : (it.ik ? String(it.ik) : 'book');
      const lbls = (sub.lbl && sub.lbl.length === 2) ? [String(sub.lbl[0]), String(sub.lbl[1])]
                                                     : ['1-ша група', '2-га група'];
      return { name: name, key: key, t: String(it.t || ''), e: String(it.e || ''), icon: icon, url: url, teacher: teacher, split: split, lbls: lbls };
    });
  });
}

// ---------------- хост (C++ вікно / Android) ----------------
const ANDROID = !!(window.AndroidHost && window.AndroidHost.open);
function host(m) {
  if (window.chrome && window.chrome.webview && window.chrome.webview.postMessage) {
    try { window.chrome.webview.postMessage(m); return true; } catch (e) {}
  }
  return false;
}
// режим запуску Zoom (тільки ПК): 'app' = додаток (zoommtg://, без браузера;
// якщо Zoom не встановлено — хост сам відкриє браузер), 'web' = браузер
let ZOOM = { mode: 'app' };
try {
  const z = JSON.parse(localStorage.getItem('fh_zoom') || 'null');
  if (z && (z.mode === 'app' || z.mode === 'web')) ZOOM.mode = z.mode;
} catch (e) {}
function saveZoom() { try { localStorage.setItem('fh_zoom', JSON.stringify(ZOOM)); } catch (e) {} if (typeof syncUp === 'function') syncUp(); }
// ПЕРЕТВОРЕННЯ ПОСИЛАННЯ У ВЕБ-ВЕРСІЮ ZOOM (режим «Через браузер»):
// https://us05web.zoom.us/j/123456789?pwd=xyz -> https://app.zoom.us/wc/123456789/join?ref_from=launch&pwd=xyz&fromPWA=1
// Це саме та сторінка «Приєднатися з браузера» — Zoom відкриється ПРЯМО в браузері,
// без десктопного клієнта. Якщо посилання вже веб-формату або не розпізнано — віддаємо як є.
function toWebZoom(u) {
  try {
    const s = String(u || '');
    if (s.indexOf('app.zoom.us/wc/') >= 0) return s;   // вже веб-посилання
    const m = s.match(/\/j\/(\d{5,})/) || s.match(/\/wc\/(\d{5,})\/join/);
    if (!m) return s;
    const pm = s.match(/[?&]pwd=([^&]+)/);
    return 'https://app.zoom.us/wc/' + m[1] + '/join?ref_from=launch' +
           (pm ? ('&pwd=' + pm[1]) : '') + '&fromPWA=1';
  } catch (e) { return u; }
}
function refreshZoomUI() {
  const a = byId('zApp'), w = byId('zWeb');
  if (a) a.classList.toggle('on', ZOOM.mode === 'app');
  if (w) w.classList.toggle('on', ZOOM.mode === 'web');
}

// ---------------- тема оформлення (2.1.0) ----------------
let THEME = 'standard';
const THEME_LIST = ['standard', 'light', 'glass'];   // 2.3.10: Океан/Захід/Ліс/Аврора тимчасово прибрано (лише 3 теми)
const THEME_NAMES = { standard: 'Стандартна тема ✓', light: 'Світла тема ✓', glass: 'Liquid Glass ✓',
                      ocean: 'Океан ✓', sunset: 'Захід ✓', forest: 'Ліс ✓', aurora: 'Аврора ✓' };
try {
  const t0 = localStorage.getItem('fh_theme');
  if (THEME_LIST.indexOf(t0) >= 0) THEME = t0;
} catch (e) {}
/* 2.8.5: watchdog Liquid Glass — на слабких GPU автоматично вмикаємо
   body.lite-glass (без блюрів; дизайн тримають тінт+бордери+градієнт).
   Міряємо середній кадр ~55 кадрів після увімкнення теми; стрибки >120 мс
   (згортання вікна/фон) скидають замір, щоб не отримати хибне «лагає». */
let glassWatchT = 0;
function glassPerfWatch() {
  let lite = false;
  try { lite = localStorage.getItem('fh_liteglass') === '1'; } catch (e) {}
  document.body.classList.toggle('lite-glass', lite);
  clearTimeout(glassWatchT);
  glassWatchT = setTimeout(function () {
    if (THEME !== 'glass' || typeof requestAnimationFrame !== 'function') return;
    let n = 0, t0 = 0, last = 0;
    const tick = function (ts) {
      if (THEME !== 'glass') return;
      if (!n) { t0 = last = ts; n = 1; requestAnimationFrame(tick); return; }
      if (ts - last > 120) { t0 = last = ts; n = 1; requestAnimationFrame(tick); return; }
      last = ts; n++;
      if (n >= 55) {
        const avg = (ts - t0) / (n - 1);
        const slow = avg > 21;   // >21 мс/кадр = менше ~48 fps -> старий iGPU не тягне
        document.body.classList.toggle('lite-glass', slow);
        try { localStorage.setItem('fh_liteglass', slow ? '1' : '0'); } catch (e) {}
        return;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, 1400);
}
function applyTheme(t, save) {
  THEME = (THEME_LIST.indexOf(t) >= 0) ? t : 'standard';   // 2.3.6: усі 7 тем і на ПК
  document.body.setAttribute('data-theme', THEME);
  try { localStorage.setItem('fh_theme', THEME); } catch (e) {}
  host('fh:theme|' + THEME);   // 2.8.8: хост запам'ятовує тему (settings.json) — сплеш наступного запуску одразу у ній
  refreshThemeUI();
  if (THEME === 'glass') glassPerfWatch(); else document.body.classList.remove('lite-glass');
  if (save) {
    syncUp(30);   // 2.8.6: тема одразу летить у хмару — на інших пристроях застосується сама
    toast(THEME_NAMES[THEME] || 'Тема змінена ✓');
  }
}
function refreshThemeUI() {
  const rows = byId('themeRows');
  if (!rows) return;
  const tiles = rows.querySelectorAll('.theme-tile');
  for (let i = 0; i < tiles.length; ++i) {
    tiles[i].classList.toggle('on', tiles[i].getAttribute('data-t') === THEME);
  }
}

function openL(u) {
  if (!u) return;
  if (ZOOM.mode === 'web') u = toWebZoom(u);   // браузер = сторінка «приєднатися в браузері»
  if (ANDROID) { try { AndroidHost.open(u); return; } catch (e) {} }
  if (host('fh:join2|' + ZOOM.mode + '|' + u)) return;   // хост: додаток або браузер
  if (host('fh:join|' + u)) return;
  window.open(u, '_blank');
}

// ---------------- підтвердження заходу на урок (ПК + телефон) ----------------
// Перемикається в налаштуваннях. Увімкнено -> клік по уроку спершу показує
// красиве вікно з затемненням і кнопками «Так / Ні» — щоб зайти на урок
// випадково не вийшло.
let CONFIRM = { on: false };
try { CONFIRM.on = localStorage.getItem('fh_confirm') === '1'; } catch (e) {}
function saveConfirm() { try { localStorage.setItem('fh_confirm', CONFIRM.on ? '1' : '0'); } catch (e) {} }

let pendingLesson = null;   // урок, що очікує підтвердження
let lastJoinBtn = null;     // кнопка «Приєднатися», яку натиснули останньою
function joinLesson(l) {
  if (!l || !l.url) return;
  if (CONFIRM.on) {
    pendingLesson = l;
    const w = byId('cwrap');
    if (!w) { openL(l.url); return; }
    const ic = byId('cIc');
    if (ic) ic.innerHTML = icon(l.icon || 'book', 19);
    const info = byId('cInfo');
    if (info) {
      const sub = subjFor(l.key) || {};
      let url = l.url;
      if (l.split && S && (S[l.key] === 1 || S[l.key] === 2)) {
        const g2 = sub.links && sub.links[String(S[l.key])];
        if (g2) url = String(g2);
      }
      info.innerHTML = '<div class="ci-tile" style="background:' + tileGrad(l.name) + '">' + icon(l.icon || 'book', 16) + '</div>' +
        '<div class="ci-t"><b>' + l.name + '</b><span>' + l.t + ' – ' + l.e +
        (l.teacher ? (' · ' + l.teacher) : '') + '</span></div>';
      info.dataset.url = url || l.url;
    }
    w.classList.remove('hidden');
  } else {
    openL(l.url);
  }
}
function closeConfirm() {
  const w = byId('cwrap');
  if (w) w.classList.add('hidden');
  pendingLesson = null;
}
function confirmYes() {
  const info = byId('cInfo');
  const url = (info && info.dataset && info.dataset.url) ? info.dataset.url
            : (pendingLesson ? pendingLesson.url : null);
  closeConfirm();
  if (lastJoinBtn) {
    lastJoinBtn.classList.add('starting');
    setTimeout(function () { if (lastJoinBtn) lastJoinBtn.classList.remove('starting'); }, 8000);
  }
  if (url) openL(url);
}

// ---------------- фідбек запуску Zoom (хост штовхає події назад) ----------------
function zoomStarting() { toast('⏳ Zoom запускається — скоро все запуститься'); if (lastJoinBtn) lastJoinBtn.classList.add('starting'); }
function zoomWait() { toast('⏳ Zoom уже запускається — зачекай кілька секунд'); }
function zoomFallback() { toast('🌐 Zoom не встановлено — відкрили через браузер'); if (lastJoinBtn) lastJoinBtn.classList.remove('starting'); }

// ---------------- тост + буфер обміну ----------------
let toastT = null;
function toast(msg) {
  const t = byId('toast');
  if (!t) return;
  t.innerHTML = icon('msg', 14) + '<span>' + String(msg) + '</span>';
  t.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(function () { t.classList.remove('show'); }, 2300);
}
function fmtCopy(l, gi) {
  let teacher = l.teacher, url = l.url;
  if (l.split && gi >= 0) {
    const tch = teachFor(l.key) || {}, sub = subjFor(l.key) || {};
    teacher = String(tch[String(gi + 1)] || '');
    if (sub.links && sub.links[String(gi + 1)]) url = String(sub.links[String(gi + 1)]);
  }
  let s = '📚 ' + l.name + '\n';
  if (teacher) s += '👩\u200D🏫 ' + teacher + '\n';
  if (url) s += '🔗 ' + url;
  return s;
}
function fallbackCopy(txt) {
  const ta = document.createElement('textarea');
  ta.value = txt;
  ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) {}
  ta.remove();
  toast(ok ? 'Посилання скопійовано ✓' : 'Не вдалося скопіювати');
}
function copyText(txt) {
  if (ANDROID) {
    try { AndroidHost.copy(txt); toast('Посилання скопійовано ✓'); return; } catch (e) {}
  }
  if (host('fh:copy|' + txt)) { toast('Посилання скопійовано ✓'); return; }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(function () { toast('Посилання скопійовано ✓'); }, function () { fallbackCopy(txt); });
    return;
  }
  fallbackCopy(txt);
}

// ---------------- утиліти ----------------
const NOW0 = new Date();
const dow0 = NOW0.getDay(); // 0 = нд
const monday = new Date(NOW0); monday.setDate(NOW0.getDate() - ((dow0 + 6) % 7));
let sel = (dow0 >= 1 && dow0 <= 5) ? dow0 - 1 : 0;
let setupOpen = false;
let tabEls = [];
let FAKENOW = null, FAKEDOW = null;   // тільки для тестів/прев'ю

function byId(id) { return document.getElementById(id); }
function el(t, c, h) { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; }
function dateStr(i) { const d = new Date(monday); d.setDate(monday.getDate() + i); return d.getDate() + '.' + (d.getMonth() + 1); }
function todayDow() { return FAKEDOW != null ? FAKEDOW : dow0; }
function nowMin() { if (FAKENOW != null) return FAKENOW; const d = new Date(); return d.getHours() * 60 + d.getMinutes(); }
function toMin(t) { const p = String(t || '').split(':'); return (parseInt(p[0], 10) || 0) * 60 + (parseInt(p[1], 10) || 0); }
function isTodaySel() { const d = todayDow(); return d >= 1 && d <= 5 && sel === d - 1; }
function tileGrad(name) {
  let h = 0; for (const ch of String(name)) h = (h * 31 + ch.codePointAt(0)) % 1000;
  const hue = 236 + (h % 54);
  return 'linear-gradient(135deg,hsl(' + hue + ',62%,58%),hsl(' + ((hue + 34) % 360) + ',68%,46%))';
}

// ---------------- SVG-ІКОНКИ ----------------
// 2.8.1: НОВИЙ набір іконок ПРЕДМЕТІВ — білі 2D (щільна біла фігура +
// темні деталі-вирізи, як у Material filled). UI-гліфи (check, link, clock…)
// лишились лінійними. Кольори: currentColor = білий плитки, IC_D = виріз.
const IC_D = 'rgba(8,8,18,.30)';
const ICONS = {
  /* ---------- предмети (filled 2D) ---------- */
  bookf:      '<path fill="currentColor" stroke="none" d="M18.3 2.5H7.2c-1.5 0-2.7 1.2-2.7 2.7v13.6c0 1.5 1.2 2.7 2.7 2.7h11.1c.66 0 1.2-.54 1.2-1.2V3.7c0-.66-.54-1.2-1.2-1.2z"/><path fill="' + IC_D + '" stroke="none" d="M7.6 4.6h2.6v14.8H7.6c-.5 0-.9-.4-.9-.9V5.5c0-.5.4-.9.9-.9z"/><rect x="13.1" y="6.3" width="4.4" height="1.7" rx=".85" fill="' + IC_D + '" stroke="none"/><rect x="13.1" y="9.7" width="4.4" height="1.7" rx=".85" fill="' + IC_D + '" stroke="none"/>',
  bookopenf:  '<path fill="currentColor" stroke="none" d="M12 5.4C10.4 4 8.2 3.4 5.9 3.4c-.88 0-1.6.72-1.6 1.6v11.4c0 .88.72 1.6 1.6 1.6 2.3 0 4.5.65 6.1 1.9V5.4z"/><path fill="currentColor" opacity=".6" stroke="none" d="M12 5.4c1.6-1.4 3.8-2 6.1-2 .88 0 1.6.72 1.6 1.6v11.4c0 .88-.72 1.6-1.6 1.6-2.3 0-4.5.65-6.1 1.9V5.4z"/>',
  msgf:       '<path fill="currentColor" stroke="none" d="M12 2.9c-5.14 0-9.3 3.63-9.3 8.1 0 2.4 1.2 4.55 3.1 6v3.3c0 .62.65 1.02 1.2.74l3.3-1.83c.55.07 1.12.11 1.7.11 5.14 0 9.3-3.63 9.3-8.1S17.14 2.9 12 2.9z"/><path d="M9.8 15.1 12 8.7l2.2 6.4M10.7 12.9h2.6" fill="none" stroke="' + IC_D + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
  msgd:       '<path fill="currentColor" stroke="none" d="M12 2.9c-5.14 0-9.3 3.63-9.3 8.1 0 2.4 1.2 4.55 3.1 6v3.3c0 .62.65 1.02 1.2.74l3.3-1.83c.55.07 1.12.11 1.7.11 5.14 0 9.3-3.63 9.3-8.1S17.14 2.9 12 2.9z"/><path d="M10.7 8.6v6.8h1.4a3.4 3.4 0 0 0 0-6.8z" fill="none" stroke="' + IC_D + '" stroke-width="1.6" stroke-linejoin="round"/>',
  globef:     '<circle cx="12" cy="12" r="9.2" fill="currentColor" stroke="none"/><path fill="' + IC_D + '" stroke="none" d="M12 2.8c-2.5 2.1-4 5.4-4 9.2s1.5 7.1 4 9.2c2.5-2.1 4-5.4 4-9.2s-1.5-7.1-4-9.2z"/><path d="M3 12h18" fill="none" stroke="' + IC_D + '" stroke-width="1.5" stroke-linecap="round"/>',
  mathf:      '<g fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round"><path d="M4.5 7.1h5.2"/><path d="M7.1 4.5v5.2"/><path d="M14.3 7.1h5.2"/><path d="M4.9 14.7l4.4 4.4"/><path d="M9.3 14.7l-4.4 4.4"/><path d="M14.3 16.9h5.2"/></g><circle cx="16.9" cy="13.7" r="1.15" fill="currentColor" stroke="none"/><circle cx="16.9" cy="20.1" r="1.15" fill="currentColor" stroke="none"/>',
  sigmaf:     '<path fill="currentColor" stroke="none" d="M17.7 6.4c.94 0 1.7-.76 1.7-1.7s-.76-1.7-1.7-1.7H7.1c-.75 0-1.42.49-1.64 1.2-.22.72.06 1.5.68 1.93L11.6 10.5c.24.17.38.44.38.73v1.54c0 .29-.14.56-.38.73l-5.46 4.37c-.62.43-.9 1.21-.68 1.93.22.71.89 1.2 1.64 1.2h10.6c.94 0 1.7-.76 1.7-1.7s-.76-1.7-1.7-1.7h-6.9l4.06-3.25c.53-.42.84-1.06.84-1.74v-.22c0-.68-.31-1.32-.84-1.74L10.8 6.4h6.9z"/>',
  shapef:     '<path fill="currentColor" stroke="none" d="M13.32 3.55c-.58-1-2.06-1-2.64 0L3.1 17.9c-.58 1.01.14 2.28 1.32 2.28h15.16c1.18 0 1.9-1.27 1.32-2.28z"/><circle cx="12" cy="14.7" r="2.3" fill="' + IC_D + '" stroke="none"/>',
  filmf:      '<path fill="currentColor" stroke="none" d="M20.4 3.4H3.6c-.88 0-1.6.72-1.6 1.6v14c0 .88.72 1.6 1.6 1.6h16.8c.88 0 1.6-.72 1.6-1.6V5c0-.88-.72-1.6-1.6-1.6z"/><path fill="' + IC_D + '" stroke="none" d="M6.9 3.4h2.2v3.1H6.9zM6.9 17.5h2.2v3.1H6.9zM14.9 3.4h2.2v3.1h-2.2zM14.9 17.5h2.2v3.1h-2.2z"/><path fill="' + IC_D + '" stroke="none" d="M10.35 9.2l4.3 2.36c.28.16.28.52 0 .68l-4.3 2.56c-.28.16-.65-.04-.65-.34V9.54c0-.3.37-.5.65-.34z"/>',
  atomf:      '<circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none"/><g fill="none" stroke="currentColor" stroke-width="1.9" opacity=".92"><ellipse cx="12" cy="12" rx="9" ry="3.7"/><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(-60 12 12)"/></g><circle cx="19.6" cy="7.6" r="1.35" fill="currentColor" stroke="none"/>',
  run:        '<path fill="currentColor" stroke="none" d="M13.49 5.48c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm-3.6 13.9 1-4.4 2.1 2v6h2v-7.5l-2.1-2 .6-3c1.3 1.5 3.3 2.5 5.5 2.5v-2c-1.9 0-3.5-1-4.3-2.4l-1-1.6c-.4-.6-1-1-1.7-1-.3 0-.5.1-.8.1l-5.2 2.2v4.7h2v-3.4l1.8-.7-1.6 8.1-4.9-1-.4 2 7 1.4z"/>',
  flaskf:     '<path fill="currentColor" stroke="none" d="M15.2 3.2H8.8c-.5 0-.9.4-.9.9s.4.9.9.9h.15v3.75L4.5 16.5c-.98 1.7.24 3.8 2.2 3.8h10.6c1.96 0 3.18-2.1 2.2-3.8l-4.45-7.75V5h.15c.5 0 .9-.4.9-.9s-.4-.9-.9-.9z"/><path fill="' + IC_D + '" stroke="none" d="M8.3 14h7.4l1.85 3.15c.4.7-.1 1.55-.9 1.55H7.35c-.8 0-1.3-.85-.9-1.55z"/><circle cx="10.6" cy="16.35" r=".9" fill="currentColor" stroke="none"/><circle cx="13.7" cy="17.2" r=".65" fill="currentColor" stroke="none"/>',
  usersf:     '<path fill="currentColor" stroke="none" d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>',
  monitorf:   '<path fill="currentColor" stroke="none" d="M20.2 3H3.8C2.81 3 2 3.81 2 4.8v10.6c0 .99.81 1.8 1.8 1.8h16.4c.99 0 1.8-.81 1.8-1.8V4.8c0-.99-.81-1.8-1.8-1.8z"/><path d="M9.7 7.4 7.3 9.9l2.4 2.5M12.2 12.4h2.9" fill="none" stroke="' + IC_D + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path fill="currentColor" stroke="none" d="M8.3 21h7.4v-1.2c0-.66-.54-1.2-1.2-1.2H9.5c-.66 0-1.2.54-1.2 1.2z"/>',
  landmarkf:  '<path fill="currentColor" stroke="none" d="M12.47 2.13a.9.9 0 0 0-.94 0L2.55 7.55c-.66.39-.38 1.4.38 1.4h18.14c.76 0 1.04-1.01.38-1.4zM4.7 10.4h2.4v7.1H4.7zM10.8 10.4h2.4v7.1h-2.4zM16.9 10.4h2.4v7.1h-2.4zM3.2 19h17.6c.66 0 1.2.54 1.2 1.2s-.54 1.2-1.2 1.2H3.2c-.66 0-1.2-.54-1.2-1.2s.54-1.2 1.2-1.2z"/>',
  buildf:     '<path fill="currentColor" stroke="none" d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>',
  ecof:       '<path fill="currentColor" stroke="none" d="M6.05 8.05a7.001 7.001 0 0 0-.02 9.88c1.47-3.4 4.09-6.24 7.36-7.93A15.952 15.952 0 0 0 8 19.32c2.6 1.23 5.8.78 7.95-1.37C19.43 14.47 20 4 20 4S9.53 4.57 6.05 8.05z"/>',
  palettef:   '<path fill="currentColor" stroke="none" d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>',
  musicf:     '<path fill="currentColor" stroke="none" d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>',
  /* ---------- UI-гліфи (лінійні, як були) ---------- */
  book:     '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M9 8.5h4M9 12h2.5"/>',
  bookopen: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
  msg:      '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8z"/>',
  globe:    '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  sigma:    '<line x1="8" y1="6.2" x2="11" y2="6.2"/><line x1="9.5" y1="4.7" x2="9.5" y2="7.7"/><line x1="13.5" y1="6.2" x2="16.5" y2="6.2"/><line x1="8" y1="17.8" x2="11" y2="17.8"/><line x1="13.5" y1="17.8" x2="16.5" y2="17.8"/><circle cx="15" cy="10.9" r="1.05"/><circle cx="9" cy="13.3" r="1.05"/><line x1="13.8" y1="12.1" x2="16.2" y2="14.5"/><line x1="16.2" y1="12.1" x2="13.8" y2="14.5"/><line x1="7.8" y1="10" x2="10.2" y2="12.4"/><line x1="10.2" y1="10" x2="7.8" y2="12.4"/>',
  shape:    '<path d="M12 3.5 21 20H3z"/>',
  flask:    '<path d="M9 3h6"/><path d="M10 3v5.2L4.6 17a2.3 2.3 0 0 0 2 3.4h10.8a2.3 2.3 0 0 0 2-3.4L14 8.2V3"/><path d="M7.4 14.5h9.2"/>',
  atom:     '<circle cx="12" cy="12" r="1.6"/><ellipse cx="12" cy="12" rx="9.4" ry="4"/><ellipse cx="12" cy="12" rx="9.4" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9.4" ry="4" transform="rotate(-60 12 12)"/>',
  ball:     '<circle cx="13.2" cy="4.9" r="1.9"/><path d="M7.2 21.2c.3-2 .6-3.4 1.8-4.7 1-1.1 2.4-1.7 3.4-3 .8-1.1 1.1-2.4 1.6-3.7"/><path d="M11.6 21.2c-.3-1.4-.3-2.7.2-4 .4-1 1.1-1.8 1.7-2.7"/><path d="M12.4 8.6c1.4-.4 2.9-.2 4.2.5"/><path d="M14.7 6.1 12 8l-4.4 1.3c-.5.2-.8.9-.5 1.4.2.5.9.8 1.4.5l3.7-1"/>',
  landmark: '<path d="M3 21h18"/><path d="M5 18v-8"/><path d="M9.5 18v-8"/><path d="M14.5 18v-8"/><path d="M19 18v-8"/><path d="M3 7l9-4.5L21 7z"/>',
  palette:  '<path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.4-.4-.6-.9-.6-1.4 0-1.1.9-2 2-2h2.3c3 0 4.8-2.2 4.8-5.1C22 5.7 17.5 2 12 2z"/><circle cx="7.5" cy="11.5" r="1.1"/><circle cx="10.3" cy="7.4" r="1.1"/><circle cx="14.8" cy="7.4" r="1.1"/>',
  monitor:  '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 8l2.2 2.5L7 13"/><path d="M11.5 13H14"/>',
  wrench:   '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  map:      '<circle cx="12" cy="12" r="9.3"/><path d="M4.6 6.4c2.2 1.5 3.1 3.4 5.4 4.2 1.6.6 3.4.4 4.6 1.6 1 1 1.2 2.6.4 3.8-.9 1.4-2.7 1.6-3.9 2.8-.8.8-1.2 1.9-1.6 3"/><path d="M15.2 3.2c1 1.8 2.6 2.7 4.9 3"/><path d="M20.9 10.6c-1.7.3-3.3.1-4.6 1"/><path d="M9.4 3.2c-.4 1.4-1.2 2.4-2.5 3"/>',
  leaf:     '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  users:    '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  copy:     '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  film:     '<rect x="2" y="3" width="20" height="18" rx="2.5"/><line x1="7" y1="3" x2="7" y2="21"/><line x1="17" y1="3" x2="17" y2="21"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7.5" x2="7" y2="7.5"/><line x1="2" y1="16.5" x2="7" y2="16.5"/><line x1="17" y1="16.5" x2="22" y2="16.5"/><line x1="17" y1="7.5" x2="22" y2="7.5"/>',
  clock:    '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  user:     '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  check:    '<polyline points="20 6 9 17 4 12"/>',
  link:     '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  volume:   '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>'
};
// 2.8.0: плоскі лінійні SVG-іконки (набір 2.4.2 з перемальованими ball/sigma/map/book)
// 2.8.1: старі ключі іконок (з БД/RTDB) — на нові білі 2D; UI-гліфи не чіпаємо
// 2.8.3: ПОВЕРНУТО ІКОНКИ 2.4.2 для всіх предметів, крім фізкультури (run) та мистецтва (palettef)
const ICON_ALIAS = { ball: 'run', palette: 'palettef' };
function icon(name, sz) {
  const nm = ICON_ALIAS[name] || name;
  return '<svg width="' + sz + '" height="' + sz + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (ICONS[nm] || ICONS.bookf) + '</svg>';
}
function iconSvg(name) {
  return '<svg width="11" height="11" viewBox="0 0 24 24" fill="#e0e7ff"><path d="M8 5v14l11-7z"/></svg>';
}

// ---------------- логотип (оригінальна іконка автора, PNG без втрат) ----------------
function logoMark(sz) {
  return '<img src="' + LOGO + '" width="' + sz + '" height="' + sz + '" alt="" style="display:block;border-radius:' + Math.max(6, Math.round(sz * 0.22)) + 'px" />';
}

// ---------------- масштабування під розмір вікна ----------------
function applyScale() {
  // 2.9.0: масштабуємо ЛИШЕ ВМІСТ (#app) — титульна панель лишається поза
  // масштабом, щоб кнопки вікна були піксель-у-піксель ті самі, що на
  // сплеші й екрані входу. Висота панелі — фіксовані 50px.
  const w = window.innerWidth || 1040, h = (window.innerHeight || 700) - 50;
  const app = byId('app');
  if (!app) return;
  let s = Math.min(w / 1040, h / 650);
  s = Math.max(0.8, Math.min(2.2, s));
  app.style.zoom = s;
}

// ---------------- головний екран ----------------
function render(anim) {
  resolveLessons();
  const list = byId('list');
  if (!list) return;
  list.innerHTML = '';
  const sliding = (anim === 'slide-l' || anim === 'slide-r');
  list.classList.toggle('still', anim === false || sliding);
  list.classList.remove('slide-l', 'slide-r');
  if (sliding) { void list.offsetWidth; list.classList.add(anim); }
  const dn = byId('dayName');
  if (dn && anim !== false) { dn.classList.remove('dchg'); void dn.offsetWidth; dn.classList.add('dchg'); }
  const D = DAYDEFS[sel];
  const day = RES[sel] || [];
  byId('dayName').textContent = D ? D[2] : '';

  if (!day.length) {
    list.appendChild(el('div', 'empty', icon('bookopen', 28) + '<p>Немає уроків</p>'));
    tabEls.forEach(function (t, i) { t.classList.toggle('on', i === sel); });
    setChip();
    return;
  }

  // ЗАРАЗ (зелений) / ДАЛІ (жовтий) — тільки на вкладці сьогоднішнього дня
  let nowIdx = -1, nextIdx = -1, nowPct = 0;
  if (isTodaySel()) {
    const m = nowMin();
    day.forEach(function (l, i) {
      const a = toMin(l.t), b = toMin(l.e);
      if (a && b && m >= a && m < b) { nowIdx = i; nowPct = b > a ? Math.max(0, Math.min(1, (m - a) / (b - a))) : 0; }
      if (nextIdx === -1 && a && m < a) nextIdx = i;
    });
    if (nowIdx !== -1) nextIdx = -1;
  }

  day.forEach(function (l, i) {
    let cls = 'card';
    if (i === nowIdx) cls += ' now'; else if (i === nextIdx) cls += ' next';
    const card = el('div', cls);
    if (anim !== false) card.style.animationDelay = (i * 0.05) + 's';

    const tile = el('div', 'ic');
    // 2.8.0: іконки уроків — плоскі білі лінійні SVG (набір 2.4.2) на градієнтній плитці
    // 2.9.2: іконка предмета (в т.ч. алгебра ±×÷) — трохи БІЛЬША (21 -> 24),
    // щоб краще читалась у плитці
    tile.innerHTML = icon(l.icon, 24);
    tile.style.background = tileGrad(l.name);

    const mid = el('div', 'mid');
    const h3 = el('h3'); h3.textContent = l.name;
    if (i === nowIdx) h3.appendChild(el('span', 'now-chip', '<i></i>ЗАРАЗ'));
    if (i === nextIdx) h3.appendChild(el('span', 'next-chip', '<i></i>ДАЛІ'));
    mid.appendChild(h3);

    const meta = el('div', 'meta');
    const t1 = el('span', 'tc');
    t1.innerHTML = icon('clock', 12);
    const tv = el('span'); tv.textContent = l.t + ' – ' + l.e;
    t1.appendChild(tv);
    meta.appendChild(t1);
    if (l.teacher) {
      const u1 = el('span', 'tc');
      u1.innerHTML = icon('user', 12);
      const uv = el('span'); uv.textContent = l.teacher;
      u1.appendChild(uv);
      meta.appendChild(u1);
    }
    mid.appendChild(meta);

    const b = el('button', 'b-join');
    b.innerHTML = '<span>Приєднатися</span> ' + iconSvg('play');
    b.onclick = function (ev) { ev.stopPropagation(); lastJoinBtn = b; joinLesson(l); };

    card.onclick = function () {
      if (lpFired) { lpFired = false; return; }
      if (swipeFired) { swipeFired = false; return; }
      lastJoinBtn = b; joinLesson(l);
    };
    card.addEventListener('contextmenu', function (ev) {
      ev.preventDefault();
      if (lpFired) { lpFired = false; return; }
      if (l.split) openModal(l);
      else copyText(fmtCopy(l, -1));       // одна група -> копіюємо одразу
    });
    bindLongPress(card, l);
    card.append(tile, mid, b);
    if (i === nowIdx) {
      const pr = el('i', 'prog');
      pr.style.width = Math.round(nowPct * 100) + '%';
      card.appendChild(pr);
    }
    list.appendChild(card);
  });
  tabEls.forEach(function (t, i) { if (t.classList) t.classList.toggle('on', i === sel); });
  setChip();
}

// ---------------- довге натискання (Android APK) = ПКМ ----------------
let lpFired = false;
let swipeFired = false;   // щойно було свайп-переключення дня — гасимо клік по картці
function bindLongPress(card, l) {
  let sx = 0, sy = 0, t = null;
  card.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse') return;
    sx = e.clientX; sy = e.clientY; lpFired = false;
    t = setTimeout(function () {
      t = null; lpFired = true;
      if (l.split) openModal(l);
      else copyText(fmtCopy(l, -1));
    }, 480);
  });
  card.addEventListener('pointermove', function (e) {
    if (t && (Math.abs(e.clientX - sx) > 12 || Math.abs(e.clientY - sy) > 12)) { clearTimeout(t); t = null; }
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) {
    card.addEventListener(ev, function () { if (t) { clearTimeout(t); t = null; } });
  });
}

// ---------------- модальне вікно копіювання (по центру, фон затемнено) ----------------
function openModal(l) {
  const w = byId('mwrap'), items = byId('mItems');
  if (!w || !items) return;
  byId('mName').textContent = l.name;
  byId('mSub').textContent = 'обери групу — скопіюємо посилання';
  const ic = byId('mIc');
  ic.innerHTML = icon(l.icon, 19);
  ic.style.background = tileGrad(l.name);
  const tch = teachFor(l.key) || {};
  items.innerHTML = '';
  [0, 1].forEach(function (gi) {
    const b = el('button', 'm-item');
    const tn = String(tch[String(gi + 1)] || '');
    b.innerHTML = icon('copy', 16) +
      '<span class="m-l"><span class="m-lbl">' + l.lbls[gi] + '</span>' +
      (tn ? '<span class="m-t">' + tn + '</span>' : '') + '</span>' +
      '<small>' + icon('link', 11) + 'копіювати</small>';
    b.onclick = function (ev) { ev.stopPropagation(); copyText(fmtCopy(l, gi)); closeModal(); };
    items.appendChild(b);
  });
  w.classList.remove('hidden');
}
function closeModal() { const w = byId('mwrap'); if (w) w.classList.add('hidden'); }

function setChip() {
  const chip = byId('chip');
  if (!chip) return;
  const d = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + sel);
  const wd = new Intl.DateTimeFormat('uk-UA', { weekday: 'long' }).format(d);
  const dm = new Intl.DateTimeFormat('uk-UA', { day: 'numeric', month: 'long' }).format(d);
  const cap = wd.charAt(0).toUpperCase() + wd.slice(1);
  const isToday = isTodaySel();
  chip.innerHTML = icon('clock', 12) + '<span>' + cap + ', ' + dm + (isToday ? ' <i class="today-dot"></i>' : '') + '</span>';
}

function todayIdx() { const d = todayDow(); return (d >= 1 && d <= 5) ? d - 1 : 0; }

function setTbSec(t) { const e = byId('tbSec'); if (e) e.textContent = t; }
// сегмент-перемикач у титульній панелі: Розклад | Налаштування | Розробник
function setSeg(view) {
  const a = byId('segSched'), b = byId('segSetup'), d = byId('segDev');
  if (a) a.classList.toggle('on', view === 'sched');
  if (b) b.classList.toggle('on', view === 'setup');
  if (d) d.classList.toggle('on', view === 'dev');
}
function showMain(force) {
  /* 2.9.2: force=true — показати РОЗКЛАД навіть якщо групи ще не обрані:
     майстер груп відкривається МОДАЛКОЮ ПОВЕРХ розкладу. Користувач бачить
     свою вкладку «Розклад» і перед ним обов'язкове вікно груп; після
     «Зберегти» лишається на розкладі. */
  if (FIRST && !force) { showSetup(); openGroups(); return; }   // перший запуск — спершу групи
  setupOpen = false;
  byId('vSetup').classList.add('hidden');
  const _vd1 = byId('vDev'); if (_vd1) _vd1.classList.add('hidden');   // 2.7.3
  const _va1 = byId('vAcc'); if (_va1) _va1.classList.add('hidden');   // 2.8.3: профіль не «висить» поверх
  document.body.setAttribute('data-view', 'sched');
  byId('vMain').classList.remove('hidden');
  setChip();
  markNav('sched');
  setSeg('sched');
  setTbSec('розклад');
  host('fh:view|main');   // 2.7.6: нативна панель малює активний сегмент
  checkNban();
}
function showSetup() {
  setupOpen = true;
  host('fh:view|setup');   // 2.7.6
  closeDrawer();
  byId('vMain').classList.add('hidden');
  const _vd2 = byId('vDev'); if (_vd2) _vd2.classList.add('hidden');   // 2.7.3
  const _va2 = byId('vAcc'); if (_va2) _va2.classList.add('hidden');   // 2.8.3
  document.body.setAttribute('data-view', 'setup');
  byId('vSetup').classList.remove('hidden');
  buildSummary();
  refreshNotifUI();
  refreshZoomUI();
  markNav('setup');
  setSeg('setup');
  setTbSec('налаштування');
}
// 2.7.3: окрема вкладка «Розробник» — ЖОРСТКИЙ гейт: неавторизованих
// одразу на гейт входу, звичайних користувачів — назад на розклад.
function showDev() {
  if (!ACC.user) { gateStart(); return; }
  if (!staff()) { showMain(); toast('Розділ «Розробник» — лише для Адміна та Розробника'); return; }
  setupOpen = false;
  closeDrawer();
  byId('vMain').classList.add('hidden');
  byId('vSetup').classList.add('hidden');
  const _va3 = byId('vAcc'); if (_va3) _va3.classList.add('hidden');   // 2.8.3
  document.body.setAttribute('data-view', 'dev');
  const v = byId('vDev'); if (v) v.classList.remove('hidden');
  const dv = byId('devVer'); if (dv) dv.textContent = 'версія ' + APP_VER;
  const dl = byId('devLogo'); if (dl) dl.innerHTML = logoMark(40);
  markNav('dev');
  setSeg('dev');
  setTbSec('розробник');
  host('fh:view|dev');   // 2.7.6
  if (byId('devVers') && !byId('devVers').children.length) devListVers();
}

function drawerOpen() { const d = byId('drawer'); return !!(d && d.classList.contains('on')); }
function openDrawer() { const d = byId('drawer'); if (d) d.classList.add('on'); const b = byId('dback'); if (b) b.classList.add('on'); }
function closeDrawer() {
  const d = byId('drawer'); if (d) d.classList.remove('on');
  const b = byId('dback'); if (b) b.classList.remove('on');
}
function markNav(view) {
  ['dwSched', 'dwSet'].forEach(function (id) {
    const e2 = byId(id); if (e2) e2.classList.remove('on');
  });
  const map = { home: 'dwSched', sched: 'dwSched', setup: 'dwSet', dev: '' };
  const t = byId(map[view] || '');   // 2.3.8: невідомий вид (профіль) — без підсвітки
  if (t) t.classList.add('on');
}

// ---------------- налаштування: групи з сегмент-перемикачами (ПК) ----------------
// Десктопний стиль: кожен предмет — рядок із перемикачем [1 | 2], зміна
// застосовується ОДРАЗУ (без модального вікна). Модалка «Деталі…» лишається
// для першого запуску і для перегляду вчителів обох груп.
function splitInfo(k) {
  const sub = subjFor(k) || {}, tch = teachFor(k) || {};
  const lbls = (sub.lbl && sub.lbl.length === 2) ? [String(sub.lbl[0]), String(sub.lbl[1])]
                                                 : ['1-ша група', '2-га група'];
  return { sub: sub, tch: tch, lbls: lbls };
}
function dispName(key) { return key ? key.charAt(0).toUpperCase() + key.slice(1) : ''; }
function saveGroupInstant(k, v) {
  if (!S) S = {};
  S[k] = v;
  try { localStorage.setItem('fh_groups2', JSON.stringify(S)); } catch (e) {}
  if (!host('fh:save|' + JSON.stringify(oldKeyMap(S)))) {
    try { localStorage.setItem('fh_groups', JSON.stringify(oldKeyMap(S))); } catch (e) {}
  }
  render(false);
  buildSummary();
  toast(infName(k) + ' — ' + v + '-ша група ✓');
}
function infName(k) { return dispName(k); }
function buildSummary() {
  const rows = byId('sumRows');
  if (!rows) return;
  rows.innerHTML = '';
  const keys = splitKeys();
  const done = keys.filter(function (k) { return S && (S[k] === 1 || S[k] === 2); }).length;
  if (!done) {
    rows.appendChild(el('div', 'sum-hint',
      'Групи ще не обрано. Натисни 1 або 2 біля предмета — і застосунок скрізь підставить саме твоїх вчителів і посилання.'));
    return;
  }
  keys.forEach(function (k, idx) {
    const inf = splitInfo(k);
    const g = (S && (S[k] === 1 || S[k] === 2)) ? S[k] : 0;
    const row = el('div', 'sw-row');
    const ic = el('div', 'su-tile');
    ic.innerHTML = icon(inf.sub.icon || 'book', 15);
    ic.style.background = tileGrad(k);
    const nm = el('div', 'sw-gname');
    const bE = el('b'); bE.textContent = dispName(k);
    const sE = el('span'); sE.textContent = g ? (String(inf.tch[String(g)] || '') + ' · ' + inf.lbls[g - 1]) : 'не обрано';
    nm.append(bE, sE);
    const seg = el('div', 'seg');
    [1, 2].forEach(function (v) {
      const b2 = el('button'); b2.type = 'button'; b2.textContent = inf.lbls[v - 1] || (v + ' група');
      b2.classList.toggle('on', g === v);
      b2.onclick = function (ev) { ev.stopPropagation(); if (g !== v) saveGroupInstant(k, v); };
      seg.appendChild(b2);
    });
    row.append(ic, nm, seg);
    rows.appendChild(row);
  });
}

// ---------------- модальне вікно налаштування груп ----------------
let draft = {};
let optEls = [];
function openGroups() {
  draft = {}; optEls = [];
  const rows = byId('gRows');
  if (!rows) return;
  const gc = byId('gCancel');
  if (gc) gc.classList.toggle('hidden', FIRST);       // перший запуск — «Скасувати» немає
  const gs = byId('gSub');
  if (gs) gs.textContent = FIRST ? 'обери групу для кожного предмета — це обов’язково'
                                 : 'обери групу для кожного предмета';
  const keys = splitKeys();
  keys.forEach(function (k) { if (S && (S[k] === 1 || S[k] === 2)) draft[k] = S[k]; });
  rows.innerHTML = '';
  keys.forEach(function (k) {
    const inf = splitInfo(k);
    const row = el('div', 'su-item');
    const ic = el('div', 'su-tile');
    ic.innerHTML = icon(inf.sub.icon || 'book', 16);
    ic.style.background = tileGrad(k);
    const body = el('div', 'su-body');
    const nm = el('div', 'su-name'); nm.textContent = dispName(k);
    const opts = el('div', 'su-opts');
    [0, 1].forEach(function (gi) {
      const v = gi + 1;
      const o = el('button', 'su-opt');
      const bE = el('b'); bE.textContent = inf.lbls[gi];
      const sE = el('span'); sE.textContent = String(inf.tch[String(v)] || '');
      const ck = el('span', 'ck'); ck.innerHTML = icon('check', 13);
      o.append(bE, sE, ck);
      o.onclick = function () { draft[k] = v; refreshGroups(); };
      o._k = k; o._v = v;
      opts.appendChild(o);
      optEls.push(o);
    });
    body.append(nm, opts);
    row.append(ic, body);
    rows.appendChild(row);
  });
  refreshGroups();
  byId('gwrap').classList.remove('hidden');
}
function closeGroups() {
  if (FIRST) return;                                  // поки групи не збережено — закрити не можна
  const w = byId('gwrap'); if (w) w.classList.add('hidden');
}
function groupsOpen() { const w = byId('gwrap'); return !!(w && !w.classList.contains('hidden')); }
function refreshGroups() {
  optEls.forEach(function (o) { o.classList.toggle('on', draft[o._k] === o._v); });
  const keys = splitKeys();
  const done = keys.filter(function (k) { return draft[k] === 1 || draft[k] === 2; }).length;
  const gp = byId('gProg');
  if (gp) gp.textContent = done + '/' + keys.length;
  byId('gSave').disabled = done !== keys.length;
}
function oldKeyMap(s) {
  const o = {};
  for (const ok in OLDKEY) o[ok] = (s[OLDKEY[ok]] === 2) ? 2 : 1;
  return o;
}
function nextLessonName() {
  const l = nextLessonFull();
  return l ? l.name : 'Урок';
}
// повний «наступний урок» — з посиланням (щоб кнопка в сповіщенні реально працювала)
function nextLessonFull() {
  resolveLessons();
  const ti = todayIdx();
  const m = nowMin();
  const days = [RES[ti] || [], RES[(ti + 1) % 5] || []];
  for (let d = 0; d < 2; ++d) {
    for (let i = 0; i < days[d].length; ++i) {
      const a = toMin(days[d][i].t);
      if (a && (d === 1 || a > m)) return days[d][i];
    }
  }
  return days[0][0] || null;
}
function saveSettings() {
  const keys = splitKeys();
  const ok = keys.every(function (k) { return draft[k] === 1 || draft[k] === 2; });
  if (!ok) return;
  const first = FIRST;
  S = {};
  keys.forEach(function (k) { S[k] = draft[k]; });
  FIRST = false;
  try { localStorage.setItem('fh_groups2', JSON.stringify(S)); } catch (e) {}
  if (!host('fh:save|' + JSON.stringify(oldKeyMap(S)))) {
    try { localStorage.setItem('fh_groups', JSON.stringify(oldKeyMap(S))); } catch (e) {}
  }
  closeGroups();
  render(false);
  if (setupOpen) buildSummary();
  toast('Групи збережено ✓');
  syncUp(30);   // 2.8.6: групи летять у хмару МОМЕНТАЛЬНО — більше не губляться при швидкому виході
  /* 2.9.2: після збереження — ЗАВЖДИ розклад (майстер відкривається поверх
     розкладу, тому після «Зберегти» користувач просто лишається на вкладці). */
  if (first || setupOpen) showMain();
}

// ---------------- сповіщення: інтерфейс + push до хостів ----------------
// 2.8.5: тестове = ПОВНА копія справжнього: заголовок «Скоро почнеться урок»,
// текст «<предмет> починається о HH:MM — через 5 хв (тестове сповіщення)»,
// кнопки «Зайти» / «Ігнорувати» у тості Windows — як у реального сповіщення.
function nextTestLessonName() {
  try {
    const now = new Date();
    const cur = (now.getHours() * 60) + now.getMinutes();
    for (let off = 0; off < 7; off++) {
      const d = new Date(now.getTime() + off * 86400000);
      const dow = ((d.getDay() + 6) % 7) + 1;           // 1..5 = Пн..Пт
      if (dow > 5) continue;
      const day = RES[dow - 1] || [];
      for (let i = 0; i < day.length; i++) {
        const l = day[i];
        if (!l || !l.t) continue;
        const m = /^(\d{1,2}):(\d{2})$/.exec(String(l.t).trim());
        if (!m) continue;
        const st = (parseInt(m[1], 10) * 60) + parseInt(m[2], 10);
        if (off > 0 || st > cur) return l.name || 'Урок';
      }
    }
  } catch (e) {}
  return 'Інформатика';
}
function testNotifSound() {
  const d = new Date(Date.now() + 5 * 60000);
  const hh = ('0' + d.getHours()).slice(-2), mm = ('0' + d.getMinutes()).slice(-2);
  // 2.8.7: дизайн тестового = дизайн справжнього (емодзі + той самий формат)
  const title = '\u23F0 Скоро почнеться урок';
  const text = '\uD83D\uDD14 ' + nextTestLessonName() + ' — початок о ' + hh + ':' + mm + ' · через 5 хв (це тестове сповіщення)';
  if (ANDROID) {
    try { AndroidHost.testNotif(title, text, 'https://us05web.zoom.us/j/74715960561', ''); } catch (e) {}
    return;
  }
  host('fh:notif-test|' + JSON.stringify({ title: title, text: text }));
}
function pushNotifSched() {
  resolveLessons();
  const items = [];
  RES.forEach(function (day, i) {
    (day || []).forEach(function (l) {
      if (l.t) items.push({ dow: i + 1, t: l.t, n: l.name, u: l.url || '', m: ZOOM.mode });
    });
  });
  const payload = JSON.stringify({ on: NOTIF.on, min: NOTIF.min, snd: !!NOTIF.snd, items: items });
  host('fh:notif|' + payload);
  if (ANDROID) { try { AndroidHost.setNotif(payload); } catch (e) {} }
}
function refreshNotifUI() {
  const nOn = byId('nOn'), row = byId('nMinRow'), perm = byId('bPerm');
  if (nOn) nOn.checked = NOTIF.on;
  if (row) row.classList.toggle('hidden', !NOTIF.on);
  if (perm) {
    let show = false;
    if (ANDROID) { try { show = !AndroidHost.hasNotifPerm(); } catch (e) { show = false; } }
    perm.classList.toggle('hidden', !show || !NOTIF.on);
  }
  const sl = byId('nMin'), sv = byId('nMinVal');
  if (sl) {
    sl.value = NOTIF.min;
    sl.style.setProperty('--p', (((NOTIF.min - 1) / 14) * 100).toFixed(1) + '%');
  }
  if (sv) sv.textContent = NOTIF.min + ' хв';
  const nSnd = byId('nSnd'), sRow = byId('nSndRow'), tBtn = byId('bTestN');
  if (nSnd) nSnd.checked = !!NOTIF.snd;
  if (sRow) sRow.classList.toggle('hidden', !NOTIF.on);   // звук є сенс показувати лише коли сповіщення ввімкнені
  if (tBtn) tBtn.classList.toggle('hidden', !NOTIF.on);   // і тестове — теж
}

// ---------------- Firebase: кеш + ліміти + live-оновлення ----------------
const FETCH_GAP = 180000;          // не частіше ніж раз на 3 хв (економія лімітів)
let lastFetchTs = 0, dbBusy = false, es = null, pollTimer = 0, evT = 0, cacheTs = 0, dbOnline = false;
function applyDb(db, fromCache) {
  if (!db || typeof db !== 'object') return false;
  let changed = false;
  // вузол може бути об'єктом АБО масивом: RTDB перетворює {"1":x,"2":y} у [null,x,y]
  function validNode(n) { return !!(n && typeof n === 'object'); }
  if (db.teachers !== undefined && validNode(db.teachers)) {
    const t = {};
    for (const k in db.teachers) {
      const v = db.teachers[k];
      if (!validNode(v)) continue;
      const g = {};
      if (typeof v['1'] === 'string' && v['1']) g['1'] = v['1'];
      if (typeof v['2'] === 'string' && v['2']) g['2'] = v['2'];
      if (g['1'] || g['2']) t[k] = g;
    }
    DBD.teachers = t; changed = true;
  }
  if (db.subjects !== undefined && validNode(db.subjects)) {
    const t = {};
    for (const k in db.subjects) {
      const v = db.subjects[k];
      if (!validNode(v)) continue;
      const o = {};
      if (typeof v.link === 'string' && v.link) o.link = v.link;
      if (validNode(v.links)) {
        const ls = {};
        if (typeof v.links['1'] === 'string' && v.links['1']) ls['1'] = v.links['1'];
        if (typeof v.links['2'] === 'string' && v.links['2']) ls['2'] = v.links['2'];
        if (ls['1'] || ls['2']) o.links = ls;
      }
      if (typeof v.icon === 'string' && v.icon) o.icon = v.icon;
      if (typeof v.tc === 'string' && v.tc) o.tc = v.tc;
      if (Array.isArray(v.lbl) && v.lbl.length === 2) o.lbl = [String(v.lbl[0]), String(v.lbl[1])];
      t[k] = o;
    }
    DBD.subjects = t; changed = true;
  }
  if (db.schedule !== undefined && validNode(db.schedule)) {
    const t = {}; let okCnt = 0;
    for (const dk in db.schedule) {
      const arr = db.schedule[dk];
      if (!Array.isArray(arr) || arr.length > 9) continue;
      const ls = []; let ok = true;
      for (const it of arr) {
        if (!it || typeof it !== 'object' || !String(it.s || '').trim() || !String(it.t || '').trim() || !String(it.e || '').trim()) { ok = false; break; }
        const o = { t: String(it.t), e: String(it.e), s: String(it.s) };
        if (it.ik) o.ik = String(it.ik);
        if (it.u) o.u = String(it.u);
        if (it.tc) o.tc = String(it.tc);
        ls.push(o);
      }
      if (ok && ls.length) { t[dk] = ls; okCnt++; }
    }
    if (okCnt) { DBD.schedule = t; changed = true; }
  }
  if (db.app !== undefined && validNode(db.app)) {
    const r = (typeof db.app.repo === 'string') ? db.app.repo.trim() : '';
    if (r && r !== UPDATE_REPO) {
      UPDATE_REPO = r;
      try { localStorage.setItem('fh_repo', r); } catch (e) {}
    }
  }
  if (db.update && typeof db.update === 'object' && db.update.test !== undefined) {
    const t2 = (db.update.test && typeof db.update.test === 'object' && db.update.test !== null) ? db.update.test : null;
    DBD.updTest = t2 ? { latest: String(t2.latest || ''), notes: Array.isArray(t2.notes) ? t2.notes.map(String).slice(0, 4) : [], tid: String(t2.tid || '') } : null;
  }
  if (changed) {
    if (!fromCache) {
      try { localStorage.setItem('fh_cache', JSON.stringify({ ts: Date.now(), data: db })); } catch (e) {}
      cacheTs = Date.now();
    }
    dbOnline = true;
    if (!setupOpen) render(false);
    pushNotifSched();
  }
  // живе відстеження версії: поки програма відкрита — як тільки в базі з'явиться
  // нова версія (SSE/doFetch), одразу показуємо модалку оновлення
  if (!fromCache && db && typeof db.update !== 'undefined') updFromDb(db.update);
  return changed;
}
function doFetch(force) {
  if (dbBusy) return;
  if (!force && Date.now() - lastFetchTs < FETCH_GAP) return;
  dbBusy = true;
  fetch(DB_URL + '/.json', { cache: 'no-store' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (j) {
      dbBusy = false;
      if (j && typeof j === 'object') { lastFetchTs = Date.now(); applyDb(j); }
    })
    .catch(function () { dbBusy = false; });
}
function startLive() {
  if (es) return;
  try {
    es = new EventSource(DB_URL + '/.json?alt=sse');
    es.onmessage = function (ev) {
      try {
        const m = JSON.parse(ev.data);
        if (!m || m.type !== 'put') return;
        // статистика пишеться самим застосунком — ігноруємо, щоб не жерти ліміти
        if (m.path && (String(m.path).indexOf('/stats/') === 0 || String(m.path).indexOf('/update/devices/') === 0)) return;
        if (!m.path || m.path === '/') { if (m.data) { lastFetchTs = Date.now(); applyDb(m.data); } }
        else { clearTimeout(evT); evT = setTimeout(function () { doFetch(true); }, 900); }
      } catch (e) {}
    };
    es.onerror = function () {
      if (es) { es.close(); es = null; }
      if (!pollTimer) pollTimer = setInterval(function () { if (!document.hidden) doFetch(false); }, 300000);
    };
  } catch (e) { es = null; }
}

// --- ЖИВЕ ОНОВЛЕННЯ РОЗКЛАДУ (2.1.0) -----------------------------------
// Легкий поллінг /schedule кожні 2.5 с (коли екран видно) + предмети/вчителі
// раз на 15 с. Зміна з редактора з'являється на всіх пристроях за 1-2 с БЕЗ
// перезапуску програми (SSE лишається як миттєвий канал де працює).
let schedLast = '', poolSchedT = 0, subLast = '', tchLast = '', subT = 0;
function pollSchedule() {
  if (document.hidden) return;
  fetch(DB_URL + '/schedule.json?cb=' + Date.now(), { cache: 'no-store' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .catch(function () { return null; })
    .then(function (j) {
      if (!j || typeof j !== 'object') return;
      const s = JSON.stringify(j);
      if (s !== schedLast) {
        const first = (schedLast === '');
        schedLast = s;
        if (!first) { applyDb({ schedule: j }); dbOnline = true; }
      }
    });
  clearTimeout(poolSchedT);
  poolSchedT = setTimeout(pollSchedule, 2500);
}
function pollSubjects() {
  if (document.hidden) { subT = setTimeout(pollSubjects, 15000); return; }
  Promise.all([
    fetch(DB_URL + '/subjects.json?cb=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }),
    fetch(DB_URL + '/teachers.json?cb=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; })
  ]).then(function (res) {
    const sj = res[0], tj = res[1];
    if (sj && typeof sj === 'object') {
      const s = JSON.stringify(sj);
      if (s !== subLast) {
        const first = (subLast === '');
        subLast = s;
        if (!first) applyDb({ subjects: sj });
      }
    }
    if (tj && typeof tj === 'object') {
      const s2 = JSON.stringify(tj);
      if (s2 !== tchLast) {
        const first2 = (tchLast === '');
        tchLast = s2;
        if (!first2) applyDb({ teachers: tj });
      }
    }
  });
  clearTimeout(subT);
  subT = setTimeout(pollSubjects, 15000);
}

// ---------------- система оновлень ----------------
// Firebase /update = { latest: "X.Y.Z", notes: ["+ ...", "- ..."] } — пише deploy-скрипт.
// Програма порівнює latest із своєю версією; якщо відрізняється і папка
// versions/<v>/ реально є на GitHub — показує МОДАЛКУ, яку не можна закрити,
// і встановлює нову версію (PC: exe сам себе замінює; телефон: APK-інсталятор).
const DEFAULT_REPO = 'matviikobrys2707/FluxHelper';
let UPDATE_REPO = DEFAULT_REPO;
try { const _r = localStorage.getItem('fh_repo'); if (_r) UPDATE_REPO = _r; } catch (e) {}
let UPD = { avail: false, ver: '', busy: false, pending: '', watch: 0, dbNotes: null, dbVer: '', test: false, pref: 'versions/release/' };
function verCmp(a, b) {
  const p = String(a).split('.'), q = String(b).split('.');
  for (let i = 0; i < 3; i++) {
    const x = parseInt(p[i], 10) || 0, y = parseInt(q[i], 10) || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}
function updOpen() { return UPD.avail; }
// плавний показ головного екрана (дозволено лише один раз і без відкритої модалки)
function revealNow() {
  if (bootRevealed || updOpen()) return;
  bootReady = true;
}
function showUpd(v, notes, testMode, pref) {
  UPD.avail = true; UPD.ver = v; UPD.busy = false; UPD.pending = '';
  UPD.test = !!testMode;
  UPD.pref = pref || 'versions/release/';
  const chip = byId('updChip');
  if (chip) chip.textContent = (UPD.pref === 'versions/beta/') ? 'доступна бета-версія' : 'доступне оновлення';
  const b = byId('boot');
  if (b && !b.classList.contains('hidden')) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 560); }
  hideNetErr();
  // 2.8.8: модалка оновлення — найголовніша. Якщо без аккаунта гейт уже
  // видно (з першого кадру чи з accBoot) — прибираємо його, щоб гейт (z 230)
  // не перекривав оновлення (z 120) і його можна було встановити
  try { gateHide(); gateLock(false); } catch (e) {}
  byId('updOld').textContent = APP_VER;
  byId('updNew').textContent = v;
  // 2.3.9: СПИСКУ ЗМІН У ПОПАПІ БІЛЬШЕ НЕМАЄ — тільки версії (власник попросив)
  const w = byId('upd');
  w.classList.remove('hidden');
  document.body.classList.add('upd-lock');   // титульна панель поверх модалки (ПК)
  byId('updGo').disabled = false;
  byId('updProg').classList.remove('on');
  byId('upFill').style.width = '0%';
  byId('upPct').textContent = '';
  byId('uStat').textContent = 'готово до встановлення';
}
// 2.7.3: існування папки версії перевіряємо за FluxHelper.exe (у папках тепер
// рівно 2 файли, changelog.txt прибрано).
// ПОРІВНЯННЯ СТРОГО «новіше»: latest <= поточної -> модалки немає (захист від відкату версії
// на сервері і від ситуації «скачав не той файл» — старіша версія не вважається оновленням).
function updCheck(latest) {
  if (!/^\d+\.\d+\.\d+$/.test(latest || '') || verCmp(latest, APP_VER) <= 0) { revealNow(); return; }
  if (UPD.avail || UPD.pending === latest) return;
  UPD.pending = latest;
  // 2.3.9: існування папки версії перевіряємо HEAD-запитом (тіло не качаємо).
  // Ченджлог більше не читаємо і не показуємо — у попапі лише версії.
  fetch('https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/versions/release/' + latest + '/FluxHelper.exe?_=' + Date.now(), { method: 'HEAD', cache: 'no-store' })
    .then(function (r) { if (!r.ok) throw 0; showUpd(latest); })
    .catch(function () {
      UPD.pending = '';
      revealNow();          // папки немає — не блокуємо застосунок
    });
}
function updFromDb(u) {
  const latest = (u && typeof u.latest === 'string') ? u.latest : '';
  if (UPD.avail) return;
  // СПРАВЖНЄ оновлення — головне (перевіряємо першим)
  if (/^\d+\.\d+\.\d+$/.test(latest) && verCmp(latest, APP_VER) > 0) {
    UPD.test = false;
    updCheck(latest);
    return;
  }
  // ТЕСТОВЕ оновлення (режим розробника): update/test = {latest, notes[], tid}.
  // Усі пристрої побачать звичайну модалку «доступне оновлення», але нічого
  // не скачається — при натисканні «Оновити» застосунок просто перезапуститься.
  // ВАЖЛИВО: коли користувач натиснув «Оновити» — на ЙОГО пристрої модалка
  // ЦЬОГО тесту (того самого tid) більше НЕ з'являється НІКОЛИ. Новий tid
  // (запуск нового тесту з вкладки «Розробник») = побачать знову.
  const t = (u && u.test && typeof u.test === 'object' && u.test !== null) ? u.test : null;
  const tv = (t && typeof t.latest === 'string') ? t.latest : '';
  if (/^\d+\.\d+\.\d+$/.test(tv) && verCmp(tv, APP_VER) > 0) {
    const tid = String(t.tid || '');
    let seen = '';
    try { seen = localStorage.getItem('fh_testseen') || ''; } catch (e) {}
    if (!(tid && seen && seen === tid)) {
      showUpd(tv, null, true);
    }
    return;
  }
  // нічого не вийшло -> просто показуємо головний екран
  revealNow();
}
// --- миттєве відстеження версії ---
// Джерело №1: GitHub versions/latest.json з cache-buster (?cb=час) — raw-CDN
// кешує на 5 хв, але кожен новий ?cb= обходить кеш, тож нова версія з'являється
// ОДРАЗУ після деплою (деплой заливає Firebase останнім, після перевірки GitHub).
// Джерело №2 (запасне): Firebase /update.json.
let updWatchBusy = false;
function fetchLatest(cb) {
  fetch('https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/versions/release/latest.json?cb=' + Date.now(), { cache: 'no-store' })
    .then(function (r) { return r.ok ? r.json() : Promise.reject(0); })
    .then(function (j) { cb(j); })
    .catch(function () {
      fetch(DB_URL + '/update.json', { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) { cb(j); })
        .catch(function () { cb(null); });
    });
}
function handleLatest(u) {
  updWatchBusy = false;
  if (!u || typeof u !== 'object') return;
  const latest = (typeof u.latest === 'string') ? u.latest : '';
  if (/^\d+\.\d+\.\d+$/.test(latest) && verCmp(latest, APP_VER) > 0) updCheck(latest);
}
function watchUpdate() {
  if (updOpen() || updWatchBusy || document.hidden) return;
  updWatchBusy = true;
  // БЕТА-КАНАЛ: тільки Адмін/Розробник із увімкненим тумблером
  if (staff() && ACC.beta) {
    fetch('https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/versions/beta/latest.json?cb=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (jb) {
        const bv = (jb && typeof jb.latest === 'string') ? jb.latest : '';
        if (/^\d+\.\d+\.\d+$/.test(bv) && verCmp(bv, APP_VER) > 0) { updCheckBeta(bv); return; }
        fetchLatest(handleLatest);
      })
      .catch(function () { fetchLatest(handleLatest); });
    return;
  }
  fetchLatest(handleLatest);
}
// 2.3.10: ручна перевірка оновлення з налаштувань (та сама логіка, що на телефоні)
function manualUpdCheck() {
  const b = byId('bUpdNow'); if (b) b.disabled = true;
  toast('Перевіряю оновлення…');
  fetchLatest(function (u) {
    if (b) b.disabled = false;
    const latest = (u && typeof u.latest === 'string') ? u.latest : '';
    if (/^\d+\.\d+\.\d+$/.test(latest) && verCmp(latest, APP_VER) > 0) {
      updCheck(latest);                                   // знайдено файл -> попап оновлення
      setTimeout(function () {
        if (!updOpen()) toast('Файл оновлення ще не опубліковано — спробуй пізніше');
      }, 9000);
      return;
    }
    if (!latest) { toast('Не вдалося зв' + String.fromCharCode(39) + 'язатися з сервером оновлень'); return; }
    toast('У тебе найновіша версія ✓');
  });
}
// --- завантаження + встановлення ---
function setUpdBtn(en) { const b = byId('updGo'); if (b) b.disabled = !en; }
function updProgOff() {
  byId('updProg').classList.remove('on');
  byId('upFill').style.width = '0%';
  byId('upPct').textContent = '';
}
function dlProg(p) {
  if (!UPD.avail || !UPD.busy) return;
  if (UPD.watch) { clearTimeout(UPD.watch); UPD.watch = 0; }
  p = Math.max(0, Math.min(100, p | 0));
  byId('updProg').classList.add('on');
  byId('upFill').style.width = p + '%';
  byId('upPct').textContent = p + '%';
  byId('uStat').textContent = (p >= 100) ? 'запускаю встановлення…' : 'завантаження…';
  if (p >= 100) setUpdBtn(false);
}
function dlErr(msg) {
  if (!UPD.avail) return;
  UPD.busy = false;
  if (UPD.watch) { clearTimeout(UPD.watch); UPD.watch = 0; }
  updProgOff();
  byId('uStat').textContent = String(msg || 'помилка завантаження');
  setUpdBtn(true);
}
function dlDone() {
  if (!UPD.avail) return;
  if (UPD.watch) { clearTimeout(UPD.watch); UPD.watch = 0; }
  byId('updProg').classList.add('on');
  byId('upFill').style.width = '100%';
  byId('upPct').textContent = '100%';
  byId('uStat').textContent = ANDROID ? 'відкриваю встановлення…' : 'встановлення… застосунок зараз перезапуститься';
  setUpdBtn(false);
}
function startUpdate() {
  if (UPD.busy || !UPD.avail) return;
  UPD.busy = true;
  setUpdBtn(false);
  // --- ТЕСТОВЕ ОНОВЛЕННЯ: нічого не качаємо — плавний «прогрес» і перезапуск.
  // Це симуляція справжнього оновлення: застосунок закриється і відкриється.
  // ОДРАЗУ запам'ятовуємо tid тесту — після перезапуску ця модалка на цьому
  // пристрої більше НІКОЛИ не з'явиться (до запуску нового тесту).
  if (UPD.test) {
    try {
      if (DBD.updTest && DBD.updTest.tid) localStorage.setItem('fh_testseen', DBD.updTest.tid);
      else localStorage.setItem('fh_testseen', 'done-' + UPD.ver);
    } catch (e) {}
    byId('updProg').classList.add('on');
    byId('uStat').textContent = 'завантаження…';
    let p = 0;
    const iv = setInterval(function () {
      p += 7 + Math.round(Math.random() * 9);
      if (p >= 100) {
        p = 100;
        clearInterval(iv);
        byId('uStat').textContent = 'встановлення… застосунок зараз перезапуститься';
        if (ANDROID) { setTimeout(function () { try { location.reload(); } catch (e) {} }, 700); }
        else { setTimeout(function () { host('fh:restart'); }, 700); }
      }
      byId('upFill').style.width = p + '%';
      byId('upPct').textContent = p + '%';
    }, 130);
    return;
  }
  if (ANDROID) {
    // ТЕЛЕФОН: Android блокує встановлення APK прямо з застосунку, тому ми
    // НЕ качаємо файл самі — відкриваємо ПРЯМИЙ ПОСИЛАННЯ у браузері.
    // Користувач вже там завантажує APK і встановлює його (як звичайний файл).
    byId('uStat').textContent = 'шукаю файл оновлення…';
    const base = 'https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/versions/release/' + UPD.ver + '/';
    const cands = [base + 'FluxControl.apk', base + 'Blazix.apk', base + 'FluxHelper.apk'];
    (function probe(i) {
      if (i >= cands.length) {
        UPD.busy = false; setUpdBtn(true);
        byId('uStat').textContent = 'файл оновлення не знайдено — спробуй пізніше';
        return;
      }
      fetch(cands[i], { method: 'HEAD', cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw 0; })
        .then(function () {
          UPD.busy = false; setUpdBtn(true);
          byId('uStat').textContent = 'завантаження відкрито у браузері — встанови APK, коли файл завантажиться';
          try { toast('Завантаження почалось ✓'); } catch (e) {}
          openL(cands[i]);
        })
        .catch(function () { probe(i + 1); });
    })(0);
    return;
  }
  // ПК: застосунок сам качає exe у свою папку, замінює себе і перезапускається
  byId('uStat').textContent = 'готуємо завантаження…';
  const payload = JSON.stringify({ v: UPD.ver, repo: UPDATE_REPO, p: UPD.pref || 'versions/release/' });
  const sent = host('fh:update|' + payload);
  if (sent) {
    // якщо за 25 с жодного прогресу — показуємо помилку
    UPD.watch = setTimeout(function () {
      if (UPD.busy && !byId('upFill').style.width) dlErr('GitHub не відповідає — перевір інтернет');
    }, 25000);
  } else {
    UPD.busy = false;
    setUpdBtn(true);
    byId('uStat').textContent = 'не вдалося запустити завантаження — спробуй ще раз';
  }
}
// --- немає інтернету: жодного інтерфейсу, тільки екран помилки ---
function showNetErr(msg) {
  const ne = byId('neterr');
  if (!ne) return;
  document.body.classList.add('net-lock');   // титульна панель поверх (ПК)
  const s = byId('neStat');
  if (s) s.textContent = msg || 'Flux Helper бере розклад з інтернету — увімкни мережу і спробуй ще раз.';
  const b = byId('boot');
  if (b && !b.classList.contains('hidden')) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 400); }
  ne.classList.remove('hidden');
  const r = byId('neRetry');
  if (r) { r.disabled = false; r.textContent = 'Спробувати ще раз'; }
}
function hideNetErr() {
  const ne = byId('neterr'); if (ne) ne.classList.add('hidden');
  document.body.classList.remove('net-lock');
}
let netBusy = false;
function netProbe(retry) {
  if (netBusy) return;
  netBusy = true;
  if (retry) {
    const s = byId('neStat'), r = byId('neRetry');
    if (s) s.textContent = 'перевіряємо з\u2019єднання…';
    if (r) r.disabled = true;
  }
  let ac = null, to = null;
  try { if (typeof AbortController === 'function') ac = new AbortController(); } catch (e) {}
  if (ac) to = setTimeout(function () { try { ac.abort(); } catch (e) {} }, 9000);
  fetch(DB_URL + '/.json', { cache: 'no-store', signal: ac ? ac.signal : undefined })
    .then(function (r) { if (!r.ok) throw 0; return r.json(); })
    .then(function (j) {
      netBusy = false;
      if (to) clearTimeout(to);
      if (!j || typeof j !== 'object') throw 0;
      lastFetchTs = Date.now();
      applyDb(j);
      hideNetErr();
      updFromDb(j.update);        // модалка оновлення АБО показ головного
    })
    .catch(function () {
      netBusy = false;
      if (to) clearTimeout(to);
      showNetErr();
    });
}

// =================================================================
//  РЕЖИМ РОЗРОБНИКА: мости запису + статистика + редактор розкладу
// =================================================================
// --- запис у Firebase через хост (немає проблем з CORS у file://) ---
const fbCbs = {};
let fbSeq = 0;
function __fhFbResult(id, ok) {
  const f = fbCbs[id];
  delete fbCbs[id];
  if (f) f(!!ok);
}
function fbEnc(p) {
  return String(p).split('/').map(function (x) { return encodeURIComponent(x); }).join('/');
}
function dbPut(path, obj, cb) {
  const body = JSON.stringify(obj === undefined ? null : obj);
  if (ANDROID && window.AndroidHost && AndroidHost.fbPut) {
    let ok = false;
    // ФІКС 2.1.0: без суфікса .json Firebase повертав 404 -> телефони
    // НЕ реєструвались у статистиці пристроїв
    let p2 = fbEnc(path);
    if (p2.indexOf('.json') < 0) p2 += '.json';
    try { ok = AndroidHost.fbPut(p2, body); } catch (e) {}
    if (cb) cb(ok);
    return;
  }
  const id = 'cb' + (++fbSeq) + '_' + Date.now();
  fbCbs[id] = cb || null;
  /* 2.9.2 ФІКС: раніше тут був fh:fbput| — повідомлення, якого хост ПК НЕ
     обробляє (мовчки проковтувалось), тому auth_cb та інші Firebase-записи
     з ПК НАСПРАВДІ не писались/не чистились. Тепер — fh:cloud| (PUT), який
     хост обробляє: нативний запит без CORS. Браузер лишається на fetch. */
  const p2 = fbEnc(path) + '.json';
  if (host('fh:cloud|' + id + '|PUT|' + (DB_URL + '/' + p2).length + '|' + DB_URL + '/' + p2 + body)) return;
  // запасний шлях (браузер/прев'ю): прямий fetch (2.9.2: + виправлений слеш)
  fetch(DB_URL + '/' + p2, { method: 'PUT', body: body })
    .then(function (r) { __fhFbResult(id, r.ok); })
    .catch(function () { __fhFbResult(id, false); });
}
function dbDel(path, cb) {
  if (ANDROID && window.AndroidHost && AndroidHost.fbDel) {
    let ok = false;
    let p3 = fbEnc(path);
    if (p3.indexOf('.json') < 0) p3 += '.json';
    try { ok = AndroidHost.fbDel(p3); } catch (e) {}
    if (cb) cb(ok);
    return;
  }
  const id = 'cb' + (++fbSeq) + '_' + Date.now();
  fbCbs[id] = cb || null;
  /* 2.9.2 ФІКС: fh:fbdel| хост ПК не обробляв (записи auth_cb назавжди
     лишались у базі) — тепер DELETE йде через fh:cloud|. */
  const p3 = fbEnc(path) + '.json';
  if (host('fh:cloud|' + id + '|DELETE|' + (DB_URL + '/' + p3).length + '|' + DB_URL + '/' + p3)) return;
  fetch(DB_URL + '/' + p3, { method: 'DELETE' })
    .then(function (r) { __fhFbResult(id, r.ok); })
    .catch(function () { __fhFbResult(id, false); });
}

// ================================================================
// 2.2.0 — CLOUDFLARE D1 (fluxcontrol): «повільні» дані (профілі,
// налаштування, реєстр пристроїв). Firebase лишає лише real-time
// (оновлення, розклад, нотатки). Account ID підтягується з
// /config/cf (Firebase) або вкладки «Розробник» — до конфігурації
// усе прозоро працює через Firebase, як раніше.
// ================================================================
// 2.7.2: токен D1 живе ТІЛЬКИ у хості (exe/Java, XOR+base64) — у HTML його немає.
const CF_ACC = 'fd6013c3a257c7759ff3c15fbb8ac002';
const CF_DB = '89424274-f50b-4931-838e-0d6f384bbc20';
function cfOk() { return true; }
let cfSeq = 0;
const cfCbs = {};
// один запит до D1 (POST /d1/database/<id>/query). Телефон — прямий fetch
// (WebView без CORS-обмежень), ПК — через хост (fh:cfq -> WinHTTP).
function cfExec(sql, params, cb) {
  const id = 'cf' + (++cfSeq) + '_' + Date.now();
  cfCbs[id] = cb || null;
  const payload = JSON.stringify({ sql: sql, params: params || [] });
  const done = function (json) {
    const cb2 = cfCbs[id]; delete cfCbs[id];
    if (!cb2) return;
    let rows = null;
    try {
      const r = (typeof json === 'string') ? JSON.parse(json) : json;
      if (r && r.success && r.result && r.result[0] && r.result[0].results) rows = r.result[0].results;
    } catch (e) {}
    cb2(rows);
  };
  setTimeout(function () { if (cfCbs[id]) { delete cfCbs[id]; cfLast = 0; if (cb) cb(null); } }, 20000);   // 2.7.3: 20с
  if (ANDROID && window.AndroidHost && window.AndroidHost.cfq) {
    try { AndroidHost.cfq(id, payload); return; } catch (e) { delete cfCbs[id]; }
  }
  if (host('fh:cfq|' + id + '|' + payload)) return;   // хост додає Authorization сам
  done('');
}
// результат від хоста ПК (викликає C++ після WinHTTP-запиту)
function __fhCfResult(id, json) {
  const cb2 = cfCbs[id]; delete cfCbs[id];
  if (!cb2) return;
  let rows = null;
  try {
    const r = JSON.parse(json);
    if (r && r.success && r.result && r.result[0] && r.result[0].results) rows = r.result[0].results;
  } catch (e) {}
  cb2(rows);
}
let cfInitTried = false;
function d1Init() {
  if (!cfOk() || cfInitTried) return;
  cfInitTried = true;
  // 2.9.0: ОДНА ТАБЛИЦЯ users = профіль (email, ім'я, Firebase UID) + налаштування
  // (settings JSON, sver/sts — версія і час знімка) + created (час створення акаунта).
  // Рівно ОДИН рядок на аккаунт. СТАРІ ТАБЛИЦІ ЛІКВІДОВАНО (просив власник):
  //   user_settings — налаштування тепер живуть у users.settings;
  //   devices       — повністю перероблено в нову таблицю device
  //                   (пристрій + власник + його налаштування, WRITE-ONLY).
  cfExec('CREATE TABLE IF NOT EXISTS users (user_id TEXT PRIMARY KEY, name TEXT, email TEXT, pic TEXT, ts INTEGER, role TEXT DEFAULT \'user\', sync INTEGER DEFAULT 1, beta INTEGER DEFAULT 0, logins INTEGER DEFAULT 0, settings TEXT, sver TEXT, sts INTEGER, created INTEGER)', [], function (r) {
    if (r === null) cfInitTried = false;
  });
  cfExec('DROP TABLE IF EXISTS user_settings', [], null);
  cfExec('DROP TABLE IF EXISTS devices', [], null);
  // 2.9.0: журнал пристроїв власника: id, чей пристрій (Firebase UID), що це,
  // і ОСТАННІЙ знімок налаштувань. Пишеться при КОЖНОМУ запуску і при кожній
  // зміні налаштувань; НІКОЛИ не читається — навіть з вимкненою синхронізацією
  // сервер бачить актуальний стан пристрою.
  cfExec('CREATE TABLE IF NOT EXISTS device (did TEXT PRIMARY KEY, user_id TEXT, type TEXT, name TEXT, model TEXT, os TEXT, ver TEXT, settings TEXT, first_seen INTEGER, last_seen INTEGER)', [], function (r) {
    if (r === null) cfInitTried = false;
  });
  // 2.8.9: нові колонки users для існуючої бази (ALTER падає тихо, якщо вже є)
  cfExec('ALTER TABLE users ADD COLUMN logins INTEGER DEFAULT 0', [], null);
  cfExec('ALTER TABLE users ADD COLUMN settings TEXT', [], null);
  cfExec('ALTER TABLE users ADD COLUMN sver TEXT', [], null);
  cfExec('ALTER TABLE users ADD COLUMN sts INTEGER', [], null);
  cfExec('ALTER TABLE users ADD COLUMN created INTEGER', [], null);
}
function loadRemoteCfg() { /* 2.7.2: конфіг не потрібен — токен у хості, D1 вбудовано */ }

// --- пристрій у базі (2.9.0) ---
// Реєстр /stats/devices та таблиця devices ЛІКВІДОВАНО (див. d1Init):
// тепер є тільки таблиця device — WRITE-ONLY журнал (did, власник, знімок
// налаштувань), що оновлюється при кожному запуску (devicePing).
function visitPing() { /* 2.7.2: візити більше нікуди не пишемо — є device */ }
function devId() {
  let d = '';
  try { d = localStorage.getItem('fh_did') || ''; } catch (e) {}
  if (d) return d;
  const raw = (navigator.userAgent || '') + '|' + (screen.width || 0) + 'x' + (screen.height || 0) +
              '|' + Date.now() + '|' + Math.random();
  let h1 = 0x811c9dc5, h2 = 0x46e3c1a7;
  for (let i = 0; i < raw.length; i++) {
    const c = raw.charCodeAt(i);
    h1 = ((h1 ^ c) * 16777619) >>> 0;
    h2 = ((h2 * 31) + c) >>> 0;
  }
  d = 'd' + h1.toString(36) + h2.toString(36);
  try { localStorage.setItem('fh_did', d); } catch (e) {}
  return d;
}
// інформація про пристрій: ПК — хост передає залізо в window.__fhDevInfo,
// телефон — AndroidHost.devInfo() (модель/андроїд/пам'ять)
function collectDevInfo() {
  const o = { type: ANDROID ? 'phone' : 'pc' };
  if (ANDROID) {
    try {
      const j = JSON.parse(AndroidHost.devInfo() || '{}');
      for (const k in j) o[k] = j[k];
    } catch (e) {}
    if (!o.name) o.name = 'Телефон';
  } else {
    try {
      const j = window.__fhDevInfo || {};
      for (const k in j) o[k] = j[k];
    } catch (e) {}
    if (!o.name) o.name = 'Комп\u2019ютер';
  }
  return o;
}
// ---------- пристрій у базі (2.9.0: таблиця device — WRITE-ONLY) ----------
// КОЖЕН запуск програми пише рядок про цей пристрій: id, ВЛАСНИК (Firebase UID
// аккаунта), ім'я/модель/ОС, версія і ЗНІМОК налаштувань. З таблиці НІКОЛИ
// не читаємо: навіть коли синхронізацію вимкнено, сервер бачить останній
// стан пристрою — але нічого з неї не повертається на пристрій.
let _statBusy = false;
function deviceSnapshot() {
  const g = {};
  for (const ok in OLDKEY) if (S && (S[OLDKEY[ok]] === 1 || S[OLDKEY[ok]] === 2)) g[ok] = S[OLDKEY[ok]];
  return JSON.stringify({ g: g, n: { on: !!NOTIF.on, min: NOTIF.min, snd: !!NOTIF.snd }, z: (typeof ZOOM !== 'undefined' && ZOOM.mode) ? ZOOM.mode : 'app', th: (typeof THEME !== 'undefined') ? THEME : '', t: Date.now(), v: APP_VER, sync: ACC.sync ? 1 : 0 });
}
function deviceWrite() {
  if (!cfOk()) return;
  /* 2.9.1: пристрій пишемо ЛИШЕ коли відомий власник (акаунт) — рядків з
     пустим user_id більше не буде; write-only дзеркало, з нього не читаємо */
  const k = userKey(ACC.user);
  if (!k) return;
  const d = collectDevInfo();
  let f = 0;
  try { f = JSON.parse(localStorage.getItem('fh_first') || 'null') || 0; } catch (e) {}
  if (!f) { f = Date.now(); try { localStorage.setItem('fh_first', JSON.stringify(f)); } catch (e2) {} }
  cfExec('INSERT INTO device (did, user_id, type, name, model, os, ver, settings, first_seen, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?) ' +
         'ON CONFLICT(did) DO UPDATE SET user_id=excluded.user_id, type=excluded.type, name=excluded.name, ' +
         'model=excluded.model, os=excluded.os, ver=excluded.ver, settings=excluded.settings, last_seen=excluded.last_seen',
    [devId(), k, String(d.type || ''), String(d.name || ''), String(d.model || ''),
     String(d.os || ''), APP_VER, deviceSnapshot(), f, Date.now()], null);
}
function devicePing() {
  if (_statBusy) return;
  _statBusy = true;
  const go = function () { _statBusy = false; deviceWrite(); };
  // на ПК чекаємо на залізо від хоста (до 4 с), щоб запис одразу був повним
  if (!ANDROID && !window.__fhDevInfo) { setTimeout(function () { _statBusy = false; devicePing(); }, 4000); return; }
  go();
}

// ================= АКАУНТ / ВХІД ЧЕРЕЗ GOOGLE (2.7.2) =================
// Канал: програма створює ключ у D1 (auth_cb) -> сайт входу пише туди профіль
// Google -> програма його забирає й видаляє. Firebase /stats НЕ використовується.
const SITE_URL = 'https://fluxhelper.pages.dev/';
const ROLEL = { user: 'Користувач', admin: 'Адмін', developer: 'Розробник' };
let ACC = { user: null, role: 'user', sync: true, beta: false };
let authReady = false, agT = 0, agState = '', syncT = 0, syncLastTs = 0, LAST_NOTIF = null;
let gateAccountGone = false;   // 2.9.1: гейт відкривається через «аккаунт видалено з бази»
let cfLast = 0, agRetry = false;   // 2.7.3: статус останньої хмарної відповіді + авто-повтор входу
try {
  const _u = JSON.parse(localStorage.getItem('fh_user') || 'null');
  if (_u && _u.sub && _u.name) ACC.user = { sub: String(_u.sub), name: String(_u.name), email: String(_u.email || ''), pic: String(_u.pic || '') };
} catch (e) {}
try { ACC.sync = localStorage.getItem('fh_sync') !== '0'; } catch (e) {}
try { ACC.beta = localStorage.getItem('fh_beta') === '1'; } catch (e) {}
try { syncLastTs = parseInt(localStorage.getItem('fh_sync_ts') || '0', 10) || 0; } catch (e) {}

function staff() { return ACC.role === 'admin' || ACC.role === 'developer'; }
function normRole(r) { if (r === 'development') return 'developer'; return (r === 'admin' || r === 'developer') ? r : 'user'; }

// ---------- гейт входу ----------
function gateShow() {
  const g = byId('agate'); if (g) g.classList.remove('hidden');
  document.body.classList.add('gate-on');
  host('fh:view|login');   // 2.7.6: на панелі ховаємо сегмент (тільки вхід)   // 2.7.3: сховати вкладки, доки немає входу
  const lg = byId('agLogo'); if (lg) lg.innerHTML = '<img src="' + LOGO + '" width="56" height="56" style="display:block;border-radius:16px">';
  // сплеш ховаємо — інакше він перехоплює кліки поверх гейта
  const b = byId('boot');
  if (b && !b.classList.contains('hidden')) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 480); }
  // майстер груп, що відкрився за гейтом, прибираємо (перехоплює кліки)
  if (groupsOpen()) closeGroups();
}
function gateHide() { const g = byId('agate'); if (g) g.classList.add('hidden'); document.body.classList.remove('gate-on'); }
function setAgStat(t, cls) { const s2 = byId('agStat'); if (s2) { s2.className = 'ag-stat' + (cls ? ' ' + cls : ''); s2.innerHTML = t || ''; } }
function gateLock(on) { host('fh:gatelock|' + (on ? '1' : '0')); }
function gateStart() {
  gateShow(); gateLock(true);
  agState = '';
  /* 2.9.1: якщо аккаунт викидано за відсутності в базі — пояснюємо це
     на екрані входу. Прапор читається з localStorage: хост після fh:logout
     ПЕРЕЗБИРАЄ ui.html, і заново зібраний гейт має показати ту саму
     причину (після показу прапор стирається — на наступний запуск не лишається). */
  let gone = gateAccountGone;
  gateAccountGone = false;
  try {
    if (localStorage.getItem('fh_gone_msg') === '1') gone = true;
    localStorage.removeItem('fh_gone_msg');
  } catch (e) {}
  if (gone) {
    setAgStat('Акаунт видалено з бази — увійдіть іншим Google-акаунтом.', 'err');
    const as2 = byId('agSub'); if (as2) as2.textContent = 'Аккаунт недійсний. Увійдіть знову, щоб користуватись програмою.';
  } else {
    setAgStat('');
    const as3 = byId('agSub');
    if (as3) as3.textContent = 'Увійди в акаунт Google — розклад, групи та налаштування житимуть на всіх твоїх пристроях.';
  }
  const gb = byId('agGo'); if (gb) gb.disabled = false;
  const gt = byId('agGoT'); if (gt) gt.textContent = 'Увійти через Google';
}
function fhRandHex(nBytes) {
  let s = ''; const c = '0123456789abcdef';
  for (let i = 0; i < nBytes * 2; ++i) s += c.charAt(Math.floor(Math.random() * 16));
  return s;
}
let authPollT = 0;
function authPollDb(st) {
  // 2.8.1: резервний канал входу — сайт пише профіль у Firebase auth_cb/<state>,
  // програма опитує цей ключ, поки не прийде профіль (до 4 хв)
  clearTimeout(authPollT);
  if (!st) return;
  const t0 = Date.now();
  const tick = function () {
    if (ACC.user || agState !== st) return;   // увійшли / сесію скасовано
    fetch(DB_URL + '/update/auth_cb/' + st + '.json', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (ACC.user || agState !== st) return;
        if (j && j.d && j.d.sub) {
          const p = j.d;
          // 2.8.3: сайт віддає picture (OpenID) і fid (Firebase UID) — обидва більше не губляться
          // 2.8.7: + tok (Google access_token) — ним ПК сам добуде fid через fbauth.html
          const u2 = { sub: String(p.sub), name: String(p.name || 'Користувач'), email: String(p.email || ''), pic: String(p.picture || p.pic || '') };
          if (p.fid) u2.fid = String(p.fid);
          if (p.tok) u2.tok = String(p.tok);
          authAccept(u2);
          dbDel('/update/auth_cb/' + st);
        } else if (Date.now() - t0 < 240000) {
          authPollT = setTimeout(tick, 1500);
        } else if (ANDROID) {
          agFail('Час входу вийшов. Натисни «Увійти через Google» ще раз.');
        }
      })
      .catch(function () {
        if (!ACC.user && agState === st && Date.now() - t0 < 240000) authPollT = setTimeout(tick, 2500);
      });
  };
  tick();
}
function authStart() {
  if (UPD.avail) return;
  // 2.8.1 — ВХІД ЧЕРЕЗ САЙТ (стара схема, яка працювала):
  // програма відкриває СИСТЕМНИЙ БРАУЗЕР зі сторінкою входу на сайті
  // FluxHelper (fluxhelper.pages.dev/auth), там звичайний Google-вхід,
  // і профіль САМОВІЛЬНО повертається в програму:
  //   канал 1 (ПК): локальний слухач 127.0.0.1:<порт> — миттєво,
  //                  без жодних вікон «відкрити програму?» і схем у реєстрі
  //   канал 2 (усі): Firebase auth_cb/<state> — резервне опитування
  agState = '';
  try { localStorage.removeItem('fh_auth_state'); } catch (e) {}
  const gb = byId('agGo'); if (gb) gb.disabled = true;
  setAgStat('<span class="spin"></span>Відкриваю сайт входу…');
  let started = false;
  if (ANDROID) {
    const st = fhRandHex(12);
    agState = st;
    try { AndroidHost.login(st); started = true; } catch (e) {}
    if (started) authPollDb(st);
    else agState = '';
  } else {
    started = host('fh:login');
  }
  if (!started) agFail('Не вдалося відкрити вхід. Спробуй ще раз.');
}
function agFail(msg) {
  const gb = byId('agGo'); if (gb) gb.disabled = false;
  const gt = byId('agGoT'); if (gt) gt.textContent = 'Спробувати ще раз';
  setAgStat(msg, 'err');
}
function usersUpsert(u) {
  // 2.8.9: ОДНА ТАБЛИЦЯ users = профіль + налаштування. Ключ рядка — ЛИШЕ
  // Firebase UID (довгий ID з Firebase Authentication, напр. OGXI6ddPV7QFqQaJD1YWcNiVT263).
  // ЧИСЛОВИХ КЛЮЧІВ (Google sub / 'g:<sub>') БІЛЬШЕ НЕ СТВОРЮЄМО — без fid запису нема.
  // При СТВОРЕННІ рядка одразу пишемо стандартні налаштування (групи не вибрані,
  // тема standard, сповіщення 5 хв): settings/created/sver/sts у ON CONFLICT НЕ торкаємось —
  // тому вони заповнюються лише один раз, при створенні акаунта.
  const k = userKey(u);
  if (!k) return;
  const now = Date.now();
  cfExec('INSERT INTO users (user_id, name, email, pic, ts, logins, created, settings, sver, sts) VALUES (?,?,?,?,?,1,?,?,?,?) ' +
         'ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, email=excluded.email, pic=excluded.pic, ts=excluded.ts, logins=COALESCE(users.logins,0)+1',
         [k, (u && u.name) || '', (u && u.email) || '', (u && u.pic) || '', now, now, defaultSettings(), APP_VER, now], null);
  if (u && u.fid) usersMigrateLegacy(String(u.fid));
}
/* 2.8.9: стандартний знімок налаштувань для НОВОГО акаунта: групи не вибрані,
   тема standard, сповіщення увімкнені (5 хв, звук), Zoom через додаток */
function defaultSettings() {
  // 2.9.0: СТАНДАРТНІ налаштування нового аккаунта (власник): сповіщення про
  // початок уроку ВИМКНЕНІ, Zoom через додаток, підтвердження вимкнено,
  // групи НЕ вибрані (0) — майстер груп проведе, тема стандартна
  return JSON.stringify({ g: {}, n: { on: false, min: 5, snd: true }, z: 'app', th: 'standard', t: Date.now(), v: APP_VER, sync: 1 });
}
/* 2.8.5: переливаємо роль/синк/бету зі старих ключів — і «sub» (2.8.0),
   і «g:<sub>» (2.8.2) — у єдиний ключ Firebase UID, старі рядки ВИДАЛЯЄМО:
   2.8.9 = один аккаунт => РІВНО ОДИН рядок у users (за Firebase UID) */
function usersMigrateLegacy(fid) {
  if (!fid || !ACC.user) return;
  const legacySub = String(ACC.user.sub || ''), legacyG = 'g:' + legacySub;
  if (!legacySub) return;
  /* 2.9.1: колонок sub/beta більше нема — міграція = стерти застарілі
     рядки старих ключів. Актуальні дані вже під Firebase UID. */
  cfExec('DELETE FROM users WHERE (user_id=? OR user_id=?) AND user_id != ?',
         [legacySub, legacyG, String(fid)], null);
}
/* 2.8.9: КЛЮЧ КОРИСТУВАЧА В D1 = ЛИШЕ Firebase UID. Числових ключів більше нема:
   якщо fid ще не здобуто (healFid/fbAuthRegister) — повертаємо '' і всі записи
   пропускаємо, доки fid не з'явиться */
function userKey(u) {
  u = u || ACC.user;
  return (u && u.fid) ? String(u.fid) : '';
}
/* ---- 2.8.2: злиття дзеркал (users_mirror / settings_mirror) у D1 ----
   Викликається щоразу, коли D1 відповіла успіхом; тротлінг 3 хв. Так дані
   про юзерів/сетинги доїжджають до Cloudflare навіть якщо нативний міст
   лежав під час входу (проксі/фаєрвол), а ожив пізніше. */
function accApplyAuth(rows) {
  if (rows && rows[0]) {
    ACC.role = normRole(rows[0].role);
    ACC.sync = (rows[0].sync === 0) ? false : true;
    /* 2.9.1: колонки beta в таблиці більше нема — прапорець бета-оновлень
       живе в localStorage пристрою (fh_beta), читається при старті */
    try { localStorage.setItem('fh_sync', ACC.sync ? '1' : '0'); } catch (e) {}
  }
  refreshAccUI(); applyDevVis(); renderDevSec();
}
/* 2.8.7: ПК також добуває fid через прихований iframe на fbauth.html (сайт):
   якщо канал входу не встиг зареєструвати юзера у Firebase (fid пустий),
   обмін робиться звідси — так само, як на телефоні. */
function fbAuthRegister(tok, cb) {
  try {
    if (!tok || String(tok).length < 10) { if (cb) cb(null); return; }
    const fr = document.createElement('iframe');
    fr.style.cssText = 'position:fixed;width:1px;height:1px;left:-9px;top:-9px;opacity:0;border:0';
    fr.setAttribute('aria-hidden', 'true');
    let done = false;
    const fin = function (fid) {
      if (done) return; done = true;
      try { fr.remove(); } catch (e) {}
      try { window.removeEventListener('message', onMsg); } catch (e2) {}
      if (cb) cb(fid || null);
    };
    const onMsg = function (ev) {
      try {
        const d = ev && ev.data;
        if (d && d.__fhFb) fin(d.__fhFb.ok ? (d.__fhFb.localId || null) : null);
      } catch (e) {}
    };
    window.addEventListener('message', onMsg);
    fr.src = 'https://fluxhelper.pages.dev/fbauth.html#t=' + encodeURIComponent(String(tok));
    document.body.appendChild(fr);
    setTimeout(function () { fin(null); }, 15000);
  } catch (e) { if (cb) cb(null); }
}
/* 2.8.7: ЄДИНИЙ КЛЮЧ = Firebase UID. Поки fid невідомий — healFid -> fbAuthRegister. */
function ensureFid(cb) {
  if (!ACC.user || ACC.user.fid) { if (cb) cb(); return; }
  healFid(function () {
    if (!ACC.user || ACC.user.fid) { if (cb) cb(); return; }
    if (ACC.user.tok) {
      fbAuthRegister(ACC.user.tok, function (fid) {
        if (fid && ACC.user && !ACC.user.fid) {
          ACC.user.fid = String(fid);
          try { localStorage.setItem('fh_user', JSON.stringify(ACC.user)); } catch (e) {}
        }
        if (cb) cb();
      });
    } else if (cb) cb();
  });
}
function authAccept(u) {
  if (!u || !u.sub) return;
  ACC.user = u;
  try { localStorage.setItem('fh_user', JSON.stringify(u)); } catch (e) {}
  clearTimeout(agT);
  clearTimeout(authPollT);
  agState = '';
  try { localStorage.removeItem('fh_auth_state'); } catch (e) {}
  authReady = true;
  usersUpsert(u);
  gateHide(); gateLock(false);
  /* 2.9.1: МИТТЄВЕ рішення — групи локально порожні => майстер відкривається
     ЗАРАЗ, без жодного очікування хмари. Раніше вікно чекало відповіді D1
     (на повільній мобільній мережі — до хвилини). Хмара досі головна:
     якщо в аккаунта групи реально є — syncApply їх застосує і майстер
     закриється сам за секунду (closeGroups у syncApply). */
  if (!S) { showMain(true); openGroups(); } else { showMain(); render(); }
  refreshAccUI();
  const rk = userKey(ACC.user);
  if (rk) cfExec('SELECT role, sync FROM users WHERE user_id=?', [rk], function (rows) { accApplyAuth(rows); });
  // 2.8.7: fid не прийшов із каналу входу — добуваємо (healFid -> fbAuthRegister);
  // після прибуття — usersUpsert під fid + МИТТЄВА міграція g:/sub-рядків.
  if (u.tok && !u.fid) {
    ensureFid(function () {
      if (!ACC.user || ACC.user.fid || ACC.user.sub !== u.sub) return;
      usersUpsert(ACC.user);
      syncPull(false);
      const rk2 = userKey(ACC.user);
      if (rk2) cfExec('SELECT role, sync FROM users WHERE user_id=?', [rk2], function (rows) { accApplyAuth(rows); });
    });
  }
  syncPull(true);       // 2.8.7: хмара вирішує FIRST — новий аккаунт = майстер груп
  syncWatchStart();     // 2.8.6: реальний час — тема/групи з інших пристроїв доїжджають самі
  if (typeof evalPendUpd === 'function') evalPendUpd();
  toast('Вітаємо, ' + (u.name || 'друже') + '!');
}
function authLogout() {
  ACC.user = null; ACC.role = 'user'; ACC.sync = true;
  syncWatchStop();   // 2.8.6: годинник синку зупиняємо одразу
  // 2.8.6: ПОВНЕ стирання слідів акаунта на стороні інтерфейсу ДО перезбору:
  // профіль, state входу, часовий замок синку, прапорці sync/beta — щоб
  // жоден механізм відновлення сесії не міг «оживити» акаунт
  try {
    localStorage.removeItem('fh_user');
    localStorage.removeItem('fh_auth_state');
    localStorage.removeItem('fh_sync_ts');
    localStorage.removeItem('fh_sync');
    localStorage.removeItem('fh_beta');
  } catch (e) {}
  cleanLocalGroups();   // 2.9.0: наступний аккаунт стартує з ЧИСТИМИ групами (майстер)
  syncLastTs = 0;
  clearTimeout(syncT);
  clearTimeout(authPollT);
  agState = '';
  authReady = false;
  refreshAccUI(); applyDevVis();
  // 2.8.6: ГОЛОВНИЙ ФІКС «після виходу можна користуватись програмою» —
  // гейт входу показуємо НЕГАЙНО (як на телефоні), ще ДО того, як хост
  // перезбере ui.html. Раніше ми лиш покладались на хост: якщо стирання
  // даних браузера/навігація тягнулись або зривались — старий UI лишався
  // повністю робочим без акаунта. Тепер гейт перекриває ВСЕ миттєво,
  // кнопки/вкладки недоступні (gateLock -> fh:close = згортання), і лише
  // вхід знімає блокування.
  gateStart();
  // 2.8.5: КОРИСТУВАЧ МАВ ПРАВУ НА ПОВНИЙ ВИХІД: чистимо g_cfg у settings.json
  // (раніше саме він повертав акаунт після перезапуску) + стираємо cookies/storage
  // хост перезбирає ui.html із нульовим збереженим акаунтом -> чистий гейт входу
  // (2.8.8: ім'я плейсхолдера авторизації в коментарях НЕ писати дослівно —
  //  ReplaceFirst хоста влучав у коментар замість коду нижче, і сесія з
  //  settings.json не відновлювалась після стирання браузерних даних!)
  host('fh:logout');
}
/* 2.8.5 (2.9.1: спрощено) — старі збірки/запасні канали писали рядок
   під 'g:<sub>' або 'sub'. Тепер колонок sub/beta в таблиці нема, а
   міграція = просто стерти застарілі рядки: актуальні дані живуть під
   Firebase UID, і один аккаунт = один рядок. */
function healFid(cb) {
  if (!ACC.user || ACC.user.fid || !ACC.user.email) { if (cb) cb(); return; }
  cfExec('SELECT user_id FROM users WHERE email=? LIMIT 1', [String(ACC.user.email)], function (rows) {
    if (rows && rows[0] && rows[0].user_id) {
      const k = String(rows[0].user_id);
      if (k.length >= 20 && k.indexOf('g:') !== 0 && k !== String(ACC.user.sub || '')) {
        ACC.user.fid = k;
        try { localStorage.setItem('fh_user', JSON.stringify(ACC.user)); } catch (e) {}
      }
    }
    if (cb) cb();
  });
}
function accBoot() {
  refreshAccUI(); applyDevVis();
  if (ACC.user) {
    authReady = true;
    gateLock(false);
    healFid(function () {
      // 2.8.9: один ключ — Firebase UID. Жодних перевірок за числовими ключами
      const k = userKey(ACC.user);
      if (!k) { gateStart(); return; }   // fid не відновити -> вхід заново
      /* 2.9.1: ПЕРЕВІРКА АКТУАЛЬНОСТІ — рядка в D1 нема (D1 доступна) =>
         аккаунт видалили з бази: підтверджуємо повторним запитом і
         викидаємо з Google-акаунта (forceAccountGone). */
      cfExec('SELECT role, sync FROM users WHERE user_id=?', [k], function (rows) {
        if (rows && rows[0]) {
          accApplyAuth(rows);
          usersUpsert(ACC.user);
          syncPull(false);
          syncWatchStart();   // 2.8.6: сесію відновлено — спостерігач знову в строю
        } else if (rows) {
          confirmAccountGone();   // 2.9.1: одночатний повтор, потім викид
        }
        // rows === null -> D1 недоступна -> працюємо офлайн з локальною сесією
      });
    });
  } else {
    gateStart();
  }
}
/* 2.9.1: ПЕРЕВІРКА АКТУАЛЬНОСТІ АКАУНТА. Якщо D1 ДОСТУПНА, а рядка
   користувача в таблиці users більше немає (видалено з бази) — аккаунт
   недійсний: миттєво викидаємо з акаунта, стираємо всі сліди (як authLogout)
   і показуємо гейт входу з поясненням. Google-сесію чистить хост
   (fh:logout -> cookies + settings.json), тому вхід буде «з нуля» —
   можна увійти ІНШИМ Google-акаунтом. */
function forceAccountGone(quiet) {
  if (!ACC.user) return;
  ACC.user = null; ACC.role = 'user'; ACC.sync = true; ACC.beta = false;
  syncWatchStop();
  try {
    localStorage.removeItem('fh_user');
    localStorage.removeItem('fh_auth_state');
    localStorage.removeItem('fh_sync_ts');
    localStorage.removeItem('fh_sync');
    localStorage.removeItem('fh_beta');
  } catch (e) {}
  cleanLocalGroups();
  syncLastTs = 0;
  clearTimeout(syncT); clearTimeout(authPollT);
  agState = ''; authReady = false;
  refreshAccUI(); applyDevVis();
  gateAccountGone = !quiet;   // гейт покаже пояснення замість звичайного тексту
  gateStart();
  /* 2.9.1: хост після fh:logout перезбирає ui.html — прапор у localStorage
     переживає перезбірку, і новий гейт пояснить причину виходу */
  try { localStorage.setItem('fh_gone_msg', '1'); } catch (e) {}
  host('fh:logout');          // 2.8.5: чистимо g_cfg у settings.json + cookies WebView
}
/* підтвердження «рядок справді зник» — один повторний запит через 3 с,
   щоб не викинути щойно створений аккаунт у гонці INSERT/SELECT */
let goneChkT = 0;
function confirmAccountGone() {
  if (!ACC.user) return;
  clearTimeout(goneChkT);
  goneChkT = setTimeout(function () {
    const k = userKey(ACC.user); if (!k) return;
    cfExec('SELECT user_id FROM users WHERE user_id=?', [k], function (rows) {
      if (ACC.user && rows && !rows[0]) forceAccountGone(false);
    });
  }, 3000);
}

// ---------- акаунт: сторінка профілю ----------
function avaHtml(u) {
  if (u && u.pic) return '<img src="' + escH(u.pic) + '" referrerpolicy="no-referrer" alt="">';
  return escH(((u && u.name) || '?').charAt(0).toUpperCase());
}
function refreshAccUI() {
  // 2.8.0: кнопка акаунта в титульній панелі (аватар + ім'я + пошта) — весь елемент клікабельний
  const tAcc = byId('tbAcc'); if (tAcc) tAcc.style.display = ACC.user ? 'flex' : 'none';
  const tAva = byId('tbAccAva'); if (tAva) tAva.innerHTML = ACC.user ? avaHtml(ACC.user) : '';
  const tNm = byId('tbAccName'); if (tNm) tNm.textContent = ACC.user ? (ACC.user.name || 'акаунт') : '—';
  const tMl = byId('tbAccMail'); if (tMl) tMl.textContent = ACC.user ? (ACC.user.email || '') : '';
  const big = byId('acAva'); if (big) big.innerHTML = ACC.user ? avaHtml(ACC.user) : '?';
  const nm = byId('acName'); if (nm) nm.textContent = ACC.user ? ACC.user.name : '—';
  const ml = byId('acMail'); if (ml) ml.textContent = ACC.user ? (ACC.user.email || '') : '';
  const rl = byId('acRole');
  if (rl) { const r = ACC.role; rl.textContent = ROLEL[r] || r; rl.className = 'ac-role r-' + r; }
  const sc = byId('acSync'); if (sc) sc.checked = !!ACC.sync;
  // 2.8.5: ID користувача більше НЕ показуємо в профілі — ключ (Firebase UID)
  // використовується лише всередині для D1/синку, щоб ніхто не плутався
  // 2.7.6: компактна картка «Акаунт» у налаштуваннях — ЗНЕСЕНО в 2.9.1 (пустий квадрат)
  const c2 = byId('ac2Card'); if (c2 && c2.parentNode) c2.parentNode.removeChild(c2);
}
function showAcc() {
  if (!ACC.user) { gateStart(); return; }
  closeDrawer();
  byId('vMain').classList.add('hidden');
  byId('vSetup').classList.add('hidden');
  const _vd3 = byId('vDev'); if (_vd3) _vd3.classList.add('hidden');   // 2.7.3
  document.body.setAttribute('data-view', 'acc');
  const v = byId('vAcc'); if (v) { v.classList.remove('hidden'); v.scrollTop = 0; }
  // 2.8.6: активна вкладка просто ВТРАЧАЄ фіолетову підсвітку (setSeg без
  // збігів знімає .on з усіх кнопок). Раніше .on лишався, а його «сірий»
  // вигляд у профілі перебивався CSS-правилом — через це ламались ховер
  // (правило з вищою специфічністю било :hover) і кольори в світлій темі.
  setSeg('acc');
  markNav('acc');
}
function accBack() {
  const v = byId('vAcc'); if (v) v.classList.add('hidden');
  if (FIRST) showSetup(); else showMain();
}

// ---------- синхронізація налаштувань (Cloudflare D1) ----------
// ПИШЕМО завжди (сервер тримає останній знімок акаунта), ЗАСТОСОВУЄМО з сервера
// лише коли тумблер «Синхронізація» увімкнений — або разово на вході (force).
function syncUp(now) {
  if (!ACC.user) return;
  clearTimeout(syncT);
  syncT = setTimeout(function () {
    if (!ACC.user) return;
    const g = {};
    for (const ok in OLDKEY) if (S && (S[OLDKEY[ok]] === 1 || S[OLDKEY[ok]] === 2)) g[ok] = S[OLDKEY[ok]];
    // 2.8.6: знімок БЕЗ sub — ідентифікація ЛИШЕ за Firebase UID (user_id).
    // Тема (th) у знімку; тумблер sync — теж.
    const p = { g: g, n: { on: !!NOTIF.on, min: NOTIF.min, snd: !!NOTIF.snd }, z: (typeof ZOOM !== 'undefined' && ZOOM.mode) ? ZOOM.mode : 'app', th: (typeof THEME !== 'undefined') ? THEME : '', t: Date.now(), v: APP_VER, sync: ACC.sync ? 1 : 0 };
    const k = userKey(ACC.user);
    if (!k) return;   // 2.8.9: без Firebase UID записів нема (жодних числових ID)
    // 2.8.9: налаштування живуть В РЯДКУ КОРИСТУВАЧА (users.settings) — одна таблиця
    cfExec('INSERT INTO users (user_id, settings, sver, sts, email, name, pic, ts) VALUES (?,?,?,?,?,?,?,?) ' +
           'ON CONFLICT(user_id) DO UPDATE SET settings=excluded.settings, sver=excluded.sver, sts=excluded.sts, ' +
           'email=excluded.email, name=excluded.name, pic=excluded.pic, ts=excluded.ts',
           [k, JSON.stringify(p), APP_VER, p.t, (ACC.user.email || ''), (ACC.user.name || ''), (ACC.user.pic || ''), Date.now()], function (rows) {
      if (rows) {
        syncLastTs = p.t; try { localStorage.setItem('fh_sync_ts', String(p.t)); } catch (e) {}
        deviceWrite();   // 2.9.0: знімок налаштувань пристрою теж оновлюється
      } else {
        // 2.8.2: D1 недоступна -> дзеркало сетингів у Firebase (доїде до D1 пізніше)
        try {
          dbPut('/update/settings_mirror/' + fbEnc(k.replace(/[^A-Za-z0-9_-]/g, '_')),
                { d: { fid: k, settings: JSON.stringify(p), v: APP_VER }, t: p.t }, null);
        } catch (e3) {}
      }
    });
  }, now ? 30 : 350);   // 2.8.6: 350 мс замість 1200 — зміни доїжджають миттєво,
                        // навіть якщо закрити програму одразу після зміни
}
function syncApply(p, force) {
  if (!p || typeof p !== 'object' || !ACC.user) return;
  if (!ACC.sync && !force) return;
  const t = parseInt(p.t, 10) || 0;
  // 2.8.5: КНОПКА «Синхронізувати дані» (force) оминає часовий замок —
  // раніше власний пізніший знімок ПК блокував підтягування теми з телефона
  if (!t || (!force && t < syncLastTs)) return;
  let ch = false, gok = false;
  if (p.g && typeof p.g === 'object') {
    const m = {};
    for (const ok in OLDKEY) { const v = p.g[ok]; if (v === 1 || v === 2) m[OLDKEY[ok]] = v; }
    if (validS(m)) {
      if (JSON.stringify(m) !== JSON.stringify(S || {})) {
        S = m;
        try { localStorage.setItem('fh_groups2', JSON.stringify(S)); } catch (e) {}
        try { localStorage.setItem('fh_groups', JSON.stringify(oldKeyMap(S))); } catch (e2) {}
        FIRST = false; ch = true;
      } else if (FIRST) {
        // 2.8.7: групи в хмарі є і вони вже застосовані — майстер більше не обов'язковий
        FIRST = false;
      }
      gok = true;
    }
  }
  if (p.n && typeof p.n === 'object') {
    const on = !!p.n.on, mn = (p.n.min >= 1 && p.n.min <= 15) ? p.n.min : 5, sd = (p.n.snd !== false);
    if (on !== NOTIF.on || mn !== NOTIF.min || sd !== !!NOTIF.snd) { NOTIF = { on: on, min: mn, snd: sd }; saveNotif(); refreshNotifUI(); ch = true; }
  }
  if ((p.z === 'app' || p.z === 'web') && typeof ZOOM !== 'undefined' && p.z !== ZOOM.mode) { ZOOM.mode = p.z; saveZoom(); refreshZoomUI(); ch = true; }
  // 2.8.5: тема із хмари — застосовуємо одразу (тема з телефона тепер доїжджає на ПК)
  if (p.th && typeof THEME !== 'undefined' && THEME_LIST.indexOf(p.th) >= 0 && p.th !== THEME) { applyTheme(p.th, false); ch = true; }
  if (t > syncLastTs) syncLastTs = t;   // монотонно: force-тягнення старішого знімка не «відкочує» замок
  try { localStorage.setItem('fh_sync_ts', String(syncLastTs)); } catch (e) {}
  // 2.8.7: групи підтверджені хмарою -> майстер закривається сам (навіть без змін)
  if (gok && !FIRST && groupsOpen()) closeGroups();
  if (ch) {
    pushNotifSched(); render(false); if (setupOpen) buildSummary();
    // 2.8.7: тост «Синхронізовано» прибрано — зміни застосовуються тихо
  }
}
/* 2.9.0: рішення про майстер груп ПРИЙМАЄ ХМАРА, а не локальний кеш.
   Якщо в рядку users груп нема (нулі/порожньо) або рядка ще нема взагалі —
   вікно вибору груп ОБОВ'ЯЗКОВЕ (ПК і телефон однаково), і закрити його
   не можна, поки не натиснеш «Зберегти». Локальні групи минулого аккаунта
   при цьому стираються: новий аккаунт ніколи не наслідує чужі групи.
   Якщо ж у хмарі все заповнено — майстер не з'являється взагалі. */
function cleanLocalGroups() {
  S = null; FIRST = true;
  try { localStorage.removeItem('fh_groups2'); } catch (e) {}
  try { localStorage.removeItem('fh_groups'); } catch (e2) {}
}
function cloudGroupsOk(p) {
  if (!p || !p.g || typeof p.g !== 'object') return false;
  const m = {};
  for (const ok in OLDKEY) { const v = p.g[ok]; if (v === 1 || v === 2) m[OLDKEY[ok]] = v; }
  return validS(m);
}
function syncPull(force) {
  if (!ACC.user) return;
  const k = userKey(ACC.user);
  if (!k) return;   // 2.8.9: читаємо лише за Firebase UID (healFid/fbAuthRegister добудують)
  cfExec('SELECT settings, sts FROM users WHERE user_id=?', [k], function (rows) {
    if (!ACC.user) return;
    if (rows && rows[0]) {
      let p = null;
      try { p = JSON.parse(rows[0].settings); } catch (e) {}
      if (cloudGroupsOk(p)) {
        syncApply(p, force);
        // 2.8.7: групи підтягнулись із хмари під час входу -> ведемо в розклад
        if (force && !FIRST && S && setupOpen) { showMain(); render(); }
      } else {
        // 2.9.0: груп у хмарі НЕМА -> локальні недійсні, майстер обов'язковий
        cleanLocalGroups();
        showMain(true); openGroups();
      }
    } else if (rows) {
      // РЯДКА В ХМАРІ НЕМАЄ = ПЕРШИЙ ВХІД ЦЬОГО АККАУНТА — майстер обов'язковий
      cleanLocalGroups();
      showMain(true); openGroups();
    }
    // rows === null -> D1 недоступна: працюємо офлайн, нічого не ламаємо
  });
}
/* 2.8.6: РЕАЛЬНИЙ ЧАС — легке спостереження за знімком у хмарі.
   Кожні 8 с — запит ТІЛЬКИ ts (мікро-відповідь, не витрачає ліміти D1);
   повне тягнемо лише коли знімок чужий і новіший. Вимкнена синхронізація —
   годинник стоїть. Завдяки цьому зміна теми/груп на ПК доїжджає на
   телефон за кілька секунд (і навпаки) без кнопки «Синхронізувати». */
let syncWatchT = 0;
function syncWatchStop() { clearTimeout(syncWatchT); syncWatchT = 0; }
function syncWatchTick() {
  syncWatchT = 0;
  if (!ACC.user || !ACC.sync) return;           // вимкнено/не в акаунті — не маємо діла
  const k = userKey(ACC.user); if (!k) return;   // 2.8.9: лише за Firebase UID
  cfExec('SELECT sts FROM users WHERE user_id=?', [k], function (rows) {
    if (!ACC.user) return;
    /* 2.9.1: D1 відповіла, а рядка НЕМА -> аккаунт видалили з бази.
       Підтверджуємо повторним запитом і викидаємо з акаунта. */
    if (rows && !rows[0]) { confirmAccountGone(); return; }
    if (rows && rows[0]) {
      const ts = parseInt(rows[0].sts, 10) || 0;
      if (ts > syncLastTs) {
        // чужий новіший знімок — тягнемо повністю (syncApply сам оминає свій запис:
        // syncUp оновлює syncLastTs ДО повернення, тому власний запис не тригерить)
        cfExec('SELECT settings FROM users WHERE user_id=?', [k], function (rows2) {
          if (rows2 && rows2[0] && ACC.user) { try { syncApply(JSON.parse(rows2[0].settings), false); } catch (e) {} }
        });
      }
    }
    if (ACC.user && ACC.sync && !syncWatchT) syncWatchT = setTimeout(syncWatchTick, 8000);
  });
}
function syncWatchStart() {
  syncWatchStop();
  if (ACC.user && ACC.sync) syncWatchT = setTimeout(syncWatchTick, 8000);
}

// ---------- вкладка розробника (тільки Адмін/Розробник) ----------
function applyDevVis() {
  // 2.7.3: вкладка «Розробник» у перемикачі з'являється ЛИШЕ після входу
  // і лише в Адміна/Розробника. Неавторизовані її не бачать взагалі.
  const sd = byId('segDev'); if (sd) sd.style.display = (ACC.user && staff()) ? '' : 'none';
  const bt = byId('devBeta'); if (bt) bt.checked = !!ACC.beta;
  const vd = byId('vDev');
  if (vd && !vd.classList.contains('hidden') && !(ACC.user && staff())) {
    vd.classList.add('hidden');
    if (typeof showMain === 'function') showMain();
  }
}
const DEV = { rel: [], bet: [], busy: false };
function renderDevSec() { if (staff()) devListVers(); }
function devListVers() {
  if (!staff() || DEV.busy) return;
  DEV.busy = true;
  const box = byId('devVers');
  if (box) box.innerHTML = '<div class="dv-row"><span class="dv-cur">читаю список версій…</span></div>';
  const done = function () {
    DEV.busy = false;
    const b2 = byId('devVers'); if (!b2) return;
    b2.innerHTML = '';
    const row = function (v, ch) {
      const r = el('div', 'dv-row');
      r.appendChild(el('span', 'dv-v', escH(v)));
      r.appendChild(el('span', 'dv-chip ' + (ch === 'beta' ? 'bet' : 'rel'), ch === 'beta' ? 'бета' : 'реліз'));
      if (v === APP_VER) r.appendChild(el('span', 'dv-cur', 'встановлена'));
      else {
        const bt = el('button', 'b-mini dv-inst', 'Встановити');
        bt.onclick = function () { devInstall(v, ch); };
        r.appendChild(bt);
      }
      b2.appendChild(r);
    };
    DEV.bet.forEach(function (v) { row(v, 'beta'); });
    DEV.rel.forEach(function (v) { row(v, 'rel'); });
    if (!DEV.rel.length && !DEV.bet.length) b2.appendChild(el('div', 'dv-row', '<span class="dv-cur">список недоступний — перевір інтернет</span>'));
  };
  const gh = function (path, cb) {
    fetch('https://api.github.com/repos/' + UPDATE_REPO + '/contents/' + path + '?cb=' + Date.now())
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (j) { cb(Array.isArray(j) ? j : []); })
      .catch(function () { cb([]); });
  };
  gh('versions/release', function (j) {
    DEV.rel = j.filter(function (x) { return x.type === 'dir' && /^\d+\.\d+\.\d+$/.test(x.name); }).map(function (x) { return x.name; });
    gh('versions/beta', function (jb) {
      DEV.bet = jb.filter(function (x) { return x.type === 'dir' && /^\d+\.\d+\.\d+$/.test(x.name); }).map(function (x) { return x.name; });
      done();
    });
  });
}
function devInstall(v, ch) {
  const pref = (ch === 'beta') ? 'versions/beta/' : 'versions/release/';
  fetch('https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/' + pref + v + '/FluxHelper.exe?_=' + Date.now(), { method: 'HEAD', cache: 'no-store' })
    .then(function (r) {
      if (r.ok) { showUpd(v, null, false, pref); }
      else toast('Файли версії ' + v + ' ще не опубліковано');
    })
    .catch(function () { toast('Немає зв\u2019язку з GitHub'); });
}
function updCheckBeta(v) {
  if (UPD.avail || UPD.pending === v) return;
  UPD.pending = v;
  fetch('https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/versions/beta/' + v + '/FluxHelper.exe?_=' + Date.now(), { method: 'HEAD', cache: 'no-store' })
    .then(function (r) { if (!r.ok) throw 0; showUpd(v, null, false, 'versions/beta/'); })
    .catch(function () { UPD.pending = ''; fetchLatest(handleLatest); });
}

function escH(s) {
  return String(s || '').replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

// --- ТЕСТОВЕ ОНОВЛЕННЯ (UI) ---
// ---------------- банер сповіщень (телефон) ----------------
let nbanPoll = 0;
function notifPermOk() {
  if (!ANDROID) return true;
  try { return !!AndroidHost.hasNotifPerm(); } catch (e) { return true; }
}
function checkNban() {
  const b = byId('nban');
  if (!b) return;
  let off = false;
  try { off = localStorage.getItem('fh_nban') === 'off'; } catch (e) {}
  b.classList.toggle('hidden', !ANDROID || FIRST || off || notifPermOk());
}
function pollNotifPerm() {
  clearInterval(nbanPoll);
  let n = 0;
  nbanPoll = setInterval(function () {
    if (++n > 15 || notifPermOk()) {
      clearInterval(nbanPoll);
      if (notifPermOk()) {
        const b = byId('nban'); if (b) b.classList.add('hidden');
        pushNotifSched();
        toast('Сповіщення увімкнено ✓');
      }
    }
  }, 900);
}

// ---------------- ініціалізація ----------------
function buildTabs() {
  const tabs = byId('tabs');
  tabEls = [];
  DAYDEFS.forEach(function (d, i) {
    const t = el('div', 'tab' + (dow0 - 1 === i ? ' td' : ''));
    const dE = el('span', 'd'); dE.textContent = d[1];
    const dtE = el('span', 'dt'); dtE.textContent = dateStr(i);
    const dot = el('span', 'tdot');
    t.append(dE, dtE, dot);
    t.onclick = function () { sel = i; render(); };
    tabs.appendChild(t);
    tabEls.push(t);
  });
}
function hideBoot() {
  // застарілий шлях — лишено для сумісності, тепер керує bootLoop()
  const b = byId('boot');
  if (b) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 560); }
}

// ---------------- екран завантаження: плавні 100% ----------------
// Прогрес рухається 0 -> 88% (ease), і тільки коли інтерфейс готовий
// і минуло щонайменше 1.1 с — плавно дозаповнюється до 100% і лише
// потім плавно показує основний екран. Ніяких стрибків.
let bootReady = false, bootP = 0, bootRevealed = false;
const bootStart = Date.now();
const bootRaf = (typeof requestAnimationFrame === 'function')
  ? function (cb) { requestAnimationFrame(cb); }
  : function (cb) { setTimeout(cb, 33); };
function bootLoop() {
  const el = Date.now() - bootStart;
  const target = (bootReady && el >= 1100) ? 100 : Math.min(88, (el / 1500) * 88);
  bootP += (target - bootP) * ((target === 100) ? 0.14 : 0.09);
  if (target === 100 && target - bootP < 0.5) bootP = 100;
  const f = byId('btFill'), pc = byId('btPct');
  if (f) f.style.width = bootP.toFixed(1) + '%';
  if (pc) pc.textContent = Math.round(bootP) + '%';
  if (bootP >= 100) {
    if (!bootRevealed) {
      bootRevealed = true;
      const b = byId('boot');
      // 2.8.2: АНТИ-СПАЛАХ — якщо акаунта немає, ПІД завантаженням показуємо
      // гейт входу, а не головний інтерфейс: користувач НІКОЛИ не бачить
      // розклад/вкладки до входу (раніше головний екран блимав на ~0,5 с)
      if (!ACC.user) {
        // 2.8.8: якщо відкрита модалка оновлення — гейт не показуємо,
        // інакше він (z 230) перекриє її (z 120)
        if (!updOpen()) { try { gateShow(); } catch (e1) {} }
        // 'booting' ховає лого в панелі — на гейті панель має бути повна (лого зліва)
        document.body.classList.remove('booting');
        if (b) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 580); }
      } else {
        document.body.classList.add('ready');
        // 2.8.0: завантаження завершено -> у титульній панелі з'являються вкладки й акаунт
        document.body.classList.remove('booting');
        if (b) { b.classList.add('off'); setTimeout(function () { b.classList.add('hidden'); }, 580); }
      }
    }
    return;
  }
  bootRaf(bootLoop);
}
function init() {
  // 2.3.9: системні підказки (title) у WebView2 малюються криво (біля верхнього краю вікна)
  // — прибираємо їх повністю, щоб при наведенні на кнопки нічого не вискакувало.
  try {
    const fhStripTitle = function () {
      const bad = document.querySelectorAll('[title]');
      for (let i = 0; i < bad.length; ++i) bad[i].removeAttribute('title');
    };
    fhStripTitle();
    // 2.3.10: СЛІДКУЄМО ЗА DOM — динамічні елементи з title (наприклад, чіпи у
    // «Керуванні доступом») зачищаються одразу після вставки: системні підказки
    // WebView («прозора фігня» вгорі в Liquid Glass) більше ніколи не з'являться.
    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(fhStripTitle).observe(document.documentElement,
        { subtree: true, childList: true, attributes: true, attributeFilter: ['title'] });
    }
  } catch (e) {}
  if (ANDROID) { document.body.classList.add('android'); document.documentElement.classList.add('android'); }
  // 2.7.5: якщо користувача немає — режим гейта ВмиКАЄМО ЩЕ ДО зникнення сплеша:
  // титулбар одразу показує лише кнопки «Згорнути»/«Закрити» (вкладок немає),
  // тож власник більше НІКОЛИ не побачить «панельку, що блимає і зникає» —
  // кнопки накладені на екран входу з першого кадру. Якщо користувач є —
  // клас лишається тільки на час сплеша і зникає разом із показом інтерфейсу.
  try { if (!ACC.user) document.body.classList.add('gate-on'); else setTimeout(function () { document.body.classList.remove('gate-on'); }, 50); } catch (e) {}
  // лого в титульній панелі ТЕПЕР СТАТИЧНИЙ <img> у HTML — малюється разом
  // із першим кадром (раніше його вставляв JS -> «іконки вгорі немає»)
  const dwl = byId('dwLogo'); if (dwl) dwl.innerHTML = logoMark(36);
  byId('neLogo').innerHTML = logoMark(74);
  byId('upLogo').innerHTML = logoMark(74);
  byId('neRetry').onclick = function () { netProbe(true); };
  byId('updGo').onclick = startUpdate;

  const ba2 = byId('bAcc2'); if (ba2) ba2.onclick = function () { showAcc(); };
  byId('bMin').onclick = function () { host('fh:min'); };
  byId('bClose').onclick = function () { host('fh:close'); };
  const ab2 = byId('tbAcc'); if (ab2) ab2.onclick = function () { showAcc(); };   // 2.8.0: пілюля акаунта в панелі
  const ago = byId('agGo'); if (ago) ago.onclick = function () { authStart(); };
  const abk = byId('accBack'); if (abk) abk.onclick = function () { accBack(); };
  const asy = byId('acSync');
  if (asy) asy.onchange = function () {
    ACC.sync = asy.checked;
    try { localStorage.setItem('fh_sync', ACC.sync ? '1' : '0'); } catch (e) {}
    if (ACC.user) cfExec('UPDATE users SET sync=? WHERE user_id=?', [ACC.sync ? 1 : 0, userKey(ACC.user)], null);
    if (ACC.sync) {
      // 2.9.0: УВІМКНУВ -> МИТТЄВО питаємо сервер і одразу застосовуємо його
      // налаштування (без очікування 8-секундного годинника); після цього
      // наш знімок летить на сервер — обидві сторони сині за секунду
      syncPull(true);
      syncWatchStart();
      setTimeout(function () { if (ACC.user) syncUp(true); }, 1500);
    } else { syncWatchStop(); deviceWrite(); }   // вимкнено — годинник стоїть, але знімок на сервері оновлюється
    toast(ACC.sync ? 'Синхронізацію увімкнено' : 'Синхронізацію вимкнено (копія на сервері лишається)');
  };
  // 2.8.6: кнопка «Завантажити з хмари» видалена — налаштування підтягуються
  // автоматично: syncPull(true) на вході + syncWatch у реальному часі
  const aou = byId('acOut'); if (aou) aou.onclick = function () { authLogout(); };
  const dbt = byId('devBeta');
  if (dbt) dbt.onchange = function () {
    ACC.beta = dbt.checked;
    /* 2.9.1: бета-прапорець тепер ТІЛЬКИ локальний (localStorage fh_beta):
       колонки beta в базі більше нема */
    try { localStorage.setItem('fh_beta', ACC.beta ? '1' : '0'); } catch (e) {}
    toast(ACC.beta ? 'Бета-оновлення увімкнено' : 'Бета-оновлення вимкнено');
    evalPendUpd();
  };
  const dref = byId('devRef'); if (dref) dref.onclick = function () { devListVers(); };
  const dntf = byId('devNotif');
  if (dntf) dntf.onclick = function () { testNotifSound(); };   // 2.8.5: той самий реальний формат, що й кнопка в налаштуваннях
  // кінець 2.7.2 хуків
  // 2.7.6: акаунт із settings.json (хост підставляє після повернення зі сторінки
  // Google) — localStorage читається далі, вхід продовжується без перелогіну
  try {
    const A0 = __AUTH_JSON__;
    if (A0 && A0.sub && !ACC.user) {
      const p0 = { sub: String(A0.sub), name: String(A0.name || 'Користувач'), email: String(A0.email || ''), pic: String(A0.pic || '') };
      if (A0.fid) p0.fid = String(A0.fid);   // 2.8.8: fid теж відновлюємо (без healFid-запиту)
      authAccept(p0);
    }
  } catch (e) {}
  accBoot();
  // 2.7.6: помилка останнього входу — ПІСЛЯ accBoot (gateStart стирає agStat)
  try { const AERR = "__AUTH_ERR__"; if (AERR) agFail(String(AERR)); } catch (e) {}
  // вкладки в центрі титульної панелі
  const sg1 = byId('segSched'); if (sg1) sg1.onclick = function () { showMain(); };
  const sg2 = byId('segSetup'); if (sg2) sg2.onclick = function () { showSetup(); };
  const sg3 = byId('segDev'); if (sg3) sg3.onclick = function () { showDev(); };
  // режим запуску Zoom (тільки ПК)
  const zA = byId('zApp'); if (zA) zA.onclick = function () { ZOOM.mode = 'app'; saveZoom(); refreshZoomUI(); toast('Zoom відкриватиметься через додаток'); };
  const zW = byId('zWeb'); if (zW) zW.onclick = function () { ZOOM.mode = 'web'; saveZoom(); refreshZoomUI(); toast('Zoom відкриватиметься через браузер'); };
  refreshZoomUI();
  // підтвердження заходу на урок
  const cT = byId('cOn');
  if (cT) {
    cT.checked = CONFIRM.on;
    cT.onchange = function () { CONFIRM.on = cT.checked; saveConfirm(); toast(CONFIRM.on ? 'Підтвердження увімкнено ✓' : 'Підтвердження вимкнено'); };
  }
  const cY = byId('cYes'); if (cY) cY.onclick = confirmYes;
  const cN = byId('cNo'); if (cN) cN.onclick = closeConfirm;
  const cB = byId('cback'); if (cB) cB.onclick = closeConfirm;
  byId('tbar').addEventListener('mousedown', function (e) {
    // перетягування вікна за вільну зону панелі (кнопки й перемикач не чіпаємо)
    if (e.button === 0 && !(e.target && e.target.closest && e.target.closest('button'))) host('fh:drag');
  });
  // 2.8.1: ПЕРЕТЯГУВАННЯ ЗВІДСІЛЬ — за фон будь-якого екрана (розклад,
  // налаштування, акаунт, екран входу). Клікабельні елементи (кнопки, картки
  // уроків, поля, списки) перетягування НЕ перехоплюють — вони працюють як було.
  document.addEventListener('mousedown', function (e) {
    if (e.button !== 0) return;
    const t = e.target;
    if (!t || !t.closest) return;
    if (t.closest('#tbar')) return;   // вже оброблено вище
    // усе, з чим користувач взаємодіє, — не тягнемо
    if (t.closest('button,a,input,textarea,select,label,img,svg,canvas,.card,.lcard,.ag-card,.us-card,.modal,.drawer,.pill,.chip,.tab,.tb-seg,.tb-acc,.daytabs,.g-card,.s-card,.m-item,.n-row,.theme-tile,.range,.sw,[data-nodrag]')) return;
    // тягнемо лише за «порожній» фон: контейнер екрана, секцію, body
    if (t.id === 'app' || t.id === 'agate' || t.id === 'vMain' || t.id === 'vSetup' ||
        t.id === 'vAcc' || t.id === 'vDev' || t.tagName === 'BODY' || t.tagName === 'HTML' ||
        (t.classList && (t.classList.contains('view') || t.classList.contains('view-sec') ||
                         t.classList.contains('wrap') || t.classList.contains('acc-wrap') ||
                         t.classList.contains('sec')))) {
      host('fh:drag');
    }
  });
  const bgEl = byId('bGroups'); if (bgEl) bgEl.onclick = openGroups;   // на ПК кнопки немає (є перемикачі 1|2 біля предметів)
  byId('gSave').onclick = saveSettings;
  byId('gCancel').onclick = closeGroups;
  byId('gback').onclick = closeGroups;
  byId('nOn').onchange = function () { NOTIF.on = byId('nOn').checked; saveNotif(); refreshNotifUI(); pushNotifSched(); syncUp(); };
  // 2.8.0: звук сповіщень + тестове сповіщення (ПК і телефон)
  const nSndT = byId('nSnd');
  if (nSndT) nSndT.onchange = function () {
    NOTIF.snd = nSndT.checked; saveNotif(); refreshNotifUI(); pushNotifSched(); syncUp();
    if (nSndT.checked) testNotifSound();
    toast(nSndT.checked ? 'Звук сповіщень увімкнено' : 'Звук сповіщень вимкнено');
  };
  const bTN = byId('bTestN');
  if (bTN) bTN.onclick = function () { testNotifSound(); };
  const nMinSl = byId('nMin');
  if (nMinSl) {
    /* 2.9.1: ЖОРСТКА ПЕРЕВІРКА ЖЕСТІВ на слайдері «повідомити за».
       Скрол (вертикальний рух, що почався на слайдері) більше НЕ змінює
       хвилини — значення відкочується, зміни не зберігаються. Реальна
       зміна = горизонтальний рух/тап, що почався на слайдері. */
    let _t0 = null, _bad = false, _orig = NOTIF.min;
    const _paint = function () {
      nMinSl.style.setProperty('--p', (((NOTIF.min - 1) / 14) * 100).toFixed(1) + '%');
      const sv = byId('nMinVal'); if (sv) sv.textContent = NOTIF.min + ' хв';
    };
    const _revert = function () { NOTIF.min = _orig; nMinSl.value = _orig; _paint(); };
    nMinSl.addEventListener('touchstart', function (e) {
      if (!e.touches || !e.touches.length) return;
      _t0 = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      _bad = false; _orig = NOTIF.min;
    }, { passive: true });
    nMinSl.addEventListener('touchmove', function (e) {
      if (!_t0 || !e.touches || !e.touches.length) return;
      const dx = Math.abs(e.touches[0].clientX - _t0.x);
      const dy = Math.abs(e.touches[0].clientY - _t0.y);
      if (dy > 12 && dy > dx * 1.15) _bad = true;   // це вертикальний скрол
      if (_bad && parseInt(nMinSl.value, 10) !== _orig) _revert();
    }, { passive: true });
    nMinSl.addEventListener('touchend', function () { if (_bad) _revert(); _t0 = null; });
    nMinSl.addEventListener('wheel', function (e) { e.preventDefault(); }, { passive: false });
    nMinSl.oninput = function () {
      if (_bad) { _revert(); return; }
      NOTIF.min = parseInt(nMinSl.value, 10) || 5;
      _paint();
    };
    nMinSl.onchange = function () {
      if (_bad) { _revert(); return; }   // скрол нічого не зберігає
      const v = parseInt(nMinSl.value, 10) || 5;
      if (v !== _orig) { saveNotif(); pushNotifSched(); syncUp(); }
      _orig = NOTIF.min;
    };
  }
  byId('bPerm').onclick = function () { if (ANDROID) { try { AndroidHost.requestNotifPerm(); pollNotifPerm(); } catch (e) {} } };
  // 2.3.9: 5-тапний режим прибрано — рамки «Про програму» більше немає.
  // Вкладка «Розробник» відкривається лише за роллю (DEV-прапорець або admin).
  // 2.3.7: перемикач синхронізації
  devicePing();   // 2.9.0: запис пристрою в базу при кожному запуску
  byId('mback').onclick = closeModal;
  byId('nbOn').onclick = function () {
    if (ANDROID) { try { AndroidHost.requestNotifPerm(); pollNotifPerm(); } catch (e) {} }
  };
  byId('nbX').onclick = function () {
    try { localStorage.setItem('fh_nban', 'off'); } catch (e) {}
    byId('nban').classList.add('hidden');
  };
  window.addEventListener('keydown', function (e) {
    if (updOpen()) return;   // блокуюча модалка оновлення — керування вимкнено
    if (e.key === 'Escape') {
      if (groupsOpen()) { closeGroups(); return; }
      const cw2 = byId('cwrap');
      if (cw2 && !cw2.classList.contains('hidden')) { closeConfirm(); return; }
      if (drawerOpen()) { closeDrawer(); return; }
      closeModal();
      return;
    }
    if (setupOpen) return;
    const k = parseInt(e.key, 10);
    if (k >= 1 && k <= 5) { sel = k - 1; render(); }
  });

  // 2.3.10: рамка «Про програму» (іконка + версія) і кнопка «Перевірити оновлення»
  const abL = byId('abLogo'); if (abL) abL.innerHTML = logoMark(40);
  const abV = byId('abVer'); if (abV) abV.textContent = 'версія ' + APP_VER;
  const bun = byId('bUpdNow'); if (bun) bun.onclick = manualUpdCheck;
  // тема + акаунт (2.1.0)
  const tr = byId('themeRows');
  if (tr) {
    const tiles = tr.querySelectorAll('.theme-tile');
    for (let i = 0; i < tiles.length; ++i) {
      tiles[i].onclick = function () { applyTheme(tiles[i].getAttribute('data-t') || 'standard', true); };
    }
  }
  applyTheme(THEME, false);
  // 2.2.0: дистанційна конфігурація (OAuth Client ID / CF Account ID) + D1
  loadRemoteCfg();
  // 2.7.2: d1Init() не потрібен — таблиці D1 створюються міграцією на сервері

  buildTabs();
  if (!ACC.user) { /* гейт входу: майстер груп відкриється ПІСЛЯ входу (authAccept) */ }
  if (S) { showMain(); render(); }
  else { showMain(true); openGroups(); render(false); }
  applyScale();
  window.addEventListener('resize', applyScale);

  // миттєвий показ із кешу (економія лімітів Firebase)
  try {
    const c = JSON.parse(localStorage.getItem('fh_cache') || 'null');
    if (c && c.data) { cacheTs = c.ts || 0; applyDb(c.data, true); }
  } catch (e) {}

  // живі дані + ОБОВ'ЯЗКОВА мережева перевірка (без інтернету — інтерфейсу немає)
  doFetch(false);
  startLive();
  pollSchedule();
  pollSubjects();
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { clearTimeout(poolSchedT); poolSchedT = setTimeout(pollSchedule, 300); }
  });
  pushNotifSched();
  netProbe(false);

  // авто-стеження за версією: SSE + тихий опитування /update кожні 25 с
  // + перевірка одразу після повернення у вікно — «Доступне оновлення»
  // з'являється САМО, щойно версія на сервері зміниться
  setInterval(watchUpdate, 25000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { watchUpdate(); doFetch(false); }
  });

  // на телефоні одразу просимо дозвіл на сповіщення
  if (ANDROID && !notifPermOk()) {
    setTimeout(function () { try { AndroidHost.requestNotifPerm(); pollNotifPerm(); } catch (e) {} }, 1200);
  }

  // тихий тік: ЗАРАЗ/ДАЛІ/прогрес — без анімації, раз на хвилину зміни
  let lastTick = '';
  setInterval(function () {
    const d = new Date();
    const k = sel + '|' + FAKENOW + '|' + d.getHours() + ':' + d.getMinutes();
    if (k !== lastTick) { lastTick = k; if (!setupOpen) render(false); }
  }, 15000);
  // ФІКС «лого із затримкою»: сплеш показуємо лише тоді, коли іконка вже
  // декодована — іконка/назва/смуга з'являються ОДНОЧАСНО (під HTML-сплешем
  // усе цей час малюється такий самий GDI-сплеш із іконкою)
  (function bootRevealLogo() {
    const b = byId('boot');
    if (!b) return;
    // 2.8.8: кнопки вікна на сплеші — працюють з першого кадру (як у програмі)
    const bMin = byId('btMin'), bClose = byId('btClose'), bTb = byId('btTb');
    if (bMin) bMin.onclick = function () { host('fh:min'); };
    if (bClose) bClose.onclick = function () { host('fh:close'); };
    if (bTb) bTb.addEventListener('mousedown', function (e) {
      // перетягування вікна за міні-титулбар сплеша (кнопки не чіпаємо)
      if (e.button === 0 && !(e.target && e.target.closest && e.target.closest('button'))) host('fh:drag');
    });
    let done = false;
    const go = function () { if (!done) { done = true; b.classList.remove('pre'); } };
    const im = b.querySelector('.bt-mark img');
    if (!im) { go(); return; }
    if (im.complete && im.naturalWidth > 0) { go(); return; }
    im.addEventListener('load', go);
    im.addEventListener('error', go);
    if (im.decode) { try { im.decode().then(go, go); } catch (e) { } }
    setTimeout(go, 700);   // страховка — без лого не лишаємось ніколи
  })();

  // плавне завершення екрана завантаження: netProbe вирішує — оновлення чи головний екран
  bootLoop();
}

// хук для тестів/прев'ю (не впливає на звичайну роботу)
window.__fh = {
  // 2.7.6: команди нативної титульної панелі (Win32)
  seg: function (v) { if (!ACC.user) return; if (v === 'setup') showSetup(); else showMain(); },
  // 2.7.6: результат входу від AndroidHost (JSON профілю) / помилка
  authResult: function (j) {
    try {
      const u = (typeof j === 'string') ? JSON.parse(j) : j;
      if (u && u.sub) {
        const p = { sub: String(u.sub), name: String(u.name || 'Користувач'), email: String(u.email || ''), pic: String(u.pic || '') };
        if (u.fid) p.fid = String(u.fid);   // 2.8.7: fid більше не втрачається
        if (u.tok) p.tok = String(u.tok);
        authAccept(p);
      }
      else agFail('Не вдалося увійти. Спробуй ще раз.');
    } catch (e) { agFail('Помилка входу. Спробуй ще раз.'); }
  },
  authFail: function (m) { agFail(String(m || 'Помилка входу. Спробуй ще раз.')); },
  applyDb: applyDb, norm: normSubj, res: function () { return RES; }, render: render,
  showSetup: showSetup, showMain: showMain,
  openGroups: openGroups, closeGroups: closeGroups, groupsOpen: groupsOpen,
  openDrawer: openDrawer, closeDrawer: closeDrawer, drawerOpen: drawerOpen,
  buildSummary: buildSummary,
  checkUpdate: function (f) { if (f) netProbe(true); },
  setRepo: function (r) { UPDATE_REPO = r || DEFAULT_REPO; UPD.pending = ''; },
  updOpen: updOpen,
  showUpd: showUpd,
  updCheck: updCheck,
  netErr: function (on) { if (on) showNetErr(); else hideNetErr(); },
  dlProg: dlProg, dlErr: dlErr, dlDone: dlDone,
  updState: function () { return UPD; },
  notifFired: function (name, t, delta) { LAST_NOTIF = { name: name, t: t, delta: delta }; },
  notifAction: function (act) {
    // кнопка «Зайти» в тості Windows -> відкриваємо той урок
    if (updOpen()) return;
    resolveLessons();
    const d = new Date();
    let dow = d.getDay(); if (dow === 0) dow = 7;
    const day = RES[dow - 1] || [];
    let target = null;
    if (LAST_NOTIF && LAST_NOTIF.name) {
      for (let i = 0; i < day.length; i++) if (day[i].name === LAST_NOTIF.name) { target = day[i]; break; }
    }
    if (!target) {
      const nowM = d.getHours() * 60 + d.getMinutes();
      for (let i = 0; i < day.length; i++) {
        const m = String(day[i].t || '').match(/^(\d{1,2}):(\d{2})$/);
        if (!m) continue;
        const sm = (+m[1]) * 60 + (+m[2]);
        if (sm - nowM >= -45 && sm - nowM <= 20) { target = day[i]; break; }
      }
    }
    if (target) { showMain(); setTimeout(function () { joinLesson(target); }, 150); }
  },
  authOk: function (u) { if (u && u.sub) authAccept(u); },
  authErr: function (m) { agState = ''; agFail(m || 'Не вдалося підтвердити вхід'); },
  // 2.8.1: хост повідомив state локального слухача входу -> запускаємо
  // резервне опитування Firebase (основний канал — loopback у хості)
  authWait: function (st, port) {
    if (!st || ACC.user) return;
    agState = String(st);
    authPollDb(String(st));
  },
  cfqCb: function (id, status, json) {
    cfLast = status || 0;   // 2.7.3: діагностика «немає зв'язку»
    const cb2 = cfCbs[id]; delete cfCbs[id];
    if (!cb2) return;
    let rows = null;
    try {
      const r = (typeof json === 'string') ? JSON.parse(json) : json;
      if (r && r.success && r.result && r.result[0] && r.result[0].results) rows = r.result[0].results;
    } catch (e) {}
    cb2(rows);
  },
  cloudCb: function (id, status, json) { },
  verCmp: verCmp,
  back: function () {
    if (updOpen()) return true;              // оновлення обов'язкове — назад шляху немає
    if (groupsOpen()) { closeGroups(); return true; }
    const vDev = byId('vDev');
    if (vDev && !vDev.classList.contains('hidden')) { showMain(); return true; }
    if (FIRST) return true;
    const cw3 = byId('cwrap');
    if (cw3 && !cw3.classList.contains('hidden')) { closeConfirm(); return true; }
    if (drawerOpen()) { closeDrawer(); return true; }
    const mw = byId('mwrap');
    if (mw && !mw.classList.contains('hidden')) { closeModal(); return true; }
    if (setupOpen) { showMain(); return true; }
    return false;
  },
  boot: function () { return { p: bootP, ready: bootReady, revealed: bootRevealed }; },
  openModalFirst: function () {
    resolveLessons(); const day = RES[sel] || [];
    for (const l of day) if (l.split) { openModal(l); return; }
  },
  setFake: function (h, m, d) { FAKENOW = h * 60 + m; FAKEDOW = d; sel = (d >= 1 && d <= 5) ? d - 1 : 0; render(false); },
  st: function () { return { S: S, NOTIF: NOTIF, sel: sel, DBD: DBD, FIRST: FIRST, APP_VER: APP_VER, UPDATE_REPO: UPDATE_REPO }; },
  fbResult: __fhFbResult,
  applyTheme: applyTheme,
};
window.__fh.zoomStarting = zoomStarting;   // хост: запуск zoommtg:// відбувся
window.__fh.zoomWait = zoomWait;           // хост: повторний клік під час запуску
window.__fh.zoomFallback = zoomFallback;   // хост: Zoom не знайдено -> браузер
window.__fh.joinLesson = joinLesson;       // тести: клік по уроку
window.__fh.confirmState = function () { return CONFIRM; };

try { init(); } catch (err) {
  bootReady = true;
  try { bootLoop(); } catch (e2) { hideBoot(); }
  document.body.innerHTML = '<p style="padding:30px;color:#fff">Помилка інтерфейсу: ' + err.message + '</p>';
}
</script>
</body>
</html>)HTML";
