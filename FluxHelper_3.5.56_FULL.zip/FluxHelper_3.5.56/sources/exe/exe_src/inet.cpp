// ============================================================
//  FluxHelper 2.8.2 — запасний канал хмари через WinINet.
//  Окремий файл, бо wininet.h конфліктує з winhttp.h (INTERNET_SCHEME_*).
//  Викликається з main.cpp (CloudThread) ЛИШЕ коли WinHTTP дав status==0.
// ============================================================
#include <windows.h>
#include <wininet.h>
#include <string>
#include <vector>

bool FhInetRequest(const wchar_t* host, const unsigned short port, bool https,
                   const wchar_t* method, const wchar_t* path, const std::wstring& hdrs,
                   const std::string& body, int& status, std::string& resp) {
    status = 0;
    HINTERNET ses = InternetOpenW(L"FluxHelper-Cloud", INTERNET_OPEN_TYPE_PRECONFIG,
                                  nullptr, nullptr, 0);
    if (!ses) return false;
    DWORD tmo = 12000; InternetSetOptionW(ses, INTERNET_OPTION_CONNECT_TIMEOUT, &tmo, sizeof(tmo));
    tmo = 8000;        InternetSetOptionW(ses, INTERNET_OPTION_SEND_TIMEOUT, &tmo, sizeof(tmo));
    tmo = 45000;       InternetSetOptionW(ses, INTERNET_OPTION_RECEIVE_TIMEOUT, &tmo, sizeof(tmo));
    bool ok = false;
    HINTERNET con = InternetConnectW(ses, host, port, nullptr, nullptr,
                                     INTERNET_SERVICE_HTTP, 0, 0);
    if (con) {
        const wchar_t* accept[] = { L"*/*", nullptr };
        DWORD flags = https ? INTERNET_FLAG_SECURE : 0;
        flags |= INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_NO_COOKIES;
        HINTERNET req = HttpOpenRequestW(con, method, path, nullptr, nullptr, accept, flags, 0);
        if (req) {
            // м'який TLS — шкільні MITM-проксі/антивіруси
            DWORD sf = 0, sl = sizeof(sf);
            if (InternetQueryOptionW(req, INTERNET_OPTION_SECURITY_FLAGS, &sf, &sl)) {
                sf |= SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID
                    | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_REVOCATION;
                InternetSetOptionW(req, INTERNET_OPTION_SECURITY_FLAGS, &sf, sizeof(sf));
            }
            BOOL sent = HttpSendRequestW(req, hdrs.empty() ? nullptr : hdrs.c_str(),
                                         hdrs.empty() ? 0 : (DWORD)-1,
                                         body.empty() ? nullptr : (LPVOID)body.data(),
                                         (DWORD)body.size());
            if (sent) {
                DWORD stCode = 0, sz = sizeof(stCode);
                if (HttpQueryInfoW(req, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                                   &stCode, &sz, nullptr))
                    status = (int)stCode;
                for (;;) {
                    DWORD avail = 0;
                    if (!InternetQueryDataAvailable(req, &avail, 0, 0) || !avail) break;
                    std::vector<char> buf(avail);
                    DWORD rd = 0;
                    if (!InternetReadFile(req, buf.data(), avail, &rd) || !rd) break;
                    resp.append(buf.data(), rd);
                    if (resp.size() > 4u * 1024 * 1024) break;
                }
                ok = true;
            }
            InternetCloseHandle(req);
        }
        InternetCloseHandle(con);
    }
    InternetCloseHandle(ses);
    return ok;
}
