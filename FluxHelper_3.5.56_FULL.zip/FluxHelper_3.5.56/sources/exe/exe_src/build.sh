#!/usr/bin/env bash
# ============================================================
#  Збірка FluxHelper.exe (Windows x64) з Linux через llvm-mingw.
#  (На Windows використовуй Build.bat — він сам все завантажить.)
#  WebView2Loader.dll вбудовується в exe (RCDATA) і витягується при запуску.
#  2.8.2: + inet.cpp (запасний канал хмари WinINet) і -lwininet.
# ============================================================
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
TC="${LLVM_MINGW_BIN:-}"          # напр. /opt/llvm-mingw/bin
[ -n "$TC" ] || { echo "Вкажи LLVM_MINGW_BIN=/шлях/до/llvm-mingw/bin"; exit 1; }
SDKINC="$DIR/../tools/webview2/pkg/build/native/include"
mkdir -p build

# 1) ресурси (іконка + DLL + VERSIONINFO)
"$TC/x86_64-w64-mingw32-windres" app.rc -O coff -o build/app.res

# 2) компіляція (main.cpp + inet.cpp)
"$TC/x86_64-w64-mingw32-g++" -std=gnu++17 -O2 -fms-extensions -static \
  -municode -mwindows -DUNICODE -D_UNICODE -I"$SDKINC" -Icompat \
  main.cpp inet.cpp build/app.res -o build/FluxHelper.exe \
  -lole32 -lshell32 -luser32 -lgdi32 -ladvapi32 -luuid -ldwmapi -lwinhttp -lwininet -lgdiplus -lws2_32

echo "=== BUILD OK: exe/build/FluxHelper.exe ==="
