// ============================================================
//  FluxControl — розклад уроків + швидкі посилання на Zoom
//  C++ / Win32 / WebView2 (Microsoft Edge Chromium)
//
//  Особливості:
//   • безрамкове вікно із заокругленими кутами (DWM, Win 11;
//     на Win 10 — SetWindowRgn), власна титульна панель у HTML
//   • кастомні кнопки «Згорнути» / «Закрити» через WebMessage
//  1) налаштування груп: %APPDATA%\FluxHelper\settings.json — ЛИШЕ налаштування.
//     З 3.4.0 на диску НЕМАЄ ЖОДНИХ даних акаунта: сесія живе у системному
//     сховищі Windows (Credential Manager, DPAPI-блоб поза папкою програми)
//     + серверне дзеркало в D1 (sess: SHA-256(токен) -> Firebase UID);
//     user.json (3.3.2) знесено, у папці програми — тільки settings.json + UI\
//   • інтерфейс генерується у %APPDATA%\FluxHelper\UI\ (ui.html + ui.css + ui.js)
//   • 3.5.0 (РЕЛІЗ): CleanupLegacyFiles() — прибирання спадку старих версій
//     (ui.html 2.4.3, кореневі ui.*, user.json 3.3.2, fh_upd.bat ≤3.3.x, цілі
//     старі папки %APPDATA%\FluxControl і %APPDATA%\Blazix до-2.4 ери); у папці
//     даних лишається ТІЛЬКИ білий список: settings.json, WebView2Loader.dll,
//     logo.png, toast.ps1, fh_upd.cmd, upd.log, upd.ok, UI\, WebView2\
//   • ПКМ-меню, DevTools і браузерні гарячі клавіші вимкнено
//
//  Збірка (MinGW-w64, див. build.sh):
//    x86_64-w64-mingw32-windres app.rc -O coff -o build/app.res
//    x86_64-w64-mingw32-g++ -std=gnu++17 -O2 -municode -mwindows
//        main.cpp build/app.res -o build/FluxHelper.exe ...
// ============================================================
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <objidl.h>
#include <dwmapi.h>
#include <winhttp.h>
#include <gdiplus.h>
#include <wincred.h>   // 3.4.0: сесія акаунта — у системному сховищі Windows
#include <tlhelp32.h>  // 3.4.11: ZoomRunning() — чи відкритий Zoom (перевірка перед сповіщенням)

#include "WebView2.h"

#include "version.h"   // FH_VER_STR — версія (єдине джерело разом з app.rc)
#include "assets.h"    // kLogoB64 — логотип у base64
/* 2.9.2: інтерфейс розбито на ТРИ частини (розмітка/стилі/логіка):
   сторінка парситься швидше, а файл на диску менший за одиницею. */
#include "ui_desktop_html.h"   // kUiHtmlDesktop — розмітка
#include "ui_desktop_css.h"    // kUiCssDesktop  — стилі (ui.css)
#include "ui_desktop_js.h"     // kUiJsDesktop   — логіка (ui.js)

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>

#ifndef DWMWA_USE_IMMERSIVE_DARK_MODE
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#endif
#ifndef DWMWA_WINDOW_CORNER_PREFERENCE
#define DWMWA_WINDOW_CORNER_PREFERENCE 33
#endif
#ifndef DWMWA_BORDER_COLOR
#define DWMWA_BORDER_COLOR 34
#endif
#ifndef DWMWA_COLOR_NONE
#define DWMWA_COLOR_NONE 0xFFFFFFFE
#endif
#ifndef DWMWCP_ROUND
#define DWMWCP_ROUND 2
#endif

// IID-константи (крос-компіляція MinGW: обходимо __uuidof)
static const IID kIID_IUnknown = {0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
static const IID kIID_EnvironmentHandler = {0x4e8a3389,0xc9d8,0x4bd2,{0xb6,0xb5,0x12,0x4f,0xee,0x6c,0xc1,0x4d}};
static const IID kIID_ControllerHandler  = {0x6c4819f3,0xc9b7,0x4260,{0x81,0x27,0xc9,0xf5,0xbd,0xe7,0xf6,0x8c}};
static const IID kIID_Controller2        = {0xc979903e,0xd4ca,0x4228,{0x92,0xeb,0x47,0xee,0x3f,0xa9,0x6e,0xab}};
static const IID kIID_NewWindowHandler   = {0xd4c185fe,0xc81c,0x4989,{0x97,0xaf,0x2d,0x3f,0xa7,0xab,0x56,0x51}};
//IID_ICoreWebView2WebMessageReceivedEventHandler та IID_ICoreWebView2Settings4 беруться з WebView2.h

static HWND g_hwnd = nullptr;
static ICoreWebView2Controller* g_ctrl = nullptr;
static ICoreWebView2* g_web = nullptr;
static UINT g_dpi = 96;         // системний масштаб
static int  g_bezel = 6;        // рамка для зміни розміру (px)
static bool g_dwmRound = false; // чи підтримує DWM заокруглення
static std::string g_uiHtml;    // згенерована розмітка (пишеться у %APPDATA%\FluxHelper\UI\ui.html)
static std::string g_uiCss;     // 2.9.2: стилі інтерфейсу (%APPDATA%\FluxHelper\UI\ui.css)
static std::string g_uiJs;      // 2.9.2: логіка інтерфейсу (%APPDATA%\FluxHelper\UI\ui.js)
static std::string g_uiInline;  // 2.9.2: аварійний варіант (css/js вшиті) для NavigateToString
static bool g_fallbackUsed = false;

// екран завантаження (GDI, поки WebView2 ініціалізується)
static bool g_bootDone = false;
static bool g_webShown = false;   // WebView показано (після готовності сторінки)
static int  g_splashTick = 0;

// налаштування (settings.json): групи + розмір вікна + сповіщення
struct AppCfg {
    int ang = 0, nim = 0, ukr = 0, inf = 0, trud = 0;
    int w = 0, h = 0;       // збережений розмір вікна (пікселі)
    int notif = 1;          // сповіщення про початок уроку (увімк/викл)
    int notifmin = 5;       // за скільки хвилин попереджати
    int notifsnd = 1;       // 2.8.0: звуковий сигнал разом зі сповіщенням
    int ver = 0;            // версія файлу налаштувань (2 -> 3: миграція без втрат)
    // 2.7.6: акаунт Google (рідний OAuth). sub — Google-ідентифікатор;
    // 2.8.5: fid — Firebase UID (довгий ID з Firebase Authentication), він є
    // ключем рядка в D1; зберігаємо, щоб рестарт ПК НЕ створював g:<sub>-дублікат
    std::string sub, mail, nm, apic, fid;
    std::string theme;     // 2.8.8: остання відома тема (standard/light/glass) — нею малюється сплеш ДО входу в мережу
};
static AppCfg g_cfg;
/* 3.4.0: НЕПРОЗОРИЙ ТОКЕН СЕСІЇ. Народжується випадково при вході/міграції,
   живе ЛИШЕ в Credential Manager (на диск у папці програми НЕ пишеться) і
   НІКОЛИ не потрапляє на сервер у відкритому вигляді (там тільки SHA-256). */
static std::string g_sessTok;
static bool g_sessNeedsMirror = false;   // міграція з 3.3.2 — треба створити дзеркало в D1
static std::wstring RandHex(int bytes);  // визначено нижче (розділ входу Google)

// ------------------------------------------------- тема оформлення (2.8.8)
// Сплеш і фон WebView2 до першого кадру малюються в темі аккаунта: при
// старті фонова нитка за частки секунди підтягує тему з D1 (user_settings),
// а якщо аккаунта/мережі немає — береться локальна (остання відома).
static SRWLOCK g_themeLock = SRWLOCK_INIT;
static std::string g_bootTheme;   // тема, підтягнута з хмари при цьому запуску (порожня = ще не прийшла)
static bool ThemeValid(const std::string& t) {
    return t == "standard" || t == "light" || t == "glass";
}
// поточна тема під локом (читають малювання сплеша й збірка ui.html)
static std::string CurrentTheme() {
    AcquireSRWLockShared(&g_themeLock);
    std::string t = !g_bootTheme.empty() ? g_bootTheme : g_cfg.theme;
    ReleaseSRWLockShared(&g_themeLock);
    return ThemeValid(t) ? t : std::string("standard");
}
static void StoreTheme(const std::string& t) {   // ПІД ексклюзивним локом!
    g_bootTheme = t;
    g_cfg.theme = t;
}

// сповіщення про початок уроків (розклад надсилає інтерфейс через fh:notif|)
struct NItem { int dow = 0; int startMin = 0; int endMin = 0; std::string name; std::string url; };   // 3.4.4: + url; 3.4.17: + endMin (кiнець уроку)
static std::vector<NItem> g_sched;
static long long g_notifKey = 0;   // щоб не спамити одне й те саме
/* 3.4.11: СТАН УРОКУ ДЛЯ СПОВІЩЕНЬ (просив власник — «повна логіка»):
   g_doneKeys — ключі уроків (день*1000+індекс), для яких СПОВІЩЕННЯ БІЛЬШЕ
   НЕ ПРИХОДИТЬ НІКОЛИ: вже надіслали, користувач натиснув «Проігнорувати»,
   зайшов на урок або Zoom уже відкритий. Заміна одиночного g_notifKey:
   один ключ не витримував снуze/ігнор/захід одночасно. */
static std::vector<long long> g_doneKeys;
static void DoneKeyAdd(long long k) {
    if (k <= 0) return;
    for (size_t i = 0; i < g_doneKeys.size(); ++i) if (g_doneKeys[i] == k) return;
    g_doneKeys.push_back(k);
    if (g_doneKeys.size() > 96) g_doneKeys.erase(g_doneKeys.begin());   // кілька тижнів вистачить
}
static bool DoneKeyHas(long long k) {
    if (k <= 0) return false;
    for (size_t i = 0; i < g_doneKeys.size(); ++i) if (g_doneKeys[i] == k) return true;
    return false;
}
/* 3.4.11: ЧИ ВІДКРИТИЙ ZOOM. Перевірка процесів через CreateToolhelp32Snapshot:
   Zoom.exe (стільний клієнт). Якщо користувач уже в конференції — сповіщення
   про урок НЕ надсилається взагалі (просив власник: «пусть проверяет, открыта
   ли программа Zoom»). */
static bool ZoomRunning() {
    HANDLE ss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (ss == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
    bool found = false;
    if (Process32FirstW(ss, &pe)) {
        do {
            wchar_t lo[MAX_PATH]; int i = 0;
            for (; pe.szExeFile[i] && i < MAX_PATH - 1; ++i) lo[i] = (pe.szExeFile[i] >= L'A' && pe.szExeFile[i] <= L'Z') ? pe.szExeFile[i] + 32 : pe.szExeFile[i];
            lo[i] = 0;
            if (wcscmp(lo, L"zoom.exe") == 0) { found = true; break; }
        } while (Process32NextW(ss, &pe));
    }
    CloseHandle(ss);
    return found;
}
/* 2.9.2: кнопка тоста «Прислати за 1 хвилину до початку уроку».
   g_lastNotifIdx — індекс останнього сповіщеного уроку в g_sched;
   g_snoozeDay/g_snoozeMin — коли саме переприслати (день + хвилина доби);
   g_snoozeTest — «демо»-режим із тестового сповіщення (через 1 хв після кліка). */
static int g_lastNotifIdx = -1;
static long long g_snoozeDay = 0;
static int g_snoozeMin = -1;
static bool g_snoozeTest = false;
static std::wstring g_snoozeName;
static int g_snoozeStart = 0;      // 3.4.6: час початку уроку для тексту нагадування
static long long g_snoozeKey = 0;  // 3.4.11: ключ уроку, якого стосується нагадування
/* 3.4.14: посилання уроку, якого стосується нагадування — їде в кнопці
   «Зайти на урок» сповіщення «Урок через 1 хвилину»: клік відкриває САМЕ
   цей урок навіть якщо пошук уроку в інтерфейсі не влучить (перезапуск,
   збій синхронізації) — «кнопка зайти реально перекидує на урок». */
static std::wstring g_snoozeUrl;

/* 3.4.14: ВИМІСЛЕНЕ посилання для тестових/демо-дій — рандомний ID
   конференції, якого в розкладі НІКОЛИ не буває (просив власник: «типа
   рандомную ссылку не из расписания, чтобы оно просто перекидывало в Zoom»).
   Zoom-додаток/браузер відкриють екран приєднання; реальні уроки не чіпаються. */
static std::wstring RandomZoomUrl() {
    unsigned long id = 600000000UL + ((unsigned long)GetTickCount() * 2654435761UL + 12345UL) % 399999999UL;
    wchar_t buf[64];
    swprintf(buf, 64, L"https://us05web.zoom.us/j/%lu", id);
    return std::wstring(buf);
}
static NOTIFYICONDATAW g_nid = {};
static bool g_trayOk = false;      // чи іконка в треї реально стоїть

// ---- гейт входу (2.7.2): доки немає акаунта — вікно закрити не можна ----
static volatile bool g_gateLock = false;   // fh:gatelock|1 / |0 з інтерфейсу
static bool g_allowClose = true;           // FALSE під час гейта; TRUE при оновленні
static std::wstring g_pendingUrl;          // fluxhelper://... з командного рядка
static UINT g_msgTaskbarCreated = 0;       // відновлення іконки після рестарту explorer

// смуги зміни розміру за краї (визначені нижче)
static void LayoutEdges();

// ------------------------------------------------- GDI+ (сплеш: оригінальний PNG-логотип)
static ULONG_PTR g_gdipTok = 0;
static Gdiplus::Bitmap* g_logoBmp = nullptr;

static int B64Val(int c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}
// 2.8.9: КРИТИЧНИЙ ФІКС. B64Val('/') — останній символ алфавіту, а '=' (padding)
// повертав -1 -> B64Decode ПОВЕРТАВ false для ЛЮБОГО base64 з падінгом.
// kLogoB64 закінчується на "YII=" -> g_logoBmp лишався null -> на сплеші НЕ БУЛО
// ІКОНКИ (міні в титулбарі і великої по центру). Токен Cloudflare теж з падінгом
// ("...8=") -> CfToken() повертав ПОРОЖНІЙ рядок -> усі запити до D1 з ПК йшли
// з пустим Bearer -> 401: рядок users не створювався, синхронізація лежала,
// тема з хмари не підтягувалась. Тепер '=' просто пропускається.
static bool B64Decode(const char* in, std::vector<unsigned char>& out) {
    out.clear();
    out.reserve(strlen(in) * 3 / 4 + 4);
    int val = 0, valb = -8;
    for (const char* p = in; *p; ++p) {
        if (*p == '\n' || *p == '\r' || *p == ' ' || *p == '=') continue;
        int d = B64Val((unsigned char)*p);
        if (d < 0) return false;
        val = (val << 6) + d;
        valb += 6;
        if (valb >= 0) { out.push_back((char)((val >> valb) & 0xFF)); valb -= 8; }
    }
    return !out.empty();
}
// ---- Cloudflare D1: токен вбудований XOR+base64-чанками (не зберігається
// у відкритому вигляді ані в сурсах, ані в бінарнику як plain text).
// Ротується у scripts/make_272.py — чанки перегенеровуються автоматично.
static const char* const kCfTokCh[4] = {
    "OTwvLgVsFzQiMTA9DA",
    "ANFDBjEjw8DAg0LxYu",
    "Ems0Hy8IPhVqEDYRaQ",
    "AqPTswaWs+aWs5Pz8="
};
static std::string CfToken() {
    static std::string out;
    static bool done = false;
    if (done) return out;
    done = true;
    std::string b64;
    for (int i = 0; i < 4; ++i) b64 += kCfTokCh[i];
    std::vector<unsigned char> raw;
    if (!B64Decode(b64.c_str(), raw)) return out;
    for (unsigned char c : raw) out += (char)(c ^ 0x5A);
    return out;
}

static void InitSplashLogo() {
    Gdiplus::GdiplusStartupInput si;
    if (Gdiplus::GdiplusStartup(&g_gdipTok, &si, nullptr) != Gdiplus::Ok) return;
    std::vector<unsigned char> png;
    if (!B64Decode(kLogoB64, png)) return;
    HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, png.size());
    if (!hg) return;
    void* pd = GlobalLock(hg);
    if (!pd) { GlobalFree(hg); return; }
    memcpy(pd, png.data(), png.size());
    GlobalUnlock(hg);
    IStream* stm = nullptr;
    if (SUCCEEDED(CreateStreamOnHGlobal(hg, TRUE, &stm)))
        g_logoBmp = Gdiplus::Bitmap::FromStream(stm);   // потік звільняється разом з Bitmap
    else
        GlobalFree(hg);
    // ФІКС «лого з'являється із затримкою»: GDI+ декодує PNG ЛІНИВО при першому
    // малюванні, тому перший кадр сплеша міг виходити без іконки. Примусово
    // декодуємо ВСЕ зображення прямо тут (offscreen того самого розміру),
    // щоб сплеш мав іконку вже на ПЕРШОМУ кадрі — разом із фоном і назвою.
    if (g_logoBmp) {
        const UINT lw = g_logoBmp->GetWidth(), lh = g_logoBmp->GetHeight();
        if (lw > 0 && lh > 0) {
            Gdiplus::Bitmap warm(lw, lh, PixelFormat32bppARGB);
            Gdiplus::Graphics gw(&warm);
            gw.DrawImage(g_logoBmp, 0, 0, (INT)lw, (INT)lh);   // малюнок 1-в-1 -> повне декодування зараз
        }
    }
}

// ------------------------------------------------- конвертації рядків
static std::wstring Utf8ToWide(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
static std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

// ------------------------------------------------- папки даних
// %APPDATA%\FluxHelper — налаштування (settings.json, ТІЛЬКИ налаштування з
// 3.4.0: сесія акаунта — у Credential Manager, файлів профілю на диску нема) +
// згенерований інтерфейс у підпапці UI\ + DLL лоадер + кеш WebView2.
static std::wstring DataDir() {
    PWSTR p = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, nullptr, &p)))
        return std::wstring(L".");
    std::wstring base = p;
    CoTaskMemFree(p);
    std::wstring d = base + L"\\FluxHelper";
    CreateDirectoryW(d.c_str(), nullptr);
    static bool migrated = false;
    if (!migrated) {
        migrated = true;
        const wchar_t* oldNames[] = { L"FluxControl", L"Blazix" };
        for (const wchar_t* on : oldNames) {
            std::wstring oldDir = base + L"\\" + on;
            if (GetFileAttributesW(oldDir.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            if (GetFileAttributesW((d + L"\\settings.json").c_str()) != INVALID_FILE_ATTRIBUTES) break;   // уже є налаштування
            WIN32_FIND_DATAW fd;
            HANDLE h = FindFirstFileW((oldDir + L"\\*").c_str(), &fd);
            if (h != INVALID_HANDLE_VALUE) {
                do {
                    if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;   // WebView2-кеш починає з нуля
                    CopyFileW((oldDir + L"\\" + fd.cFileName).c_str(),
                              (d + L"\\" + fd.cFileName).c_str(), TRUE);
                } while (FindNextFileW(h, &fd));
                FindClose(h);
            }
            break;
        }
    }
    return d;
}
// %APPDATA%\FluxHelper\WebView2 — кеш браузерного рушія (усе в одному місці)
static std::wstring CacheDir() {
    std::wstring d = DataDir() + L"\\WebView2";
    CreateDirectoryW(d.c_str(), nullptr);
    return d;
}

// ------------------------------------------------- налаштування (settings.json)
static bool CfgValid(const AppCfg& c) {
    return (c.ang == 1 || c.ang == 2) && (c.nim == 1 || c.nim == 2) &&
           (c.ukr == 1 || c.ukr == 2) && (c.inf == 1 || c.inf == 2) &&
           (c.trud == 1 || c.trud == 2);
}

// 2.7.6: дістає рядок "key":"value" із JSON (UTF-8, з урахуванням \\ та \")
static bool JsonGetStr(const char* buf, const char* key, std::string& out) {
    out.clear();
    const char* p = strstr(buf, key);
    if (!p) return false;
    p = strchr(p + strlen(key), ':');
    if (!p) return false;
    p = strchr(p, '"');
    if (!p) return false;
    ++p;
    while (*p && *p != '"') {
        if (*p == '\\' && p[1]) {
            char c = p[1];
            if (c == '"' || c == '\\' || c == '/') out += c;
            else if (c == 'n') out += '\n';
            else if (c == 'u') {
                unsigned cp = 0;
                for (int i = 1; i <= 4 && p[1 + i]; ++i) {
                    char h = p[1 + i];
                    cp <<= 4;
                    if (h >= '0' && h <= '9') cp |= unsigned(h - '0');
                    else if (h >= 'a' && h <= 'f') cp |= unsigned(h - 'a' + 10);
                    else if (h >= 'A' && h <= 'F') cp |= unsigned(h - 'A' + 10);
                    else { cp = 0xFFFD; break; }
                }
                if (cp < 0x80) out += char(cp);
                else if (cp < 0x800) { out += char(0xC0 | (cp >> 6)); out += char(0x80 | (cp & 0x3F)); }
                else { out += char(0xE0 | (cp >> 12)); out += char(0x80 | ((cp >> 6) & 0x3F)); out += char(0x80 | (cp & 0x3F)); }
                p += 4;
            }
            p += 2;
        } else { out += *p; ++p; }
    }
    return true;
}
// 2.7.6: значення, безпечне для вставки в JSON
static std::string JsonEsc(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += char(c); }
        else if (c == '<') o += "\\u003c";
        else if (c == '>') o += "\\u003e";
        else if (c == '&') o += "\\u0026";
        else if (c == '\n') o += "\\n";
        else if (c == '\r') o += "\\r";
        else if (c < 0x20) { char b[8]; snprintf(b, sizeof(b), "\\u%04x", c); o += b; }
        else o += char(c);
    }
    return o;
}

// ------------------------------------------------- сесія акаунта (3.4.0)
/* 3.3.2 тримав профіль у user.json. З 3.4.0 — НА ДИСКУ НЕ ЛИШАЄТЬСЯ ЖОДНИХ
   ДАНИХ ПРО АКАУНТ:
     • settings.json — тільки налаштування (групи, вікно, сповіщення, тема);
     • профіль + випадковий токен сесії — у системному сховищі Windows
       (Credential Manager): це DPAPI-блоб, прив'язаний до облікового запису
       Windows, поза папкою програми; текстом його не відкрити і не
       відредагувати — «підмінити логін» правкою файлу більше неможливо;
     • серверне дзеркало sess (D1): ключ = SHA-256(токен), сам токен і профіль
       на сервер у відкритому вигляді не потрапляють.
   Поведінка незмінна: сесія переживає рестарт, гейт — тільки без акаунта. */
static void SaveAllCfg();   // вперед (визначено нижче)

static std::wstring UserPath() { return DataDir() + L"\\user.json"; }   // лише міграція/стирання спадку 3.3.2
static const wchar_t* kCredTarget = L"FluxHelper\\Session";

static void SessionSave() {
    if (g_cfg.sub.empty() || g_sessTok.empty()) return;
    std::string j = "{\"t\":\"" + JsonEsc(g_sessTok) + "\"" +
                    ",\"sub\":\"" + JsonEsc(g_cfg.sub) + "\"" +
                    ",\"mail\":\"" + JsonEsc(g_cfg.mail) + "\"" +
                    ",\"nm\":\"" + JsonEsc(g_cfg.nm) + "\"" +
                    ",\"pic\":\"" + JsonEsc(g_cfg.apic) + "\"" +
                    ",\"fid\":\"" + JsonEsc(g_cfg.fid) + "\"}";
    CREDENTIALW c = {};
    c.Type = CRED_TYPE_GENERIC;
    c.TargetName = (LPWSTR)kCredTarget;
    c.UserName = (LPWSTR)L"FluxHelper";
    c.CredentialBlobSize = (DWORD)j.size();       // ліміт 2560 Б — блоб ~0.5 КБ
    c.CredentialBlob = (LPBYTE)j.data();
    c.Persist = CRED_PERSIST_LOCAL_MACHINE;       // DPAPI-шифрування рівня Windows-акаунта
    CredWriteW(&c, 0);
}

static bool SessionLoad() {
    PCREDENTIALW p = nullptr;
    if (!CredReadW(kCredTarget, CRED_TYPE_GENERIC, 0, &p) || !p || !p->CredentialBlob) return false;
    std::string j((const char*)p->CredentialBlob, p->CredentialBlobSize);
    CredFree(p);
    JsonGetStr(j.c_str(), "\"t\"",    g_sessTok);
    JsonGetStr(j.c_str(), "\"sub\"",  g_cfg.sub);
    JsonGetStr(j.c_str(), "\"mail\"", g_cfg.mail);
    JsonGetStr(j.c_str(), "\"nm\"",   g_cfg.nm);
    JsonGetStr(j.c_str(), "\"pic\"",  g_cfg.apic);
    JsonGetStr(j.c_str(), "\"fid\"",  g_cfg.fid);
    return !g_sessTok.empty() && !g_cfg.sub.empty();
}

static void SessionWipe() {
    CredDeleteW(kCredTarget, CRED_TYPE_GENERIC, 0);
}

static void LoadAllCfg() {
    HANDLE f = CreateFileW((DataDir() + L"\\settings.json").c_str(),
                           GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    char buf[4096] = {};
    DWORD rd = 0;
    ReadFile(f, buf, sizeof(buf) - 1, &rd, nullptr);
    CloseHandle(f);
    auto get = [&](const char* key, int def) -> int {
        const char* p = strstr(buf, key);
        if (!p) return def;
        p = strchr(p + strlen(key), ':');
        if (!p) return def;
        return atoi(p + 1);
    };
    g_cfg.ang  = get("\"ang\"", 0);
    g_cfg.nim  = get("\"nim\"", 0);
    g_cfg.ukr  = get("\"ukr\"", 0);
    g_cfg.inf  = get("\"inf\"", 0);
    g_cfg.trud = get("\"trud\"", 0);
    g_cfg.w    = get("\"w\"", 0);
    g_cfg.h    = get("\"h\"", 0);
    int nf = get("\"notif\"", 1);
    g_cfg.notif = (nf == 0) ? 0 : 1;
    int nm = get("\"notifmin\"", 5);
    g_cfg.notifmin = (nm >= 1 && nm <= 15) ? nm : 5;
    int ns = get("\"notifsnd\"", 1);          // 2.8.0: звук сповіщень (переживає оновлення)
    g_cfg.notifsnd = (ns == 0) ? 0 : 1;
    g_cfg.ver = get("\"v\"", 0);
    /* 3.4.0: сесія — у Credential Manager (на диску тільки settings.json).
       Разова міграція з 3.3.2: якщо user.json ще існує — переносимо профіль
       у Credential Manager (генеруємо свіжий токен сесії) і СТИРАЄМО файл. */
    if (!SessionLoad() && g_cfg.sub.empty()) {
        HANDLE fu = CreateFileW(UserPath().c_str(), GENERIC_READ, FILE_SHARE_READ,
                                nullptr, OPEN_EXISTING, 0, nullptr);
        if (fu != INVALID_HANDLE_VALUE) {
            char ubuf[2048] = {};
            DWORD urd = 0;
            ReadFile(fu, ubuf, sizeof(ubuf) - 1, &urd, nullptr);
            CloseHandle(fu);
            std::string usub;
            JsonGetStr(ubuf, "\"sub\"", usub);
            if (!usub.empty()) {
                JsonGetStr(ubuf, "\"mail\"", g_cfg.mail);
                JsonGetStr(ubuf, "\"nm\"",   g_cfg.nm);
                JsonGetStr(ubuf, "\"pic\"",  g_cfg.apic);
                JsonGetStr(ubuf, "\"fid\"",  g_cfg.fid);
                g_cfg.sub = usub;
                g_sessTok = WideToUtf8(RandHex(24));
                SessionSave();
                g_sessNeedsMirror = true;   // дзеркало в D1 створимо після старту вікна
            }
        }
    }
    DeleteFileW(UserPath().c_str());   // 3.4.0: user.json як формат більше не існує
    JsonGetStr(buf, "\"theme\"", g_cfg.theme); // 2.8.8: тема для сплеша (standard/light/glass)
    if (!ThemeValid(g_cfg.theme)) g_cfg.theme.clear();
}

static void SaveAllCfg() {
    /* 3.3.2/3.4.0: У settings.json — ЛИШЕ налаштування. З 3.4.0 профілю нема
       ні в settings.json, ні в user.json — сесія живе в Credential Manager. */
    std::string j = "{\"ang\":" + std::to_string(g_cfg.ang) +
                    ",\"nim\":" + std::to_string(g_cfg.nim) +
                    ",\"ukr\":" + std::to_string(g_cfg.ukr) +
                    ",\"inf\":" + std::to_string(g_cfg.inf) +
                    ",\"trud\":" + std::to_string(g_cfg.trud) +
                    ",\"w\":" + std::to_string(g_cfg.w) +
                    ",\"h\":" + std::to_string(g_cfg.h) +
                    ",\"notif\":" + std::to_string(g_cfg.notif) +
                    ",\"notifmin\":" + std::to_string(g_cfg.notifmin) +
                    ",\"notifsnd\":" + std::to_string(g_cfg.notifsnd) + ",\"v\":3";
    if (!g_cfg.theme.empty()) j += ",\"theme\":\"" + JsonEsc(g_cfg.theme) + "\"";   // 2.8.8: тема сплеша/фону
    j += "}";

    HANDLE f = CreateFileW((DataDir() + L"\\settings.json").c_str(),
                           GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(f, j.data(), (DWORD)j.size(), &w, nullptr);
    CloseHandle(f);
}

// запам'ятовуємо розмір вікна, який поставив користувач
static void SaveWindowSize() {
    if (!g_hwnd) return;
    RECT rc;
    GetWindowRect(g_hwnd, &rc);
    int w = rc.right - rc.left, h = rc.bottom - rc.top;
    if (w < 200 || h < 150) return;   // згорнуте вікно — не зберігаємо
    g_cfg.w = w; g_cfg.h = h;
    SaveAllCfg();
}

// копіювання тексту (форматування уроку з інтерфейсу) в буфер обміну Windows
static void CopyToClipboard(const std::wstring& text) {
    if (!OpenClipboard(g_hwnd)) return;
    EmptyClipboard();
    const SIZE_T bytes = (text.size() + 1) * sizeof(wchar_t);
    HGLOBAL g = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (g) {
        void* p = GlobalLock(g);
        if (p) { memcpy(p, text.c_str(), bytes); GlobalUnlock(g); }
        if (SetClipboardData(CF_UNICODETEXT, g) == nullptr) GlobalFree(g);
    }
    CloseClipboard();
}

// ------------------------------------------------- сповіщення про початок уроку
// Інтерфейс надсилає fh:notif|{"on":true,"min":5,"items":[{"dow":1,"t":"08:30","n":"Алгебра"},...]}
// Розклад тримаємо в пам'яті й раз на 15 с перевіряємо, чи не починається урок.
static void ParseNotif(const std::wstring& j) {
    size_t p = j.find(L"\"on\":");
    if (p != std::wstring::npos)
        g_cfg.notif = (j.compare(p + 5, 4, L"true") == 0) ? 1 : 0;
    /* 3.4.5: ТИХА СИНХРОНІЗАЦІЯ. Розклад, що доїхав ЗІ СЕРВЕРА (синк налаштувань
       з іншого пристрою), не має негайно стріляти сповіщенням за урок, що вже
       у вікні (min хвилин) — саме це виглядало як «тестове сповіщення з
       телефона прийшло на ПК». Позначаємо такі уроки вже сповіщеними. */
    bool quiet = (j.find(L"\"q\":true") != std::wstring::npos);
    p = j.find(L"\"min\":");
    if (p != std::wstring::npos) {
        int v = _wtoi(j.c_str() + p + 6);
        if (v >= 1 && v <= 15) g_cfg.notifmin = v;
    }
    p = j.find(L"\"snd\":");                 // 2.8.0: звук сповіщень з інтерфейсу
    if (p != std::wstring::npos)
        g_cfg.notifsnd = (j.compare(p + 5, 4, L"true") == 0) ? 1 : 0;
    g_sched.clear();
    p = j.find(L"\"items\":");
    if (p == std::wstring::npos) return;
    std::wstring s = j.substr(p);
    size_t q = 0;
    while ((q = s.find(L"\"dow\":", q)) != std::wstring::npos) {
        NItem it;
        it.dow = _wtoi(s.c_str() + q + 6);
        size_t t1 = s.find(L"\"t\":\"", q);
        if (t1 != std::wstring::npos) {
            int h = 0, m2 = 0;
            if (swscanf(s.c_str() + t1 + 5, L"%d:%d", &h, &m2) == 2) it.startMin = h * 60 + m2;
        }
        size_t n1 = s.find(L"\"n\":\"", q);
        if (n1 != std::wstring::npos) {
            std::wstring nm;
            const wchar_t* r = s.c_str() + n1 + 5;
            while (*r && *r != L'"') { nm += *r; ++r; }
            it.name = WideToUtf8(nm);
        }
        // 3.4.4: посилання на урок ("u":"https://us..zoom.us/j/...") —
        // раніше його викидали, і кнопка «Зайти на урок» не могла відкрити урок
        size_t u1 = s.find(L"\"u\":\"", q);
        if (u1 != std::wstring::npos && u1 < q + 400) {
            std::wstring ul;
            const wchar_t* r2 = s.c_str() + u1 + 5;
            while (*r2 && *r2 != L'"') { ul += *r2; ++r2; }
            it.url = WideToUtf8(ul);
        }
        // 3.4.17: кiнець уроку ("e":"HH:MM") — сповіщення зникає в кiнці уроку
        size_t e1 = s.find(L"\"e\":\"", q);
        if (e1 != std::wstring::npos && e1 < q + 500) {
            int he = 0, me = 0;
            if (swscanf(s.c_str() + e1 + 5, L"%d:%d", &he, &me) == 2) it.endMin = he * 60 + me;
        }
        if (it.dow >= 1 && it.dow <= 7 && it.startMin > 0) g_sched.push_back(it);
        q += 6;
    }
    if (quiet) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        long long dayKey = (long long)st.wYear * 10000 + st.wMonth * 100 + st.wDay;
        int nowM = st.wHour * 60 + st.wMinute;
        for (size_t i = 0; i < g_sched.size(); ++i) {
            if (g_sched[i].dow != (int)st.wDayOfWeek) continue;
            int delta = g_sched[i].startMin - nowM;
            if (delta >= 0 && delta <= g_cfg.notifmin) {
                long long k = dayKey * 1000 + (long long)i;
                g_notifKey = k;                              // «вже сповіщено» — CheckNotifs пропустить
                DoneKeyAdd(k);                               // 3.4.11: у реєстр «більше не сповіщуємо»
                g_lastNotifIdx = (int)i;
            }
        }
    }
}

// ================================================== звук сповіщень (2.8.0)
// Компактний приємний дзвіночок, синтезований у пам'яті (WAV, 44100 Hz, 16-біт):
// акорд C6->G5->E6 (мажорна арпеджіо з м'якою атакою і затуханням).
// Ніяких зовнішніх файлів і залежностей — граємо через PlaySound (winmm).
static std::vector<unsigned char> g_chimeWav;
static bool g_chimeReady = false;
static void BuildChime() {
    if (g_chimeReady) return;
    g_chimeReady = true;
    const int rate = 44100;
    const double dur = 1.15;
    const int n = (int)(rate * dur);
    // три ноти з перекриттям (арпеджіо): C6 (1046.5), E6 (1318.5), G6 (1568.0)
    struct Note { double f, t0, amp; };
    const Note notes[3] = { {1046.5, 0.00, 0.52}, {1318.5, 0.14, 0.44}, {1568.0, 0.28, 0.36} };
    std::vector<double> s((size_t)n, 0.0);
    for (const Note& nt : notes) {
        for (int i = (int)(nt.t0 * rate); i < n; ++i) {
            double t = (i - nt.t0 * rate) / (double)rate;
            if (t < 0) continue;
            // м'яка атака 12 мс + експоненційне затухання ~0.45 с
            double env = (t < 0.012) ? (t / 0.012) : exp(-(t - 0.012) * 7.5);
            if (env < 0.0008) continue;
            double v = sin(6.283185307179586 * nt.f * t) * 0.62
                     + sin(6.283185307179586 * nt.f * 2.0 * t) * 0.22
                     + sin(6.283185307179586 * nt.f * 3.0 * t) * 0.07;
            s[(size_t)i] += v * env * nt.amp;
        }
    }
    // нормалізація і конвертація в 16-біт PCM
    double peak = 0.0;
    for (double v : s) { double a = v < 0 ? -v : v; if (a > peak) peak = a; }
    double k = peak > 0 ? 0.72 / peak : 0.0;
    std::vector<short> pcm((size_t)n);
    for (int i = 0; i < n; ++i) {
        double v = s[(size_t)i] * k;
        if (v > 0.98) v = 0.98; if (v < -0.98) v = -0.98;
        pcm[(size_t)i] = (short)(v * 32767.0);
    }
    // WAV-заголовок (44 байти) + дані
    const int dataBytes = n * 2;
    g_chimeWav.reserve((size_t)dataBytes + 44);
    auto put4 = [&](const char* t) { for (int i = 0; i < 4; ++i) g_chimeWav.push_back((unsigned char)t[i]); };
    auto put32 = [&](unsigned v) { g_chimeWav.push_back(v & 255); g_chimeWav.push_back((v >> 8) & 255); g_chimeWav.push_back((v >> 16) & 255); g_chimeWav.push_back((v >> 24) & 255); };
    auto put16 = [&](unsigned v) { g_chimeWav.push_back(v & 255); g_chimeWav.push_back((v >> 8) & 255); };
    put4("RIFF"); put32((unsigned)(36 + dataBytes)); put4("WAVE");
    put4("fmt "); put32(16); put16(1); put16(1); put32((unsigned)rate); put32((unsigned)(rate * 2)); put16(2); put16(16);
    put4("data"); put32((unsigned)dataBytes);
    for (int i = 0; i < n; ++i) {
        unsigned short u = (unsigned short)(unsigned short)(unsigned)pcm[(size_t)i];
        g_chimeWav.push_back(u & 255); g_chimeWav.push_back((u >> 8) & 255);
    }
}
// граємо дзвіночок (якщо користувач не вимкнув звук сповіщень)
static void PlayChime() {
    if (!g_cfg.notifsnd) return;
    BuildChime();
    if (g_chimeWav.empty()) return;
    static bool wmmTried = false;
    if (!wmmTried) {
        wmmTried = true;
        LoadLibraryW(L"winmm.dll");   // PlaySound у статичній лінковці не потрібен — беремо динамічно
    }
    typedef BOOL (WINAPI *FnPlaySound)(const void*, void*, DWORD);
    static FnPlaySound ps = nullptr;
    if (!ps) {
        HMODULE m = GetModuleHandleW(L"winmm.dll");
        if (m) ps = (FnPlaySound)(void*)GetProcAddress(m, "PlaySoundW");
    }
    if (ps) ps(g_chimeWav.data(), nullptr, SND_MEMORY | SND_ASYNC | SND_NODEFAULT);
}

// ================================================== сповіщення Windows (тости)
// Справжні Windows-тости (WinRT) з кнопками «Зайти»/«Ігнорувати».
// Усе динамічно через combase.dll — без нових lib. Будь-яка невдача -> балун.
// IID звірені з mingw-w64 windows.ui.notifications.h / windows.data.xml.dom.h.
#ifndef __HSTRING_DEFINED
#define __HSTRING_DEFINED
struct __HSTRING__;                     // opague HSTRING (hstring.h у mingw не втягнуто)
typedef struct __HSTRING__* HSTRING;
#endif
static const IID kIID_IToastNotificationManagerStatics =
    {0x50AC103F,0xD235,0x4598,{0xBB,0xEF,0x98,0xFE,0x4D,0x1A,0x3A,0xD4}};
static const IID kIID_IToastNotificationFactory =
    {0x04124B20,0x82C6,0x4229,{0xB1,0x09,0xFD,0x9E,0xD4,0x66,0x2B,0x53}};
static const IID kIID_IToastNotifier =
    {0x75927B93,0x03F3,0x41EC,{0x91,0xD3,0x6E,0x5B,0xAC,0x1B,0x38,0xE7}};
static const IID kIID_IXmlDocumentIO =
    {0x6CD0E74E,0xEE65,0x4489,{0x9E,0xBF,0xCA,0x43,0xE8,0x7B,0xA6,0x37}};
static const IID kIID_IActivationFactory =
    {0x00000035,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};

struct FhInspectable : IUnknown {   // слоти 3..5 (після IUnknown)
    virtual HRESULT STDMETHODCALLTYPE GetIids(ULONG*, IID**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetRuntimeClassName(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetTrustLevel(int*) = 0;
};
struct FhToastMgrStatics : FhInspectable {              // Windows.UI.Notifications.ToastNotificationManager
    virtual HRESULT STDMETHODCALLTYPE CreateToastNotifier(HSTRING, void**) = 0;             // слот 6
    virtual HRESULT STDMETHODCALLTYPE CreateToastNotifierWithId(HSTRING, HSTRING, void**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetTemplateContent(int, void**) = 0;
};
struct FhToastNotifier : FhInspectable {                // notifier
    virtual HRESULT STDMETHODCALLTYPE Show(void*) = 0;                                       // слот 6
    virtual HRESULT STDMETHODCALLTYPE Hide(void*) = 0;
};
struct FhToastNotifFactory : FhInspectable {            // Windows.UI.Notifications.ToastNotification
    virtual HRESULT STDMETHODCALLTYPE CreateToastNotification(void*, void**) = 0;            // слот 6
};
/* 3.4.17: IToastNotification — слоти 6/7: get/put_ExpirationTime. Тост із
   ExpirationTime САМ ЗНИКАЄ з Центру сповіщень, коли урок скінчився
   (автоудалення сповіщень на ПК — просив власник). DateTime = FILETIME
   (100нс вiд 1601), передається значенням (8 байтiв). */
struct FhToastNotif : FhInspectable {                   // примiрник тоста
    virtual HRESULT STDMETHODCALLTYPE get_ExpirationTime(long long* value) = 0;              // слот 6
    virtual HRESULT STDMETHODCALLTYPE put_ExpirationTime(long long value) = 0;               // слот 7
};
struct FhActivationFactory : IUnknown {                 // IActivationFactory
    virtual HRESULT STDMETHODCALLTYPE ActivateInstance(void**) = 0;                          // слот 3
};
struct FhXmlDocIO : FhInspectable {                     // IXmlDocumentIO
    virtual HRESULT STDMETHODCALLTYPE LoadXml(HSTRING) = 0;                                  // слот 6
};

// ============================= 3.4.6: ІКОНКА У СПОВІЩЕННЯХ =============================
// Користувач: «приходить уведомление, но іконки FluxHelper у ньому нема —
// просто назва, тайтл, текст». Причина: AUMID IconUri вказував на сам exe
// (file:///...FluxHelper.exe) — платформа сповіщень Windows малює іконку ЛИШЕ
// з .png/.ico, exe вона ігнорує. Лікується двома опорами:
//   1) витягуємо вбудований логотип у %APPDATA%\FluxHelper\logo.png і пишемо
//      в реєстр AppUserModelId\FluxHelper -> IconUri = цей png;
//   2) у самому XML тоста малюємо <image placement="appLogoOverride"> —
//      іконка з'являється в картці сповіщення навіть тоді, коли AUMID-запис
//      перекритий політик або ще не підхоплений системою.
static std::wstring LogoPngPath() { return DataDir() + L"\\logo.png"; }

static void EnsureLogoPng() {
    const std::wstring p = LogoPngPath();
    WIN32_FIND_DATAW fd{};
    HANDLE h = FindFirstFileW(p.c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        const unsigned want = (unsigned)(strlen(kLogoB64) * 3 / 4);   // ~розмір png
        FindClose(h);
        if (fd.nFileSizeLow >= want - 32 && fd.nFileSizeLow <= want + 32) return;   // уже витягнуто
    }
    std::vector<unsigned char> png;
    if (!B64Decode(kLogoB64, png) || png.empty()) return;
    HANDLE f = CreateFileW(p.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    DWORD wr = 0;
    WriteFile(f, png.data(), (DWORD)png.size(), &wr, nullptr);
    CloseHandle(f);
}

// URI для <image src="..."> у тості: file:///C:/Users/...%20.../logo.png
static std::wstring LogoFileUri() {
    std::wstring p = LogoPngPath();
    for (wchar_t& c : p) if (c == L'\\') c = L'/';
    std::wstring o = L"file:///";
    for (wchar_t c : p) {
        if (c == L' ') { o += L"%20"; continue; }
        if ((c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') || (c >= L'0' && c <= L'9') ||
            c == L'/' || c == L':' || c == L'.' || c == L'-' || c == L'_') { o += c; continue; }
        wchar_t b[8];
        swprintf(b, 8, L"%%%02X", (unsigned)c & 0xFF);
        o += b;
    }
    return o;
}

// 3.4.6: URL у аргументі кнопки тоста (fluxhelper://join?u=<url>) —
// percent-encode/decode. Раніше Zoom-посилання з &pwd=... обрізалось на
// першому & (ProtoArgU зупинявся на '&') -> кнопка «Зайти» відкривала кімнату
// БЕЗ пароля. Тепер enc/dec симетричні — повне посилання доїжджає цілим.
static std::wstring ProtoEnc(const std::wstring& u) {
    static const wchar_t* hex = L"0123456789ABCDEF";
    std::wstring o;
    for (wchar_t c : u) {
        if ((c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') || (c >= L'0' && c <= L'9') ||
            c == L'-' || c == L'_' || c == L'.' || c == L'~') { o += c; continue; }
        o += L'%';
        o += hex[(c >> 4) & 15];
        o += hex[c & 15];
    }
    return o;
}
static int HexVal(wchar_t c) {
    if (c >= L'0' && c <= L'9') return c - L'0';
    if (c >= L'a' && c <= L'f') return c - L'a' + 10;
    if (c >= L'A' && c <= L'F') return c - L'A' + 10;
    return -1;
}
static std::wstring ProtoDec(const std::wstring& s) {
    std::wstring o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == L'%' && i + 2 < s.size()) {
            int h = HexVal(s[i + 1]), l = HexVal(s[i + 2]);
            if (h >= 0 && l >= 0) { o += (wchar_t)((h << 4) | l); i += 2; continue; }
        }
        o += s[i];
    }
    return o;
}

// AUMID-ярлик у «Меню Пуск» — без нього Windows не показує тости від unpackaged-застосунків
static void EnsureAumidShortcut() {
    wchar_t exe[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    // 3.4.5: друга опора — запис у реєстрі AppUserModelId (DisplayName + IconUri).
    // На Win10 1709+/Win11 платформа сповіщень приймає і його, тож тости
    // показуються навіть коли створення ярлика не вдалось (OneDrive-стіл тощо).
    // 3.4.6: IconUri = logo.png (PNG витягнуто з exe) — сам exe як іконку
    // Windows НЕ малює, тому в сповіщенні не було логотипа.
    {
        HKEY k = nullptr;
        if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\AppUserModelId\\FluxHelper",
                            0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) == ERROR_SUCCESS) {
            const wchar_t* dn = L"FluxHelper";
            RegSetValueExW(k, L"DisplayName", 0, REG_SZ, (const BYTE*)dn, (DWORD)((wcslen(dn) + 1) * sizeof(wchar_t)));
            std::wstring ic = LogoPngPath();   // звичайний шлях до png (без file://)
            RegSetValueExW(k, L"IconUri", 0, REG_SZ, (const BYTE*)ic.c_str(), (DWORD)((ic.size() + 1) * sizeof(wchar_t)));
            RegCloseKey(k);
        }
    }
    wchar_t start[MAX_PATH] = {};
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_STARTMENU, nullptr, 0, start))) return;
    std::wstring lnk = std::wstring(start) + L"\\Programs\\FluxHelper.lnk";
    DWORD at = GetFileAttributesW(lnk.c_str());
    if (at != INVALID_FILE_ATTRIBUTES) return;   // вже є
    IShellLinkW* sl = nullptr;
    HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
                                  IID_IShellLinkW, (void**)&sl);
    if (FAILED(hr) || !sl) return;
    sl->SetPath(exe);
    sl->SetWorkingDirectory(L"");
    IPropertyStore* ps = nullptr;
    if (SUCCEEDED(sl->QueryInterface(IID_IPropertyStore, (void**)&ps)) && ps) {
        // PKEY_AppUserModel_ID = {9F4C2855-9F79-4B39-A8D0-4E1BA58A3CC5}, pid 5
        PROPERTYKEY pk;
        pk.fmtid = {0x9F4C2855,0x9F79,0x4B39,{0xA8,0xD0,0x4E,0x1B,0xA5,0x8A,0x3C,0xC5}};
        pk.pid = 5;
        PROPVARIANT pv;
        memset(&pv, 0, sizeof(pv));
        pv.vt = VT_LPWSTR;
        pv.pwszVal = (LPWSTR)CoTaskMemAlloc(sizeof(wchar_t) * 16);
        if (pv.pwszVal) { wcscpy(pv.pwszVal, L"FluxHelper"); ps->SetValue(pk, pv); ps->Commit(); }
        ps->Release();
    }
    IPersistFile* pf = nullptr;
    if (SUCCEEDED(sl->QueryInterface(IID_IPersistFile, (void**)&pf)) && pf) {
        pf->Save(lnk.c_str(), TRUE);
        pf->Release();
    }
    sl->Release();
}

// протокол fluxhelper:// — щоб кнопка «Зайти» в тості відкривала програму
static void RegisterProtocol() {
    wchar_t exe[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    HKEY k = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\fluxhelper",
                        0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) != ERROR_SUCCESS) return;
    const wchar_t* url = L"URL:FluxHelper Protocol";
    RegSetValueExW(k, nullptr, 0, REG_SZ, (const BYTE*)url, (DWORD)((wcslen(url) + 1) * sizeof(wchar_t)));
    const wchar_t* up = L"";
    RegSetValueExW(k, L"URL Protocol", 0, REG_SZ, (const BYTE*)up, (DWORD)sizeof(wchar_t));
    RegCloseKey(k);
    HKEY k2 = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\fluxhelper\\shell\\open\\command",
                        0, nullptr, 0, KEY_SET_VALUE, nullptr, &k2, nullptr) == ERROR_SUCCESS) {
        wchar_t cmd[MAX_PATH + 24] = {};
        swprintf(cmd, MAX_PATH + 23, L"\"%s\" \"%%1\"", exe);
        RegSetValueExW(k2, nullptr, 0, REG_SZ, (const BYTE*)cmd, (DWORD)((wcslen(cmd) + 1) * sizeof(wchar_t)));
        RegCloseKey(k2);
    }
}

static std::wstring XmlEsc(const std::wstring& t) {
    std::wstring o;
    for (wchar_t c : t) {
        if      (c == L'&')  o += L"&amp;";
        else if (c == L'<')  o += L"&lt;";
        else if (c == L'>')  o += L"&gt;";
        else if (c == L'"') o += L"&quot;";
        else if (c == L'\'') o += L"&apos;";
        else if (c == L'\n') o += L' ';
        else o += c;
    }
    return o;
}

// 3.4.5: СПРАВЖНІЙ ТОСТ WINDOWS — ГОЛОВНИЙ канал сповіщень (замість власного
// попап-вікна). Кнопки — системні: клік запускає fluxhelper:// протокол.
// ЗВУК — РІДНИЙ звук сповіщень Windows: snd=true -> системний «Notification
// Default» всередині тоста (тому звук грає навіть якщо вікно згорнуто у трей),
// snd=false -> <audio silent="true"/> (повна тиша, як просив власник).
// test=true -> кнопки тестового: «Зайти на урок» (з URL тесту) + «Нагадати за 1 хв» (демо).
// false = не вийшло (викликач показує PowerShell-тост -> попап -> балун)
static bool ShowToast(const std::wstring& title, const std::wstring& text, bool snd, bool test, const std::wstring& url, bool sn = true, int expireMin = -1) {
    EnsureLogoPng();   // 3.4.6: логотип для appLogoOverride (якщо ще не витягнуто)
    typedef LONG (WINAPI *FnRoInit)(int);
    typedef LONG (WINAPI *FnRoGetAct)(LPCWSTR, const IID*, void**);
    typedef LONG (WINAPI *FnCreateStr)(LPCWSTR, UINT32, HSTRING*);
    typedef LONG (WINAPI *FnDelStr)(HSTRING);
    HMODULE cb = GetModuleHandleW(L"combase.dll");
    if (!cb) cb = LoadLibraryW(L"combase.dll");
    if (!cb) return false;
    FnRoInit     roInit = (FnRoInit)(void*)GetProcAddress(cb, "RoInitialize");
    FnRoGetAct   roGet  = (FnRoGetAct)(void*)GetProcAddress(cb, "RoGetActivationFactory");
    FnCreateStr  wstr   = (FnCreateStr)(void*)GetProcAddress(cb, "WindowsCreateString");
    FnDelStr     dstr   = (FnDelStr)(void*)GetProcAddress(cb, "WindowsDeleteString");
    if (!roInit || !roGet || !wstr || !dstr) return false;

    wchar_t xml[2400];
    std::wstring t = XmlEsc(title), x = XmlEsc(text);
    /* 3.4.5: кнопки за типом сповіщення.
       ТЕСТОВЕ (3.4.11 — ТОЧЬ-В-ТОЧЬ як справжнє, тільки «(тест)» у тексті):
       «Зайти на урок» + «Нагадати за 1 хв» (демо, якщо в налаштуваннях НЕ
       1 хвилина — просив власник).
       УРОЧНЕ (3.4.11): «Зайти на урок» / «Нагадати за 1 хв» (тільки якщо
       налаштування НЕ «за 1 хвилину» і нагадування ще не планували).
       3.4.14: «Проігнорувати» ПРИБРАНО ВСЮДИ (телефон + ПК) — власник:
       «нехай буде дві кнопки — зайти на урок і нагадати за одну хвилину»;
       три кнопки в вузькій спливашці обрізались. Клік по тілу тоста
       (fluxhelper://open) відкриває застосунок — карту теж можна зняти
       свайпом/хрестиком системи. */
    // 3.4.6: URL уроку в аргументі кнопки — percent-encode (zoom-посилання
    // містить ?pwd=...&... — без encode обрізалось на першому &)
    std::wstring ju = L"fluxhelper://join";
    if (!url.empty()) ju += L"?u=" + ProtoEnc(url);
    std::wstring acts;
    if (test) {
        /* 3.4.13: у ТЕСТОВОМУ тості «Нагадати за 1 хв» = ДЕМО (+1 хв від зараз):
           окремий протокол fluxhelper://tsnooze — раніше кнопка тесту мала той
           самий адрес, що й у реального сповіщення, і могла змістити нагадування
           РЕАЛЬНОГО уроку замість демонстрації. */
        acts = L"<action content=\"Зайти на урок\" arguments=\"" + XmlEsc(ju) +
               L"\" activationType=\"protocol\"/>";
        if (sn) acts += L"<action content=\"Нагадати за 1 хв\" arguments=\"fluxhelper://tsnooze\" activationType=\"protocol\"/>";
    } else {
        acts = L"<action content=\"Зайти на урок\" arguments=\"" + XmlEsc(ju) + L"\" activationType=\"protocol\"/>";
        if (sn) acts += L"<action content=\"Нагадати за 1 хв\" arguments=\"fluxhelper://snooze\" activationType=\"protocol\"/>";
    }
    const wchar_t* au = snd
        ? L"<audio src=\"ms-winsoundevent:Notification.Default\"/>"
        : L"<audio silent=\"true\"/>";
    /* 3.4.6: appLogoOverride — логотип FluxHelper усередині самої картки
       сповіщення (не залежить від AUMID-реєстру). 3.5.1: hint-crop="circle" —
       логотип малюється КРУГОЮ, точь-в-точь як аватар у шторці на телефоні
       (раніше було "none" — квадрат, власник: «на пк іконки не такі красиві
       як на телефоні»). */
    const std::wstring logoImg = L"<image placement=\"appLogoOverride\" src=\"" + XmlEsc(LogoFileUri()) +
                                 L"\" hint-crop=\"circle\"/>";
    _snwprintf(xml, 2399,
        L"<toast activationType=\"protocol\" launch=\"fluxhelper://open\">"
        L"<visual><binding template=\"ToastGeneric\">"
        L"%s"
        L"<text>%s</text><text>%s</text></binding></visual>"
        L"%s"
        L"<actions>%s</actions></toast>",
        logoImg.c_str(), t.c_str(), x.c_str(), au, acts.c_str());
    xml[2399] = 0;

    roInit(1);   // RO_INIT_MULTITHREADED (ідемпотентний для потоку)
    HSTRING hsXml = nullptr, hsAumid = nullptr;
    bool ok = false;
    void* mgr = nullptr; void* notifier = nullptr; void* af = nullptr; void* doc = nullptr;
    void* xio = nullptr; void* tf = nullptr; void* toast = nullptr;
    do {
        if (FAILED(wstr(xml, (UINT32)wcslen(xml), &hsXml))) break;
        if (FAILED(wstr(L"FluxHelper", 10, &hsAumid))) break;
        // RoGetActivationFactory бере LPCWSTR (не HSTRING)
        if (FAILED(roGet(L"Windows.UI.Notifications.ToastNotificationManager",
                         &kIID_IToastNotificationManagerStatics, &mgr)) || !mgr) break;
        if (((FhToastMgrStatics*)mgr)->CreateToastNotifier(hsAumid, &notifier) != S_OK || !notifier) break;
        if (FAILED(roGet(L"Windows.Data.Xml.Dom.XmlDocument", &kIID_IActivationFactory, &af)) || !af) break;
        if (((FhActivationFactory*)af)->ActivateInstance(&doc) != S_OK || !doc) break;
        if (((IUnknown*)doc)->QueryInterface(kIID_IXmlDocumentIO, (void**)&xio) != S_OK || !xio) break;
        if (((FhXmlDocIO*)xio)->LoadXml(hsXml) != S_OK) break;
        if (FAILED(roGet(L"Windows.UI.Notifications.ToastNotification",
                         &kIID_IToastNotificationFactory, &tf)) || !tf) break;
        if (((FhToastNotifFactory*)tf)->CreateToastNotification(doc, &toast) != S_OK || !toast) break;
        /* 3.4.17: автоудалення тоста в кiнцi уроку. expireMin — хвилини вiд
           пiвноi (кiнець уроку з розкладу). Невдача не критична — тост просто
           живе в Центрi сповіщень до ручного змахування. */
        if (expireMin >= 0 && expireMin < 24 * 60) {
            SYSTEMTIME te;
            GetLocalTime(&te);
            te.wHour = (WORD)(expireMin / 60);
            te.wMinute = (WORD)(expireMin % 60);
            te.wSecond = 0;
            te.wMilliseconds = 0;
            FILETIME fe{};
            if (SystemTimeToFileTime(&te, &fe)) {
                long long univ = ((long long)fe.dwHighDateTime << 32) | fe.dwLowDateTime;
                long long nowUniv = 0;
                SYSTEMTIME tn;
                GetLocalTime(&tn);
                FILETIME fn{};
                if (SystemTimeToFileTime(&tn, &fn)) {
                    nowUniv = ((long long)fn.dwHighDateTime << 32) | fn.dwLowDateTime;
                    if (univ <= nowUniv) univ = nowUniv + (long long)60000 * 10 * 15;   // кiнець минув — прибрати за 15 хв
                    try { ((FhToastNotif*)toast)->put_ExpirationTime(univ); } catch (...) { }
                }
            }
        }
        // 3.4.5: HRESULT від Show() перевіряється — без реєстрації AUMID/ярлика
        // Show міг мовчки нічого не показати, і користувач не бачив СПОВІЩЕННЯ
        // ВЗАГАЛІ (ok ставився true бездивно). Тепер невдача -> фолбек-ланцюжок.
        if (((FhToastNotifier*)notifier)->Show(toast) != S_OK) break;
        ok = true;
    } while (0);
    if (toast) ((IUnknown*)toast)->Release();
    if (tf) ((IUnknown*)tf)->Release();
    if (xio) ((IUnknown*)xio)->Release();
    if (doc) ((IUnknown*)doc)->Release();
    if (af) ((IUnknown*)af)->Release();
    if (notifier) ((IUnknown*)notifier)->Release();
    if (mgr) ((IUnknown*)mgr)->Release();
    if (hsXml) dstr(hsXml);
    if (hsAumid) dstr(hsAumid);
    return ok;
}

// сповіщення: 3.4.5 — СПРАВЖНІЙ ТОСТ WINDOWS (головний канал, кнопки системні,
// звук — рідний звук сповіщень Windows). Фолбеки: той самий тост через
// PowerShell (WinRT-проєкція) -> власне попап-вікно -> балун у треї.
static bool ShowNotifWin(const std::wstring& title, const std::wstring& text, bool test, const std::wstring& url, bool sn = true);   // визначено нижче
static void ShowBalloon(const std::wstring& title, const std::wstring& text);    // визначено нижче
static bool ShowToast(const std::wstring& title, const std::wstring& text, bool snd, bool test, const std::wstring& url, bool sn, int expireMin);
static bool ShowToastPS(const std::wstring& title, const std::wstring& text, bool snd, bool test, const std::wstring& url, bool sn, int expireMin);
/* 3.4.17: expireMin — хвилина дня, коли урок СКІНЧУЄТЬСЯ (з розкладу, -1 = нема);
   тост сам зникає з Центру сповіщень у цей момент (автоудалення — просив власник) */
static void ShowNotif(const std::wstring& title, const std::wstring& text, bool snd = true, bool test = false, const std::wstring& url = L"", bool sn = true, int expireMin = -1) {
    if (ShowToast(title, text, snd, test, url, sn, expireMin)) return;   // рідний звук у самому тості
    if (ShowToastPS(title, text, snd, test, url, sn, expireMin)) return; // той самий тост через PowerShell
    if (snd) PlayChime();                                 // у ручних фолбеках звука в тості нема
    if (ShowNotifWin(title, text, test, url, sn)) return;   // фолбек: власне вікно (кнопки свої)
    ShowBalloon(title, text);                // останній фолбек
}

// 3.4.5: фолбек-тост через PowerShell (WinRT-проєкція є в кожній Windows 10/11,
// PowerShell 5.1 — теж). Спрацьовує тоді, коли прямий COM-шлях не показав
// тост (політики/пошкоджений combase-стек). Той самий AUMID, той самий рідний
// звук — користувач різниці не помітить. XML із подвійними лапками ->
// безпечне вставляння в одинарні лапки PowerShell ('' = єдиний escape).
static bool ShowToastPS(const std::wstring& title, const std::wstring& text, bool snd, bool test, const std::wstring& url, bool sn = true, int expireMin = -1) {
    EnsureLogoPng();
    std::wstring ju = L"fluxhelper://join";
    if (!url.empty()) ju += L"?u=" + ProtoEnc(url);
    /* 3.4.14: «Проігнорувати» прибрано і тут — ті самі ДВІ кнопки, що й у
       рідного тоста (клік по тілу/свайп прибирає карту не гірше). */
    std::wstring acts;
    if (test) {
        /* 3.4.13: демо-кнопка тесту — fluxhelper://tsnooze (як у ShowToast) */
        acts = L"<action content=\"Зайти на урок\" arguments=\"" + XmlEsc(ju) + L"\" activationType=\"protocol\"/>";
        if (sn) acts += L"<action content=\"Нагадати за 1 хв\" arguments=\"fluxhelper://tsnooze\" activationType=\"protocol\"/>";
    } else {
        acts = L"<action content=\"Зайти на урок\" arguments=\"" + XmlEsc(ju) + L"\" activationType=\"protocol\"/>";
        if (sn) acts += L"<action content=\"Нагадати за 1 хв\" arguments=\"fluxhelper://snooze\" activationType=\"protocol\"/>";
    }
    std::wstring au = snd ? L"<audio src=\"ms-winsoundevent:Notification.Default\"/>" : L"<audio silent=\"true\"/>";
    /* 3.5.1: круглий логотип — як на телефоні (див. коментар у ShowToast) */
    const std::wstring logoImg = L"<image placement=\"appLogoOverride\" src=\"" + XmlEsc(LogoFileUri()) +
                                 L"\" hint-crop=\"circle\"/>";
    std::wstring xml = L"<toast activationType=\"protocol\" launch=\"fluxhelper://open\">"
                       L"<visual><binding template=\"ToastGeneric\">"
                       + logoImg +
                       L"<text>" + XmlEsc(title) + L"</text><text>" + XmlEsc(text) + L"</text>"
                       L"</binding></visual>" + au + L"<actions>" + acts + L"</actions></toast>";

    /* 3.4.17: скільки ХВИЛИН лишилось до кінця уроку (для ExpirationTime) */
    int untilMin = 45;
    if (expireMin >= 0 && expireMin < 24 * 60) {
        SYSTEMTIME tn0;
        GetLocalTime(&tn0);
        untilMin = expireMin - (tn0.wHour * 60 + tn0.wMinute);
        if (untilMin < 1) untilMin = 1;        // кінець минув — зникне одразу
        if (untilMin > 24 * 60) untilMin = 24 * 60;
    }
    const std::wstring ps1 = DataDir() + L"\\toast.ps1";
    HANDLE f = CreateFileW(ps1.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    // UTF-8 з BOM — PowerShell 5.1 читає кирилицю коректно
    const unsigned char bom[3] = { 0xEF, 0xBB, 0xBF };
    DWORD wr = 0;
    WriteFile(f, bom, 3, &wr, nullptr);
    std::string u8 = WideToUtf8(
        L"$ErrorActionPreference='Stop'\r\n"
        L"try {\r\n"
        L"[void][Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime]\r\n"
        L"[void][Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType=WindowsRuntime]\r\n"
        L"$x = New-Object Windows.Data.Xml.Dom.XmlDocument\r\n"
        L"$x.LoadXml('" + xml + L"')\r\n"
        L"$t = New-Object Windows.UI.Notifications.ToastNotification($x)\r\n"
        /* 3.4.17: автоудалення в кiнцi уроку (окремий try — не зривати показ) */
        L"try { $t.ExpirationTime = [DateTimeOffset]::Now.AddMinutes(" + std::to_wstring(untilMin) + L") } catch {}\r\n"
        L"[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('FluxHelper').Show($t)\r\n"
        L"exit 0\r\n} catch { exit 1 }\r\n");
    WriteFile(f, u8.c_str(), (DWORD)u8.size(), &wr, nullptr);
    CloseHandle(f);

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    std::wstring args = L"powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + ps1 + L"\"";
    BOOL ok = CreateProcessW(nullptr, (LPWSTR)args.c_str(), nullptr, nullptr, FALSE,
                             CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    if (ok) { CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
    else DeleteFileW(ps1.c_str());
    return ok != FALSE;
}

static void ShowBalloon(const std::wstring& title, const std::wstring& text) {
    if (!g_hwnd) return;
    NOTIFYICONDATAW nid = {};
    nid.cbSize = sizeof(nid);
    nid.hWnd = g_hwnd;
    nid.uID = 1;
    nid.uFlags = NIF_INFO;
    wcsncpy(nid.szInfoTitle, title.c_str(), 63);
    wcsncpy(nid.szInfo, text.c_str(), 255);
    nid.dwInfoFlags = NIIF_INFO;
    Shell_NotifyIconW(NIM_MODIFY, &nid);
}

// ================================================== 3.4.4: ВЛАСНЕ ВІКНО-ПОВІДОМЛЕННЯ
// WinRT-тости на частині машин не показуються (AUMID/політики) або падають у
// балун без кнопок. Тому тепер ГОЛОВНИЙ канал — власне попап-вікно внизу справа
// у стилі застосунку: назва уроку, час, і ГАРАНТОВАНО робочі кнопки
// «Зайти на урок» / «Нагадати за 1 хв» — ДВІ (3.4.14; клік = дія, не залежить
// від налаштувань Windows). Поверх усіх вікон, краде фокус, зникає через 15 с.
static const wchar_t* kNotifCls = L"FhNotifPopup";
static std::wstring g_nTitle, g_nBody;      // текст поточного попапа
static RECT g_nBtn[2];                      // 3.4.14: зони ДВОХ кнопок (клієнтські координати)
static HWND g_nhPopup = nullptr;
static bool g_nTest = false;                // 3.4.14: попап тестового/демо-сповіщення (кнопка «Нагадати» = демо)
static bool g_nSn = true;                   // 3.4.15: чи малювати другу кнопку («Нагадати за 1 хв»);
                                            // нагадування «за 1 хвилину» має ЛИШЕ «Зайти на урок»
static std::wstring g_nUrl;                 // 3.4.14: посилання уроку для кнопки «Зайти» (може бути порожнім)
/* 3.5.1: попап-сповіщення — «точь-в-точь як на телефоні». g_nIcon — велика
   чітка іконка (кадр 96px із вбудованого .ico; раніше LoadIconW давав 32px
   кадр, стиснутий у 26px — замазано і «не красиво»); g_nScale — DPI-масштаб
   для шрифтів/відступів (раніше текст малювався у фізичних пікселях і на
   125-150% виглядав дрібним). Іконка живе до кінця процесу — один примірник. */
static HICON g_nIcon = nullptr;
static double g_nScale = 1.0;
static void ArmSnooze(bool forceDemo = false);   // 3.4.13: forceDemo — тест-кнопка
static void UiScript(const std::wstring& js);   // визначено нижче (клік «Зайти» -> JS)
static void UiJoinLesson(const std::wstring& url);   // 3.4.14: єдина точка кліку «Зайти на урок»

static bool NhPtIn(const RECT& r, int x, int y) {
    return x >= r.left && x < r.right && y >= r.top && y < r.bottom;
}

static LRESULT CALLBACK NotifProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(h, &ps);
        RECT rc; GetClientRect(h, &rc);
        const double sc = (g_nScale > 0.1) ? g_nScale : 1.0;   // 3.5.1: DPI-масштаб
        // фон: темно-графітова картка з фіолетовою окантовкою (як рамки в застосунку)
        HBRUSH bg = CreateSolidBrush(RGB(16, 16, 24));
        HBRUSH oldb = (HBRUSH)SelectObject(dc, bg);
        HPEN pen = CreatePen(PS_SOLID, 1, RGB(124, 58, 237));
        HPEN oldp = (HPEN)SelectObject(dc, pen);
        RoundRect(dc, rc.left, rc.top, rc.right, rc.bottom, 22, 22);
        SelectObject(dc, oldp); DeleteObject(pen);
        SelectObject(dc, oldb); DeleteObject(bg);
        SetBkMode(dc, TRANSPARENT);
        // 3.5.1: іконка ВЕЛИКА і ЧІТКА — кадр 96px із вбудованого .ico,
        // малюється у 44*sc (на телефоні логотип у картці ~такого ж розміру;
        // раніше LoadIconW -> кадр 32px, стиснутий у 26px = замазане плямо)
        const int isz = (int)(44 * sc);
        if (!g_nIcon) {
            g_nIcon = (HICON)LoadImageW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(1),
                                        IMAGE_ICON, isz * 2, isz * 2, LR_DEFAULTCOLOR);
            if (!g_nIcon) g_nIcon = LoadIconW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(1));
        }
        if (g_nIcon) DrawIconEx(dc, rc.left + 14, rc.top + 14, g_nIcon, isz, isz, 0, nullptr, DI_NORMAL);
        // текстова колонка — праворуч від іконки (як у тості Windows)
        const int tx = rc.left + 14 + isz + 11;
        // заголовок
        SetTextColor(dc, RGB(255, 255, 255));
        HFONT fb = CreateFontW(-(int)(15 * sc), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
                               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                               DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
        HFONT of = (HFONT)SelectObject(dc, fb);
        RECT rt = { tx, rc.top + (int)(15 * sc), rc.right - 14, rc.top + (int)(37 * sc) };
        DrawTextW(dc, g_nTitle.c_str(), -1, &rt, DT_SINGLELINE | DT_END_ELLIPSIS | DT_LEFT);
        // текст повідомлення (до 3 рядків)
        SetTextColor(dc, RGB(201, 201, 212));
        HFONT fn = CreateFontW(-(int)(13 * sc), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                               DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
        SelectObject(dc, fn);
        RECT rb = { tx, rc.top + (int)(40 * sc), rc.right - 14, rc.bottom - (int)(58 * sc) };
        DrawTextW(dc, g_nBody.c_str(), -1, &rb, DT_WORDBREAK | DT_LEFT | DT_END_ELLIPSIS);
        // кнопки: «Зайти на урок» (акцентна) + «Нагадати за 1 хв» (якщо є).
        // 3.4.15: нагадування «за 1 хвилину» (sn=false) — ОДНА кнопка на всю
        // ширину; звичайні сповіщення — ДВІ («Проігнорувати» прибрано 3.4.14)
        // 3.5.1: кнопки ЗАОКРУГЛЕНІ (радиус ~12*sc) — як чипи кнопок на телефоні
        const wchar_t* labels[2] = { L"Зайти на урок", L"Нагадати за 1 хв" };
        const int nBtns = g_nSn ? 2 : 1;
        const int rad = (int)(12 * sc) + 2;
        int y0 = rc.bottom - (int)(46 * sc), bh = (int)(32 * sc);
        int bx = rc.left + 14, bw = (rc.right - rc.left - 28 - (g_nSn ? 8 : 0)) / nBtns;
        if (!g_nSn) g_nBtn[1] = RECT{0,0,0,0};
        for (int i = 0; i < nBtns; ++i) {
            g_nBtn[i].left = bx; g_nBtn[i].top = y0;
            g_nBtn[i].right = bx + bw; g_nBtn[i].bottom = y0 + bh;
            RECT br = g_nBtn[i];
            if (i == 0) {
                // акцентна кнопка — фіолетовий градієнт (GradientFill — динамічно,
                // бо msimg32 не в лінках), затиснутий у заокруглену форму
                typedef BOOL (WINAPI *FnGrad)(HDC, void*, ULONG, void*, ULONG, ULONG);
                static FnGrad grad = nullptr;
                if (!grad) {
                    HMODULE ms = LoadLibraryW(L"msimg32.dll");
                    if (ms) grad = (FnGrad)(void*)GetProcAddress(ms, "GradientFill");
                }
                if (grad) {
                    HRGN rgn = CreateRoundRectRgn(br.left, br.top, br.right + 1, br.bottom + 1, rad, rad);
                    SelectClipRgn(dc, rgn);
                    TRIVERTEX tv[2] = {
                        { br.left, br.top, 0x7c00, 0x3a00, 0xed00, 0xff00 },
                        { br.right, br.bottom, 0xa800, 0x5500, 0xf700, 0xff00 }
                    };
                    GRADIENT_RECT gr = { 0, 1 };
                    grad(dc, tv, 2, &gr, 1, GRADIENT_FILL_RECT_H);
                    SelectClipRgn(dc, nullptr);
                    DeleteObject(rgn);
                } else {
                    HBRUSH ab = CreateSolidBrush(RGB(124, 58, 237));
                    HBRUSH oab = (HBRUSH)SelectObject(dc, ab);
                    HPEN ap = CreatePen(PS_SOLID, 1, RGB(150, 95, 245));
                    HPEN oap = (HPEN)SelectObject(dc, ap);
                    RoundRect(dc, br.left, br.top, br.right, br.bottom, rad, rad);
                    SelectObject(dc, oap); DeleteObject(ap);
                    SelectObject(dc, oab); DeleteObject(ab);
                }
                // світліша окантовка поверх градієнта
                HGDIOBJ nob = SelectObject(dc, GetStockObject(NULL_BRUSH));
                HPEN fp = CreatePen(PS_SOLID, 1, RGB(150, 95, 245));
                HGDIOBJ ofp = (HPEN)SelectObject(dc, fp);
                RoundRect(dc, br.left, br.top, br.right, br.bottom, rad, rad);
                SelectObject(dc, ofp); DeleteObject(fp);
                SelectObject(dc, nob);
                SetTextColor(dc, RGB(255, 255, 255));
            } else {
                HBRUSH bb = CreateSolidBrush(RGB(32, 32, 44));
                HBRUSH obb = (HBRUSH)SelectObject(dc, bb);
                HPEN gp = CreatePen(PS_SOLID, 1, RGB(64, 64, 84));
                HPEN ogp = (HPEN)SelectObject(dc, gp);
                RoundRect(dc, br.left, br.top, br.right, br.bottom, rad, rad);
                SelectObject(dc, ogp); DeleteObject(gp);
                SelectObject(dc, obb); DeleteObject(bb);
                SetTextColor(dc, RGB(215, 215, 226));
            }
            RECT tr = g_nBtn[i];
            DrawTextW(dc, labels[i], -1, &tr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            bx += bw + 8;
        }
        SelectObject(dc, of); DeleteObject(fb); DeleteObject(fn);
        EndPaint(h, &ps);
        return 0;
    }
    case WM_LBUTTONDOWN: {
        int x = (short)LOWORD(lp), y = (short)HIWORD(lp);
        for (int i = 0; i < 2; ++i) {
            if (!g_nSn && i == 1) continue;          // 3.4.15: однокнопковий попап
            if (!NhPtIn(g_nBtn[i], x, y)) continue;
            if (i == 0) {
                // «Зайти на урок» — 3.4.14: та сама ЄДНА точка, що й у кнопки тоста:
                // якщо відоме посилання уроку (g_nUrl) — відкриється саме воно
                UiJoinLesson(g_nUrl);
            } else if (i == 1) {
                ArmSnooze(g_nTest);   // 3.4.14: тестовий попап — демо-нагадування
            }
            KillTimer(h, 1);
            DestroyWindow(h);
            return 0;
        }
        return 0;
    }
    case WM_SETCURSOR: {
        POINT pt; GetCursorPos(&pt);
        ScreenToClient(h, &pt);
        for (int i = 0; i < 2; ++i) {
            if (!g_nSn && i == 1) break;             // 3.4.15: однокнопковий попап
            if (NhPtIn(g_nBtn[i], pt.x, pt.y)) { SetCursor(LoadCursorW(nullptr, IDC_HAND)); return TRUE; }
        }
        SetCursor(LoadCursorW(nullptr, IDC_ARROW));
        return TRUE;
    }
    case WM_TIMER:
        if (wp == 1) { KillTimer(h, 1); DestroyWindow(h); }
        return 0;
    case WM_DESTROY:
        if (g_nhPopup == h) g_nhPopup = nullptr;
        return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

/* показати попап; false = не вийшло (викликач падає на тост/балун).
   3.4.14: test/url — тип сповіщення і посилання уроку для кнопки «Зайти»:
   клік відкриє саме цей урок (UiJoinLesson), «Нагадати» в тестовому = демо.
   3.4.15: sn — чи є друга кнопка («Нагадати за 1 хв»); у нагадування
   «за 1 хвилину» кнопки тільки «Зайти на урок». */
static bool ShowNotifWin(const std::wstring& title, const std::wstring& text, bool test, const std::wstring& url, bool sn) {
    if (!g_hwnd) return false;
    g_nTest = test; g_nUrl = url; g_nSn = sn;   // 3.4.14/3.4.15: стан для обробника кліків
    // один попап за раз: старий закриваємо (свіже повідомлення важливіше)
    if (g_nhPopup) { DestroyWindow(g_nhPopup); g_nhPopup = nullptr; }
    static bool clsDone = false;
    if (!clsDone) {
        WNDCLASSW wc = {};
        wc.lpfnWndProc = NotifProc;
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpszClassName = kNotifCls;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        if (!RegisterClassW(&wc)) return false;
        clsDone = true;
    }
    unsigned dpi = 96;
    typedef UINT (WINAPI *FnGetDpi)(HWND);
    HMODULE uu = GetModuleHandleW(L"user32.dll");
    if (uu) {
        FnGetDpi gd = (FnGetDpi)(void*)GetProcAddress(uu, "GetDpiForWindow");
        if (gd) dpi = gd(g_hwnd) ? gd(g_hwnd) : 96;
    }
    double sc = dpi / 96.0;
    g_nScale = sc;   // 3.5.1: масштаб для малювання попапа (шрифти/іконка/кнопки)
    int W = (int)(392 * sc), H = (int)(178 * sc);
    RECT wa{};
    if (!SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) { wa.right = GetSystemMetrics(SM_CXSCREEN); wa.bottom = GetSystemMetrics(SM_CYSCREEN); }
    int x = wa.right - W - (int)(16 * sc), y = wa.bottom - H - (int)(16 * sc);
    g_nTitle = title; g_nBody = text;
    DWORD ex = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;
    HWND h = CreateWindowExW(ex, kNotifCls, L"", WS_POPUP,
                             x, y, W, H, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    if (!h) return false;
    // заокруглені кути (плюс спроба DWM-округлення); 3.5.1: радіус у фізичних px
    HRGN rg = CreateRoundRectRgn(0, 0, W, H, (int)(22 * sc), (int)(22 * sc));
    SetWindowRgn(h, rg, FALSE);
    typedef HRESULT (WINAPI *FnDwmSet)(HWND, DWORD, const void*, DWORD);
    HMODULE dw = GetModuleHandleW(L"dwmapi.dll");
    if (dw) {
        FnDwmSet dsm = (FnDwmSet)(void*)GetProcAddress(dw, "DwmSetWindowAttribute");
        if (dsm) { int pref = 2; dsm(h, 33, &pref, sizeof(pref)); }   // DWMWA_WINDOW_CORNER_PREFERENCE = DWMWCP_ROUND
    }
    g_nhPopup = h;
    ShowWindow(h, SW_SHOWNOACTIVATE);
    InvalidateRect(h, nullptr, TRUE);
    SetTimer(h, 1, 15000, nullptr);   // 15 с і зникає
    return true;
}

/* 2.9.2: кнопка тоста «Нагадати за 1 хв» -> другий інстанс передає
   fluxhelper://snooze -> ставимо одноразовий «будильник» на 1 хвилину
   до початку ОСТАННЬОГО сповіщеного уроку (саме тоді, коли користувач
   хоче отримати нагадування ще раз).
   3.4.11 — НОВІ ПРАВИЛА (просив власник):
   • Нагадування ПРИХОДИТЬ РІВНО ЗА 1 ХВ ДО ПОЧАТКУ УРОКУ і більше НІКОЛИ;
   • якщо урок уже почався / починається менш ніж через 1 хв — нагадування
     НЕ надсилається взагалі (раніше кнопка залишалась активною і після
     початку уроку — це виправлено);
   • одне нагадування на урок: повторне натискання нічого не змінює;
   • якщо урок уже «закритий» (ігнор/захід/Zoom) — нагадування не ставиться. */
static void ArmSnooze(bool forceDemo) {
    SYSTEMTIME st;
    GetLocalTime(&st);
    long long dayKey = (long long)st.wYear * 10000 + st.wMonth * 100 + st.wDay;
    int nowM = st.wHour * 60 + st.wMinute;
    g_snoozeTest = false;
    /* 3.4.13: forceDemo — кнопка «Нагадати за 1 хв» у ТЕСТОВОМУ тості
       (fluxhelper://tsnooze): завжди демо-режим (+1 хв від зараз), НІКОЛИ
       не зміщує нагадування реального уроку. */
    if (forceDemo) {
        g_snoozeDay = dayKey;
        g_snoozeMin = nowM + 1;
        g_snoozeName = L"";
        g_snoozeStart = 0;
        g_snoozeTest = true;
        g_snoozeKey = 0;
        g_snoozeUrl = L"";
        return;
    }
    if (g_lastNotifIdx >= 0 && g_lastNotifIdx < (int)g_sched.size()) {
        const NItem& it = g_sched[g_lastNotifIdx];
        long long k = dayKey * 1000 + (long long)g_lastNotifIdx;
        if (DoneKeyHas(k) && g_snoozeKey != k) return;   // урок уже закритий (ігнор/захід) — нагадування не буде
        if (g_snoozeKey == k && g_snoozeMin >= 0) return;   // вже заплановано — друге не потрібно
        int target = it.startMin - 1;
        if (target <= nowM) return;   // 3.4.11: урок починається менш ніж за 1 хв / уже почався — БЕЗ нагадування
        g_snoozeDay = dayKey;
        g_snoozeMin = target;
        g_snoozeName = Utf8ToWide(it.name);
        g_snoozeStart = it.startMin;
        g_snoozeKey = k;
        g_snoozeUrl = Utf8ToWide(it.url);   // 3.4.14: кнопка «Зайти» нагадування відкриє саме цей урок
    } else {
        // сповіщення ще не було (або перезапуск) — демо-режим: через 1 хвилину
        g_snoozeDay = dayKey;
        g_snoozeMin = nowM + 1;
        g_snoozeName = L"";
        g_snoozeStart = 0;
        g_snoozeTest = true;
        g_snoozeKey = 0;
        g_snoozeUrl = L"";
    }
}

// копія сповіщення в інтерфейс (журнал з часом отримання) — виклик з головного потоку
static void UiScript(const std::wstring& js);   // визначено нижче (поряд з оновленням)
static void PushNotifToUi(const std::string& nameUtf8, int startMin, int delta) {
    std::string n = nameUtf8;
    for (auto& c : n) if (c == '"' || c == '\\') c = ' ';
    wchar_t js[420];
    swprintf(js, 420,
             L"window.__fh&&window.__fh.notifFired&&window.__fh.notifFired(\"%s\",\"%02d:%02d\",%d)",
             Utf8ToWide(n).c_str(), startMin / 60, startMin % 60, delta);
    UiScript(js);
}

// ФІКС «пише через 3 хв, коли до уроку 0 хв»: хвилини у ТЕКСТІ сповіщення
// завжди реальні (настоящі) — рахуємо скільки ХВИЛИН лишилось САМЕ ПІД ЧАС показу.
static void CheckNotifs() {
    if (!g_hwnd) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    long long dayKey = (long long)st.wYear * 10000 + st.wMonth * 100 + st.wDay;
    int nowM = st.wHour * 60 + st.wMinute;
    /* 2.9.2: СПОВІЩЕННЯ ЗА 1 ХВИЛИНУ (кнопка тоста «Нагадати за 1 хв»).
       Перевіряємо ПЕРШИМ: воно іде окремо від звичайного розкладу.
       3.4.11: воно ОДНОРАЗОВЕ й чесне — якщо урок уже почався або його
       проігнорували/закрили (вхід, Zoom) — нагадування НЕ приходить. */
    if (g_snoozeMin >= 0 && g_snoozeDay == dayKey && nowM >= g_snoozeMin) {
        g_snoozeMin = -1;
        bool skip = false;
        if (!g_snoozeTest) {
            if (g_snoozeStart > 0 && nowM >= g_snoozeStart) skip = true;        // урок уже почався
            if (DoneKeyHas(g_snoozeKey)) skip = true;                           // ігнор/вхід уже були
            if (ZoomRunning()) skip = true;                                     // Zoom відкритий — користувач уже на уроці
        }
        g_snoozeTest = false;
        if (!skip) {
            if (g_snoozeStart <= 0) {
                /* 3.4.15: демо-нагадування тесту — САМЕ нагадування (не звичайний
                   тест): заголовок як у реального, у тексті «(тест)»; «Зайти на
                   урок» веде на ВИМІСЛЕНЕ посилання (рандомний ID, якого в
                   розкладі не буває). Кнопка ОДНА (sn=false). */
                ShowNotif(L"Нагадування про початок уроку за одну хвилину",
                          L"Це демонстрація нагадування — кнопка «Зайти на урок» працює (тест)",
                          g_cfg.notifsnd != 0, true, RandomZoomUrl(), false);
            } else {
                /* 3.4.15 (просив власник): нагадування «за 1 хвилину» — власна
                   картка: заголовок «Нагадування про початок уроку за одну
                   хвилину», дрібним текстом — який урок і через скільки
                   почнеться; ОДНА кнопка — «Зайти на урок» (sn=false), клік
                   відкриває саме цей урок (g_snoozeUrl, навіть після
                   перезапуску застосунку). */
                int remain = g_snoozeStart - nowM;
                if (remain < 0) remain = 0;
                const wchar_t* how = (remain == 0) ? L"починається зараз"
                                  : (remain == 1 ? L"через 1 хвилину" : L"через кілька хвилин");
                wchar_t msg[300];
                if (remain > 1)
                    swprintf(msg, 300, L"%s • початок о %02d:%02d • через %d хв",
                             g_snoozeName.c_str(), g_snoozeStart / 60, g_snoozeStart % 60, remain);
                else
                    swprintf(msg, 300, L"%s • початок о %02d:%02d • %s",
                             g_snoozeName.c_str(), g_snoozeStart / 60, g_snoozeStart % 60, how);
                ShowNotif(L"Нагадування про початок уроку за одну хвилину", msg, g_cfg.notifsnd != 0, false, g_snoozeUrl, false,
                          (g_snoozeStart > 0) ? g_snoozeStart + 45 : -1);   // 3.4.17
            }
        }
    }
    if (!g_cfg.notif || g_sched.empty()) return;
    if (st.wDayOfWeek < 1 || st.wDayOfWeek > 5) return;
    bool zoomWasChecked = false, zoomUp = false;
    for (size_t i = 0; i < g_sched.size(); ++i) {
        const NItem& it = g_sched[i];
        if (it.dow != (int)st.wDayOfWeek) continue;
        int delta = it.startMin - nowM;
        if (delta >= 0 && delta <= g_cfg.notifmin) {
            long long key = dayKey * 1000 + (long long)i;
            if (DoneKeyHas(key)) continue;   // 3.4.11: цього уроку вже стосувались (надіслали/ігнор/вхід)
            /* 3.4.11: АВТОПЕРЕВІРКА ZOOM (просив власник). Zoom відкритий —
               користувач уже на уроці: сповіщення НЕ надсилається, урок
               позначаємо «закритим» (більше ніяких нагадувань про нього). */
            if (!zoomWasChecked) { zoomUp = ZoomRunning(); zoomWasChecked = true; }
            DoneKeyAdd(key);
            g_notifKey = key;
            if (zoomUp) continue;
            g_lastNotifIdx = (int)i;
            std::wstring nm = Utf8ToWide(it.name);
            /* 3.4.6: ДИЗАЙН СПОВІЩЕННЯ від користувача:
               ЗАГОЛОВОК (перший, жирний рядок) = «Зайти на урок через N хв» —
               сама дія; ДРУГИЙ рядок = деталі: назва уроку • час початку. */
            wchar_t ttl[160], msg[300];
            if (delta <= 0) {
                swprintf(ttl, 160, L"\u0417\u0430\u0439\u0442\u0438 \u043d\u0430 \u0443\u0440\u043e\u043a \u2014 \u0432\u0436\u0435 \u043f\u043e\u0447\u0438\u043d\u0430\u0454\u0442\u044c\u0441\u044f");
                swprintf(msg, 300, L"%s \u2022 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u043e %02d:%02d", nm.c_str(), it.startMin / 60, it.startMin % 60);
            } else {
                swprintf(ttl, 160, L"\u0417\u0430\u0439\u0442\u0438 \u043d\u0430 \u0443\u0440\u043e\u043a \u0447\u0435\u0440\u0435\u0437 %d \u0445\u0432", delta);
                swprintf(msg, 300, L"%s \u2022 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u043e %02d:%02d", nm.c_str(), it.startMin / 60, it.startMin % 60);
            }
            /* 3.4.6: кнопка «Зайти на урок» несе САМЕ ПОСИЛАННЯ уроку (encoded)
               — join працює навіть якщо пошук уроку в інтерфейсі не влучить.
               3.4.11: кнопка «Нагадати за 1 хв» — ЛИШЕ якщо в налаштуваннях
               НЕ 1 хвилина (за 1 хв кнопка бессенна — логіка від власника);
               сповіщення стріляє РІВНО ОДИН раз за час із налаштувань. */
            int expM = (it.endMin > it.startMin) ? it.endMin : (it.startMin + 45);   // 3.4.17
            ShowNotif(ttl, msg, g_cfg.notifsnd != 0, false, Utf8ToWide(it.url), g_cfg.notifmin > 1, expM);
            PushNotifToUi(it.name, it.startMin, delta);
            return;
        }
    }
}

static void AddTray() {
    if (!g_hwnd) return;
    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = g_hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    g_nid.uCallbackMessage = WM_APP + 1;
    g_nid.hIcon = LoadIconW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(1));
    wcsncpy(g_nid.szTip, L"FluxHelper", 63);
    g_trayOk = Shell_NotifyIconW(NIM_ADD, &g_nid) != FALSE;
}

// ================================================== хмарний міст (Cloudflare D1 REST)
// Интерфейс шле fh:cfq|<id>|<json {sql,params}> -> POST у D1 з вбудованим токеном
// -> __fh.cfqCb(<id>,<status>,<json>). fh:cloud|... — той самий міст без токена
// (довільний URL) -> __fh.cloudCb. CORS не діє для нативних запитів.
static const UINT WM_CLOUD_DONE = WM_APP + 6;   // lp = new CloudResult
struct CloudParams {
    std::wstring id, method, url, body, auth;
    int kind = 1;   // 1 = cfq, 2 = cloud (generic), 4 = token exchange, 5 = auth probe
    bool noRedir = false;   // 2.7.7: не слідувати редіректам (probe OAuth-клієнта)
    std::wstring ctype;     // 2.7.7: свій Content-Type (порожньо = application/json)
};
struct CloudResult { std::wstring id; int status; std::string body; int kind; std::wstring loc; };

// 2.7.3: ПРОКСІ-РОЗУМНА сесія WinHTTP. У шкільних/корпоративних мережах
// інтернет ходить через системний проксі, але WINHTTP_ACCESS_TYPE_DEFAULT_PROXY
// його НЕ бачить (читає лише службові WinHTTP-ключі реєстру). Через це D1 і
// tokeninfo помирали на таких ПК, хоча браузер працював — користувач бачив
// «Немає зв'язку з базою» і не міг увійти. Дивимось IE/WinINET-налаштування
// юзера (авто-детект PAC або явний проксі) — як звичайний браузер.
#ifndef SECURITY_FLAG_IGNORE_REVOCATION
#define SECURITY_FLAG_IGNORE_REVOCATION 0x00000080
#endif
#ifndef WINHTTP_OPTION_REDIRECT_POLICY_DISABLE
#define WINHTTP_OPTION_REDIRECT_POLICY_DISABLE 0
#endif

static HINTERNET SmartWinHttpOpen(const wchar_t* agent) {
    WINHTTP_CURRENT_USER_IE_PROXY_CONFIG ie{};
    if (WinHttpGetIEProxyConfigForCurrentUser(&ie)) {
        if (ie.fAutoDetect) {
            HINTERNET s = WinHttpOpen(agent, WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                      WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
            if (s) return s;
        }
        if (ie.lpszProxy) {
            HINTERNET s = WinHttpOpen(agent, WINHTTP_ACCESS_TYPE_NAMED_PROXY, ie.lpszProxy,
                                      ie.lpszProxyBypass ? ie.lpszProxyBypass : WINHTTP_NO_PROXY_BYPASS, 0);
            if (s) return s;
        }
    }
    return WinHttpOpen(agent, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                       WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
}

// 2.8.2: запасний канал WinINet — реалізація в inet.cpp (окремий TU, бо
// wininet.h конфліктує з winhttp.h). Викликається при status==0 (транспорт мертвий).
bool FhInetRequest(const wchar_t* host, const unsigned short port, bool https,
                   const wchar_t* method, const wchar_t* path, const std::wstring& hdrs,
                   const std::string& body, int& status, std::string& resp);

static DWORD WINAPI CloudThread(LPVOID lp) {
    std::unique_ptr<CloudParams> p((CloudParams*)lp);
    std::string resp;
    std::wstring loc;
    int status = 0;
    wchar_t host[256] = {}, path[2048] = {};
    URL_COMPONENTSW uc{};
    uc.dwStructSize = sizeof(uc);
    uc.lpszHostName = host;  uc.dwHostNameLength = 255;
    uc.lpszUrlPath  = path;  uc.dwUrlPathLength = 2047;
    if (WinHttpCrackUrl(p->url.c_str(), (DWORD)p->url.size(), 0, &uc)) {
        // 2.7.4: SmartWinHttpOpen замість DEFAULT_PROXY — у школах/VPN інтернет
        // ходить через системний проксі, прямі з'єднання часто стягнуті фаєрволом
        // (попередній фікс застосували лише до апдейтера — хмарний міст пропустили)
        HINTERNET ses = SmartWinHttpOpen(L"FluxHelper-Cloud");
        if (ses) {
            int tmo = 8000;   // 2.7.3: явні таймаути (дефолти WinHTTP — хвилини очікування)
            WinHttpSetOption(ses, WINHTTP_OPTION_RESOLVE_TIMEOUT, &tmo, sizeof(tmo));
            tmo = 12000; WinHttpSetOption(ses, WINHTTP_OPTION_CONNECT_TIMEOUT, &tmo, sizeof(tmo));
            tmo = 20000; WinHttpSetOption(ses, WINHTTP_OPTION_SEND_TIMEOUT, &tmo, sizeof(tmo));
            tmo = 45000; WinHttpSetOption(ses, WINHTTP_OPTION_RECEIVE_TIMEOUT, &tmo, sizeof(tmo));
            DWORD redir = p->noRedir ? WINHTTP_OPTION_REDIRECT_POLICY_DISABLE
                                     : WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;
            WinHttpSetOption(ses, WINHTTP_OPTION_REDIRECT_POLICY, &redir, sizeof(redir));
            HINTERNET con = WinHttpConnect(ses, host, uc.nPort, 0);
            HINTERNET req = con ? WinHttpOpenRequest(con, p->method.c_str(), path, nullptr,
                                  WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                  (uc.nScheme == INTERNET_SCHEME_HTTPS) ? WINHTTP_FLAG_SECURE : 0) : nullptr;
            std::string bodyUtf8 = WideToUtf8(p->body);
            BOOL sent = FALSE;
            for (int att = 0; att < 2 && !sent; ++att) {
                if (req && att == 1) {
                    // 2.7.3: повтор із пом'якшеним TLS. Шкільні проксі та
                    // антивіруси перехоплюють HTTPS (MITM) — суворий Schannel
                    // відхиляє їхній сертифікат, і весь хмарний міст помирав.
                    DWORD sf = 0, sl = sizeof(sf);
                    if (WinHttpQueryOption(req, WINHTTP_OPTION_SECURITY_FLAGS, &sf, &sl)) {
                        sf |= SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID
                            | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_REVOCATION;
                        WinHttpSetOption(req, WINHTTP_OPTION_SECURITY_FLAGS, &sf, sizeof(sf));
                    }
                }
                if (req) {
                    std::wstring hdrs;
                    if (!p->auth.empty()) hdrs += L"Authorization: Bearer " + p->auth + L"\r\n";
                    if (!bodyUtf8.empty())
                        hdrs += L"Content-Type: " +
                                (p->ctype.empty() ? std::wstring(L"application/json") : p->ctype) + L"\r\n";
                    if (bodyUtf8.empty())
                        sent = WinHttpSendRequest(req, hdrs.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS
                                                                    : (LPWSTR)hdrs.c_str(), (DWORD)-1,
                                                  WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
                    else
                        sent = WinHttpSendRequest(req, (LPWSTR)hdrs.c_str(), (DWORD)-1,
                                                  (LPVOID)bodyUtf8.data(), (DWORD)bodyUtf8.size(),
                                                  (DWORD)bodyUtf8.size(), 0);
                    sent = sent && WinHttpReceiveResponse(req, nullptr);
                }
            }
            DWORD stCode = 0, sz = sizeof(stCode);
            if (sent && WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                            WINHTTP_HEADER_NAME_BY_INDEX, &stCode, &sz, WINHTTP_NO_HEADER_INDEX)) {
                status = (int)stCode;
                {   // Location — потрібно для probe клієнта без редіректів (kind=5)
                    wchar_t lb[1024] = {};
                    DWORD lsz = sizeof(lb) - sizeof(wchar_t);
                    if (WinHttpQueryHeaders(req, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX,
                                            lb, &lsz, WINHTTP_NO_HEADER_INDEX))
                        loc.assign(lb, lsz / sizeof(wchar_t));
                }
                for (;;) {
                    DWORD avail = 0;
                    if (!WinHttpQueryDataAvailable(req, &avail) || !avail) break;
                    std::vector<char> buf(avail);
                    DWORD rd = 0;
                    if (!WinHttpReadData(req, buf.data(), avail, &rd) || !rd) break;
                    resp.append(buf.data(), rd);
                    if (resp.size() > 4u * 1024 * 1024) break;
                }
            }
            if (req) WinHttpCloseHandle(req);
            if (con) WinHttpCloseHandle(con);
            WinHttpCloseHandle(ses);
        }
    }
    CloudResult* r = nullptr;
    if (status == 0 && p->kind == 1 && !p->body.empty()) {
        // 2.8.2: WinHTTP не зміг навіть з'єднатися (статус 0) -> запасний WinINet
        std::wstring hdr2;
        if (!p->auth.empty()) hdr2 += L"Authorization: Bearer " + p->auth + L"\r\n";
        if (!p->body.empty()) hdr2 += L"Content-Type: " +
            (p->ctype.empty() ? std::wstring(L"application/json") : p->ctype) + L"\r\n";
        std::string resp2;
        int st2 = 0;
        if (FhInetRequest(host, (unsigned short)uc.nPort,
                          uc.nScheme == INTERNET_SCHEME_HTTPS, p->method.c_str(), path,
                          hdr2, WideToUtf8(p->body), st2, resp2)) {
            status = st2; resp = resp2;
        }
    }
    r = new CloudResult{ p->id, status, resp, p->kind, loc };
    PostMessageW(g_hwnd, WM_CLOUD_DONE, 0, (LPARAM)r);
    return 0;
}

// JSON-екранізація для UTF-8-рядків (значення параметрів SQL-запиту)
static std::string JsonEscU8(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += (char)c; }
        else if (c == '\n') o += "\\n";
        else if (c == '\r') o += "\\r";
        else if (c == '\t') o += "\\t";
        else if (c < 0x20) { char b[8]; snprintf(b, sizeof(b), "\\u%04x", c); o += b; }
        else o += (char)c;
    }
    return o;
}

// витягнути значення простого JSON-рядка "key":"value"
static std::wstring JsonStr(const std::string& j, const char* key) {
    std::string pat = std::string("\"") + key + "\":\"";
    size_t p = j.find(pat);
    if (p == std::string::npos) return L"";
    p += pat.size();
    std::string v;
    while (p < j.size() && j[p] != '"') {
        if (j[p] == '\\' && p + 1 < j.size()) {
            char c = j[p + 1];
            if (c == '"' || c == '\\' || c == '/') v += c;
            else if (c == 'n') v += '\n';
            else if (c == 'u' && p + 5 < j.size()) { p += 4; }   // юнікод-ескејп пропускаємо
            ++p;
        } else v += j[p];
        ++p;
    }
    return Utf8ToWide(v);
}

// перевірка ID-токена через публічний tokeninfo Google (валідує підпис сам Google)
static void AuthFromTokenInfo(int status, const std::string& body) {
    if (status != 200) {
        UiScript(L"window.__fh&&window.__fh.authErr&&window.__fh.authErr('Google не підтвердив вхід — спробуй ще раз')");
        return;
    }
    // aud у tokeninfo — рядок або масив; шукаємо наш client_id як підрядок
    // (приймаємо і старий web-клієнт сайту входу, і новий десктопний з version.h)
    if (body.find("k470ldmdv0r9am0720v6lgaatm6rtuf3") == std::string::npos &&
        body.find(FH_OAUTH_CLIENT_A) == std::string::npos) {
        UiScript(L"window.__fh&&window.__fh.authErr&&window.__fh.authErr('Токен не для цієї програми')");
        return;
    }
    std::wstring sub = JsonStr(body, "sub");
    if (sub.empty()) {
        UiScript(L"window.__fh&&window.__fh.authErr&&window.__fh.authErr('Не вдалося прочитати профіль Google')");
        return;
    }
    std::wstring nm = JsonStr(body, "name");
    std::wstring em = JsonStr(body, "email");
    std::wstring pic = JsonStr(body, "picture");
    auto esc = [](std::wstring t) {
        for (auto& c : t) if (c == L'"' || c == L'\\') c = L' ';
        return t;
    };
    std::wstring js = L"window.__fh&&window.__fh.authOk&&window.__fh.authOk({sub:\"" + esc(sub) +
        L"\",name:\"" + esc(nm) + L"\",email:\"" + esc(em) + L"\",pic:\"" + esc(pic) + L"\"})";
    UiScript(js);
}

// запуск перевірки у фоні (WinHTTP GET tokeninfo)
static void VerifyIdToken(const std::wstring& token) {
    if (token.size() < 40 || token.size() > 4000) {
        UiScript(L"window.__fh&&window.__fh.authErr&&window.__fh.authErr('Некоректні дані входу')");
        return;
    }
    for (wchar_t c : token) {
        if (!(c == L'.' || c == L'-' || c == L'_' || (c >= L'0' && c <= L'9') ||
              (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z'))) {
            UiScript(L"window.__fh&&window.__fh.authErr&&window.__fh.authErr('Некоректні дані входу')");
            return;
        }
    }
    CloudParams* cp = new CloudParams();
    cp->id = L"auth";
    cp->method = L"GET";
    cp->url = std::wstring(L"https://oauth2.googleapis.com/tokeninfo?id_token=") + token;
    cp->kind = 3;
    std::thread(CloudThread, cp).detach();
}

// витяг ?u=<url> з fluxhelper://join?u=... (кнопка тоста). 3.4.6: значення
// percent- закодоване (ProtoEnc) — декодуємо (раніше Zoom-посилання обрізалось
// на першому '&', і «Зайти» відкривало кімнату без пароля).
static std::wstring ProtoArgU(const std::wstring& url) {
    size_t p = url.find(L"?u=");
    if (p == std::wstring::npos) return L"";
    std::wstring u = url.substr(p + 3);
    size_t c = u.find_first_of(L"& ");
    if (c != std::wstring::npos) u = u.substr(0, c);
    return ProtoDec(u);
}

// лапки для JS-рядка
static std::wstring JsEsc(const std::wstring& s) {
    std::wstring o;
    for (wchar_t c : s) { if (c == L'\'' || c == L'\\') { o += L'\\'; o += c; } else if (c == L'"') { o += L'\\'; o += L'"'; } else o += c; }
    return o;
}

/* 3.4.14: клік «Зайти на урок» (тост/попап) — ОДНА точка: якщо відома URL
   уроку (аргумент кнопки або нагадування) — відкриваємо САМЕ її; інакше
   інтерфейс шукає останній сповіщений урок. Так «Зайти» гарантовано
   перекидує на урок і на ПК, і на телефоні (дзеркальна логіка fh.join). */
static void UiJoinLesson(const std::wstring& url) {
    DoneKeyAdd(g_notifKey);
    g_snoozeMin = -1;
    if (!url.empty())
        UiScript(L"window.__fh&&window.__fh.notifAction&&window.__fh.notifAction('join','" + JsEsc(url) + L"')");
    else
        UiScript(L"window.__fh&&window.__fh.notifAction&&window.__fh.notifAction('join')");
}

// обробка fluxhelper://... з командного рядка / другого інстансу
/* 3.4.11: користувач УВІЙШОВ на урок із розкладу/кнопки уроку (fh:join/fh:join2).
   Якщо на цей урок мало прийти сповіщення — ГОЛОСУЄМО ЙОГО ВЖЕ НЕ ПРИСИЛАТИ:
   шукаємо в сьогоднішньому розкладі урок із цим посиланням і позначаємо
   «закритим» (раніше після входу вручну сповіщення все одно приходило). */
static void JoinMarkToday(const std::wstring& link) {
    if (link.size() < 12 || g_sched.empty()) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    long long dayKey = (long long)st.wYear * 10000 + st.wMonth * 100 + st.wDay;
    for (size_t i = 0; i < g_sched.size(); ++i) {
        if (g_sched[i].dow != (int)st.wDayOfWeek) continue;
        const std::wstring u = Utf8ToWide(g_sched[i].url);
        if (!u.empty() && u == link) {
            DoneKeyAdd(dayKey * 1000 + (long long)i);
            if (g_lastNotifIdx == (int)i) g_snoozeMin = -1;   // снуze цього уроку скасовуємо
        }
    }
}

static void HandleProtoUrl(const std::wstring& url) {
    if (url.find(L"fluxhelper://auth?d=") != std::wstring::npos) {
        std::wstring tok = url.substr(url.find(L"fluxhelper://auth?d=") + 20);
        VerifyIdToken(tok);
    }
    /* 3.4.5: кнопки ТОСТА працюють і тоді, коли застосунок було закрито:
       клік по кнопці запускає новий інстанс з fluxhelper://join|snooze у
       командному рядку — тут він доїжджає після підйому інтерфейсу. */
    if (url.find(L"fluxhelper://join") != std::wstring::npos) {
        /* 3.4.14: єдина точка входу «Зайти на урок» (з URL із кнопки або без) */
        UiJoinLesson(ProtoArgU(url));
    }
    /* 3.4.11: «Проігнорувати» в тості — сповіщення про ЦЕЙ УРОК більше
       НІКОЛИ не приходить (і «Нагадати за 1 хв» скасовується). */
    if (url.find(L"fluxhelper://ignore") != std::wstring::npos) {
        DoneKeyAdd(g_notifKey);
        g_snoozeMin = -1;
    }
    if (url.find(L"fluxhelper://snooze") != std::wstring::npos)
        ArmSnooze();
    /* 3.4.13: кнопка «Нагадати за 1 хв» ТЕСТОВОГО тоста — завжди демо */
    if (url.find(L"fluxhelper://tsnooze") != std::wstring::npos)
        ArmSnooze(true);
}

static const wchar_t* kCfApiBase =
    L"https://api.cloudflare.com/client/v4/accounts/"
    L"fd6013c3a257c7759ff3c15fbb8ac002/d1/database/89424274-f50b-4931-838e-0d6f384bbc20/query";

// ------------------------------------------------- тема з хмари (2.8.8)
// ДО показу інтерфейсу дізнаємось, яка тема оформлення у цього аккаунта:
// фонова нитка робить один мікро-запит у D1 (SELECT settings ... WHERE
// user_id = <Firebase UID>, або за поштою, якщо UID ще не зберігся) і
// витягує "th" зі знімка налаштувань. Без аккаунта / без мережі — локальна
// або стандартна. Запит фоновий: вікно з'являється одразу, сплеш просто
// перефарбовується, щойно відповідь долетить (до показу WebView2 вона
// встигає практично завжди — ініціалізація WebView2 значно довша).

// фон WebView2 ДО першого кадру = базовий колір теми (без темного спалаху
// у світлій темі і навпаки). Викликається при створенні контролера і при
// зміні теми (fh:theme).
static void UpdateWebViewBg() {
    if (!g_ctrl) return;
    const std::string t = CurrentTheme();
    ICoreWebView2Controller2* c2 = nullptr;
    if (SUCCEEDED(g_ctrl->QueryInterface(kIID_Controller2, (void**)&c2)) && c2) {
        COREWEBVIEW2_COLOR bg{};
        bg.A = 255;
        if (t == "light")     { bg.R = 0xEE; bg.G = 0xF0; bg.B = 0xF8; }   // #eef0f8
        else if (t == "glass"){ bg.R = 0x0E; bg.G = 0x0A; bg.B = 0x26; }   // #0e0a26
        else                  { bg.R = 5;    bg.G = 5;    bg.B = 8;    }   // #050508
        c2->put_DefaultBackgroundColor(bg);
        c2->Release();
    }
}

// лапки всередині SQL-літерала (' -> '')
static std::string SqlEsc(const std::string& s) {
    std::string o; o.reserve(s.size() + 8);
    for (char c : s) { if (c == '\'') o += "''"; else o += c; }
    return o;
}

// синхронний мікро-запит теми (викликається ЛИШЕ з фонової нитки).
// Повертає "light"/"glass"/"standard" або порожній рядок.
static std::string FetchThemeFromCloudSync() {
    // 2.8.9: налаштування живуть У РЯДКУ КОРИСТУВАЧА (users.settings).
    // Запит: спершу за Firebase UID (ключ рядка), без нього — за поштою.
    std::string sql;
    if (!g_cfg.fid.empty())
        sql = "SELECT settings FROM users WHERE user_id='" + SqlEsc(g_cfg.fid) + "' LIMIT 1";
    else if (!g_cfg.mail.empty())
        sql = "SELECT settings FROM users WHERE email='" + SqlEsc(g_cfg.mail) + "' "
              "AND user_id NOT LIKE 'g:%' ORDER BY ts DESC LIMIT 1";
    else
        return "";
    std::string body = "{\"sql\":\"" + JsonEscU8(sql) + "\",\"params\":[]}";
    std::string resp;
    int status = 0;
    wchar_t host[256] = {}, path[2048] = {};
    URL_COMPONENTSW uc{};
    uc.dwStructSize = sizeof(uc);
    uc.lpszHostName = host;  uc.dwHostNameLength = 255;
    uc.lpszUrlPath  = path;  uc.dwUrlPathLength = 2047;
    if (!WinHttpCrackUrl(kCfApiBase, (DWORD)wcslen(kCfApiBase), 0, &uc)) return "";
    HINTERNET ses = SmartWinHttpOpen(L"FluxHelper-Theme");
    if (!ses) return "";
    int tmo = 1200;   // КОРПОТКІ таймаути: вікно вже показано, чекати не можна
    WinHttpSetOption(ses, WINHTTP_OPTION_RESOLVE_TIMEOUT, &tmo, sizeof(tmo));
    tmo = 1800; WinHttpSetOption(ses, WINHTTP_OPTION_CONNECT_TIMEOUT, &tmo, sizeof(tmo));
    tmo = 1000; WinHttpSetOption(ses, WINHTTP_OPTION_SEND_TIMEOUT, &tmo, sizeof(tmo));
    tmo = 2500; WinHttpSetOption(ses, WINHTTP_OPTION_RECEIVE_TIMEOUT, &tmo, sizeof(tmo));
    HINTERNET con = WinHttpConnect(ses, host, uc.nPort, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, L"POST", path, nullptr, WINHTTP_NO_REFERER,
                          WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
    if (req) {
        std::wstring hdrs = L"Authorization: Bearer " + Utf8ToWide(CfToken()) +
                            L"\r\nContent-Type: application/json\r\n";
        if (WinHttpSendRequest(req, (LPWSTR)hdrs.c_str(), (DWORD)-1,
                               (LPVOID)body.data(), (DWORD)body.size(), (DWORD)body.size(), 0) &&
            WinHttpReceiveResponse(req, nullptr)) {
            DWORD st = 0, sz = sizeof(st);
            WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                WINHTTP_HEADER_NAME_BY_INDEX, &st, &sz, WINHTTP_NO_HEADER_INDEX);
            status = (int)st;
            for (;;) {   // читаємо тіло (воно маленьке, але цикл на всяк випадок)
                DWORD av = 0;
                if (!WinHttpQueryDataAvailable(req, &av) || !av) break;
                std::vector<char> chunk(av + 1, 0);
                DWORD rd = 0;
                if (!WinHttpReadData(req, chunk.data(), av, &rd) || !rd) break;
                resp.append(chunk.data(), rd);
                if (resp.size() > (1 << 20)) break;   // розумна межа
            }
        }
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    if (status != 200 || resp.empty()) return "";
    // у відповіді results[0].settings = "{\"g\":...,\"th\":\"light\",...}" (екранований JSON)
    // 2.8.9: settings може бути NULL (старий рядок без налаштувань) — JsonGetStr не знайде ключ
    std::string set, th;
    if (!JsonGetStr(resp.c_str(), "\"settings\"", set) || set.empty()) return "";
    if (!JsonGetStr(set.c_str(), "\"th\"", th)) return "";
    return ThemeValid(th) ? th : std::string();
}

static DWORD WINAPI ThemeFetchThread(LPVOID) {
    std::string th = FetchThemeFromCloudSync();
    if (!ThemeValid(th)) return 0;
    bool changed = false;
    {
        AcquireSRWLockExclusive(&g_themeLock);
        changed = (th != g_cfg.theme);
        StoreTheme(th);   // малювання сплеша й ui.html одразу бачать нову тему
        ReleaseSRWLockExclusive(&g_themeLock);
    }
    // збереження й перемальовка — на головній нитці (без гонок на файлі)
    if (changed && g_hwnd) PostMessage(g_hwnd, WM_APP + 12, 0, 0);
    return 0;
}
// Запуск перевірки теми: лише якщо на цьому ПК вже є аккаунт.
static void StartThemeFetch() {
    if (g_cfg.sub.empty() && g_cfg.fid.empty() && g_cfg.mail.empty()) return;
    std::thread(ThemeFetchThread, (LPVOID)nullptr).detach();
}

// ------------------------------------------------- збірка HTML
static void ReplaceFirst(std::string& s, const std::string& from, const std::string& to) {
    size_t p = s.find(from);
    if (p != std::string::npos) s.replace(p, from.size(), to);
}
static void ReplaceAll(std::string& s, const std::string& from, const std::string& to) {
    if (from.empty()) return;
    size_t p = 0;
    while ((p = s.find(from, p)) != std::string::npos) {
        s.replace(p, from.size(), to);
        p += to.size();
    }
}
static std::string g_authErr;   // 2.7.6: остання помилка входу (one-shot у UI)

static std::string BuildUiHtml() {
    std::string html = kUiHtmlDesktop;
    std::string css = kUiCssDesktop;
    std::string js = kUiJsDesktop;
    // ГОЛОВНИЙ ФІКС «іконки немає вгорі»: плейсхолдер логотипа зустрічається у
    // HTML КІЛЬКА разів (статичний <img> у титульній панелі + <img> сплеша +
    // const LOGO у JS). Замінюємо ВСЕ і в розмітці, і в JS-частині.
    ReplaceAll(html, "__LOGO_B64__", kLogoB64);
    ReplaceAll(js, "__LOGO_B64__", kLogoB64);
    // APP_VER: у JS-константі та у футері гейта
    ReplaceAll(js, "__APP_VER__", FH_VER_STR);
    char buf[128];
    if (CfgValid(g_cfg))
        snprintf(buf, sizeof(buf), "{\"ang\":%d,\"nim\":%d,\"ukr\":%d,\"inf\":%d,\"trud\":%d}",
                 g_cfg.ang, g_cfg.nim, g_cfg.ukr, g_cfg.inf, g_cfg.trud);
    else
        snprintf(buf, sizeof(buf), "null");
    ReplaceFirst(js, "__SETTINGS_JSON__", buf);
    ReplaceFirst(js, "__DEVINFO_JSON__", "{}");   // 2.4.1: базова інфа про пристрій
    // 3.4.0: акаунт із Credential Manager (хост підставляє профіль сесії у JS;
    // на диску його нема — саме тому localStorage-канал більше не головний)
    if (!g_cfg.sub.empty()) {
        std::string a = "{\"sub\":\"" + JsonEsc(g_cfg.sub) + "\",\"name\":\"" + JsonEsc(g_cfg.nm) +
                        "\",\"email\":\"" + JsonEsc(g_cfg.mail) + "\",\"pic\":\"" + JsonEsc(g_cfg.apic) + "\"" +
                        (g_cfg.fid.empty() ? std::string() : (",\"fid\":\"" + JsonEsc(g_cfg.fid) + "\"")) + "}";
        ReplaceFirst(js, "__AUTH_JSON__", a);
    } else
        ReplaceFirst(js, "__AUTH_JSON__", "null");
    ReplaceFirst(js, "__AUTH_ERR__", JsonEsc(g_authErr));
    g_authErr.clear();

    ReplaceFirst(html, "__APP_VER__", FH_VER_STR);   // футер екрана входу
    // 2.8.8: тема з ПЕРШОГО кадру — <body data-theme="..."> ще до виконання JS.
    ReplaceFirst(html, "__BOOT_THEME__", CurrentTheme());
    // 2.8.8: ФІКС «після виходу лого/назва зникають, вкладки мигають»:
    // якщо аккаунта немає — одразу вшиваємо gate-on у розмітку
    if (g_cfg.sub.empty()) {
        ReplaceFirst(html, "<body class=\"booting\"", "<body class=\"booting gate-on\"");
        ReplaceFirst(html, "<div id=\"agate\" class=\"hidden\">", "<div id=\"agate\">");
    }

    // 2.9.2: аварійний варіант для NavigateToString — css/js вшиті в документ
    std::string inl = html;
    ReplaceFirst(inl, "<link rel=\"stylesheet\" href=\"ui.css\">", "<style>" + css + "</style>");
    ReplaceFirst(inl, "<script src=\"ui.js\"></script>", "<script>" + js + "</script>");
    g_uiCss = css;
    g_uiJs = js;
    g_uiInline = inl;
    return html;
}

/* 2.9.2: пишемо ТРИ файли інтерфейсу (ui.html + ui.css + ui.js).
   3.3.2: вони живуть у ПІДПАПЦІ %APPDATA%\FluxHelper\UI\ (а не просто в папці
   програми — так просив власник). Старі ui.* з кореня папки підчищаються
   разово. true — лише якщо ВСІ три записані; інакше викликач іде в
   NavigateToString з вшитим варіантом (g_uiInline). */
static bool WriteUiFiles(std::wstring& outPath) {
    static bool cleaned = false;
    const std::wstring dir = DataDir() + L"\\UI";
    CreateDirectoryW(dir.c_str(), nullptr);
    if (!cleaned) {
        cleaned = true;
        // разове прибирання: у версіях до 3.3.2 ui.html/ui.css/ui.js лежали в корені
        DeleteFileW((DataDir() + L"\\ui.html").c_str());
        DeleteFileW((DataDir() + L"\\ui.css").c_str());
        DeleteFileW((DataDir() + L"\\ui.js").c_str());
    }
    const struct { const wchar_t* name; const std::string* data; } parts[3] = {
        { L"\\ui.html", &g_uiHtml }, { L"\\ui.css", &g_uiCss }, { L"\\ui.js", &g_uiJs } };
    for (int i = 0; i < 3; ++i) {
        HANDLE f = CreateFileW((dir + parts[i].name).c_str(), GENERIC_WRITE, 0, nullptr,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (f == INVALID_HANDLE_VALUE) return false;
        DWORD w = 0;
        WriteFile(f, parts[i].data->data(), (DWORD)parts[i].data->size(), &w, nullptr);
        CloseHandle(f);
    }
    outPath = dir + L"\\ui.html";
    return true;
}

// Правильний file:///URL: зворотні слеші -> прямі, двокрапку літери диска НЕ кодуємо.
// (Колишнє кодування давало file:///C%3A%5CUsers%5C... -> ERR_INVALID_URL у Chromium)
static std::wstring FileUrl(const std::wstring& path) {
    std::string u8 = WideToUtf8(path);
    std::string out = "file:///";
    char b[8];
    for (unsigned char c : u8) {
        if (c == '\\') { out += '/'; continue; }          // C:\Users -> C:/Users
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '/' || c == ':' ||                        // літера диска (C:)
            c == '-' || c == '_' || c == '.' || c == '~' || c == '!')
            out += (char)c;
        else { snprintf(b, sizeof(b), "%%%02X", (unsigned)c); out += b; }  // пробіли/кирилиця -> %XX
    }
    return Utf8ToWide(out);
}

// ================================================== автооновлення (PC)
// Інтерфейс надсилає  fh:update|{"v":"1.5.4","repo":"user/FluxHelper"}.
// 1) Качаємо НОВИЙ exe з GitHub (versions/<v>/FluxControl.exe, запасний варіант —
//    старе ім'я FluxHelper.exe) ПРЯМО В ПАПКУ, ДЕ ЛЕЖИТЬ ЗАПУЩЕНИЙ exe —
//    щоб після оновлення програма лишилась на тому самому місці (стіл тощо).
// 2) ПЕРЕВІРЯЄМО, що завантажений файл — справді потрібна версія (у VERSIONINFO
//    всередині exe рядок версії лежить у UTF-16). Раніше саме несвіжий файл у
//    versions/<v> спричиняв «скачує ту саму версію» — тепер таке ловиться.
// 3) Заміна «на гарячому» БЕЗ .bat: працюючий exe перейменовується у
//    FluxControl.old.tmp.exe (Windows дозволяє перейменувати запущений файл),
//    FluxControl.new.exe стає FluxControl.exe -> запуск нової версії -> вихід.
//    Старий .bat-механізм часом мовчки падав (файл заблокований антивірусом
//    або OneDrive) — тоді версія залишалась старою і з'являвся зайвий «термінал».
// Прогрес -> вікно через WM_APP+3/+4/+5 (з потоку можна лише PostMessage).

static const UINT WM_UPD_PROG = WM_APP + 3;   // wp = 0..100
static const UINT WM_UPD_ERR  = WM_APP + 4;   // lp = new std::wstring
static const UINT WM_UPD_DONE = WM_APP + 5;   // завантажено, запускаємо

static void UpdPostErr(const wchar_t* msg) {
    PostMessageW(g_hwnd, WM_UPD_ERR, 0, (LPARAM)(void*)new std::wstring(msg));
}

// повний шлях до поточного exe
static std::wstring ExePath() {
    wchar_t buf[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    return std::wstring(buf);
}

// папка, де лежить поточний exe (оновлення ставиться поруч, а не в %TEMP%)
static std::wstring ExeDirUpd() {
    std::wstring p = ExePath();
    size_t s = p.find_last_of(L"\\/");
    return (s == std::wstring::npos) ? std::wstring(L".") : p.substr(0, s);
}

// 3.4.5: MD5 для контролю цілісності скачаного exe (bcrypt.dll динамічно —
// без нових залежностей у статичній збірці). latest.json несе exe_md5, і якщо
// сервер дав MD5 — файл без збігу НЕ ВСТАНОВЛЮЄТЬСЯ взагалі (захист від
// пошкодженого/підміненого завантаження, який UTF-16-пошук не ловить).
static bool MemMd5(const std::vector<unsigned char>& data, unsigned char out[16]) {
    if (data.empty()) return false;
    HMODULE bm = GetModuleHandleW(L"bcrypt.dll");
    if (!bm) bm = LoadLibraryW(L"bcrypt.dll");
    if (!bm) return false;
    typedef LONG (WINAPI *FnOpenAlg)(void**, LPCWSTR, LPCWSTR, DWORD);
    typedef LONG (WINAPI *FnCreateHash)(void*, void*, unsigned char*, DWORD, void*, DWORD, void**);
    typedef LONG (WINAPI *FnHashData)(void*, const unsigned char*, DWORD, DWORD);
    typedef LONG (WINAPI *FnFinishHash)(void*, unsigned char*, DWORD, DWORD);
    typedef LONG (WINAPI *FnCloseAlg)(void*, DWORD);
    FnOpenAlg     openAlg = (FnOpenAlg)(void*)GetProcAddress(bm, "BCryptOpenAlgorithmProvider");
    FnCreateHash  crHash  = (FnCreateHash)(void*)GetProcAddress(bm, "BCryptCreateHash");
    FnHashData    hashDat = (FnHashData)(void*)GetProcAddress(bm, "BCryptHashData");
    FnFinishHash  finHash = (FnFinishHash)(void*)GetProcAddress(bm, "BCryptFinishHash");
    FnCloseAlg    closeAl = (FnCloseAlg)(void*)GetProcAddress(bm, "BCryptCloseAlgorithmProvider");
    if (!openAlg || !crHash || !hashDat || !finHash || !closeAl) return false;
    void* alg = nullptr; void* hash = nullptr;
    bool ok = false;
    do {
        if (openAlg(&alg, L"MD5", nullptr, 0) != 0 || !alg) break;
        if (crHash(alg, &hash, nullptr, 0, nullptr, 0, 0) != 0 || !hash) break;
        if (hashDat(hash, data.data(), (DWORD)data.size(), 0) != 0) break;
        if (finHash(hash, out, 16, 0) != 0) break;
        ok = true;
    } while (0);
    if (hash) closeAl(hash, 0);
    if (alg) closeAl(alg, 0);
    return ok;
}
static std::wstring Md5Hex(const unsigned char d[16]) {
    static const wchar_t* hx = L"0123456789abcdef";
    std::wstring o;
    for (int i = 0; i < 16; ++i) { o += hx[(d[i] >> 4) & 15]; o += hx[d[i] & 15]; }
    return o;
}

// Заміна exe «на гарячому»: запущений exe НЕ вдасться видалити, але МОЖНА
// перейменувати. 1) <self> -> FluxHelper.old.tmp.exe (процес далі працює),
// 2) FluxHelper.new.exe -> <self> (нова версія стає на місце старої,
//    під ЯКИМ ІМ'ЯМ програма була запущена — під таким і лишається).
// Невдала спроба -> відкат. Це надійніше за .bat: не залежить від кодових
// сторінок cmd, антивірусів і OneDrive, не показує вікон консолі.
// 3.4.5: ретраїв стало 10 (антивірус може тримати новий файл кілька секунд
// після скачування), пауза 500 мс — сумарно до 5 с на кожен крок.
static bool InstallUpdateFiles(const std::wstring& exePath) {
    size_t s = exePath.find_last_of(L"\\/");
    if (s == std::wstring::npos) return false;
    const std::wstring dir = exePath.substr(0, s);
    const std::wstring oldP = dir + L"\\FluxHelper.old.tmp.exe";
    const std::wstring newP = dir + L"\\FluxHelper.new.exe";
    DeleteFileW(oldP.c_str());   // залишок давнішого оновлення (якщо зараз не зайнятий)
    for (int attempt = 0; attempt < 10; ++attempt) {
        if (MoveFileExW(exePath.c_str(), oldP.c_str(), MOVEFILE_REPLACE_EXISTING)) {
            if (MoveFileExW(newP.c_str(), exePath.c_str(), MOVEFILE_REPLACE_EXISTING))
                return true;
            MoveFileExW(oldP.c_str(), exePath.c_str(), MOVEFILE_REPLACE_EXISTING);   // відкат
        }
        Sleep(500);
    }
    return false;
}

// 3.4.5: ДОГЛЯДАЧ ОНОВЛЕННЯ — прихований cmd-скрипт, який ГАРАНТУЄ закінчення
// установки навіть якщо головний процес упав посеред заміни (той самий
// випадок власника: «закрило стару, а нову не відкрило і старий файл не
// видалило»). Скрипт: 1) чекає виходу старого процесу (до 45 с, потім
// taskkill /F), 2) ставить FluxHelper.new.exe на місце цільового імені
// (ретраї 45 с), 3) чекає маркер upd.ok від нової версії — якщо вона сама не
// запустилась, ЗАПУСКАЄ ЇЇ (дві спроби), 4) прибирає .old/.new залишки,
// 5) пише журнал у %APPDATA%\FluxHelper\upd.log і видаляє сам себе.
static bool StartUpdateWatchdog(DWORD oldPid, const std::wstring& target) {
    const std::wstring dir = DataDir();
    const std::wstring cmd = dir + L"\\fh_upd.cmd";
    const std::wstring log = dir + L"\\upd.log";
    const std::wstring okf = dir + L"\\upd.ok";
    size_t sl = target.find_last_of(L"\\/");
    const std::wstring tdir = (sl == std::wstring::npos) ? L"." : target.substr(0, sl);
    const std::wstring tname = (sl == std::wstring::npos) ? target : target.substr(sl + 1);
    size_t dot = tname.rfind(L'.');
    const std::wstring stem = (dot == std::wstring::npos) ? tname : tname.substr(0, dot);
    const std::wstring oldf = tdir + L"\\" + stem + L".old.tmp.exe";
    const std::wstring newf = tdir + L"\\FluxHelper.new.exe";

    DeleteFileW(cmd.c_str());   // старий скрипт (якщо ще не виконується — не зачепимо)
    HANDLE f = CreateFileW(cmd.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    std::wstring s;
    s += L"@echo off\r\nsetlocal\r\n";
    s += L"set \"OLDPID=" + std::to_wstring((unsigned long)oldPid) + L"\"\r\n";
    s += L"set \"TARGET=" + target + L"\"\r\n";
    s += L"set \"TARGETDIR=" + tdir + L"\"\r\n";
    s += L"set \"NEWF=" + newf + L"\"\r\n";
    s += L"set \"OLDF=" + oldf + L"\"\r\n";
    s += L"set \"OKF=" + okf + L"\"\r\n";
    s += L"set \"LOG=" + log + L"\"\r\n";
    s += L"echo [%date% %time%] watchdog: start, old pid %OLDPID%>>\"%LOG%\"\r\n";
    s += L"del \"%OKF%\" >nul 2>&1\r\n";
    s += L"set /a W=0\r\n:wait\r\n";
    s += L"tasklist /NH /FI \"PID eq %OLDPID%\" 2>nul | find /I \"INFO:\" >nul\r\n";
    s += L"if not errorlevel 1 goto waited\r\n";
    s += L"set /a W+=1\r\n";
    s += L"if %W% GEQ 45 goto killold\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\ngoto wait\r\n";
    s += L":killold\r\n";
    s += L"echo [%date% %time%] watchdog: force kill old>>\"%LOG%\"\r\n";
    s += L"taskkill /F /PID %OLDPID% >nul 2>&1\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\n";
    s += L"taskkill /F /PID %OLDPID% >nul 2>&1\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\n";
    s += L":waited\r\n";
    s += L"echo [%date% %time%] watchdog: old exited>>\"%LOG%\"\r\n";
    s += L"if exist \"%NEWF%\" goto doswap\r\n";
    s += L"if exist \"%TARGET%\" goto checkok\r\n";
    s += L"echo [%date% %time%] watchdog: target and new file both missing>>\"%LOG%\"\r\n";
    s += L"goto done\r\n";
    s += L":doswap\r\n";
    s += L"set /a M=0\r\n:swap\r\n";
    s += L"move /y \"%NEWF%\" \"%TARGET%\" >nul 2>&1\r\n";
    s += L"if not errorlevel 1 goto swapped\r\n";
    s += L"set /a M+=1\r\n";
    s += L"if %M% GEQ 45 echo [%date% %time%] watchdog: SWAP FAILED>>\"%LOG%\"\r\n";
    s += L"if %M% GEQ 45 goto checkok\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\ngoto swap\r\n";
    s += L":swapped\r\n";
    s += L"echo [%date% %time%] watchdog: swap ok>>\"%LOG%\"\r\n";
    s += L":checkok\r\n";
    s += L"set /a K=0\r\n:ck\r\n";
    s += L"if exist \"%OKF%\" goto clean\r\n";
    s += L"set /a K+=1\r\n";
    s += L"if %K% GEQ 12 goto relaunch\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\ngoto ck\r\n";
    s += L":relaunch\r\n";
    s += L"echo [%date% %time%] watchdog: launching new version>>\"%LOG%\"\r\n";
    s += L"start \"\" /D \"%TARGETDIR%\" \"%TARGET%\"\r\n";
    s += L"set /a K=0\r\n:ck2\r\n";
    s += L"if exist \"%OKF%\" goto clean\r\n";
    s += L"set /a K+=1\r\n";
    s += L"if %K% GEQ 8 goto retry2\r\n";
    s += L"ping -n 2 127.0.0.1 >nul\r\ngoto ck2\r\n";
    s += L":retry2\r\n";
    s += L"echo [%date% %time%] watchdog: retry launch>>\"%LOG%\"\r\n";
    s += L"start \"\" /D \"%TARGETDIR%\" \"%TARGET%\"\r\n";
    s += L"ping -n 8 127.0.0.1 >nul\r\n";
    s += L"if exist \"%OKF%\" goto clean\r\n";
    s += L"echo [%date% %time%] watchdog: LAUNCH FAILED>>\"%LOG%\"\r\n";
    s += L"goto done\r\n";
    s += L":clean\r\n";
    s += L"echo [%date% %time%] watchdog: new version running, cleanup>>\"%LOG%\"\r\n";
    s += L":done\r\n";
    s += L"del \"%OKF%\" >nul 2>&1\r\n";
    s += L"del \"%NEWF%\" >nul 2>&1\r\n";
    s += L"del \"%OLDF%\" >nul 2>&1\r\n";
    s += L"(goto) 2>nul & del \"%~f0\"\r\n";
    DWORD wr = 0;
    BOOL wok = WriteFile(f, s.c_str(), (DWORD)(s.size() * sizeof(wchar_t)), &wr, nullptr);
    CloseHandle(f);
    if (!wok) { DeleteFileW(cmd.c_str()); return false; }

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    std::wstring args = L"cmd.exe /c \"" + cmd + L"\"";
    BOOL ok = CreateProcessW(nullptr, (LPWSTR)args.c_str(), nullptr, nullptr, FALSE,
                             CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    if (ok) { CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
    return ok != FALSE;
}

// Стартова чистка: залишки старих оновлень і давні назви exe (Blazix/FluxHelper).
// Файл, з якого зараз працює процес, і тимчасово зайняті — пропускаються мовчки
// (спроба повториться при наступному запуску й у таймері WM_TIMER(2)).
static void CleanupOldFiles() {
    const std::wstring dir = ExeDirUpd();
    const std::wstring self = ExePath();
    const wchar_t* junk[] = {
        L"\\fh_upd.bat", L"\\FluxControl.new.exe", L"\\FluxControl.old.tmp.exe",
        L"\\FluxHelper.new.exe", L"\\FluxHelper.old.tmp.exe",
        L"\\Blazix.exe", L"\\FluxControl.exe", nullptr };
    for (int i = 0; junk[i]; ++i) {
        std::wstring p = dir + junk[i];
        if (_wcsicmp(p.c_str(), self.c_str()) == 0) continue;   // це ми самі — не чіпаємо
        DeleteFileW(p.c_str());   // зайнятий іншим процесом -> спробуємо пізніше
    }
}

/* 3.5.0 (РЕЛІЗ): прибирання СПАДКУ старих версій у папці даних.
   Власник: «в новой версии мы поменяли структуру, но в файлах всё равно могут
   быть файлы типа C:\Users\...\AppData\Roaming\FluxHelper\ui.html — посмотри
   код версии 2.4.3, все файлы, что она создаёт, и сделай, чтоб оно удаляло
   всё, что не нужно». Реліз 3.5.0 — ПЕРШИЙ реліз після 2.4.3: у користувачів
   2.4.3 (і бета-лінійки 2.7.x-3.4.x) у папці даних лежить сміття, яке нова
   структура вже НЕ ЧИТАЄ. Що створювали старі версії і що з тим сталося:
   • 2.4.3 (останній РЕЛІЗ): %APPDATA%\FluxHelper\ui.html — ВЕСЬ інтерфейс
     одним файлом; з 2.9.2 інтерфейс = UI\ui.html + ui.css + ui.js, а старі
     ui.* з кореня підчищались лише разово під час ЗАПИСУ інтерфейсу — тепер
     стираються завжди, навіть якщо запис не зібрався;
   • 2.9.2: ui.html / ui.css / ui.js у КОРЕНІ папки (до 3.3.2) — те саме;
   • 3.3.2: user.json (профіль) — з 3.4.0 сесія в Credential Manager (DPAPI),
     файл стирає LoadAllCfg; тут повторно, для надійності;
   • ≤3.3.x: fh_upd.bat у корені папки даних — старий .bat-доглядач оновлень;
     з 3.4.x доглядач пише fh_upd.cmd, а CleanupOldFiles чистить .bat лише в
     папці exe — у папці даних він залишався назавжди;
   • ера ДО 2.4 (перейменування Blazix -> FluxControl -> FluxHelper): 2.4.3
     ПЕРЕНЕСЛА файли налаштувань з %APPDATA%\Blazix і %APPDATA%\FluxControl,
     але самі старі папки (разом із кешем WebView2) НЕ ВИДАЛИЛА — вони досі
     лежать у користувачів.
   НЕ ЧІПАЄМО (потрібні зараз): settings.json, WebView2Loader.dll, logo.png,
   toast.ps1, fh_upd.cmd, upd.log, upd.ok + папки UI\ і WebView2\.
   УСЕ ІНШЕ у корені папки даних = спадок: файли стираються, чужі ПАПКИ
   видаляються рекурсивно (білий список). ЗАПАМ'ЯТАЙ: коли НОВА ВЕРСІЯ
   додає файл у папку даних — ДОДАЙ ЙОГО В KEEP-СПИСОК НИЖЧЕ, інакше він
   буде стертий при наступному старті! Зайняті файли пропускаються мовчки
   (чистка повториться при наступному запуску). */
static void DelTree(const std::wstring& path) {
    SHFILEOPSTRUCTW op{};
    op.hwnd = nullptr;
    op.wFunc = FO_DELETE;
    std::vector<wchar_t> buf(path.begin(), path.end());
    buf.push_back(L'\0'); buf.push_back(L'\0');   // подвійний нуль — вимога SHFileOperation
    op.pFrom = buf.data();
    op.fFlags = FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;
    SHFileOperationW(&op);
}

static void CleanupLegacyFiles() {
    const std::wstring dir = DataDir();
    static const wchar_t* kKeepFiles[] = {
        L"settings.json", L"WebView2Loader.dll", L"logo.png", L"toast.ps1",
        L"fh_upd.cmd", L"upd.log", L"upd.ok", nullptr };
    static const wchar_t* kKeepDirs[] = { L"UI", L"WebView2", nullptr };
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do {
            if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
            const std::wstring full = dir + L"\\" + fd.cFileName;
            bool keep = false;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                for (int i = 0; kKeepDirs[i]; ++i)
                    if (!_wcsicmp(fd.cFileName, kKeepDirs[i])) { keep = true; break; }
                if (!keep) DelTree(full);   // чужа/стара підпапка — стираємо з вмістом
            } else {
                for (int i = 0; kKeepFiles[i]; ++i)
                    if (!_wcsicmp(fd.cFileName, kKeepFiles[i])) { keep = true; break; }
                if (!keep) DeleteFileW(full.c_str());   // спадок старих версій
            }
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    // цілі старі папки даних (до-2.4 ера): 2.4.3 з них мігрувала, але не стирала
    PWSTR baseP = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, nullptr, &baseP))) {
        std::wstring base = baseP;
        CoTaskMemFree(baseP);
        DelTree(base + L"\\FluxControl");
        DelTree(base + L"\\Blazix");
    }
}

static bool ReadFileBin(const std::wstring& path, std::vector<unsigned char>& out) {
    HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                           OPEN_EXISTING, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    out.clear();
    char buf[65536];
    DWORD rd = 0;
    for (;;) {
        if (!ReadFile(f, buf, sizeof(buf), &rd, nullptr) || !rd) break;
        out.insert(out.end(), buf, buf + rd);
        if (out.size() > 200u * 1024 * 1024) break;
    }
    CloseHandle(f);
    return !out.empty();
}

// чи є в бінарних даних рядок у UTF-16LE (так VERSIONINFO зберігає версію)
static bool MemHasUtf16(const std::vector<unsigned char>& data, const std::wstring& s) {
    if (s.empty() || data.empty()) return false;
    std::vector<unsigned char> pat;
    pat.reserve(s.size() * 2);
    for (wchar_t c : s) {
        pat.push_back((unsigned char)(c & 0xFF));
        pat.push_back((unsigned char)(((unsigned)c) >> 8));
    }
    if (data.size() < pat.size()) return false;
    const unsigned char* d = data.data();
    for (size_t i = 0; i + pat.size() <= data.size(); ++i)
        if (d[i] == pat[0] && memcmp(d + i, pat.data(), pat.size()) == 0) return true;
    return false;
}

// (старий скрипт fh_upd.bat видалено — заміна файлів тепер у InstallUpdateFiles вище)

// 0 = ок; інакше HTTP-код або -1 (мережа) / -2 (диск). Прогрес -> WM_UPD_PROG.
static int HttpDownloadTo(const std::wstring& url, const std::wstring& dst) {
    wchar_t host[256] = {}, path[1024] = {};
    URL_COMPONENTSW uc{};
    uc.dwStructSize = sizeof(uc);
    uc.lpszHostName = host;  uc.dwHostNameLength = 255;
    uc.lpszUrlPath  = path;  uc.dwUrlPathLength  = 1023;
    if (!WinHttpCrackUrl(url.c_str(), (DWORD)url.size(), 0, &uc)) return -1;

    HINTERNET ses = SmartWinHttpOpen(L"FluxHelper-Updater");   // 2.7.3: бачить системний проксі
    if (!ses) return -1;
    DWORD redir = WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;
    WinHttpSetOption(ses, WINHTTP_OPTION_REDIRECT_POLICY, &redir, sizeof(redir));

    HINTERNET con = WinHttpConnect(ses, host, uc.nPort, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER,
                          WINHTTP_DEFAULT_ACCEPT_TYPES,
                          (uc.nScheme == INTERNET_SCHEME_HTTPS) ? WINHTTP_FLAG_SECURE : 0) : nullptr;
    bool sent = false;
    if (req) sent = WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                       WINHTTP_NO_REQUEST_DATA, 0, 0, 0)
                  && WinHttpReceiveResponse(req, nullptr);
    int res = -1;
    DWORD status = 0, sz = sizeof(status);
    if (sent && WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                    WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX)) {
        if (status != 200) {
            res = (int)status;
        } else {
            HANDLE f = CreateFileW(dst.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                                   FILE_ATTRIBUTE_NORMAL, nullptr);
            if (f == INVALID_HANDLE_VALUE) {
                res = -2;
            } else {
                DWORD total = 0; sz = sizeof(total);
                WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH | WINHTTP_QUERY_FLAG_NUMBER,
                                    WINHTTP_HEADER_NAME_BY_INDEX, &total, &sz, WINHTTP_NO_HEADER_INDEX);
                DWORD got = 0, lastPct = -1;
                bool ok = true;
                for (;;) {
                    DWORD avail = 0;
                    if (!WinHttpQueryDataAvailable(req, &avail)) { ok = false; break; }
                    if (!avail) break;
                    std::vector<char> buf(avail);
                    DWORD rd = 0;
                    if (!WinHttpReadData(req, buf.data(), avail, &rd) || !rd) { ok = false; break; }
                    DWORD wr = 0;
                    if (!WriteFile(f, buf.data(), rd, &wr, nullptr) || wr != rd) { ok = false; break; }
                    got += rd;
                    if (total > 0) {
                        DWORD pct = (DWORD)((unsigned long long)got * 100 / total);
                        if (pct != lastPct) { lastPct = pct; PostMessageW(g_hwnd, WM_UPD_PROG, pct, 0); }
                    }
                }
                CloseHandle(f);
                if (!ok || got < 100000) {           // надто маленький файл = явно не exe
                    DeleteFileW(dst.c_str());
                    res = ok ? -3 : -1;
                } else {
                    res = 0;
                }
            }
        }
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return res;
}

struct UpdParams { std::wstring ver, repo, pref, md5; };

static void UpdateThreadMain(UpdParams p) {
    // ДЖЕРЕЛА ЗАВАНТАЖЕННЯ (по черзі):
    //  3.5.5: РЕЛІЗ — СПЕРШУ ВЛАСНИЙ САЙТ fluxhelper.pages.dev/FluxHelper.exe
    //  (просив власник: «не с Гитхаба, а с сайта» — швидше, без лімітів GitHub);
    //  далі GitHub Release і raw. БЕТА — як і раніше спершу GitHub (власник:
    //  «бета поки що тільки з Гітхаба»), сайт лише резервним джерелом.
    //  raw.githubusercontent кешується Fastly на 5 хв; запит з новим ?cb=
    //  обходить кеш і віддає нову версію ОДРАЗУ після публікації.
    const std::wstring vName = L"FluxHelper_v" + p.ver + L".exe";
    const wchar_t* names[4] = { vName.c_str(), L"FluxHelper.exe", L"FluxControl.exe", L"Blazix.exe" };
    const std::wstring relBase = L"https://github.com/" + p.repo + L"/releases/download/v" + p.ver + L"/";
    const std::wstring rawBase = L"https://raw.githubusercontent.com/" + p.repo + L"/main/" + p.pref + p.ver + L"/";
    const bool isRel = (p.pref == L"versions/release/");
    const std::wstring siteUrl = isRel
        ? (L"https://fluxhelper.pages.dev/FluxHelper.exe")
        : (L"https://fluxhelper.pages.dev/versions/beta/" + p.ver + L"/FluxHelper.exe");
    wchar_t cb[32];
    swprintf(cb, 32, L"?cb=%llu", (unsigned long long)GetTickCount64());
    // качаємо в папку запущеного exe (стіл тощо) — після оновлення файл лишається на місці
    const std::wstring dst = ExeDirUpd() + L"\\FluxHelper.new.exe";

    int st = -1;
    bool got404 = false;
    st = HttpDownloadTo(siteUrl, dst);          // 3.5.5: сайт першим (реліз і резерв бети)
    if (st != 0) {
        for (int i = 0; i < 4 && st != 0; ++i) {
            st = HttpDownloadTo(relBase + names[i], dst);
            if (st == 404) {
                got404 = true;
                st = HttpDownloadTo(rawBase + names[i] + cb, dst);
            }
        }
    }
    if (st != 0) {
        if (st == 404 || got404) UpdPostErr(L"версію не знайдено на сервері (404)");
        else if (st == -2) UpdPostErr(L"не вдалося зберегти файл поруч із програмою (папка без прав запису?)");
        else               UpdPostErr(L"немає з'єднання з сервером оновлень — перевір інтернет");
        return;
    }

    // 3.4.5: КОНТРОЛЬ ЦІЛІСНОСТІ. Якщо сервер дав MD5 — збіг ОБОВ'ЯЗКОВИЙ
    // (пошкоджений/обірваний файл викидається ДО того, як щось замінити).
    // Без MD5 — стара перевірка версії всередині файла (UTF-16 у VERSIONINFO).
    {
        std::vector<unsigned char> data;
        if (!ReadFileBin(dst, data) || data.size() < 100000) {
            DeleteFileW(dst.c_str());
            UpdPostErr(L"файл оновлення на сервері пошкоджений або стара версія — спробуй пізніше");
            return;
        }
        std::wstring gotMd5;
        if (p.md5.size() == 32) {
            unsigned char d[16];
            if (MemMd5(data, d)) gotMd5 = Md5Hex(d);
        }
        bool intact = gotMd5.empty() ? MemHasUtf16(data, p.ver)
                                     : (_wcsicmp(gotMd5.c_str(), p.md5.c_str()) == 0);
        if (!intact) {
            DeleteFileW(dst.c_str());
            UpdPostErr(L"завантажений файл не пройшов перевірку цілісності — спробуй ще раз за хвилину");
            return;
        }
    }

    // заміна файлів «на гарячому»: працюючий exe перейменовується, новий стає на його місце
    const std::wstring exePath = ExePath();
    PostMessageW(g_hwnd, WM_UPD_PROG, 100, 0);
    Sleep(250);                        // даємо JS показати «встановлення…»
    if (!InstallUpdateFiles(exePath)) {
        // 3.4.5: заміна не вдалась (файл тримає антивірус/OneDrive). Робочу
        // програму НЕ чіпаємо — вона далі працює; доглядач, який уже чекає,
        // домкнить заміну одразу після виходу програми.
        UpdPostErr(L"файл тимчасово зайнятий (антивірус?) — після закриття програми оновлення доустановиться саме");
        return;
    }

    PostMessageW(g_hwnd, WM_UPD_DONE, 0, 0);
    g_allowClose = true;               // оновлення завершується — вихід дозволено
    Sleep(700);                        // даємо JS показати «застосунок зараз перезапуститься»

    // 3.4.5: ДОГЛЯДАЧ стартує ДО запуску нової версії — якщо що-небудь далі
    // впаде (CreateProcess, збій під час виходу), саме він завершить цикл
    // «замінити -> запустити -> прибрати сміття» з двома спробами запуску.
    StartUpdateWatchdog(GetCurrentProcessId(), exePath);

    // запускаємо НОВУ версію. 3.4.5: прапорець --upd-wait — новий процес
    // ЧЕКАЄ, доки старий звільнить одиночний м'ютекс (раніше він бачив «уже
    // працює» і МОВЧКИ ВИХОДИВ — саме тому «стара закрилась, а нова не
    // відкрилась»). Далі перевіряємо, що новий процес живий, і лише потім
    // закриваємось.
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    std::wstring nArgs = L"\"" + exePath + L"\" --upd-wait";
    if (CreateProcessW(exePath.c_str(), (LPWSTR)nArgs.c_str(), nullptr, nullptr, FALSE,
                       0, nullptr, nullptr, &si, &pi)) {
        CloseHandle(pi.hThread);
        bool alive = false;            // жива перевірка: процес має дожити 1,5 с
        for (int i = 0; i < 6; ++i) {
            Sleep(250);
            DWORD code = 0;
            if (GetExitCodeProcess(pi.hProcess, &code) && code == STILL_ACTIVE) { alive = true; break; }
        }
        CloseHandle(pi.hProcess);
        if (alive) {
            Sleep(250);
            PostMessageW(g_hwnd, WM_CLOSE, 0, 0);   // вихід -> нова версія вже працює
        } else {
            // новий процес умер (наприклад антивірус) — НЕ виходимо: стара
            // версія лишається робочою, доглядач зробить повторний запуск
            UpdPostErr(L"нова версія запустилась і одразу завершилась (перевір антивірус) — стара версія працює далі");
        }
    } else {
        UpdPostErr(L"нова версія встановлена — запускаю її автоматично…");
        Sleep(1200);
        PostMessageW(g_hwnd, WM_CLOSE, 0, 0);       // вихід -> доглядач сам запустить нову
    }
}

// виклик JS з головного потоку (для прогресу завантаження)
static void UiScript(const std::wstring& js) {
    if (g_web) g_web->ExecuteScript(js.c_str(), nullptr);
}

// ------------------------------------------------- запуск Zoom
// Налаштування «як відкривати Zoom» (лише ПК):
//   • додаток  -> протокол zoommtg:// (сам Zoom, БЕЗ браузера);
//     якщо Zoom не встановлено — автоматично через браузер
//   • браузер  -> звичайне https-посилання (веб-версія Zoom)
// Наявність Zoom перевіряємо за реєстрацією протокола zoommtg у HKCR.
static bool ZoomProtoOk() {
    HKEY k = nullptr;
    // пошук і в HKCU (користувацькі асоціації), і в HKLM (системні)
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\zoommtg", 0, KEY_READ, &k) == ERROR_SUCCESS) {
        RegCloseKey(k); return true;
    }
    if (RegOpenKeyExW(HKEY_CLASSES_ROOT, L"zoommtg", 0, KEY_READ, &k) == ERROR_SUCCESS) {
        RegCloseKey(k); return true;
    }
    return false;
}

// https://us05web.zoom.us/j/123456789?pwd=xyz -> zoommtg://zoom.us/join?action=join&confno=123456789&pwd=xyz
static bool BuildZoomAppUrl(const std::wstring& httpsUrl, std::wstring& out) {
    size_t j = httpsUrl.find(L"/j/");
    if (j == std::wstring::npos) return false;
    size_t idStart = j + 3;
    size_t idEnd = idStart;
    while (idEnd < httpsUrl.size() && httpsUrl[idEnd] != L'?' && httpsUrl[idEnd] != L'/' && httpsUrl[idEnd] != L'&') ++idEnd;
    std::wstring id = httpsUrl.substr(idStart, idEnd - idStart);
    if (id.empty()) return false;
    for (wchar_t c : id) if (!(c >= L'0' && c <= L'9')) return false;   // confno — тільки цифри
    out = L"zoommtg://zoom.us/join?action=join&confno=" + id;
    size_t pwd = httpsUrl.find(L"pwd=");
    if (pwd != std::wstring::npos) {
        std::wstring pv;
        for (size_t i = pwd + 4; i < httpsUrl.size(); ++i) {
            wchar_t c = httpsUrl[i];
            if (c == L'&') break;
            pv += c;
        }
        if (!pv.empty()) out += L"&pwd=" + pv;
    }
    return true;
}

static void OpenJoinLink(const std::wstring& mode, const std::wstring& url) {
    if (mode == L"app") {
        std::wstring z;
        if (ZoomProtoOk() && BuildZoomAppUrl(url, z)) {
            // Zoom встановлено -> запускаємо ДОДАТОК напряму, минаючи браузер
            if ((intptr_t)ShellExecuteW(g_hwnd, L"open", z.c_str(), nullptr, nullptr, SW_SHOWNORMAL) > 32) return;
        }
        // Zoom немає (або посилання не розпізнано) -> автоматично через браузер
    }
    ShellExecuteW(g_hwnd, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

// ================================================== 2.7.7: ВХІД GOOGLE (браузер + локальний канал)
// Повністю нова система:
//  1) Кнопка входу ПЕРЕВІРЯЄ OAuth-клієнт (probe без редіректів) і відкриває
//     СИСТЕМНИЙ БРАУЗЕР — сторінки Google НІКОЛИ не з'являються всередині програми.
//  2) redirect_uri = http://127.0.0.1:<порт> — відповідь приймає локальний
//     HTTP-слухач у самій програмі (канонічний desktop-флоу Google: без реєстрацій
//     у реєстрі Windows, без сайтів входу, без D1-каналів і без redirect_uri_mismatch).
//  3) PKCE (S256): код авторизації міняємо на ID-токен прямо на
//     oauth2.googleapis.com (десктоп-клієнт — публічний, секрет не потрібен).
//  4) Усі зовнішні навігації WebView перехоплює NavStartHandler і відкриває в
//     браузері -> інтерфейс разом із титульною панеллю НІКОЛИ не замінюється
//     чужою сторінкою, тож панель фізично не може «зникнути».

static const UINT WM_AUTH_READY = WM_APP + 7;   // wp = порт, lp = покоління — слухач готовий
static const UINT WM_AUTH_CB    = WM_APP + 8;   // lp = new std::wstring — URL відповіді браузера
static const UINT WM_AUTH_ERR   = WM_APP + 9;   // lp = new std::wstring — помилка слухача
static const UINT WM_AUTH_GONE  = WM_APP + 11;  // 3.4.12: сторінку входу ЗАКРИЛИ (bye/heartbeat зник)

static bool g_wsaOk = false;                    // 3.4.12: Winsock ініціалізовано один раз у wWinMain
/* 3.4.12: ЖИВІСТЬ СТОРІНКИ ВХОДУ. Сайт auth.html кожні 2.5 с стукає
   GET /hb?state=... на локальний слухач, а при закритті вкладки надсилає
   sendBeacon('/bye?state=...'). Як тільки «серцебиття» зникло або прийшов
   bye — кнопка «Увійти через Google» ЗНОВУ АКТИВНА (раніше після закриття
   сайту вона «висіла» аж до 4-хвилинного таймауту — точний баг від власника). */
static volatile long long g_authHbAt = 0;       // GetTickCount64 останнього /hb
static volatile bool g_authHbSeen = false;      // сторінка хоч раз стукала
static const UINT TIMER_AUTH    = 6;            // таймаут очікування відповіді браузера

static void BackToUi();   // перезбірка інтерфейсу (визначено нижче)

static bool g_loginBusy = false;          // вхід триває (одна спроба за раз)
static bool g_loginArmed = false;         // 3.4.0: слухач+state готові ЗАЗДАЛЕГІДЬ (миттєвий вхід)
static bool g_loginOpenPending = false;   // 3.4.0: клік стався до готовності слухача
static LONG g_authGen = 0;                // покоління слухача (скасування попереднього)
static std::wstring g_st;                 // одноразовий ключ сесії входу (state)
static int g_authPort = 0;
// percent-encode значення URL-параметрів (RFC 3986 unreserved + -._~)
static std::wstring EncUri(const std::wstring& u) {
    wchar_t b[8];
    std::wstring o;
    for (wchar_t c : u) {
        if ((c >= L'0' && c <= L'9') || (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') ||
            c == L'-' || c == L'.' || c == L'_' || c == L'~') o += c;
        else { swprintf(b, 8, L"%%%02X", (unsigned)c & 0xFF); o += b; }
    }
    return o;
}

// ---- SHA-256 (компактна реалізація — потрібна для PKCE challenge) ----
struct Sha256 {
    uint32_t h[8]; uint64_t bits; unsigned char buf[64]; size_t bl;
    static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
    static uint32_t K(int i) {
        static const uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };
        return k[i];
    }
    void init() {
        static const uint32_t I[8] = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                                       0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 };
        memcpy(h, I, sizeof(h)); bits = 0; bl = 0;
    }
    void block(const unsigned char* p) {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i)
            w[i] = ((uint32_t)p[i*4] << 24) | ((uint32_t)p[i*4+1] << 16) | ((uint32_t)p[i*4+2] << 8) | p[i*4+3];
        for (int i = 16; i < 64; ++i) {
            uint32_t s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >> 3);
            uint32_t s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; ++i) {
            uint32_t S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25), ch = (e & f) ^ ((~e) & g);
            uint32_t t1 = hh + S1 + ch + K(i) + w[i];
            uint32_t S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22), mj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + mj;
            hh=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }
    void update(const void* dv, size_t n) {
        const unsigned char* p = (const unsigned char*)dv;
        bits += (uint64_t)n * 8;
        while (n) {
            size_t t = 64 - bl; if (t > n) t = n;
            memcpy(buf + bl, p, t); bl += t; p += t; n -= t;
            if (bl == 64) { block(buf); bl = 0; }
        }
    }
    void fin(unsigned char out[32]) {
        uint64_t total = bits;
        unsigned char pad = 0x80; update(&pad, 1);
        unsigned char z = 0;
        while (bl != 56) update(&z, 1);
        unsigned char l[8];
        for (int i = 0; i < 8; ++i) l[i] = (unsigned char)((total >> ((7 - i) * 8)) & 0xFF);
        update(l, 8);
        for (int i = 0; i < 8; ++i) {
            out[i*4] = (unsigned char)(h[i] >> 24); out[i*4+1] = (unsigned char)(h[i] >> 16);
            out[i*4+2] = (unsigned char)(h[i] >> 8); out[i*4+3] = (unsigned char)(h[i]);
        }
    }
};
// 3.4.0: hex-рядок SHA-256 — ключ серверного дзеркала сесії (sess.sid).
// Токен сесії на сервер НЕ пишеться: навіть той, хто читає D1, не може
// відновити токен за його хешем і зайти під чужим акаунтом.
static std::string Sha256Hex(const std::string& in) {
    Sha256 h;
    h.init();
    h.update(in.data(), in.size());
    unsigned char d[32];
    h.fin(d);
    static const char* HX = "0123456789abcdef";
    std::string o;
    o.reserve(64);
    for (int i = 0; i < 32; ++i) { o += HX[d[i] >> 4]; o += HX[d[i] & 15]; }
    return o;
}
static std::string B64UrlEnc(const unsigned char* d, size_t n) {
    static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    std::string o;
    for (size_t i = 0; i < n; i += 3) {
        uint32_t v = (uint32_t)d[i] << 16;
        if (i + 1 < n) v |= (uint32_t)d[i+1] << 8;
        if (i + 2 < n) v |= d[i+2];
        o += T[(v >> 18) & 63]; o += T[(v >> 12) & 63];
        if (i + 1 < n) o += T[(v >> 6) & 63];
        if (i + 2 < n) o += T[v & 63];
    }
    return o;   // без «=» — Google приймає unpadded challenge
}

static int B64UrlVal(int c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '-') return 62;
    if (c == '_') return 63;
    return -1;
}
static bool B64UrlDecode(const std::string& in, std::string& out) {
    out.clear();
    int buf = 0, bits = 0;
    for (unsigned char c : in) {
        if (c == '=') break;
        int v = B64UrlVal(c);
        if (v < 0) return false;
        buf = (buf << 6) | v;  bits += 6;
        if (bits >= 8) { bits -= 8; out += char((buf >> bits) & 0xFF); }
    }
    return true;
}
static std::wstring RandHex(int bytes) {
    std::wstring s;
    wchar_t buf[40];
    while ((int)s.size() < bytes * 2) {
        GUID g{};
        if (CoCreateGuid(&g) != S_OK) break;
        swprintf(buf, 40, L"%08x%04x%04x%02x%02x%02x%02x%02x%02x",
                 g.Data1, g.Data2, g.Data3,
                 g.Data4[0], g.Data4[1], g.Data4[2], g.Data4[3],
                 g.Data4[4], g.Data4[5]);
        s += buf;
    }
    return s.substr(0, (size_t)bytes * 2);
}
// значення параметра з query (?) або fragment (#) URL
static std::wstring UrlParam(const std::wstring& u, const wchar_t* name) {
    for (int pass = 0; pass < 2; ++pass) {
        wchar_t sep = pass ? L'#' : L'?';
        size_t p = u.find(sep);
        if (p == std::wstring::npos) continue;
        std::wstring ss = u.substr(p + 1);
        std::wstring pat = std::wstring(name) + L"=";
        size_t q = ss.find(pat);
        while (q != std::wstring::npos) {
            if (q == 0 || ss[q - 1] == L'&') {
                size_t e = ss.find(L'&', q);
                return ss.substr(q + pat.size(), (e == std::wstring::npos) ? e : e - q - pat.size());
            }
            q = ss.find(pat, q + 1);
        }
    }
    return L"";
}
static std::string WToStr(const std::wstring& w) {
    std::string o;
    for (wchar_t c : w) if (c < 128) o += (char)c; else o += '?';
    return o;
}

// 2.8.1: percent-декодування параметрів URL (UTF-8) — для профілю з сайту
static std::wstring UrlDecode(const std::wstring& s) {
    std::string u8;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == L'%' && i + 2 < s.size()) {
            auto hx = [](wchar_t c) -> int {
                if (c >= L'0' && c <= L'9') return c - L'0';
                if (c >= L'a' && c <= L'f') return c - L'a' + 10;
                if (c >= L'A' && c <= L'F') return c - L'A' + 10;
                return -1;
            };
            int a = hx(s[i + 1]), b = hx(s[i + 2]);
            if (a >= 0 && b >= 0) { u8 += (char)((a << 4) | b); i += 2; continue; }
        }
        if (s[i] == L'+') { u8 += ' '; continue; }
        if (s[i] < 128) u8 += (char)s[i];
    }
    return Utf8ToWide(u8);
}

// ---- повідомлення про помилку входу прямо в гейт (без перезавантаження UI) ----
static void AuthUiErr(const wchar_t* m) {
    g_loginBusy = false;
    g_loginArmed = false;          // 3.4.0: слухач заглушено — наступний клік перезбере
    g_loginOpenPending = false;
    KillTimer(g_hwnd, TIMER_AUTH);
    InterlockedIncrement(&g_authGen);          // глушимо слухач, якщо живий
    std::wstring js = L"window.__fh&&window.__fh.authErr&&window.__fh.authErr(\"";
    for (const wchar_t* p = m; *p; ++p) { if (*p == L'"' || *p == L'\\') js += L'\\'; js += *p; }
    js += L"\")";
    UiScript(js);
}

// ---- локальний HTTP-слухач: приймає відповідь Google у браузері ----
// Браузер після входу заходить на http://127.0.0.1:<порт>/?code=…&state=…,
// слухач показує сторінку «Вхід завершено» і передає керування головному вікну.
static DWORD WINAPI AuthSrvThread(LPVOID lp) {
    LONG myGen = (LONG)(INT_PTR)lp;
    SOCKET s = INVALID_SOCKET;
    int bound = 0, port = 0;
    /* 3.4.12: WSAStartup робиться ОДИН раз у WinMain (g_wsaOk) — потік лише
       користується Winsock. Раніше кожен потік мав свій WSAStartup/WSACleanup,
       і cleanup попереднього потока вбивав сокети нового («занадто швидкий
       повторний вхід — сторінка не відкривається»). */
    if (g_wsaOk) {
        for (int pt = 8977; pt <= 8986 && !bound && g_authGen == myGen; ++pt) {
            s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            if (s == INVALID_SOCKET) break;
            sockaddr_in a{};
            a.sin_family = AF_INET;
            a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);   // ТІЛЬКИ локальний інтерфейс
            a.sin_port = htons((u_short)pt);
            if (bind(s, (sockaddr*)&a, sizeof(a)) == 0 && listen(s, 4) == 0) { bound = 1; port = pt; }
            else { closesocket(s); s = INVALID_SOCKET; }
        }
    }
    if (!bound) {
        if (s != INVALID_SOCKET) closesocket(s);
        if (g_authGen == myGen)
            PostMessageW(g_hwnd, WM_AUTH_ERR, 0, (LPARAM)new std::wstring(
                L"Не вдалося запустити локальний сервер входу (127.0.0.1). Можливо, його блокує фаєрвол або антивірус."));
        return 0;
    }
    PostMessageW(g_hwnd, WM_AUTH_READY, (WPARAM)port, (LPARAM)(INT_PTR)myGen);
    static const char OK_BODY[] =
        "<!doctype html><html><head><meta charset=\"utf-8\"><title>FluxHelper</title>"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0a0a12;"
        "font-family:'Segoe UI',Arial,sans-serif;color:#fff;text-align:center;padding:20px}"
        ".c{max-width:420px;padding:36px 30px;border-radius:24px;background:linear-gradient(160deg,#151527,#0d0d18);"
        "border:1px solid rgba(139,92,246,.35);box-shadow:0 18px 60px rgba(99,102,241,.25)}"
        "h1{font-size:19px;margin:0 0 8px}p{color:#a5a8bd;font-size:13.5px;line-height:1.55;margin:0}"
        ".k{width:52px;height:52px;margin:0 auto 14px;border-radius:16px;display:grid;place-items:center;"
        "background:linear-gradient(135deg,#8b5cf6,#6366f1);font-size:26px}</style></head>"
        "<body><div class=\"c\"><div class=\"k\">&#10003;</div><h1>Вхід завершено</h1>"
        "<p>Повернись у FluxHelper — акаунт уже підтверджено.<br>Цю вкладку можна закрити.</p></div></body></html>";
    for (;;) {
        if (g_authGen != myGen) break;
        fd_set rd; FD_ZERO(&rd); FD_SET(s, &rd);
        timeval tv{ 0, 400 * 1000 };
        int r = select(0, &rd, nullptr, nullptr, &tv);
        if (g_authGen != myGen) break;
        if (r <= 0) continue;
        SOCKET c = accept(s, nullptr, nullptr);
        if (c == INVALID_SOCKET) continue;
        char req[16384] = {};
        int n = 0;
        while (n < (int)sizeof(req) - 1) {
            int k = recv(c, req + n, (int)sizeof(req) - 1 - n, 0);
            if (k <= 0) break;
            n += k; req[n] = 0;
            if (strstr(req, "\r\n\r\n")) break;
        }
        if (n > 0) {
            req[n] = 0;
            // 2.8.1: preflight Chrome Private Network Access (сайт -> 127.0.0.1)
            if (strncmp(req, "OPTIONS", 7) == 0) {
                const char* OPT =
                    "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\n"
                    "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
                    "Access-Control-Allow-Headers: *\r\n"
                    "Access-Control-Allow-Private-Network: true\r\n"
                    "Access-Control-Max-Age: 86400\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                send(c, OPT, (int)strlen(OPT), 0);
                shutdown(c, SD_BOTH); closesocket(c);
                continue;
            }
            if (strncmp(req, "GET ", 4) == 0) {
                const char* sp = req + 4;
                const char* e = strchr(sp, ' ');
                std::string path = e ? std::string(sp, e - sp) : std::string(sp);
                /* 3.4.12: серцебиття сторінки входу (жива) і прощання (закрили
                   вкладку). Жодних відповідей у браузер не треба — 204. */
                if (path.find("/hb?") != std::string::npos || path.find("/hb&") != std::string::npos) {
                    g_authHbAt = (long long)GetTickCount64();
                    g_authHbSeen = true;
                    const char* HB = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                    send(c, HB, (int)strlen(HB), 0);
                    shutdown(c, SD_BOTH); closesocket(c);
                    continue;
                }
                if (path.find("/bye?") != std::string::npos) {
                    const char* BY = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                    send(c, BY, (int)strlen(BY), 0);
                    shutdown(c, SD_BOTH); closesocket(c);
                    if (g_loginBusy) PostMessageW(g_hwnd, WM_AUTH_GONE, 0, 0);
                    break;   // сторінку закрили — слухач більше не потрібен
                }
                // 2.8.1: сайт повертає ПРОФІЛЬ (state+d) — код OAuth більше не потрібен
                if (path.find("state=") != std::string::npos &&
                    (path.find("d=") != std::string::npos || path.find("err=") != std::string::npos)) {
                    char hdr[320];
                    snprintf(hdr, sizeof(hdr),
                             "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                             "Access-Control-Allow-Origin: *\r\n"
                             "Content-Length: %zu\r\nConnection: close\r\n\r\n", sizeof(OK_BODY) - 1);
                    send(c, hdr, (int)strlen(hdr), 0);
                    send(c, OK_BODY, (int)sizeof(OK_BODY) - 1, 0);
                    std::wstring q = Utf8ToWide("http://127.0.0.1:" + std::to_string(port) + path);
                    PostMessageW(g_hwnd, WM_AUTH_CB, 0, (LPARAM)(new std::wstring(q)));
                    shutdown(c, SD_BOTH); closesocket(c);
                    break;   // відповідь отримано — слухач більше не потрібен
                }
                const char* N404 = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                send(c, N404, (int)strlen(N404), 0);
            }
        }
        shutdown(c, SD_BOTH);
        closesocket(c);
    }
    closesocket(s);
    return 0;
}

// ---- 2.8.1: probe/обмін PKCE видалено — вхід тепер через сайт FluxHelper:
// браузер відкриває fluxhelper.pages.dev/auth.html, там звичайний Google-вхід,
// профіль повертається через локальний слухач або Firebase (auth_cb/<state>).

// ---- збереження профілю Google і передача його в інтерфейс ----
static void AuthUiOk(const std::string& sub, const std::string& nm, const std::string& mail, const std::string& pic, const std::string& fid, const std::string& tok) {
    g_loginBusy = false;
    g_loginArmed = false;          // 3.4.0: вхід завершено — слухач більше не потрібен
    g_loginOpenPending = false;
    KillTimer(g_hwnd, TIMER_AUTH);
    InterlockedIncrement(&g_authGen);
    auto esc = [](const std::string& t) {
        std::string o;
        for (unsigned char c : t) if (c != '"' && c != '\\') o += (char)c;
        return o;
    };
    // 2.8.3: fid = Firebase UID користувача (стає ключем рядка в D1)
    // 2.8.7: tok = Google access_token — JS сам добуде fid через fbauth.html, якщо fid пустий
    std::string js = "window.__fh&&window.__fh.authOk&&window.__fh.authOk({sub:\"" + esc(sub) +
        "\",name:\"" + esc(nm) + "\",email:\"" + esc(mail) + "\",pic:\"" + esc(pic) +
        (fid.empty() ? std::string() : ("\",fid:\"" + esc(fid))) +
        (tok.empty() ? std::string() : ("\",tok:\"" + esc(tok))) + "\"})";
    UiScript(Utf8ToWide(js));
}
static void OnTokenExchange(int status, const std::string& body) {
    (void)status; (void)body;   // 2.8.1: обмін PKCE більше не використовується
}

// ---------------- 3.4.0: СЕРВЕРНЕ ДЗЕРКАЛО СЕСІЇ (D1, таблиця sess) ----------------
// Сесія дублюється на сервер: sess(sid=SHA-256(токен), user_id, ts). Це виконує
// побажання «зберігалося на сервері»: навіть після чистки Credential Manager
// на ПК наявність/відсутність рядка підтверджується сервером, а сам токен
// ніде, крім DPAPI-блоба, не існує. best-effort: мережа недоступна — не блокує.
static void CloudSqlNow(const std::string& sql, const std::string& paramsJson) {
    CloudParams* cp = new CloudParams();
    cp->id = L"srv" + RandHex(4);
    cp->method = L"POST";
    cp->url = kCfApiBase;
    cp->auth = Utf8ToWide(CfToken());
    cp->kind = 1;
    cp->body = Utf8ToWide("{\"sql\":\"" + JsonEscU8(sql) + "\",\"params\":" + paramsJson + "}");
    std::thread(CloudThread, cp).detach();
}
static void SessionCloudMirror(bool wipe) {
    if (g_sessTok.empty()) return;
    const std::string sid = Sha256Hex(g_sessTok);
    const std::string uid = g_cfg.fid.empty() ? g_cfg.sub : g_cfg.fid;
    if (wipe) {
        CloudSqlNow("DELETE FROM sess WHERE sid=?", "[\"" + JsonEscU8(sid) + "\"]");
        return;
    }
    if (uid.empty()) return;
    FILETIME ft{};
    GetSystemTimeAsFileTime(&ft);
    long long nowMs = (((long long)ft.dwHighDateTime << 32) | ft.dwLowDateTime) / 10000 - 11644473600000LL;
    CloudSqlNow("CREATE TABLE IF NOT EXISTS sess (sid TEXT PRIMARY KEY, user_id TEXT, ts INTEGER)", "[]");
    CloudSqlNow("INSERT INTO sess (sid,user_id,ts) VALUES (?,?,?) "
                "ON CONFLICT(sid) DO UPDATE SET user_id=excluded.user_id, ts=excluded.ts",
                "[\"" + JsonEscU8(sid) + "\",\"" + JsonEscU8(uid) + "\",\"" + std::to_string(nowMs) + "\"]");
}

/* 3.4.9: ЗБЕРЕЖЕННЯ ПРОФІЛЮ GOOGLE — спільна точка для ОБОХ каналів входу.
   Канал 1 (основний): loopback-слухач -> WM_AUTH_CB. Канал 2 (резервний):
   сайт пише профіль у Firebase (auth_cb/<state>), інтерфейс опитує його сам
   і повідомляє хоста через fh:authsave|... — раніше цей канал минав хоста,
   Credential Manager лишався порожнім, і після перезапуску програма знову
   просила увійти, хоч вхід уже пройшов. Тепер обидва канали зберігають
   сесію ОДНАКОВО й ОДРАЗУ: налаштування в settings.json + DPAPI-блоб у
   Credential Manager + дзеркало sess у D1 + нативний INSERT рядка users. */
static void PersistGoogleProfile(const std::string& sub, std::string nm, const std::string& mail,
                                 const std::string& pic, const std::string& fid, const std::string& tok) {
    (void)tok;   // tok потрібен лише інтерфейсу (запасний обмін fid через fbauth.html)
    if (sub.empty() || mail.empty()) return;
    if (nm.empty()) { size_t at = mail.find('@'); nm = (at == std::string::npos) ? mail : mail.substr(0, at); }
    g_cfg.sub = sub; g_cfg.mail = mail; g_cfg.nm = nm; g_cfg.apic = pic;
    g_cfg.fid = fid;   // 2.8.5: Firebase UID — рестарт не ламає ключ D1
    SaveAllCfg();
    /* 3.4.0: НА ДИСКІ ДАНИХ АКАУНТА БІЛЬШЕ НЕМАЄ. Сесія = випадковий токен
       у Credential Manager (DPAPI-блоб поза папкою програми) + серверне
       дзеркало sess у D1 (ключ = SHA-256(токен)). user.json стерто. */
    g_sessTok = WideToUtf8(RandHex(24));
    SessionSave();
    DeleteFileW(UserPath().c_str());
    SessionCloudMirror(false);
    // 2.8.2: СТРАХОВКА — юзер пишеться в D1 ще й нативно, поза інтерфейсом:
    // навіть якщо JS-канал не встиг/не зміг, рядок у Users з'явиться одразу.
    // 2.8.9: ключ = ЛИШЕ Firebase UID (fid); БЕЗ fid нативного запису нема —
    // жодних числових ключів (sub / g:<sub>) програма більше не створює.
    // При СТВОРЕННІ акаунта одразу пишемо стандартні налаштування
    // (групи не вибрані, тема standard): settings/created у ON CONFLICT не торкаємось.
    if (!fid.empty()) {
        std::string sql = "INSERT INTO users (user_id, name, email, pic, ts, logins, created, settings, sver, sts) "
                          "VALUES (?,?,?,?,?,1,?,?,?,?) "
                          "ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, email=excluded.email, "
                          "pic=excluded.pic, ts=excluded.ts, logins=COALESCE(users.logins,0)+1";
        long long nowMs;
        FILETIME ft{}; GetSystemTimeAsFileTime(&ft);
        nowMs = (((long long)ft.dwHighDateTime << 32) | ft.dwLowDateTime) / 10000 - 11644473600000LL;
        char num[24]; snprintf(num, sizeof(num), "%lld", nowMs);
        std::string ds = std::string("{\\\"g\":{},\\\"n\\\":{\\\"on\\\":false,\\\"min\\\":5,\\\"snd\\\":true},"
                                     "\\\"z\\\":\\\"app\\\",\\\"th\\\":\\\"standard\\\",\\\"t\\\":") + num +
                         std::string(",\\\"v\\\":\\\"" FH_VER_STR "\\\",\\\"sync\\\":1}");
        std::string payload = std::string("{\"sql\":\"") + JsonEscU8(sql) +
            "\",\"params\":[\"" + JsonEscU8(fid) + "\",\"" + JsonEscU8(nm) + "\",\"" +
            JsonEscU8(mail) + "\",\"" + JsonEscU8(pic) + "\",\"" + num + "\",\"" + num + "\",\"" +
            ds + "\",\"" + FH_VER_STR + "\",\"" + num + "\"]}";
        CloudParams* cp = new CloudParams();
        cp->id = L"srv" + RandHex(4);
        cp->method = L"POST";
        cp->url = kCfApiBase;
        cp->auth = Utf8ToWide(CfToken());
        cp->kind = 1;
        cp->body = Utf8ToWide(payload);
        std::thread(CloudThread, cp).detach();
    }
}

/* 3.4.0: ПІДІГРІВ ВХОДУ. Щойно гейт з'являється на екрані (fh:gatewarm),
   програма уже стартує локальний слухач 127.0.0.1 і генерує одноразовий
   state. Клік «Увійти через Google» відкриває браузер МОМЕНТАЛЬНО —
   без очікування bind() порту, жодного «завантаження» перед відкриттям. */
static void OpenLoginBrowser();   // вперед (визначено нижче)

static void ArmLogin() {
    if (g_loginArmed) return;
    InterlockedIncrement(&g_authGen);          // глушимо попередній слухач (якщо був)
    LONG gen = g_authGen;
    g_st = RandHex(12);
    g_authPort = 0;
    CloseHandle(CreateThread(nullptr, 0, AuthSrvThread, (LPVOID)(INT_PTR)gen, 0, nullptr));
}

// кнопка «Увійти через Google» (fh:login з інтерфейсу)
static void StartLogin() {
    if (!g_web || g_loginBusy) return;
    if (g_loginArmed && g_authPort > 0) { OpenLoginBrowser(); return; }   // уже готово — миттєво
    g_loginOpenPending = true;   // слухач ще стартує — браузер відкриємо на WM_AUTH_READY
    ArmLogin();
}

// відкрити сайт входу у системному браузері (слухач уже готовий)
static void OpenLoginBrowser() {
    if (g_loginBusy || g_authPort <= 0) return;
    g_loginBusy = true;
    g_loginArmed = false;
    g_authHbSeen = false;    // 3.4.12: нова спроба — серцебиття з нуля
    g_authHbAt = 0;
    SetTimer(g_hwnd, TIMER_AUTH, 240000, nullptr);
    // сторінка входу на ВЛАСНОМУ САЙТІ (fluxhelper.pages.dev) — там звичайний
    // Google-вхід, профіль повертається автоматично: loopback або Firebase
    std::wstring url = std::wstring(L"https://fluxhelper.pages.dev/auth.html#s=") + g_st +
                       L"&p=" + std::to_wstring(g_authPort);
    ShellExecuteW(g_hwnd, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    // інтерфейс запускає резервне опитування Firebase (auth_cb/<state>)
    std::wstring js = L"window.__fh&&window.__fh.authWait&&window.__fh.authWait(\"" + g_st + L"\"," +
                      std::to_wstring(g_authPort) + L")";
    UiScript(js);
}

// вихід: ПОВНЕ СТИРАННЯ всіх слідів акаунта (2.8.0, переглянуто в 3.4.0):
//  1) сесія в Credential Manager (DPAPI-блоб) + дзеркало sess у D1;
//     user.json (спадок 3.3.2) стирається, якщо ще існує
//  2) cookie, localStorage, кеш, IndexedDB, паролі — ВЕСЬ браузерний профіль
//     WebView2 (щоб після перезапуску акаунт не «повертався»)
//  3) перезбірка інтерфейсу (гейт входу знову на екрані) — ПІСЛЯ стирання
static void BackToUi();   // перезбірка інтерфейсу (визначено нижче)
static void BackToUiLogout();   // 2.8.0: визначено після ComImpl (стирання даних браузера)

// перезбираємо ui.html (використовується виходом і стартом)
static void BackToUi() {
    if (!g_web) return;
    g_uiHtml = BuildUiHtml();
    g_fallbackUsed = false;
    std::wstring path;
    if (WriteUiFiles(path))
        g_web->Navigate(FileUrl(path).c_str());
    else
        g_web->NavigateToString(Utf8ToWide(g_uiInline).c_str());
}

// ------------------------------------------------- COM-база для обробників
template <class T, const IID& IID_T>
struct ComImpl : T {
    ULONG m_ref = 1;
    virtual ~ComImpl() {}
    STDMETHODIMP QueryInterface(REFIID riid, void** ppv) override {
        if (!ppv) return E_POINTER;
        *ppv = nullptr;
        if (riid == IID_T || riid == kIID_IUnknown) {
            *ppv = static_cast<T*>(this);
            AddRef();
            return S_OK;
        }
        return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef()  override { return ++m_ref; }
    STDMETHODIMP_(ULONG) Release() override {
        ULONG r = --m_ref;
        if (r == 0) delete this;
        return r;
    }
};

// 2.8.0: харнім КОРИСТУВАЧА повністю — handler завершення стирання даних браузера
struct ClearBrowsingHandler : ComImpl<ICoreWebView2ClearBrowsingDataCompletedHandler, IID_ICoreWebView2ClearBrowsingDataCompletedHandler> {
    STDMETHODIMP Invoke(HRESULT) override {
        if (g_hwnd) PostMessageW(g_hwnd, WM_APP + 10, 0, 0);   // стирання завершено -> перезбираємо UI
        return S_OK;
    }
};
static void BackToUiLogout() {
    SessionCloudMirror(true);   // 3.4.0: серверне дзеркало сесії (sess) теж стирається
    g_cfg.sub.clear(); g_cfg.mail.clear(); g_cfg.nm.clear(); g_cfg.apic.clear();
    g_cfg.fid.clear();   // 2.8.5: стираємо і Firebase UID
    SaveAllCfg();
    SessionWipe();                     // 3.4.0: DPAPI-сесія в Credential Manager стерта
    g_sessTok.clear();
    DeleteFileW(UserPath().c_str());   // спадок 3.3.2, якщо ще існував
    bool wipeStarted = false;
    if (g_web) {
        ICoreWebView2_13* w13 = nullptr;
        if (SUCCEEDED(g_web->QueryInterface(IID_ICoreWebView2_13, (void**)&w13)) && w13) {
            ICoreWebView2Profile* prof = nullptr;
            if (SUCCEEDED(w13->get_Profile(&prof)) && prof) {
                ICoreWebView2Profile2* p2 = nullptr;
                if (SUCCEEDED(prof->QueryInterface(IID_ICoreWebView2Profile2, (void**)&p2)) && p2) {
                    auto* cbh = new ClearBrowsingHandler();
                    if (p2->ClearBrowsingDataAll(cbh) == S_OK) wipeStarted = true;   // cookie+storage+cache — усе стирається
                    cbh->Release();
                    p2->Release();
                }
                prof->Release();
            }
            w13->Release();
        }
    }
    if (!wipeStarted) BackToUi();   // старий WebView2 без Profile2 — як було
    // інакше UI перезбереться в handler-і після завершення стирання (WM_APP+10)
}

struct CtrlHandler;

// Середовище створено -> створюємо контролер (тіло — після CtrlHandler)
struct EnvHandler : ComImpl<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler, kIID_EnvironmentHandler> {
    STDMETHODIMP Invoke(HRESULT err, ICoreWebView2Environment* env) override;
};

// Клік по посиланню -> відкриваємо у браузері за замовчуванням (Zoom запуститься сам)
struct NewWindowHandler : ComImpl<ICoreWebView2NewWindowRequestedEventHandler, kIID_NewWindowHandler> {
    STDMETHODIMP Invoke(ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* args) override {
        if (!args) return S_OK;
        LPWSTR uri = nullptr;
        if (SUCCEEDED(args->get_Uri(&uri)) && uri) {
            ShellExecuteW(g_hwnd, L"open", uri, nullptr, nullptr, SW_SHOWNORMAL);
            CoTaskMemFree(uri);
        }
        args->put_Handled(TRUE);
        return S_OK;
    }
};

// Повідомлення з інтерфейсу: кнопки заголовка, перетягування, збереження груп
struct MsgHandler : ComImpl<ICoreWebView2WebMessageReceivedEventHandler, IID_ICoreWebView2WebMessageReceivedEventHandler> {
    STDMETHODIMP Invoke(ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) override {
        if (!args) return S_OK;
        LPWSTR raw = nullptr;
        if (FAILED(args->TryGetWebMessageAsString(&raw)) || !raw) return S_OK;
        std::wstring m(raw);
        CoTaskMemFree(raw);
        if      (m == L"fh:min")   ShowWindow(g_hwnd, SW_MINIMIZE);
        else if (m == L"fh:close") {
            // гейт входу: закрити не можна — згортаємо у трей
            if (g_gateLock && !g_allowClose) ShowWindow(g_hwnd, SW_MINIMIZE);
            else DestroyWindow(g_hwnd);
        }
        else if (m.rfind(L"fh:gatelock|", 0) == 0)
            g_gateLock = (m.find(L"|1") != std::wstring::npos);
        else if (m.rfind(L"fh:theme|", 0) == 0) {
            // 2.8.8: інтерфейс змінив тему (в налаштуваннях або підтягнув з
            // хмари) — хост запам'ятовує її для сплеша/фону наступного запуску
            std::string t = WideToUtf8(m.substr(9));
            if (ThemeValid(t)) {
                {   AcquireSRWLockExclusive(&g_themeLock);
                    StoreTheme(t);
                    ReleaseSRWLockExclusive(&g_themeLock); }
                SaveAllCfg();
                UpdateWebViewBg();
            }
        }
        else if (m == L"fh:gatewarm") {   // 3.4.0: гейт показано — готуємо слухач заздалегідь
            if (!g_loginBusy) { g_loginOpenPending = false; ArmLogin(); }
        }
        else if (m == L"fh:login")  StartLogin();   // 2.7.7: вхід у системному браузері
        else if (m == L"fh:logout") BackToUiLogout();
        else if (m == L"fh:drag") {
            // перетягування за власну титульну панель
            ReleaseCapture();
            SendMessageW(g_hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }
        else if (m.rfind(L"fh:join2|", 0) == 0) {
            // fh:join2|<mode>|<url>  mode: app = Zoom-додаток (zoommtg://), web = браузер
            std::wstring rest(m.c_str() + 9);
            size_t bar = rest.find(L'|');
            std::wstring mode = (bar == std::wstring::npos) ? L"app" : rest.substr(0, bar);
            std::wstring url = (bar == std::wstring::npos) ? rest : rest.substr(bar + 1);
            if (url.rfind(L"http", 0) == 0) { JoinMarkToday(url); OpenJoinLink(mode, url); }
        }
        else if (m.rfind(L"fh:join|", 0) == 0) {
            JoinMarkToday(std::wstring(m.c_str() + 8));   // 3.4.11: вхід із розкладу — сповіщення не потрібне
            ShellExecuteW(g_hwnd, L"open", m.c_str() + 8, nullptr, nullptr, SW_SHOWNORMAL);
        }
        else if (m.rfind(L"fh:save|", 0) == 0) {
            // {"ang":1,...} — групи з інтерфейсу; решта полів settings.json зберігається
            const std::wstring j = std::wstring(m.c_str() + 8);
            auto gi = [&](const wchar_t* k) -> int {
                size_t p = j.find(k);
                if (p == std::wstring::npos) return 0;
                p = j.find(L':', p);
                if (p == std::wstring::npos) return 0;
                return _wtoi(j.c_str() + p + 1);
            };
            g_cfg.ang = gi(L"\"ang\"");   g_cfg.nim = gi(L"\"nim\"");
            g_cfg.ukr = gi(L"\"ukr\"");   g_cfg.inf = gi(L"\"inf\"");
            g_cfg.trud = gi(L"\"trud\"");
            if (CfgValid(g_cfg)) SaveAllCfg();
        }
        else if (m.rfind(L"fh:notif|", 0) == 0) {
            ParseNotif(std::wstring(m.c_str() + 9));
            SaveAllCfg();
        }
        else if (m.rfind(L"fh:authsave|", 0) == 0) {
            /* 3.4.9: РЕЗЕРВНИЙ КАНАЛ ВХОДУ (Firebase auth_cb) минає loopback-
               слухач — інтерфейс сам передає профіль Google (URL-encoded JSON).
               Зберігаємо сесію так само, як WM_AUTH_CB: Credential Manager +
               settings.json + дзеркало sess + нативний INSERT users. Фікс
               «зайшов в акаунт — закрив програму — знову просить увійти». */
            std::wstring enc = m.substr(12);
            if (enc.size() >= 8 && enc.size() <= 8192) {
                std::wstring dec = UrlDecode(enc);
                std::string prof;
                prof.reserve(dec.size());
                for (wchar_t c : dec) {          // UTF-16 -> UTF-8 (як у WM_AUTH_CB)
                    if (c < 0x80) prof += (char)c;
                    else if (c < 0x800) { prof += (char)(0xC0 | (c >> 6)); prof += (char)(0x80 | (c & 0x3F)); }
                    else { prof += (char)(0xE0 | (c >> 12)); prof += (char)(0x80 | ((c >> 6) & 0x3F)); prof += (char)(0x80 | (c & 0x3F)); }
                }
                std::string sub2, nm2, mail2, pic2, fid2, tok2;
                JsonGetStr(prof.c_str(), "\"sub\"", sub2);
                JsonGetStr(prof.c_str(), "\"name\"", nm2);
                JsonGetStr(prof.c_str(), "\"email\"", mail2);
                JsonGetStr(prof.c_str(), "\"picture\"", pic2);
                JsonGetStr(prof.c_str(), "\"fid\"", fid2);
                JsonGetStr(prof.c_str(), "\"tok\"", tok2);
                PersistGoogleProfile(sub2, nm2, mail2, pic2, fid2, tok2);
            }
        }
        else if (m.rfind(L"fh:copy|", 0) == 0)
            CopyToClipboard(std::wstring(m.c_str() + 8));
        else if (m.rfind(L"fh:openurl|", 0) == 0)
            ShellExecuteW(g_hwnd, L"open", std::wstring(m.c_str() + 11).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        else if (m.rfind(L"fh:cfq|", 0) == 0) {
            // fh:cfq|<id>|<json>  — D1 SQL з вбудованим токеном
            std::wstring rest(m.c_str() + 7);
            size_t bar = rest.find(L'|');
            if (bar != std::wstring::npos) {
                CloudParams* cp = new CloudParams();
                cp->id = rest.substr(0, bar);
                cp->body = rest.substr(bar + 1);
                cp->method = L"POST";
                cp->url = kCfApiBase;
                cp->auth = Utf8ToWide(CfToken());
                cp->kind = 1;
                std::thread(CloudThread, cp).detach();
            }
        }
        else if (m.rfind(L"fh:cloud|", 0) == 0) {
            // fh:cloud|<id>|<METHOD>|<urlLen>|<url><body>  — довільний https-запит
            std::wstring rest(m.c_str() + 9);
            size_t b1 = rest.find(L'|');
            if (b1 != std::wstring::npos) {
                std::wstring id = rest.substr(0, b1);
                size_t b2 = rest.find(L'|', b1 + 1);
                if (b2 != std::wstring::npos) {
                    std::wstring method = rest.substr(b1 + 1, b2 - b1 - 1);
                    int ul = _wtoi(rest.c_str() + b2 + 1);
                    size_t b3 = rest.find(L'|', b2 + 1);
                    if (b3 != std::wstring::npos && ul > 0 && (int)rest.size() - (int)b3 - 1 >= ul) {
                        CloudParams* cp = new CloudParams();
                        cp->id = id;
                        cp->method = method.empty() ? L"GET" : method;
                        cp->url = rest.substr(b3 + 1, (size_t)ul);
                        cp->body = rest.substr(b3 + 1 + (size_t)ul);
                        cp->kind = 2;
                        std::thread(CloudThread, cp).detach();
                    }
                }
            }
        }
        else if (m.rfind(L"fh:notif-test|", 0) == 0) {
            // РЕЖИМ РОЗРОБНИКА: тестове сповіщення з інтерфейсу.
            // {"title":"...","text":"...","snd":true,"url":"https://..."}
            // 3.4.5: СПРАВЖНІЙ ТОСТ WINDOWS із кнопкою «Зайти на урок» (відкриває
            // URL тесту — 3.4.14: рандомний ID, не з розкладу); звук — за
            // перемикачем сповіщень. 3.4.14: «Проігнорувати» прибрано всюди.
            std::wstring j(m.c_str() + 14);
            auto jv = [&](const wchar_t* key) -> std::wstring {
                size_t p = j.find(key);
                if (p == std::wstring::npos) return L"";
                p = j.find(L'"', p);
                if (p == std::wstring::npos) return L"";
                size_t e = j.find(L'"', p + 1);
                if (e == std::wstring::npos) return L"";
                return j.substr(p + 1, e - p - 1);
            };
            std::wstring ti = jv(L"\"title\""), tx = jv(L"\"text\""), turl = jv(L"\"url\"");
            size_t sp = j.find(L"\"snd\":");
            bool snd = (sp == std::wstring::npos) ? true : (j.compare(sp + 6, 4, L"true") == 0);
            /* 3.4.11: кнопка «Нагадати за 1 хв» у ТЕСТОВОМУ сповіщенні —
               тільки якщо в налаштуваннях НЕ «за 1 хвилину» (логіка від
               власника: якщо стоїть 1 хв — кнопку не присилати взагалі). */
            size_t spn = j.find(L"\"sn\":");
            bool sn = (spn == std::wstring::npos) ? (g_cfg.notifmin > 1) : (j.compare(spn + 5, 4, L"true") == 0);
            /* 3.4.6: тестове виглядає як звичайне — заголовок = дія,
               другий рядок = деталі */
            if (ti.empty()) ti = L"Зайти на урок через 5 хв";
            if (tx.empty()) tx = L"Інформатика • початок за 5 хв (тестове сповіщення)";
            /* 2.9.2: тестове сповіщення — кнопка «Прислати за 1 хв» працює в
               демо-режимі (g_lastNotifIdx = -1 => ArmSnooze покаже нагадування
               через 1 хвилину від зараз). */
            g_lastNotifIdx = -1;
            ShowNotif(ti, tx, snd, true, turl, sn);
        }
        else if (m.rfind(L"fh:update|", 0) == 0) {
            // {"v":"1.5.1","repo":"user/FluxHelper"} — завантажити та встановити
            std::wstring j(m.c_str() + 10);
            auto jv = [&](const wchar_t* key) -> std::wstring {
                size_t p = j.find(key);
                if (p == std::wstring::npos) return L"";
                p = j.find(L':', p);
                if (p == std::wstring::npos) return L"";
                p = j.find(L'\"', p);
                if (p == std::wstring::npos) return L"";
                size_t e = j.find(L'\"', p + 1);
                if (e == std::wstring::npos) return L"";
                return j.substr(p + 1, e - p - 1);
            };
            std::wstring v = jv(L"\"v\""), repo = jv(L"\"repo\""), pref = jv(L"\"p\""), md5 = jv(L"\"md5\"");
            if (pref.empty()) pref = L"versions/release/";
            bool okP = (pref == L"versions/release/" || pref == L"versions/beta/");
            /* 3.4.19: v.size() >= 3 замість >= 5 — коротка форма версії «3.5»
               (дві частини) теж коректна; інтерфейс зазвичай нормалізує до
               «3.5.0» (normVer), але хай нативний валідатор не відкидає
               коротку форму з старих хостів/дев-панелі */
            bool okV = (v.size() >= 3);
            for (wchar_t c : v) if (!(c == L'.' || (c >= L'0' && c <= L'9'))) okV = false;
            bool okM = (md5.empty() || md5.size() == 32);
            if (okV && okP && okM && repo.find(L'/') != std::wstring::npos)
                std::thread(UpdateThreadMain, UpdParams{v, repo, pref, md5}).detach();
            else
                UpdPostErr(L"некоректні дані оновлення");
        }
        return S_OK;
    }
};

// 2.7.7: усі зовнішні навігації -> СИСТЕМНИЙ БРАУЗЕР. Всередині програми живе
// лише наш інтерфейс (file://), тому титульна панель і екрани не можуть бути
// замінені жодною сторінкою (це і була причина «панель з'явилась і зникла»).
struct NavStartHandler : ComImpl<ICoreWebView2NavigationStartingEventHandler, IID_ICoreWebView2NavigationStartingEventHandler> {
    STDMETHODIMP Invoke(ICoreWebView2* web, ICoreWebView2NavigationStartingEventArgs* args) override {
        if (!args) return S_OK;
        LPWSTR uri = nullptr;
        if (SUCCEEDED(args->get_Uri(&uri)) && uri) {
            std::wstring u(uri);
            CoTaskMemFree(uri);
            if (u.rfind(L"file://", 0) == 0 || u.rfind(L"about:", 0) == 0 || u.rfind(L"data:", 0) == 0)
                return S_OK;   // свій інтерфейс — навігуємо як звично
            args->put_Cancel(TRUE);
            if (u.rfind(L"http://", 0) == 0 || u.rfind(L"https://", 0) == 0)
                ShellExecuteW(g_hwnd, L"open", u.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        }
        return S_OK;
    }
};

// Страховка: якщо %APPDATA%\FluxHelper\UI\ui.html не завантажився з диска
// (антивірус, незвичний шлях) — показуємо той самий HTML напряму з пам'яті
struct NavCompletedHandler : ComImpl<ICoreWebView2NavigationCompletedEventHandler, IID_ICoreWebView2NavigationCompletedEventHandler> {
    STDMETHODIMP Invoke(ICoreWebView2* web, ICoreWebView2NavigationCompletedEventArgs* args) override {
        if (!args || !web) { g_bootDone = true; g_webShown = true; return S_OK; }
        BOOL ok = TRUE;
        if (SUCCEEDED(args->get_IsSuccess(&ok)) && !ok && !g_fallbackUsed && !g_uiHtml.empty()) {
            g_fallbackUsed = true;
            web->NavigateToString(Utf8ToWide(g_uiInline).c_str());
            return S_OK;   // таймер поставить наступний NavigationCompleted
        }
        // сторінка завантажилась: даємо їй ~0.3 с намалювати перший кадр (разом
        // з іконкою) і ЛИШЕ ПОТІМ показуємо WebView — GDI-сплеш з іконкою
        // лишається на екрані до останнього кадру, «мигання без іконки» зникло
        SetTimer(g_hwnd, 4, 320, nullptr);
        return S_OK;
    }
};

static void UpdateBounds() {
    if (!g_ctrl || !g_hwnd) return;
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    g_ctrl->put_Bounds(rc);
    LayoutEdges();   // смуги зміни розміру — поверх WebView
}

// смуги зміни розміру (визначені нижче, потрібні тут)
static void LayoutEdges();

// повторно ховаємо кольорову окантовку DWM (іноді скидається після тем/фокусу)
static void RefreshBorderColor() {
    if (g_dwmRound && g_hwnd) {
        COLORREF bc = DWMWA_COLOR_NONE;
        DwmSetWindowAttribute(g_hwnd, DWMWA_BORDER_COLOR, &bc, sizeof(bc));
    }
}

// Контролер створено -> налаштовуємо і показуємо інтерфейс
struct CtrlHandler : ComImpl<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, kIID_ControllerHandler> {
    STDMETHODIMP Invoke(HRESULT err, ICoreWebView2Controller* ctrl) override {
        if (FAILED(err) || !ctrl) {
            g_bootDone = true;
            MessageBoxW(g_hwnd,
                L"Не вдалося створити веб-переглядач (WebView2).\n"
                L"Перевір, чи встановлений Microsoft Edge WebView2 Runtime.",
                L"FluxHelper — помилка", MB_OK | MB_ICONERROR);
            return S_OK;
        }
        g_ctrl = ctrl;
        ctrl->AddRef();  // тримаємо посилання для WM_SIZE / фокуса

        ICoreWebView2* web = nullptr;
        ctrl->get_CoreWebView2(&web);
        g_web = web;
        if (web) {
            // чистий інтерфейс: без ПКМ-меню, DevTools, статус-бару, зум-контролів
            ICoreWebView2Settings* st = nullptr;
            if (SUCCEEDED(web->get_Settings(&st)) && st) {
                st->put_AreDefaultContextMenusEnabled(FALSE);  // без меню «Оновити/Друк…»
                st->put_AreDevToolsEnabled(FALSE);
                st->put_IsStatusBarEnabled(FALSE);
                st->put_IsZoomControlEnabled(FALSE);
                // вимикаємо браузерні гарячі клавіші (Ctrl+R, F5, Ctrl+P, Ctrl+F …)
                ICoreWebView2Settings4* st4 = nullptr;
                if (SUCCEEDED(st->QueryInterface(IID_ICoreWebView2Settings4, (void**)&st4)) && st4) {
                    st4->put_AreBrowserAcceleratorKeysEnabled(FALSE);
                    st4->Release();
                }
                st->Release();
            }

            EventRegistrationToken tok{};
            auto* nh = new NewWindowHandler();
            web->add_NewWindowRequested(nh, &tok);
            nh->Release();
            auto* mh = new MsgHandler();
            web->add_WebMessageReceived(mh, &tok);
            mh->Release();
            // 2.7.6: перехоплення відповіді Google
            auto* nsh = new NavStartHandler();
            web->add_NavigationStarting(nsh, &tok);
            nsh->Release();

            // фон ДО першого кадру = базовий колір теми аккаунта (2.8.8):
            // без темного спалаху, коли у користувача світла/Liquid Glass
            UpdateWebViewBg();

            // інтерфейс -> файли %APPDATA%\FluxHelper\UI\ і навігація на ui.html
            g_uiHtml = BuildUiHtml();
            g_fallbackUsed = false;
            std::wstring path;
            if (WriteUiFiles(path))
                web->Navigate(FileUrl(path).c_str());
            else
                web->NavigateToString(Utf8ToWide(g_uiInline).c_str());

            // страховка на випадок невдалої навігації на файл
            auto* nch = new NavCompletedHandler();
            web->add_NavigationCompleted(nch, &tok);
            nch->Release();
        }

        UpdateBounds();
        // НЕ показуємо WebView одразу: GDI-сплеш (з іконкою) лишається на екрані,
        // поки сторінка не допишеться і не намалюється — таймер 4 покаже WebView.
        ctrl->put_IsVisible(FALSE);
        SetTimer(g_hwnd, 5, 20000, nullptr);   // страховка: якщо навігація зависла
        ctrl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        return S_OK;
    }
};

STDMETHODIMP EnvHandler::Invoke(HRESULT err, ICoreWebView2Environment* env) {
    if (FAILED(err) || !env) {
        MessageBoxW(g_hwnd,
            L"Не вдалося ініціалізувати WebView2.\n\n"
            L"Встанови Microsoft Edge WebView2 Runtime (безкоштовно):\n"
            L"https://go.microsoft.com/fwlink/p/?LinkId=2124703",
            L"FluxHelper — помилка", MB_OK | MB_ICONERROR);
        return S_OK;
    }
    auto* h = new CtrlHandler();
    env->CreateCoreWebView2Controller(g_hwnd, h);
    h->Release();  // володіння переходить до середовища
    return S_OK;
}

// ------------------------------------------------- лоадер WebView2
// DLL вбудовано в exe як RCDATA (ресурс 101). Витягуємо й завантажуємо з
// першої доступної локації: %APPDATA%\FluxHelper -> папка exe -> %LOCALAPPDATA%.
static std::wstring ExeDir() {
    wchar_t buf[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    std::wstring p(buf);
    size_t s = p.find_last_of(L"\\/");
    return (s == std::wstring::npos) ? std::wstring(L".") : p.substr(0, s);
}

static bool ExtractRcData(const std::wstring& path) {
    HRSRC rs = FindResourceW(nullptr, MAKEINTRESOURCEW(101), RT_RCDATA);
    if (!rs) return false;
    HGLOBAL hg = LoadResource(nullptr, rs);
    if (!hg) return false;
    LPVOID p = LockResource(hg);
    DWORD sz = SizeofResource(nullptr, rs);
    if (!p || !sz) return false;
    HANDLE f = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    DWORD w = 0;
    WriteFile(f, p, sz, &w, nullptr);
    CloseHandle(f);
    return true;
}

static HMODULE PrepareLoader() {
    PWSTR lp = nullptr;
    std::wstring local;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &lp))) {
        local = std::wstring(lp) + L"\\FluxControl";
        CoTaskMemFree(lp);
        CreateDirectoryW(local.c_str(), nullptr);
    }
    const std::wstring dirs[3] = { DataDir(), ExeDir(), local };
    for (const auto& d : dirs) {
        if (d.empty()) continue;
        std::wstring path = d + L"\\WebView2Loader.dll";
        HMODULE h = LoadLibraryW(path.c_str());          // вже витягнута раніше?
        if (h) return h;
        if (!ExtractRcData(path)) continue;              // витяг з ресурсів exe
        h = LoadLibraryW(path.c_str());
        if (h) return h;
    }
    return LoadLibraryW(L"WebView2Loader.dll");          // системний пошук (папка exe)
}

// ------------------------------------------------- заокруглення кутів (Win 10 fallback)
static void ApplyRounding(HWND h) {
    if (g_dwmRound || !h) return;
    if (IsZoomed(h)) { SetWindowRgn(h, nullptr, TRUE); return; }
    RECT rc;
    GetWindowRect(h, &rc);
    int w = rc.right - rc.left, hh = rc.bottom - rc.top;
    HRGN r = CreateRoundRectRgn(0, 0, w + 1, hh + 1, 18, 18);
    SetWindowRgn(h, r, TRUE);
}

// ------------------------------------------------- зміна розміру за краї
// WebView2 — дочірнє вікно, яке перехоплює мишу по всій клієнтській області,
// тому WM_NCHITTEST головного вікна по краях не спрацьовує. Рішення — 8
// ПОВНІСТЮ ПРОЗОРИХ (layered, alpha 0) дитячих вікон-смуг ПОВЕРХ WebView:
// вони невидимі, але повертають HT* з WM_NCHITTEST -> система сама тягне край.
enum { EL = 0, ER, ET, EB, ETL, ETR, EBL, EBR, ECNT };
static HWND g_edge[ECNT] = {};

static LRESULT CALLBACK EdgeProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_NCHITTEST: {
        switch (GetWindowLongPtrW(h, GWLP_USERDATA)) {
        case EL:  return HTLEFT;
        case ER:  return HTRIGHT;
        case ET:  return HTTOP;
        case EB:  return HTBOTTOM;
        case ETL: return HTTOPLEFT;
        case ETR: return HTTOPRIGHT;
        case EBL: return HTBOTTOMLEFT;
        case EBR: return HTBOTTOMRIGHT;
        }
        return HTCLIENT;
    }
    case WM_ERASEBKGND:
        return 1;                       // прозорі, нічого не малюємо
    case WM_PAINT: {
        PAINTSTRUCT ps;
        BeginPaint(h, &ps);
        EndPaint(h, &ps);
        return 0;
    }
    }
    return DefWindowProcW(h, m, wp, lp);
}

static void CreateEdges(HINSTANCE inst) {
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = EdgeProc;
    wc.hInstance = inst;
    wc.hCursor = nullptr;
    wc.lpszClassName = L"FluxHelperEdge";
    RegisterClassExW(&wc);
    for (int i = 0; i < ECNT; ++i) {
        g_edge[i] = CreateWindowExW(WS_EX_LAYERED, wc.lpszClassName, nullptr,
                                    WS_CHILD, 0, 0, 1, 1, g_hwnd, nullptr, inst, nullptr);
        if (g_edge[i]) {
            SetLayeredWindowAttributes(g_edge[i], 0, 0, LWA_ALPHA);   // alpha 0 = невидимі
            SetWindowLongPtrW(g_edge[i], GWLP_USERDATA, (LONG_PTR)i);
        }
    }
}

// розкладаємо смуги по краях і тримаємо їх ПОВЕРХ вікна WebView2
static void LayoutEdges() {
    if (!g_hwnd) return;
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    int cw = rc.right - rc.left, ch = rc.bottom - rc.top;
    if (IsZoomed(g_hwnd) || cw < 80 || ch < 60) {
        for (int i = 0; i < ECNT; ++i)
            if (g_edge[i]) ShowWindow(g_edge[i], SW_HIDE);
        return;
    }
    const int e = g_bezel;
    const int c = e * 2 + 2;            // кутові зони трохи більші
    struct ER_ { int id, x, y, w, h; };
    const ER_ r[ECNT] = {
        { EL,  0,     c,     e, ch - 2 * c },   // лівий край
        { ER,  cw - e, c,    e, ch - 2 * c },   // правий край
        { ET,  c,     0,     cw - 2 * c, e },   // верх
        { EB,  c,     ch - e, cw - 2 * c, e },  // низ
        { ETL, 0,     0,     c, c }, { ETR, cw - c, 0,     c, c },
        { EBL, 0,     ch - c, c, c }, { EBR, cw - c, ch - c, c, c }
    };
    for (int i = 0; i < ECNT; ++i) {
        if (!g_edge[i]) continue;
        SetWindowPos(g_edge[i], HWND_TOP, r[i].x, r[i].y, r[i].w, r[i].h,
                     SWP_NOACTIVATE | SWP_SHOWWINDOW);
    }
}

// ------------------------------------------------- екран завантаження (GDI)
// 2.8.8: малюється, поки WebView2 ініціалізується. ТОЧНО ТАК САМ, як
// HTML-сплеш: фіолетовий градієнт як в основному меню, міні-титулбар
// (іконка + назва зліва, кнопки «Згорнути»/«Закрити» справа — КЛІКАБЕЛЬНІ,
// зона титулбара перетягує вікно), по центру велика іконка + назва + смуга.
// Кольори беруться з теми аккаунта (хмара -> локальна -> standard).
struct SplashPal {
    COLORREF bgTop, bgBot;          // вертикальний градієнт фону
    COLORREF glowTop, glowCorner;   // фіолетові «світіння», як у меню
    COLORREF name, btn, pct;        // назва / кнопки вікна / відсотки
    COLORREF barTrack, barFill;     // смуга завантаження
    BYTE     glowTopA, glowCornerA;
};
static SplashPal SplashPalette(const std::string& t) {
    SplashPal p = {};
    if (t == "light") {
        p.bgTop = RGB(0xF5,0xF4,0xFC); p.bgBot = RGB(0xEE,0xF0,0xF8);
        p.glowTop = RGB(139,92,246);   p.glowTopA = 40;
        p.glowCorner = RGB(99,102,241);p.glowCornerA = 30;
        p.name = RGB(0x1C,0x1F,0x33);  p.btn = RGB(0x3D,0x42,0x57); p.pct = RGB(0x6A,0x70,0x89);
        p.barTrack = RGB(0xDE,0xE1,0xEC); p.barFill = RGB(124,58,237);
    } else if (t == "glass") {
        p.bgTop = RGB(0x0E,0x0A,0x26); p.bgBot = RGB(0x1A,0x0F,0x2E);
        p.glowTop = RGB(168,85,247);   p.glowTopA = 120;
        p.glowCorner = RGB(56,189,248);p.glowCornerA = 80;
        p.name = RGB(0xF2,0xF3,0xFA);  p.btn = RGB(0xCF,0xCB,0xE8); p.pct = RGB(0xB9,0xB4,0xD9);
        p.barTrack = RGB(46,42,74);    p.barFill = RGB(167,139,250);
    } else {   // standard (темна, як меню)
        p.bgTop = RGB(0x0B,0x08,0x17); p.bgBot = RGB(5,5,8);
        p.glowTop = RGB(124,58,237);   p.glowTopA = 56;
        p.glowCorner = RGB(79,70,229); p.glowCornerA = 40;
        p.name = RGB(255,255,255);     p.btn = RGB(0xA9,0xAD,0xBF); p.pct = RGB(0x8B,0x8F,0xA3);
        p.barTrack = RGB(28,28,36);    p.barFill = RGB(139,92,246);
    }
    return p;
}

// прямокутники кнопок вікна на сплеші (клієнтські координати; малює
// DrawSplash, читають WM_NCHITTEST/WM_LBUTTONDOWN, поки WebView не показано)
static RECT g_sMinRc = {}, g_sCloseRc = {};
static RECT g_sBarRc = {};        // смуга завантаження (для marquee)
static int  g_sBarW = 0;          // повна ширина смуги

// м'яке світіння (приблизна заміна radial-gradient з CSS): еліпс із
// GDI+ PathGradient — яскравий центр, прозорий край
static void SplashGlow(Gdiplus::Graphics& gfx, int cx, int cy, int rx, int ry,
                       COLORREF c, BYTE a) {
    Gdiplus::GraphicsPath path;
    path.AddEllipse(cx - rx, cy - ry, rx * 2, ry * 2);
    Gdiplus::PathGradientBrush br(&path);
    Gdiplus::Color center(a, (BYTE)GetRValue(c), (BYTE)GetGValue(c), (BYTE)GetBValue(c));
    br.SetCenterColor(center);
    Gdiplus::Color surround(0, (BYTE)GetRValue(c), (BYTE)GetGValue(c), (BYTE)GetBValue(c));
    INT n = 1;
    br.SetSurroundColors(&surround, &n);
    gfx.FillEllipse(&br, cx - rx, cy - ry, rx * 2, ry * 2);
}

// 2.8.9: КНОПКИ ВІКНА НА СПЛЕШІ = ПІКСЕЛЬ-У-ПІКСЕЛЬ як .tb-btn у головному меню:
// 34x29, радіус 9, відступи як у CSS (padding-right 7 + margin-right 4 у «Закрити»),
// іконки як SVG 12x12 (мінус 7px, хрест 6px, перо 1.3px — у 2.8.8 лінії були 12px
// завдовжки з пером 2px, через що кнопки «відрізнялись» від меню), і ТАКІ САМИ
// hover-стилі: білий напівпрозорий фон + рамка + білий значок; «Закрити» — червоний.
static int g_sHover = 0;    // 0 = ніде, 1 = «Згорнути», 2 = «Закрити»
static bool g_sTrack = false;

static Gdiplus::GraphicsPath* RoundRectPath(int x, int y, int w2, int h2, float r) {
    Gdiplus::GraphicsPath* p = new Gdiplus::GraphicsPath();
    float d = r * 2;
    p->AddArc((Gdiplus::REAL)x, (Gdiplus::REAL)y, d, d, 180, 90);
    p->AddArc((Gdiplus::REAL)(x + w2 - d), (Gdiplus::REAL)y, d, d, 270, 90);
    p->AddArc((Gdiplus::REAL)(x + w2 - d), (Gdiplus::REAL)(y + h2 - d), d, d, 0, 90);
    p->AddArc((Gdiplus::REAL)x, (Gdiplus::REAL)(y + h2 - d), d, d, 90, 90);
    p->CloseFigure();
    return p;
}

static void SplashBtn(Gdiplus::Graphics& gfx, const RECT& r2, bool hover, bool danger,
                      BYTE baseA) {
    const double k = (double)g_dpi / 96.0;
    if (hover) {
        // .tb-btn:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.17);color:#fff}
        // .tb-btn.tb-x:hover{background:rgba(244,63,94,.14);border-color:rgba(244,63,94,.55);color:#fb7185}
        Gdiplus::Color bg = danger ? Gdiplus::Color((BYTE)(36 * baseA / 255), 244, 63, 94)
                                   : Gdiplus::Color((BYTE)(18 * baseA / 255), 255, 255, 255);
        Gdiplus::Color bd = danger ? Gdiplus::Color((BYTE)(140 * baseA / 255), 244, 63, 94)
                                   : Gdiplus::Color((BYTE)(43 * baseA / 255), 255, 255, 255);
        Gdiplus::SolidBrush brBg(bg);
        Gdiplus::Pen penBd(bd, 1.0f);
        Gdiplus::GraphicsPath* p = RoundRectPath(r2.left, r2.top,
            r2.right - r2.left, r2.bottom - r2.top, (float)(9 * k));
        gfx.FillPath(&brBg, p);
        gfx.DrawPath(&penBd, p);
        delete p;
    }
    const BYTE ic = hover ? 255 : (BYTE)(baseA);   // значок: білий у hover, інакше #a9adbf
    BYTE ir = 0xA9, ig = 0xAD, ib = 0xBF;
    if (hover) { if (danger) { ir = 0xFB; ig = 0x71; ib = 0x85; } else { ir = ig = ib = 0xFF; } }
    Gdiplus::Color col(ic, ir, ig, ib);
    Gdiplus::Pen pen(col, (Gdiplus::REAL)(1.3 * k));
    pen.SetStartCap(Gdiplus::LineCapRound);
    pen.SetEndCap(Gdiplus::LineCapRound);
    const int cx2 = (r2.left + r2.right) / 2, cy2 = (r2.top + r2.bottom) / 2;
    if (danger) {
        // SVG 12x12 viewBox 24: лінії 6..18 -> 6px, пів-діагональ 3px
        int g2 = (int)(3 * k); if (g2 < 2) g2 = 2;
        gfx.DrawLine(&pen, (Gdiplus::REAL)(cx2 - g2), (Gdiplus::REAL)(cy2 - g2),
                           (Gdiplus::REAL)(cx2 + g2), (Gdiplus::REAL)(cy2 + g2));
        gfx.DrawLine(&pen, (Gdiplus::REAL)(cx2 + g2), (Gdiplus::REAL)(cy2 - g2),
                           (Gdiplus::REAL)(cx2 - g2), (Gdiplus::REAL)(cy2 + g2));
    } else {
        // SVG: лінія 5..19 -> 7px завдовжки
        int g2 = (int)(3.5 * k); if (g2 < 2) g2 = 2;
        gfx.DrawLine(&pen, (Gdiplus::REAL)(cx2 - g2), (Gdiplus::REAL)cy2,
                           (Gdiplus::REAL)(cx2 + g2), (Gdiplus::REAL)cy2);
    }
}

static void DrawSplash(HDC dc, const RECT& rc) {
    int w = rc.right - rc.left, hh = rc.bottom - rc.top;
    if (w <= 0 || hh <= 0) return;
    const std::string theme = CurrentTheme();
    const SplashPal pal = SplashPalette(theme);
    const double k = (double)g_dpi / 96.0;

    HDC mem = CreateCompatibleDC(dc);
    HBITMAP bmp = CreateCompatibleBitmap(dc, w, hh);
    HGDIOBJ ob = SelectObject(mem, bmp);

    // --- фон: вертикальний градієнт + світіння (GDI+ поверх GDI) ---
    {
        Gdiplus::Graphics gfx(mem);
        gfx.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
        Gdiplus::Rect full(0, 0, w, hh);
        Gdiplus::LinearGradientBrush bgb(full,
            Gdiplus::Color(255, (BYTE)GetRValue(pal.bgTop), (BYTE)GetGValue(pal.bgTop), (BYTE)GetBValue(pal.bgTop)),
            Gdiplus::Color(255, (BYTE)GetRValue(pal.bgBot), (BYTE)GetGValue(pal.bgBot), (BYTE)GetBValue(pal.bgBot)),
            Gdiplus::LinearGradientModeVertical);
        gfx.FillRectangle(&bgb, full);
        // світіння зверху по центру + у нижньому куті — «фіолетовий градієнт меню»
        SplashGlow(gfx, w / 2, (int)(-hh * 0.06), (int)(310 * k), (int)(210 * k), pal.glowTop, pal.glowTopA);
        SplashGlow(gfx, (int)(w * 0.88), (int)(hh * 1.18), (int)(350 * k), (int)(250 * k), pal.glowCorner, pal.glowCornerA);
    }

    // --- міні-титулбар: лого + назва зліва, кнопки вікна справа ---
    const int tbH = (int)(50 * k);
    const int logoSm = (int)(27 * k);
    if (g_logoBmp) {
        Gdiplus::Graphics gfx(mem);
        gfx.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
        gfx.DrawImage(g_logoBmp, (int)(14 * k), (tbH - logoSm) / 2, logoSm, logoSm);
    }
    SetBkMode(mem, TRANSPARENT);
    {
        HFONT f = CreateFontW(-(int)MulDiv(15, g_dpi, 96), 0, 0, 0, FW_BOLD, 0, 0, 0,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        HGDIOBJ of = SelectObject(mem, f);
        SetTextColor(mem, pal.name);
        RECT tr = { (int)(51 * k), 0, w, tbH };
        DrawTextW(mem, L"FluxHelper", -1, &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        SelectObject(mem, of);
        DeleteObject(f);
    }
    // кнопки: 34x29, права «Закрити» з відступом 4+7 від краю — як у програмі
    const int bw = (int)(34 * k), bh = (int)(29 * k);
    g_sCloseRc.right  = w - (int)(11 * k);
    g_sCloseRc.left   = g_sCloseRc.right - bw;
    g_sCloseRc.top    = (tbH - bh) / 2;
    g_sCloseRc.bottom = g_sCloseRc.top + bh;
    g_sMinRc.right    = g_sCloseRc.left - (int)(2 * k);
    g_sMinRc.left     = g_sMinRc.right - bw;
    g_sMinRc.top      = g_sCloseRc.top;
    g_sMinRc.bottom   = g_sCloseRc.bottom;
    {
        // 2.8.9: малюємо через GDI+ з hover-станами — 1-в-1 як .tb-btn у меню
        Gdiplus::Graphics gfx(mem);
        gfx.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
        SplashBtn(gfx, g_sMinRc, g_sHover == 1, false, 255);
        SplashBtn(gfx, g_sCloseRc, g_sHover == 2, true, 255);
    }

    // --- центральний блок: іконка 92 + назва + смуга (той самий GDI-сплеш,
    //     що й у 2.8.5-2.8.7, тепер у кольорах теми) ---
    const int logoSz = (int)(92 * k);
    const int bwBar = (int)(198 * k), bhBar = (int)(5 * k);
    const int total = (int)(183 * k);
    int y = (hh - total) / 2; if (y < tbH + (int)(8 * k)) y = tbH + (int)(8 * k);
    const int cx = w / 2;
    if (g_logoBmp) {
        Gdiplus::Graphics gfx(mem);
        gfx.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
        Gdiplus::Rect dst(cx - logoSz / 2, y, logoSz, logoSz);
        gfx.DrawImage(g_logoBmp, dst);
    }

    int y2 = y + logoSz + (int)(15 * k);
    SetTextColor(mem, pal.name);
    HFONT f2 = CreateFontW(-(int)MulDiv(20, g_dpi, 96), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
                           OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                           DEFAULT_PITCH, L"Segoe UI");
    HGDIOBJ of2 = SelectObject(mem, f2);
    RECT tr2 = { 0, y2, w, y2 + (int)(26 * k) };
    DrawTextW(mem, L"FluxHelper", -1, &tr2, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(mem, of2);
    DeleteObject(f2);

    const int by = y2 + (int)(26 * k) + (int)(19 * k);
    HBRUSH bb = CreateSolidBrush(pal.barTrack);
    RECT bar = { cx - bwBar / 2, by, cx + bwBar / 2, by + bhBar };
    FillRect(mem, &bar, bb);
    DeleteObject(bb);
    g_sBarRc = bar;
    g_sBarW = bwBar;
    const int seg = (int)(64 * k);
    const int period = bwBar + seg;
    int sx = (g_splashTick * 3) % period;
    int x0 = cx - bwBar / 2 + sx - seg;
    int x1 = cx - bwBar / 2 + sx;
    if (x0 < cx - bwBar / 2) x0 = cx - bwBar / 2;
    if (x1 > cx + bwBar / 2) x1 = cx + bwBar / 2;
    if (x1 > x0) {
        HBRUSH sb = CreateSolidBrush(pal.barFill);
        RECT sr = { x0, by, x1, by + bhBar };
        FillRect(mem, &sr, sb);
        DeleteObject(sb);
    }

    BitBlt(dc, 0, 0, w, hh, mem, 0, 0, SRCCOPY);
    SelectObject(mem, ob);
    DeleteObject(bmp);
    DeleteDC(mem);
}

// ------------------------------------------------- вікно
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_GETMINMAXINFO: {
        MINMAXINFO* mmi = (MINMAXINFO*)lp;
        mmi->ptMinTrackSize.x = MulDiv(640, g_dpi, 96);
        mmi->ptMinTrackSize.y = MulDiv(440, g_dpi, 96);
        return 0;
    }
    case WM_NCCALCSIZE:
        // прибираємо стандартну рамку/заголовок: клієнтська область = усе вікно
        if (!wp) break;
        if (IsZoomed(h)) {
            int pad = GetSystemMetrics(SM_CXFRAME) + GetSystemMetrics(SM_CXPADDEDBORDER);
            RECT* r = (RECT*)lp;
            r->left += pad; r->top += pad; r->right -= pad; r->bottom -= pad;
        }
        return 0;
    case WM_NCHITTEST: {
        // тонка рамка навколо WebView -> зміна розміру перетягуванням країв
        if (IsZoomed(h)) break;
        POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
        RECT rc;
        GetWindowRect(h, &rc);
        int x = pt.x - rc.left, y = pt.y - rc.top;
        int w = rc.right - rc.left, hh = rc.bottom - rc.top;
        int bd = g_bezel;
        bool l = x < bd, r = x >= w - bd, t = y < bd, b = y >= hh - bd;
        if (t && l) return HTTOPLEFT;
        if (t && r) return HTTOPRIGHT;
        if (b && l) return HTBOTTOMLEFT;
        if (b && r) return HTBOTTOMRIGHT;
        if (l) return HTLEFT;
        if (r) return HTRIGHT;
        if (t) return HTTOP;
        if (b) return HTBOTTOM;
        // 2.8.8: сплеш — зона міні-титулбара перетягує вікно (як fh:drag у HTML),
        // кнопки «Згорнути»/«Закрити» лишаються кліками (WM_LBUTTONDOWN)
        if (!g_webShown) {
            POINT cpt = { x, y };
            if (y < MulDiv(50, g_dpi, 96) &&
                !PtInRect(&g_sMinRc, cpt) && !PtInRect(&g_sCloseRc, cpt))
                return HTCAPTION;
        }
        break;
    }
    case WM_LBUTTONDOWN: {
        // 2.8.8: кнопки вікна прямо на GDI-сплеші — згорнути/закрити можна,
        // навіть поки WebView2 ще ініціалізується
        if (!g_webShown) {
            POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
            if (PtInRect(&g_sCloseRc, pt)) { DestroyWindow(h); return 0; }
            if (PtInRect(&g_sMinRc, pt))  { ShowWindow(h, SW_MINIMIZE); return 0; }
        }
        break;
    }
    case WM_MOUSEMOVE: {
        // 2.8.9: hover-підсвітка кнопок на GDI-сплеші — така сама, як у меню
        if (g_webShown) break;
        POINT pt = { GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
        int hv = PtInRect(&g_sCloseRc, pt) ? 2 : (PtInRect(&g_sMinRc, pt) ? 1 : 0);
        if (hv != g_sHover) {
            g_sHover = hv;
            InvalidateRect(h, nullptr, FALSE);
        }
        if (!g_sTrack) {
            TRACKMOUSEEVENT tme = { sizeof(tme), TME_LEAVE, h, 0 };
            if (TrackMouseEvent(&tme)) g_sTrack = true;
        }
        return 0;
    }
    case WM_MOUSELEAVE:
        g_sTrack = false;
        if (g_sHover) { g_sHover = 0; InvalidateRect(h, nullptr, FALSE); }
        return 0;
    case WM_SIZE:
        if (wp == SIZE_MINIMIZED) {
            if (g_ctrl) g_ctrl->put_IsVisible(FALSE);
            return 0;
        }
        if (g_ctrl) {
            if (g_webShown) g_ctrl->put_IsVisible(TRUE);   // до готовності сторінки тримаємо схованим
            UpdateBounds();
        }
        LayoutEdges();
        ApplyRounding(h);
        RefreshBorderColor();
        return 0;
    case WM_EXITSIZEMOVE:
        // користувач закінчив тягнути вікно -> запам'ятовуємо розмір назавжди
        SaveWindowSize();
        return 0;
    case WM_APP + 1:
        // клік по іконці в треї -> показати вікно
        if (lp == WM_LBUTTONUP || lp == WM_LBUTTONDBLCLK) {
            ShowWindow(h, SW_RESTORE);
            SetForegroundWindow(h);
        }
        break;
    case WM_APP + 3:   // прогрес завантаження оновлення (wp = 0..100)
        UiScript(L"window.__fh&&window.__fh.dlProg(" + std::to_wstring((int)wp) + L")");
        return 0;
    case WM_APP + 4: { // помилка завантаження оновлення (lp = new std::wstring)
        std::wstring* msg = (std::wstring*)lp;
        if (msg) {
            std::wstring t = *msg;
            for (auto& c : t) if (c == L'\"' || c == L'\\') c = L' ';
            UiScript(L"window.__fh&&window.__fh.dlErr(\"" + t + L"\")");
            delete msg;
        }
        return 0;
    }
    case WM_APP + 5:   // завантаження завершено, запускаємо встановлення
        UiScript(L"window.__fh&&window.__fh.dlDone()");
        return 0;
    case WM_APP + 10:  // 2.8.0: стирання даних акаунта завершено -> перезбираємо інтерфейс
        BackToUi();
        return 0;
    case WM_CLOUD_DONE: {   // відповідь хмари (cfq/cloud/tokeninfo/auth/probe)
        CloudResult* r = (CloudResult*)lp;
        if (r && r->kind == 3) {
            AuthFromTokenInfo(r->status, r->body);
            delete r;
            return 0;
        }
        if (r && r->kind == 4) {   // 2.7.7: PKCE-обмін коду на ID-токен
            OnTokenExchange(r->status, r->body);
            delete r;
            return 0;
        }
        if (r && r->kind == 5) {   // 2.8.1: probe OAuth видалено — ігноруємо
            delete r;
            return 0;
        }
        if (r) {
            std::wstring js = L"window.__fh&&window.__fh.";
            js += (r->kind == 1) ? L"cfqCb" : L"cloudCb";
            js += L"(\"" + r->id + L"\"," + std::to_wstring(r->status) + L",";
            if (!r->body.empty()) {
                std::string b = r->body.substr(0, 900000);
                // 2.7.3: сирі \n\r у JSON-відповіді легальні (пробіли між
                // токенами) — прибираємо, а НЕ губимо всю відповідь (null).
                b.erase(std::remove(b.begin(), b.end(), '\n'), b.end());
                b.erase(std::remove(b.begin(), b.end(), '\r'), b.end());
                js += Utf8ToWide(b);
            } else js += L"null";
            js += L")";
            UiScript(js);
            delete r;
        }
        return 0;
    }
    case WM_CLOSE:
        // гейт входу: закрити вікно неможливо (Alt+F4 теж) — тільки згортання
        if (g_gateLock && !g_allowClose) {
            ShowWindow(h, SW_MINIMIZE);
            return 0;
        }
        break;
    case WM_AUTH_READY: {   // 3.4.0: слухач готовий (підігрів або клік до готовності)
        if ((LONG)(INT_PTR)lp != g_authGen) return 0;
        g_authPort = (int)wp;
        g_loginArmed = true;
        if (g_loginOpenPending && !g_loginBusy) {
            g_loginOpenPending = false;
            OpenLoginBrowser();   // клік був раніше — відкриваємо браузер зараз
        }
        return 0;
    }
    case WM_AUTH_CB: {      // 2.8.1: сайт повернув ПРОФІЛЬ Google (локальний канал)
        std::unique_ptr<std::wstring> u((std::wstring*)lp);
        KillTimer(h, TIMER_AUTH);
        std::wstring st = UrlParam(*u, L"state");
        std::wstring er = UrlParam(*u, L"err");
        if (st != g_st) { AuthUiErr(L"Сесія входу недійсна. Натисни «Увійти через Google» ще раз."); return 0; }
        if (!er.empty()) {
            AuthUiErr(er == L"denied"
                ? L"Вхід скасовано у браузері. Натисни «Увійти через Google» ще раз."
                : L"Вхід не завершено. Спробуй ще раз.");
            return 0;
        }
        std::wstring d = UrlParam(*u, L"d");
        if (d.empty()) { AuthUiErr(L"Сайт не повернув профіль. Спробуй ще раз."); return 0; }
        std::string prof;
        {
            std::wstring dec = UrlDecode(d);
            prof.clear();
            for (wchar_t c : dec) {
                if (c < 0x80) prof += (char)c;
                else if (c < 0x800) { prof += (char)(0xC0 | (c >> 6)); prof += (char)(0x80 | (c & 0x3F)); }
                else { prof += (char)(0xE0 | (c >> 12)); prof += (char)(0x80 | ((c >> 6) & 0x3F)); prof += (char)(0x80 | (c & 0x3F)); }
            }
        }
        std::string sub, nm, mail, pic, fid, tok;
        JsonGetStr(prof.c_str(), "\"sub\"", sub);
        JsonGetStr(prof.c_str(), "\"email\"", mail);
        JsonGetStr(prof.c_str(), "\"name\"", nm);
        JsonGetStr(prof.c_str(), "\"picture\"", pic);
        JsonGetStr(prof.c_str(), "\"fid\"", fid);
        JsonGetStr(prof.c_str(), "\"tok\"", tok);   // 2.8.7: access_token для запасного обміну fid
        if (sub.empty() || mail.empty()) { AuthUiErr(L"Не вдалося прочитати профіль Google. Спробуй ще раз."); return 0; }
        /* 3.4.9: збереження сесії винесено в PersistGoogleProfile — та сама
           робота, що й для резервного каналу fh:authsave (одна точка правди) */
        PersistGoogleProfile(sub, nm, mail, pic, fid, tok);
        AuthUiOk(sub, nm, mail, pic, fid, tok);
        return 0;
    }
    case WM_AUTH_ERR: {     // 2.7.7: локальний слухач не зміг стартувати
        std::unique_ptr<std::wstring> m((std::wstring*)lp);
        AuthUiErr(m->c_str());
        return 0;
    }
    case WM_AUTH_GONE: {    // 3.4.12: сторінку входу ЗАКРИЛИ (bye) — кнопка знову активна
        AuthUiErr(L"\u0412\u0456\u043A\u043D\u043E \u0432\u0445\u043E\u0434\u0443 \u0437\u0430\u043A\u0440\u0438\u0442\u043E. \u041D\u0430\u0442\u0438\u0441\u043D\u0438 \u00AB\u0423\u0432\u0456\u0439\u0442\u0438 \u0447\u0435\u0440\u0435\u0437 Google\u00BB \u0449\u0435 \u0440\u0430\u0437.");
        return 0;
    }
    case WM_COPYDATA: {   // другий інстанс передає fluxhelper://... (кнопка «Зайти» в тості)
        // 3.4.6: кнопки «Зайти на урок»/«Нагадати за 1 хв» — БЕЗ показу вікна:
        // клік по кнопці тоста відкриває САМЕ урок (Zoom-додаток/браузер за
        // налаштуванням), а не головне вікно програми. Вікно показуємо лише
        // для fluxhelper://open (клік по тілу тоста) і входу (auth).
        COPYDATASTRUCT* cds = (COPYDATASTRUCT*)lp;
        if (cds && cds->lpData && cds->cbData > 0) {
            std::wstring url((const wchar_t*)cds->lpData, cds->cbData / sizeof(wchar_t));
            const bool silentAct = (url.find(L"fluxhelper://join") != std::wstring::npos ||
                                    url.find(L"fluxhelper://snooze") != std::wstring::npos ||
                                    url.find(L"fluxhelper://tsnooze") != std::wstring::npos);
            if (!silentAct) {
                ShowWindow(h, SW_RESTORE);
                SetForegroundWindow(h);
            }
            if (url.find(L"fluxhelper://join") != std::wstring::npos) {
                /* 3.4.5: тестовий тост несе URL уроку в ?u= — прокидаємо в інтерфейс */
                std::wstring u = ProtoArgU(url);
                if (!u.empty())
                    UiScript(L"window.__fh&&window.__fh.notifAction&&window.__fh.notifAction('join','" + JsEsc(u) + L"')");
                else
                    UiScript(L"window.__fh&&window.__fh.notifAction&&window.__fh.notifAction('join')");
            }
            /* 2.9.2: кнопка тоста «Прислати за 1 хв» — одноразове нагадування.
               3.4.13: fluxhelper://tsnooze — ДЕМО з тестового тоста (+1 хв). */
            if (url.find(L"fluxhelper://tsnooze") != std::wstring::npos)
                ArmSnooze(true);
            else if (url.find(L"fluxhelper://snooze") != std::wstring::npos)
                ArmSnooze();
            if (url.find(L"fluxhelper://auth") != std::wstring::npos)
                HandleProtoUrl(url);
            return TRUE;
        }
        break;
    }
    case WM_TIMER:
        if (wp == 3) {
            if (g_bootDone) { KillTimer(h, 3); InvalidateRect(h, nullptr, FALSE); }
            else { ++g_splashTick; InvalidateRect(h, nullptr, FALSE); }
            return 0;
        }
        if (wp == 4 || wp == 5) {   // сторінка готова (або таймаут) -> показуємо WebView
            KillTimer(h, 4); KillTimer(h, 5);
            if (!g_webShown) {
                g_webShown = true;
                if (g_ctrl) g_ctrl->put_IsVisible(TRUE);
                g_bootDone = true;   // ховаємо GDI-сплеш — інтерфейс уже з іконкою
                InvalidateRect(h, nullptr, FALSE);
            }
            return 0;
        }
        if (wp == TIMER_AUTH) {   // 2.7.7: браузер не відповів за 4 хвилини
            KillTimer(h, TIMER_AUTH);
            if (g_loginBusy) AuthUiErr(L"Час очікування вийшов. Якщо у браузері не було вікна входу Google — спробуй ще раз.");
            return 0;
        }
        if (wp == 2) {
            CheckNotifs();
            /* 3.4.12: сторінка входу зникла БЕЗ bye (вбили процес браузера,
               впав ноут) — серцебиття мовчить >70 с -> кнопка входу знову
               активна. (Звичайне закриття вкладки ловиться миттєво через
               sendBeacon /bye; це страховий шлях.) Поріг 70 с — щоб не
               спрацьовувати при системному пригальмуванні таймерів фону. */
            if (g_loginBusy && g_authHbSeen) {
                long long nowT = (long long)GetTickCount64();
                if (g_authHbAt > 0 && nowT - g_authHbAt > 70000)
                    PostMessageW(g_hwnd, WM_AUTH_GONE, 0, 0);
            }
            CleanupOldFiles();   // дозчищаємо залишки оновлень, якщо були зайняті
            LayoutEdges();   // страховка: смуги завжди поверх вікна WebView2
            if (!g_pendingUrl.empty() && g_bootDone) {   // fluxhelper://auth з запуску
                std::wstring u = g_pendingUrl;
                g_pendingUrl.clear();
                HandleProtoUrl(u);
            }
            /* 3.4.13: ТОЧНІСТЬ НАГАДУВАННЯ «за 1 хвилину» (просив власник:
               «перевір щоб воно точно тоді, коли треба»). Звичайний цикл —
               15 с; коли нагадування заплановане на поточний день — таймер
               звужується до 2 с, щоб нагадування прийшло рівно в свою
               хвилину (розкид ≤2 с замість ≤15 с). Після показу таймер
               сам повертається до 15 с (g_snoozeMin = -1 у CheckNotifs). */
            {
                SYSTEMTIME stn;
                GetLocalTime(&stn);
                long long dayNow = (long long)stn.wYear * 10000 + stn.wMonth * 100 + stn.wDay;
                UINT per = (g_snoozeMin >= 0 && g_snoozeDay == dayNow) ? 2000 : 15000;
                SetTimer(g_hwnd, 2, per, nullptr);
            }
            return 0;
        }
        break;
    case WM_ACTIVATE:
        RefreshBorderColor();
        break;
    case WM_APP + 12: {   // 2.8.8: тему аккаунта підтягнуто з хмари — зберігаємо і перефарбовуємо сплеш
        SaveAllCfg();
        UpdateWebViewBg();   // g_ctrl може бути ще null — функція сама перевіряє
        InvalidateRect(h, nullptr, FALSE);
        return 0;
    }
    case WM_NCACTIVATE:
        // без перемальовки неклієнтської рамки — усуває білі спалахи по краях
        // при зміні фокусу/розміру вікна (стандартний трюк для безрамкових вікон)
        return DefWindowProcW(h, m, wp, -1);
    case WM_ERASEBKGND: {
        HDC dc = (HDC)wp;
        RECT rc;
        GetClientRect(h, &rc);
        static HBRUSH br = CreateSolidBrush(RGB(5, 5, 8));
        FillRect(dc, &rc, br);
        return 1;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(h, &ps);
        if (!g_bootDone) {
            RECT rc;
            GetClientRect(h, &rc);
            DrawSplash(dc, rc);   // гарний екран завантаження, поки WebView2 стартує
        }
        EndPaint(h, &ps);
        return 0;
    }
    case WM_SETFOCUS:
        if (g_ctrl) g_ctrl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        return 0;
    case WM_DESTROY:
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        KillTimer(h, 2);
        KillTimer(h, 3);
        KillTimer(h, TIMER_AUTH);
        InterlockedIncrement(&g_authGen);   // глушимо локальний слухач входу
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR lpCmd, int nCmdShow) {
    /* 3.4.12: Winsock — ОДНА ініціалізація на процес (раніше кожен потік
       слухача мав свій WSAStartup/WSACleanup, і cleanup старого потока
       «вбивав» сокети нового — швидкий повторний вхід не відкривав сторінку). */
    WSADATA wsa0{};
    g_wsaOk = (WSAStartup(MAKEWORD(2, 2), &wsa0) == 0);
    // 2.7.2: кнопка «Зайти» в тості запускає fluxhelper://... — передаємо
    // аргумент працюючому інстансу (WM_COPYDATA) і виходимо
    std::wstring cmdLine = lpCmd ? lpCmd : L"";
    bool isProto = cmdLine.find(L"fluxhelper://") != std::wstring::npos;
    // 3.4.5: прапорець --upd-wait ставить оновлювач: нова версія чекає виходу
    // старої (м'ютекс), а не виходить з «уже працює». Без прапорця поведінка
    // подвійного запуску не змінюється (миттєве фокусування вікна).
    bool updWait = cmdLine.find(L"--upd-wait") != std::wstring::npos;
    HANDLE hMut = nullptr;
    if (updWait) {
        // ГРЕЙС-ПЕРІОД 60 с: стара версія закривається (або її доб'є доглядач
        // через 45 с). Якщо м'ютекс і тоді зайнятий — виходимо, доглядач
        // побачить відсутність маркера і перезапустить нас ще раз.
        for (int i = 0; i < 200; ++i) {
            hMut = CreateMutexW(nullptr, TRUE, L"FluxHelper.SingleInstance");
            if (hMut && GetLastError() != ERROR_ALREADY_EXISTS) break;
            if (hMut) { ReleaseMutex(hMut); CloseHandle(hMut); hMut = nullptr; }
            Sleep(300);
        }
        if (!hMut) return 0;   // так і не дочекались — доглядач повторить запуск
    } else {
        hMut = CreateMutexW(nullptr, TRUE, L"FluxHelper.SingleInstance");
        if (hMut && GetLastError() == ERROR_ALREADY_EXISTS) {
            // 3.4.6: вікно головного інстансу може ще НЕ існувати (другий
            // інстанс стартував раніше — клік по кнопці тоста під час запуску
            // програми). Раніше FindWindow повертав null -> кнопка тоста
            // «німо» вмирала. Тепер чекаємо на вікно до 4 с.
            HWND prev = nullptr;
            for (int i = 0; i < 40 && !prev; ++i) {
                prev = FindWindowW(L"FluxHelperWnd", nullptr);
                if (!prev) Sleep(100);
            }
            if (prev) {
                if (isProto) {
                    COPYDATASTRUCT cds{};
                    cds.dwData = 0x4648;   // 'FH'
                    cds.cbData = (DWORD)((cmdLine.size() + 1) * sizeof(wchar_t));
                    cds.lpData = (void*)cmdLine.c_str();
                    SendMessageW(prev, WM_COPYDATA, (WPARAM)g_hwnd, (LPARAM)&cds);
                } else {
                    ShowWindow(prev, SW_RESTORE);
                    SetForegroundWindow(prev);
                }
            }
            if (hMut) ReleaseMutex(hMut);
            return 0;
        }
    }
    // 3.4.5: маркер «нова версія успішно стартувала» для доглядача оновлення
    // (він пише себе ЩОРАЗУ при старті — доглядач живий лише вікном оновлення
    // і читає маркер тільки в цей час, тому звичайні запуски йому байдужі).
    {
        HANDLE okf = CreateFileW((DataDir() + L"\\upd.ok").c_str(), GENERIC_WRITE, 0,
                                 nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (okf != INVALID_HANDLE_VALUE) {
            DWORD wr = 0;
            wchar_t pidbuf[24];
            swprintf(pidbuf, 24, L"%lu", (unsigned long)GetCurrentProcessId());
            WriteFile(okf, pidbuf, (DWORD)(wcslen(pidbuf) * sizeof(wchar_t)), &wr, nullptr);
            CloseHandle(okf);
        }
    }
    if (isProto) g_pendingUrl = cmdLine;
    SetProcessDPIAware();
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    InitSplashLogo();   // GDI+ + PNG-логотип для сплеша
    LoadAllCfg();   // групи + розмір вікна + сповіщення з минулого запуску
    CfToken();          // розкодувати вбудований токен один раз
    EnsureLogoPng();         // 3.4.6: логотип для іконки в сповіщеннях (до AUMID/тостів)
    EnsureAumidShortcut();   // ярлик з AUMID — інакше Windows не покаже тости
    RegisterProtocol();      // fluxhelper:// для кнопки «Зайти»
    g_msgTaskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");
    CleanupOldFiles();   // залишки минулих оновлень (.bat/.new/.old, старі імена exe)
    CleanupLegacyFiles();   // 3.5.0: спадок старих версій у папці даних (ui.html 2.4.3, FluxControl/Blazix тощо)

    // масштаб інтерфейсу під системний DPI
    typedef UINT (WINAPI *FnGetDpiForSystem)(void);
    FnGetDpiForSystem gdf = (FnGetDpiForSystem)(void*)GetProcAddress(
        GetModuleHandleW(L"user32.dll"), "GetDpiForSystem");
    if (gdf) g_dpi = gdf();
    g_bezel = MulDiv(6, (int)g_dpi, 96);
    if (g_bezel < 4) g_bezel = 4;

    WNDCLASSEXW wc{};
    wc.cbSize        = sizeof(wc);
    wc.style         = 0;   // без CS_HREDRAW/CS_VREDRAW — менше перемальовок при розтягуванні
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hIcon         = LoadIconW(hInst, MAKEINTRESOURCEW(1));
    wc.hIconSm       = LoadIconW(hInst, MAKEINTRESOURCEW(1));
    wc.hCursor       = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(5, 5, 8));
    wc.lpszClassName = L"FluxHelperWnd";
    RegisterClassExW(&wc);

    // вікно по центру екрана; якщо минулого разу розмір змінювали — відновлюємо
    RECT wa{};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int W = MulDiv(1040, (int)g_dpi, 96);
    int H = MulDiv(700, (int)g_dpi, 96);
    if (g_cfg.w >= MulDiv(640, (int)g_dpi, 96) && g_cfg.h >= MulDiv(440, (int)g_dpi, 96)) {
        W = g_cfg.w;
        H = g_cfg.h;
    }
    if (W > wa.right - wa.left - 20) W = wa.right - wa.left - 20;
    if (H > wa.bottom - wa.top - 20) H = wa.bottom - wa.top - 20;
    int x = wa.left + ((wa.right - wa.left) - W) / 2;
    int y = wa.top  + ((wa.bottom - wa.top) - H) / 2;

    // безрамкове вікно: стандартний заголовок вимкнено через WM_NCCALCSIZE
    g_hwnd = CreateWindowExW(0, wc.lpszClassName, L"FluxHelper",
                             WS_POPUP | WS_THICKFRAME | WS_CAPTION | WS_SYSMENU |
                             WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
                             x, y, W, H, nullptr, nullptr, hInst, nullptr);
    if (!g_hwnd) return 1;

    // ФІКС «іконки вгорі»: у безрамкових вікон (WS_POPUP) іконка класу не
    // завжди підхоплюється системою -> примусово шлем WM_SETICON (велика
    // для Alt+Tab/панелі задач, мала — для заголовка/панелі задач).
    {
        HICON icB = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(1), IMAGE_ICON,
            GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
        HICON icS = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(1), IMAGE_ICON,
            GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
        if (icB) { SendMessageW(g_hwnd, WM_SETICON, ICON_BIG, (LPARAM)icB); }
        if (icS) { SendMessageW(g_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)icS); }
    }

    // прозорі смуги по краях: тягнути край -> зміна розміру (розмір запам'ятовується)
    CreateEdges(hInst);

    BOOL dark = TRUE;
    DwmSetWindowAttribute(g_hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof(dark));

    // заокруглені кути (Windows 11); кольорову окантовку навколо вікна не малюємо
    UINT pref = DWMWCP_ROUND;
    g_dwmRound = SUCCEEDED(DwmSetWindowAttribute(g_hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &pref, sizeof(pref)));
    if (g_dwmRound) {
        COLORREF bc = DWMWA_COLOR_NONE;          // без рамки навколо вікна
        DwmSetWindowAttribute(g_hwnd, DWMWA_BORDER_COLOR, &bc, sizeof(bc));
    } else {
        ApplyRounding(g_hwnd);  // Windows 10: регіон
    }

    ShowWindow(g_hwnd, nCmdShow);
    UpdateWindow(g_hwnd);

    // сплеш-анімація (поки WebView2 стартує) + перевірка сповіщень раз на 15 с
    SetTimer(g_hwnd, 3, 33, nullptr);
    SetTimer(g_hwnd, 2, 15000, nullptr);
    AddTray();   // іконка в треї — для сповіщень Windows про початок уроку

    // 2.8.8: тема аккаунта з хмари — фоновий мікро-запит ПІД час старту
    // WebView2: сплеш малюється в темі аккаунта, ще до появи інтерфейсу
    StartThemeFetch();
    // 3.4.0: міграція з 3.3.2 — створюємо серверне дзеркало сесії (sess у D1)
    if (g_sessNeedsMirror) SessionCloudMirror(false);

    // WebView2Loader.dll вбудовано в exe: витягуємо й завантажуємо з першої
    // доступної локації (%APPDATA% -> папка exe -> %LOCALAPPDATA%)
    HMODULE hLoader = PrepareLoader();
    if (!hLoader) {
        MessageBoxW(g_hwnd,
            L"Не вдалося підготувати WebView2Loader.dll.\n"
            L"Перевстанови програму або перевір, чи не блокує її антивірус.",
            L"FluxHelper — помилка", MB_OK | MB_ICONERROR);
        return 1;
    }

    auto createEnv = (decltype(&CreateCoreWebView2EnvironmentWithOptions))
        GetProcAddress(hLoader, "CreateCoreWebView2EnvironmentWithOptions");
    if (!createEnv) {
        MessageBoxW(g_hwnd, L"WebView2Loader.dll пошкоджений. Перевстанови програму.",
                    L"FluxHelper — помилка", MB_OK | MB_ICONERROR);
        return 1;
    }

    std::wstring cacheDir = CacheDir();
    auto* eh = new EnvHandler();
    createEnv(nullptr, cacheDir.c_str(), nullptr, eh);
    eh->Release();

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    CoUninitialize();
    return (int)msg.wParam;
}
