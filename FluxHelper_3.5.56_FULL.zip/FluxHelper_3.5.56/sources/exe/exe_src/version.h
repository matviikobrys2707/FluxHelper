// ============================================================
//  FluxHelper — єдине джерело версії (exe-ресурси + інтерфейс).
//  Змінюєш ТІЛЬКИ ТУТ і перезбираєш: app.rc (VERSIONINFO у
//  властивостях файлу Windows) і APP_VER в інтерфейсі беруться звідси.
//  Build.bat читає звідси поточну версію і пропонує наступну.
//  УВАГА: Blazix — це ім'я АВТОРА (видавець), а не програми!
// ============================================================
#ifndef FH_VERSION_H
#define FH_VERSION_H

#define FH_VER_MAJ 3
#define FH_VER_MIN 5
#define FH_VER_PAT 10

#define FH_STRINGIFY_(x) #x
#define FH_STRINGIFY(x)  FH_STRINGIFY_(x)
#define FH_VER_STR FH_STRINGIFY(FH_VER_MAJ) "." FH_STRINGIFY(FH_VER_MIN) "." FH_STRINGIFY(FH_VER_PAT)

// видавець (автор), який показує Windows у властивостях файлу
#define FH_PUBLISHER "Blazix"
// назва програми БЕЗ пробілів (ім'я exe, ProductName, InternalName)
#define FH_PRODUCT   "FluxHelper"
// FileDescription у властивостях файлу (ASCII — llvm-rc добре його переносить)
#define FH_DESC      "FluxHelper"

// ------------------------------------------------------------
//  2.7.7: OAuth-клієнт Google (тип Desktop application).
//  Стара трійка клієнтів (k470ldmv/14h6abj/t8gqql3m) БУЛА ВИДАЛЕНА
//  у Google Cloud Console — усі показували «Error 401: deleted_client».
//  КОЛИ СТВОРИШ НОВИЙ КЛІЄНТ (APIs & Services -> Credentials ->
//  Create credentials -> OAuth client ID -> Desktop application),
//  просто впиши новий Client ID у FH_OAUTH_CLIENT_A і перезбери.
//  redirect_uri реєструвати НЕ треба: програма слухає http://127.0.0.1:8977+.
//  FH_OAUTH_SECRET_A потрібен ТІЛЬКИ для Web-клієнта; для Desktop лиши порожнім.
// ------------------------------------------------------------
//  3.3.0: клієнт ОНОВЛЕНО на ЖИВИЙ web-клієнт сайту входу (старий
//  t8gqql3m видалено з Google Cloud — 401 deleted_client). Сам вхід
//  іде через fluxhelper.pages.dev/auth.html, а exe лише валідує aud
//  ID-токена (main.cpp: AuthFromTokenInfo).
#define FH_OAUTH_CLIENT_A "668834523935-k470ldmdv0r9am0720v6lgaatm6rtuf3.apps.googleusercontent.com"
#define FH_OAUTH_SECRET_A ""

#endif
