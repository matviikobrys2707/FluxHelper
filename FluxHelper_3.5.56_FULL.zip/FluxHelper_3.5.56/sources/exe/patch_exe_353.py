#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FluxHelper 3.5.53 EXE: same-length binary patch of version strings (from 3.5.52 exe).
ascii '3.5.52' x3 + utf16 x2 (FileVersion/ProductVersion). Логіка/інтерфейс ПК
НЕ ЗМІНЮЮТЬСЯ (власник: «на компьютере ничего не трогать»). Бекап 3.5.52 —
versions/beta/3.5.52 у публічному репо + build353/FluxHelper_3.5.52_BACKUP.exe."""
import hashlib, os

SRC = '/home/z/my-project/work/site/versions/beta/3.5.52/FluxHelper.exe'
OUT = '/home/z/my-project/work/build353/FluxHelper.exe'

t = bytearray(open(SRC, 'rb').read())
orig_len = len(t)

a = t.count(b'3.5.52'); u = t.count('3.5.52'.encode('utf-16-le'))
assert a == 3 and u == 2, f'unexpected counts: ascii={a} utf16={u}'
t = t.replace(b'3.5.52', b'3.5.53')
t = t.replace('3.5.52'.encode('utf-16-le'), '3.5.53'.encode('utf-16-le'))

assert len(t) == orig_len, 'length changed!'
assert t.count(b'3.5.53') == 3 and t.count('3.5.53'.encode('utf-16-le')) == 2
assert t.count(b'3.5.52') == 0

os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, 'wb').write(bytes(t))
print('EXE:', OUT)
print('size:', len(t))
print('md5 :', hashlib.md5(bytes(t)).hexdigest())
print('sha256:', hashlib.sha256(bytes(t)).hexdigest())
