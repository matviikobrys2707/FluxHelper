#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EXE 3.5.54: same-length патч номера версії 3.5.53 → 3.5.54.
Функціонал НЕ міняється (власник: «на компьютере ничего не трогать»).
Замінюються всі UTF-16LE та ASCII входження '3.5.53' → '3.5.54'
(VERSIONINFO-рядки + текст версії у вбудованому UI). Розмір 1:1.
"""
import hashlib, sys

SRC = '/home/z/my-project/work/site/versions/beta/3.5.53/FluxHelper.exe'
DST = '/home/z/my-project/work/build354/FluxHelper_354.exe'

old_a, new_a = b'3.5.53', b'3.5.54'
old_u, new_u = '3.5.53'.encode('utf-16-le'), '3.5.54'.encode('utf-16-le')
assert len(old_a) == len(new_a) and len(old_u) == len(new_u)

data = bytearray(open(SRC, 'rb').read())
orig = bytes(data)
n_a = n_u = 0

def replace_all(buf, old, new):
    out, cnt, i = [], 0, 0
    while True:
        j = buf.find(old, i)
        if j == -1:
            out.append(buf[i:])
            break
        out.append(buf[i:j]); out.append(new)
        i = j + len(old); cnt += 1
    return b''.join(out), cnt

data, n_a = replace_all(data, old_a, new_a)
data, n_u = replace_all(data, old_u, new_u)

assert len(data) == len(orig), 'Розмір змінився!'
assert data.find(new_u) >= 0 and data.find(new_a) >= 0
assert data.find(old_a) == -1 and data.find(old_u) == -1, 'лишились старі входження!'

# перевірка: змінилися ТІЛЬКИ останні цифри входжень (по 1 байту на входження:
# '3.5.53' → '3.5.54' відрізняється лише останнім символом)
diff_ranges = [i for i in range(len(orig)) if orig[i] != data[i]]
assert len(diff_ranges) == n_a + n_u, \
    f'змінено несподіваних байт: {len(diff_ranges)} != {n_a + n_u}'

open(DST, 'wb').write(data)
print(f'ASCII x{n_a}, UTF-16 x{n_u}, змінено байт: {len(diff_ranges)} (по 1 на входження)')
print('size:', len(data), '(== оригінал)')
print('md5:', hashlib.md5(data).hexdigest())
print('orig md5:', hashlib.md5(orig).hexdigest())
