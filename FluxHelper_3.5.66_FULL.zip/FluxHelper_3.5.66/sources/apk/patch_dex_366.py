#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3.5.66 — ДОСЛОВНЫЙ перенос логики Google-входа из 3.5.1 в текущий dex
(по прямому запросу пользователя: «скопируй полностью логику авторизации 3.5.1,
просто перенеси, ничего не изменяй, только чтобы оно работало»).

Что переносится из dex 3.5.1 (байт-в-байт, только перенумерация анонимных
классов $7..$16 → $8..$17 под нумерацию текущего dex):
  методы MainActivity: startGoogleLogin, credentialLogin (двухфазный:
  prewarm-хендл → getCredentialAsync(handle) — именно так шторка открывалась
  быстро и надёжно в 3.5.1), showAccountPicker (системный выбор аккаунта —
  вернулся, как в 3.5.1), buildCredRequest (filterByAuthorizedAccounts=0x0 —
  ВСЕ аккаунты, как в 3.5.1), prewarmCred, credentialFail, nativeTokenFlow,
  fetchUserInfoAndFinish, cancelLoginTimers, nativeAuthFail, onActivityResult,
  verifyIdToken;
  классы: $10→$11 (вотчдог), $11→$12 (AM-колбэк), $12→$13 (fetchUserInfo),
  $13→$14 (prewarm), $14→$15 (Executor), $15→$16 + $15$1→$16$1 (CM-колбэк),
  $16→$17 (credentialFail-runnable), $7→$8 + $7$1→$8$1 (verifyIdToken).

Что СОХРАНЯЕТСЯ текущее (транспорт/эндпоинты, не логика выбора аккаунта;
перенос сломал бы вход иначе):
  fbExchange (Origin-заголовок https://fluxhelper.pages.dev — без него обмен
  токена отбивается сервером; endpoint t8gq удалён из Google Cloud),
  openBrowserLogin (браузерный фолбэк auth.html — oauth-ссылка 3.5.1 ведёт на
  удалённый клиент t8gq = Error 400: deleted_client), handleAuthUri (guard
  done=1 для web-флоу), credentialLoginLast, Host-мост, ui.js, весь остальной
  код приложения.

Гвард cmInFlight (3.5.65) удаляется вместе с полями-ссылками."""
import os, re, shutil

SRC = '/home/z/my-project/work/build61/dex65_src_patched'
DST = '/home/z/my-project/work/build61/dex66_src'
OLD = '/home/z/my-project/work/build351/dex351_src/com/fluxhelper/app'
APP = 'com/fluxhelper/app'

# 3.5.1 → текущая нумерация анонимных классов
CLASS_MAP = {7: 8, 8: 9, 9: 10, 10: 11, 11: 12, 12: 13, 13: 14, 14: 15, 15: 16, 16: 17}

def remap(t):
    return re.sub(r'MainActivity\$(\d+)((?:\$\d+)?)',
                  lambda m: 'MainActivity$%d%s' % (CLASS_MAP[int(m.group(1))], m.group(2) or ''),
                  t)

def extract_methods(path):
    out, cur, buf = {}, None, []
    for line in open(path, encoding='utf-8'):
        if line.startswith('.method'):
            m = re.match(r'\.method\s+[^\n]*?(\S+)\(', line)
            cur = m.group(1) if m else None
            buf = [line]
        elif cur is not None:
            buf.append(line)
            if line.startswith('.end method'):
                out.setdefault(cur, []).append(''.join(buf))
                cur, buf = None, []
    return out

def replace_method(t, name, new_body, tag):
    """Замена метода по имени (first occurrence) в тексте класса."""
    i = t.find('.method')
    # ищем сигнатуру с этим именем
    pos = -1
    start = 0
    while True:
        i = t.find('.method', start)
        if i < 0:
            break
        j = t.find('.end method', i)
        sig = t[i:j]
        mname = re.match(r'\.method\s+[^\n]*?(\S+)\(', sig)
        if mname and mname.group(1) == name:
            pos = i
            end = j + len('.end method')
            break
        start = j
    assert pos >= 0, f'{tag}: метод {name} не знайдено в поточному класі'
    print(f'OK   {tag}: {name} ({end - pos} → {len(new_body)} символів)')
    return t[:pos] + new_body + t[end:]

if os.path.exists(DST):
    shutil.rmtree(DST)
shutil.copytree(SRC, DST)

old_m = extract_methods(f'{OLD}/MainActivity.smali')
cur_p = f'{DST}/{APP}/MainActivity.smali'
t = open(cur_p, encoding='utf-8').read()

# --- 1. Трансплантат методов (3.5.1 verbatim + перенумерация) ---
for name in ['startGoogleLogin', 'credentialLogin', 'showAccountPicker',
             'buildCredRequest', 'prewarmCred', 'credentialFail',
             'nativeTokenFlow', 'fetchUserInfoAndFinish', 'cancelLoginTimers',
             'nativeAuthFail', 'onActivityResult', 'verifyIdToken']:
    bodies = old_m.get(name)
    assert bodies and len(bodies) == 1, f'{name}: у 3.5.1 знайдено {len(bodies or [])} шт'
    t = replace_method(t, name, remap(bodies[0]), f'метод 3.5.1')

# --- 2. Удаление поля cmInFlight ---
n = t.count('.field public cmInFlight:Z')
assert n == 1, f'cmInFlight field: {n}'
t = t.replace('\n.field public cmInFlight:Z\n', '\n')
refs = t.count('cmInFlight')
assert refs == 0, f'cmInFlight: залишилось {refs} посилань у MainActivity'
print('OK   поле cmInFlight видалено (посилань у MainActivity: 0)')
open(cur_p, 'w', encoding='utf-8', newline='\n').write(t)

# --- 3. Трансплантат классов (3.5.1 verbatim + перенумерация) ---
CLASS_PAIRS = [('10', '11'), ('11', '12'), ('12', '13'), ('13', '14'),
               ('14', '15'), ('15', '16'), ('15$1', '16$1'),
               ('16', '17'), ('7', '8'), ('7$1', '8$1')]
for o, c in CLASS_PAIRS:
    src = f'{OLD}/MainActivity${o}.smali'
    dst = f'{DST}/{APP}/MainActivity${c}.smali'
    body = remap(open(src, encoding='utf-8').read())
    assert f'MainActivity${c};' in body, f'$ {o}->{c}: .class не переписано'
    assert 'MainActivity$' + o + ';' not in body.replace(f'MainActivity${c};', ''), f'$ {o}->{c}: старі зсилки'
    open(dst, 'w', encoding='utf-8', newline='\n').write(body)
    print(f'OK   клас MainActivity${o} → MainActivity${c} ({len(body.splitlines())} рядків)')

# --- 4. Контроль: cmInFlight не залишилось ніде ---
left = 0
for root, _, files in os.walk(DST):
    for f in files:
        if f.endswith('.smali') and 'cmInFlight' in open(os.path.join(root, f), encoding='utf-8').read():
            left += 1
print('cmInFlight у дереві:', left, 'файлів (очікується 0)')
assert left == 0

print('\n3.5.66 TRANSPLANT APPLIED')
