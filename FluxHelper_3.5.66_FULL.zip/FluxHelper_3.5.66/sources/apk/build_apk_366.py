#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.64 (versionCode 30564): порядок логина как в 3.5.1.

ФИКС РЕАЛЬНОЙ ПРИЧИНЫ «ВЕЧНОГО ВХОДА»:
- fbExchange шлёт Origin: https://fluxhelper.pages.dev → ключ Firebase
  (referer-restricted) принимает запрос → обмен идёт ПРЯМО (<1с),
  Render relay больше не нужен в happy path (был холодный 14-60с).
- watchdog 8с→4с + текст «Відкриваю вибір акаунта Google…».
- openBrowserLogin: &oneclick=1 → auth.html сразу redirect на Google.
- ui.js: rescue 20с→6с.

База: FluxHelper_361.apk (3.5.61 = shipped 3.5.58 dex + AXML). Dex заменён
на classes62.dex (собран smali 2.5.2 из dex62_src = dex 3.5.58 + 5 патчей;
baksmali roundtrip-диф = только перенумерация меток)."""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/work/build61/FluxHelper_365.apk'
DEX    = '/home/z/my-project/work/build61/classes66.dex'
UIJS   = '/home/z/my-project/work/build61/ui364.js'
OUTDIR = '/home/z/my-project/work/build61'
BT     = '/home/z/my-project/work/android/android-14'
KEYS   = 'fluxhelper.keystore.OFFICIAL-6871F0 (файл ключа не публікується)'
BASE_MD5 = 'a26d945810d4db7398b819d0a97d2e0a'

UNSIGNED = f'{OUTDIR}/FluxHelper_362_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_362_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper_366.apk'

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

assert md5(BASE) == BASE_MD5, 'база 3.5.61 не совпадает!'
assert os.path.getsize(DEX) > 5_000_000, 'dex подозрительно мал'
dexbytes = open(DEX, 'rb').read()
assert b'https://fluxhelper.pages.dev' in dexbytes
assert b'&oneclick=1' in dexbytes
assert b'authRetryDone' in dexbytes or b'lastAcc' in dexbytes
uijs = open(UIJS, 'rb').read()
assert b'}, 6000);' in uijs and b'AndroidHost.login' in uijs

with zipfile.ZipFile(BASE) as z:
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue
    if n == 'AndroidManifest.xml':
        ax = bytearray(zipfile.ZipFile(BASE).read(n))
        vc_old = (30565).to_bytes(4, 'little'); vc_new = (30566).to_bytes(4, 'little')
        assert ax.count(vc_old) == 1, f'versionCode: {ax.count(vc_old)}'
        i = ax.find(vc_old); assert i > 0
        ax[i:i+4] = vc_new
        vn_old = '3.5.65'.encode('utf-16-le'); vn_new = '3.5.66'.encode('utf-16-le')
        assert ax.count(vn_old) == 1, f'versionName: {ax.count(vn_old)}'
        j = ax.find(vn_old); assert j > 0
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: 30566 / 3.5.66')
    elif n == 'classes.dex':
        zf.writestr(n, dexbytes, compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: classes66.dex,', len(dexbytes), 'bytes')
    elif n == 'assets/www/ui.js':
        zf.writestr(n, uijs, compress_type=zipfile.ZIP_DEFLATED)
        print('ASSET ui.js: rescue 12с,', len(uijs), 'bytes')
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:400])
assert '6871f0d5' in r.stdout.lower()

with zipfile.ZipFile(SIGNED) as z:
    d = z.read('classes.dex')
    ax = z.read('AndroidManifest.xml')
    uj = z.read('assets/www/ui.js')
assert hashlib.md5(d).hexdigest() == hashlib.md5(dexbytes).hexdigest()
assert (30566).to_bytes(4, 'little') in ax and '3.5.66'.encode('utf-16-le') in ax
assert b'}, 12000);' in uj
print('in-apk: dex ✓ AXML 30566/3.5.66 ✓ ui.js 12с ✓')

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
