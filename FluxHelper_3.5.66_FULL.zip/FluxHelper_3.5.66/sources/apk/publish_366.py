#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Публікація 3.5.66 (beta, versionCode 30566): логіка Google-входу = ДОСЛОВНО
ЯК У 3.5.1 (перенесена з оригінального dex 3.5.1 за запитом користувача).
Прибрано причину «меню не з'являється» з 3.5.65 (холодний одиночний запит
без prepare + гвард cmInFlight). Транспортні фіксu збережено."""
import os, shutil, hashlib, subprocess, json

REPO = '/home/z/my-project/work/repo_pub'
APK = '/home/z/my-project/work/build61/FluxHelper_366.apk'
EXE = '/home/z/my-project/work/build61/FluxHelper_366.exe'

APK_MD5 = '6159d62ba41fc1aab7ec421484e88beb'
EXE_MD5 = 'd356f5164ee1ec52dd4957f19cb5ff6d'
EXE_SHA = '74e621d78241cd8036782ce90596260cc0e8973575aab7aa96c6555f5a6df55b'

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

assert md5(APK) == APK_MD5, 'APK md5!'
assert md5(EXE) == EXE_MD5, 'EXE md5!'

VD = os.path.join(REPO, 'versions/beta/3.5.66')
os.makedirs(VD, exist_ok=True)
shutil.copy2(APK, os.path.join(VD, 'FluxHelper.apk'))
shutil.copy2(EXE, os.path.join(VD, 'FluxHelper.exe'))

CHANGELOG = '''FluxHelper 3.5.66 (beta, versionCode 30566) — 18.11.2026

🎯 ГОЛОВНЕ: ЛОГІКА ВХОДУ ЧЕРЕЗ GOOGLE = ТОЧНО ЯК У 3.5.1

   За запитом користувача вся логіка авторизації ПЕРЕНЕСЕНА ДОСЛОВНО з
   оригінального dex 3.5.1 (порівняння з баксмалі оригінального APK 3.5.1,
   трансплантат 12 методів + 10 класів, лише перенумерація анонімних класів).

   Потік як у 3.5.1:
   1) prewarmCred готує запит заздалегідь (filterByAuthorizedAccounts=false —
      УСІ акаунти, як у 3.5.1) → на тапі шторка/вибір відкриваються ШВИДКО;
   2) Credential Manager (двофазний: підготовлений хендл → getCredentialAsync);
   3) якщо CM недоступний — СИСТЕМНИЙ ВИБІР АКАУНТА (як у 3.5.1) →
      AccountManager токен → userinfo → verify → вхід;
   4) браузерний резерв як резерв.

🔧 ПОЯСНЕННЯ ПРОБЛЕМИ 3.5.65 («меню не з'являється»):
   у 3.5.65 запит ішов ХОЛОДИМ одиночним викликом без підготовки (зразок
   «офіційних прикладів») — на частині пристроїв такий виклик не відкриває
   меню взагалі. У 3.5.66 повернуто перевірений шлях 3.5.1 з prewarm-хендлом.

🧹 ПРИБРАНО З 3.5.65: холодний одиночний getCredentialAsync, гвард
   cmInFlight (0 посилань у dex).

🛡 ЗБЕРЕЖЕНО ТРАНСПОРТ (це не логіка вибору акаунта, без цього вхід ламається):
   • Origin-заголовок при обміні токена (сервер відхиляє без нього);
   • браузерний резерв auth.html — старий oauth-endpoint 3.5.1 видалено з
     Google (Error 400: deleted_client), тому посилання 3.5.1 мертве сьогодні;
   • web-флоу завершення входу (done=1 guard у handleAuthUri).

✅ dex 3.5.66 = dex 3.5.65 + дослівний трансплантат 3.5.1; baksmali
   roundtrip без логічних змін; решта застосунку не чіпалась; ui.js без змін;
   офіційний підпис APK/EXE 6871f0d5 ✓.
✅ ПК (EXE): тільки номер версії 3.5.65 → 3.5.66 (1:1, 1 953 280).

md5 apk: ''' + APK_MD5 + ''' | md5 exe: ''' + EXE_MD5
with open(os.path.join(VD, 'changelog.txt'), 'w', encoding='utf-8', newline='\n') as f:
    f.write(CHANGELOG)

shutil.copy2(APK, os.path.join(REPO, 'FluxHelper.apk'))
shutil.copy2(EXE, os.path.join(REPO, 'FluxHelper.exe'))

notes_beta = [
    "🎯 3.5.66: логіка входу через Google = ТОЧНО ЯК У 3.5.1 (дословний перенос з оригінального dex 3.5.1): prewarm → швидкий вибір з УСІМА акаунтами → системний вибір акаунта → AccountManager токен → вхід",
    "🔧 Прибрано причину «меню не з'являється» з 3.5.65: холодний одиночний запит без підготовки + гвард cmInFlight",
    "🛡 Збережено транспорт: Origin-заголовок обміну токена, браузерний резерв auth.html (старий oauth-endpoint 3.5.1 видалено Google = Error 400)",
    "✅ dex = трансплантат 12 методів + 10 класів з 3.5.1; решта застосунку без змін; підпис 6871f0d5 ✓; APK ~2.48 МБ",
]
beta = {
    "latest": "3.5.66",
    "notes": notes_beta,
    "apk_md5": APK_MD5,
    "apk_size": os.path.getsize(APK),
    "exe_md5": EXE_MD5,
    "exe_sha256": EXE_SHA,
    "exe_size": os.path.getsize(EXE),
    "updated_at": "2026-11-18",
}
with open(os.path.join(REPO, 'versions/beta/latest.json'), 'w', encoding='utf-8', newline='\n') as f:
    json.dump(beta, f, ensure_ascii=False, indent=2)
    f.write('\n')

root = dict(beta)
root["notes"] = [
    "✦ Цей файл — дзеркало бета-каналу; кореневі FluxHelper.apk / FluxHelper.exe — ЗАВЖДИ остання бета",
    "✦ 3.5.66: логіка входу = ТОЧНО ЯК У 3.5.1 (дословний перенос): prewarm → вибір з усіма акаунтами → системний вибір → вхід; прибрано холодний запит і гвард 3.5.65",
    "✦ Транспорт збережено (Origin, auth.html); підпис 6871f0d5 ✓",
]
root["channel"] = "beta"
root["apk_url"] = "/versions/beta/3.5.66/FluxHelper.apk"
root["exe_url"] = "/versions/beta/3.5.66/FluxHelper.exe"
with open(os.path.join(REPO, 'latest.json'), 'w', encoding='utf-8', newline='\n') as f:
    json.dump(root, f, ensure_ascii=False, indent=2)
    f.write('\n')

p = os.path.join(REPO, 'README.md')
t = open(p, encoding='utf-8').read()
OLD_BETA = ("**Поточна бета: 3.5.65** (versionCode 30565, 18.11.2026) — СІРИЙ системний діалог вибору акаунта ПОВНІСТЮ "
            "ВИДАЛЕНО: тільки сучасна шторка Credential Manager (аватарки + ім'я + email) за офіційними прикладами "
            "Google; один async-запит без лагів; гвард подвійних натискань; скасування → тихо, без акаунтів/старий CM → "
            "браузерний вхід одразу · бібліотеки на місці (APK ~2.48 МБ) · офіційний підпис APK/EXE: `6871f0d5`")
NEW_BETA = ("**Поточна бета: 3.5.66** (versionCode 30566, 18.11.2026) — логіка входу через Google ПОВЕРНЕНА ДОТОЧНО "
            "ЯК У 3.5.1 (дословний перенос з оригінального dex 3.5.1 за запитом користувача): prewarm → швидкий вибір "
            "з УСІМА акаунтами (filter=false) → системний вибір акаунта як у 3.5.1 → AccountManager токен → вхід; "
            "прибрано холодний одиночний запит 3.5.65 і гвард cmInFlight (самі й були причиною «меню не з'являється») · "
            "збережено транспортні фіксu (Origin в обміні токена, браузерний резерв auth.html — бо старий "
            "oauth-endpoint видалено Google) · бібліотеки на місці (APK ~2.48 МБ) · офіційний підпис APK/EXE: `6871f0d5`")
assert t.count(OLD_BETA) == 1, f'README beta row: {t.count(OLD_BETA)}'
t = t.replace(OLD_BETA, NEW_BETA)
hash_pairs = [
    ('a26d945810d4db7398b819d0a97d2e0a', APK_MD5),
    ('3bba0e676874d4fb330571d7e58e556abc766e9edb6c0d860b6965025e78a893', '86b7507790054c4e078131423b0e649dee6cc83f9c542f3de83f32fbc1def363'),
    ('95589fc30186bcd3d5d0707bfee02000', EXE_MD5),
    ('158814dca9152c57983cf187096ac877c1abfaf14e548c253f615b5ac95c9c9a', EXE_SHA),
]
for old, new in hash_pairs:
    n = t.count(old)
    if n:
        t = t.replace(old, new)
        print('README hash заменён:', old[:12], 'x', n)
    else:
        print('README hash отсутствует (ок):', old[:12])
# версия уже заменена в beta-строке; исторические упоминания 3.5.65 не трогаем
open(p, 'w', encoding='utf-8', newline='\n').write(t)

def g(*a):
    r = subprocess.run(['git', '-C', REPO] + list(a), capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-800:], r.stderr[-800:])
        raise SystemExit(f'git {a[0]} failed')
    return r.stdout.strip()

old_zip = os.path.join(REPO, 'FluxHelper_3.5.65_FULL.zip')
if os.path.exists(old_zip):
    g('rm', '-q', 'FluxHelper_3.5.65_FULL.zip')
g('add', '-A')
g('commit', '-q', '-m',
  'beta 3.5.66 (30566): логіка входу через Google ПОВЕРНЕНА ДОТІЛЬНО ЯК У 3.5.1 — дослівний трансплантат з '
  'оригінального dex 3.5.1 (12 методів + 10 класів): prewarm → швидкий вибір з УСІМА акаунтами (filter=false) → '
  'системний вибір акаунта → AccountManager токен → вхід; прибрано холодний одиночний запит 3.5.65 і гвард '
  'cmInFlight (причина «меню не зявляється»); збережено транспорт (Origin в обміні, браузерний резерв auth.html — '
  'oauth-endpoint t8gq видалено Google); root+versions/beta/3.5.66+latest.json ×2 → 3.5.66')
print(g('log', '--oneline', '-1'))

tok = open('/home/z/my-project/work/src/keys/gh.token', encoding='utf-8').read().strip()
assert tok.startswith('github_pat_')
subprocess.run(['git', '-C', REPO, 'remote', 'set-url', 'origin',
                f'https://x-access-token:{tok}@github.com/matviikobrys2707/FluxHelper'], capture_output=True)
r = subprocess.run(['git', '-C', REPO, 'push', '-q', 'origin', 'main'], capture_output=True, text=True)
subprocess.run(['git', '-C', REPO, 'remote', 'set-url', 'origin',
                'https://github.com/matviikobrys2707/FluxHelper'], capture_output=True)
print('push rc=', r.returncode, (r.stderr[-300:] if r.returncode else ''))
