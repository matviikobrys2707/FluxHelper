.class final synthetic Landroidx/credentials/PrepareGetCredentialResponse$Builder$setFrameworkResponse$2;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "PrepareGetCredentialResponse.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/credentials/PrepareGetCredentialResponse$Builder;->setFrameworkResponse(Landroid/credentials/PrepareGetCredentialResponse;)Landroidx/credentials/PrepareGetCredentialResponse$Builder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/FunctionReferenceImpl;",
        "Lkotlin/jvm/functions/Function0<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 9

    const/4 v1, 0x0

    const-class v3, Landroidx/credentials/PrepareGetCredentialResponse$Builder;

    const-string v4, "hasAuthenticationResults"

    const-string v5, "hasAuthenticationResults()Z"

    const/4 v6, 0x0

    move-object v0, p0

    move-object v2, p1

    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Boolean;
    .registers 2

    .line 147
    iget-object v0, p0, Landroidx/credentials/PrepareGetCredentialResponse$Builder$setFrameworkResponse$2;->receiver:Ljava/lang/Object;

    check-cast v0, Landroidx/credentials/PrepareGetCredentialResponse$Builder;

    # invokes: Landroidx/credentials/PrepareGetCredentialResponse$Builder;->hasAuthenticationResults()Z
    invoke-static {v0}, Landroidx/credentials/PrepareGetCredentialResponse$Builder;->access$hasAuthenticationResults(Landroidx/credentials/PrepareGetCredentialResponse$Builder;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 147
    invoke-virtual {p0}, Landroidx/credentials/PrepareGetCredentialResponse$Builder$setFrameworkResponse$2;->invoke()Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method
