#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3.5.59: ПОВНЕ ПЕРЕПИСУВАННЯ Google-входу в APK (з нуля).

Старе (ВИДАЛЯЄТЬСЯ повністю):
  • androidx Credential Manager: buildCredRequest, credentialLogin,
    credentialLoginLast, credentialFail, prewarmCred→стуб, synchronizedPendingAlive,
    pendingCred/credLock/tokExec/pickerOpen, $14/$15/$16/$16$1/$17
  • нативний обмін токена: verifyIdToken, fbExchange, fbExchangeRelay,
    fetchUserInfoAndFinish, nativeTokenFlow, tokHandler, unboxKotlinResult,
    onActivityResult, $8/$8$1/$9/$10(старий)/$12/$13
  • watchdog нативи: loginWatchdog/loginResumeReset, $11, $3, onResume-блок
  • openBrowserLogin (старий rescue) → переписаний з нуля

Нове (ЄДИНИЙ шлях входу — системний браузер):
  startGoogleLogin/loginLastDirect → openWebLoginCore(st,hint) →
    браузер: auth.html#s=<st>&oneclick=1&mobile=1[&login_hint=<hint>]
  → Google OAuth у браузері → auth.html пише профіль у D1 (auth_cb) →
  повернення: deep link fluxhelper://auth?s=<st>&d=<json>  (головний канал,
    state звіряється з prefs st/st_prev — захист від підробних intent)
  або poll auth_cb (cfExec → D1) як резерв.
  handleAuthUri + новий MainActivity$10: d=<json> → jsCall authOkStr(jsStr(d)).
"""
import os, re, sys

AP = '/home/z/my-project/work/src/dex59/com/fluxhelper/app/'
MAIN = AP + 'MainActivity.smali'

# ---------------------------------------------------------------- helpers
def strip_method(t, name_and_sig):
    """Видалити цілий .method блок за сигнатурою."""
    pat = re.compile(r'\n\.method [^\n]*' + re.escape(name_and_sig) + r'[^\n]*\n.*?\.end method\n', re.S)
    t2, n = pat.subn('\n', t)
    assert n == 1, f'{name_and_sig}: found {n}'
    return t2

def strip_field(t, decl):
    pat = re.compile(r'\n\.field ' + re.escape(decl) + r'[^\n]*\n')
    t2, n = pat.subn('\n', t)
    assert n == 1, f'field {decl}: found {n}'
    return t2

# ---------------------------------------------------------------- 1. MainActivity
t = open(MAIN, encoding='utf-8').read()

# 1a. Видалити методи старого входу (повністю)
for m in [
    'buildCredRequest(', 'credentialLogin()', 'credentialLoginLast()',
    'credentialFail(', 'showAccountPicker()', 'nativeTokenFlow(',
    'verifyIdToken(', 'fbExchange(', 'fbExchangeRelay(',
    'fetchUserInfoAndFinish(', 'synchronizedPendingAlive()', 'tokHandler()',
    'unboxKotlinResult(', 'onActivityResult(', 'openBrowserLogin(',
    'startGoogleLogin(', 'loginLastDirect(', 'handleAuthUri(',
    'cancelLoginTimers()',
]:
    t = strip_method(t, m)

# 1b. prewarmCred → порожній стуб (onCreate/Host.prewarm його викликають)
pat_prew = re.compile(r'\n\.method private prewarmCred\(\)V\n.*?\.end method\n', re.S)
t, n = pat_prew.subn(
    '\n.method private prewarmCred()V\n    .registers 1\n\n'
    '# 3.5.59: CM prewarm видалено разом із Credential Manager;\n'
    '# стуб лишено для onCreate/Host.prewarm.\n\n    return-void\n.end method\n', t)
assert n == 1, 'prewarmCred stub'

# 1c. Видалити поля старого входу
for f in [
    'private static tokExec:Landroid/os/HandlerThread;',
    'private volatile pendingCred:Landroidx/credentials/PrepareGetCredentialResponse$PendingGetCredentialHandle;',
    'private final credLock:Ljava/lang/Object;',
    'private loginResumeReset:Ljava/lang/Runnable;',
    'private loginWatchdog:Ljava/lang/Runnable;',
    'public pickerOpen:Z',
    'private static final FB_API_KEY:Ljava/lang/String;',
    'private static final OAUTH_CLIENT:Ljava/lang/String;',
    'private static final OAUTH_SCHEME:Ljava/lang/String;',
    'private static final OAUTH_SCOPE:Ljava/lang/String;',
    'private static final REDIRECT_URI:Ljava/lang/String;',
    'private static final REQ_PICK_ACCOUNT:I',
    'private static final WEB_CLIENT_ID:Ljava/lang/String;',
]:
    t = strip_field(t, f)

# 1d. onResume: прибрати блок resume-reset ($3 scheduling).
# ВАЖЛИВО: ':catchall_b' перший раз зустрічається В СЕРЕДИНІ директиви
# .catchall — шукаємо РЯДКИ-означення міток ('\n    :label\n').
oc = re.search(r'(\.method protected onResume\(\)V\n.*?\.end method\n)', t, re.S)
assert oc, 'onResume'
body = oc.group(1)
k1 = body.find('\n    :catchall_b\n')          # рядок-означення мітки catch
assert k1 > 0, 'catchall_b label def not found'
start = k1 + len('\n    :catchall_b\n')
k2 = body.find('\n    :cond_26\n', start)      # рядок-означення :cond_26
assert k2 > start, 'cond_26 label def not found'
new_body = body[:start] + body[k2:]
t = t.replace(body, new_body)
open(MAIN, 'w', encoding='utf-8').write(t)
print('onResume: блок $3 прибрано')

# ---------------------------------------------------------------- 1e. нові методи
NEW_METHODS = r'''
.method private startGoogleLogin(Ljava/lang/String;)V
    .registers 5

    # 3.5.59: вхід — ЛИШЕ системний браузер. state від JS зберігається
    # (st = новий, st_prev = попередній для толерантності до двох вкладок),
    # далі openWebLoginCore відкриває auth.html у браузері. Ніякого
    # Credential Manager, ніяких нативних обмінів токена.

    if-nez p1, :cond_s

    const-string p1, ""

    :cond_s
    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "st"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "st_prev"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v2, "st"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-direct {p0, p1, v0}, Lcom/fluxhelper/app/MainActivity;->openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method

.method private loginLastDirect(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    # 3.5.59: плитка «нещодавно» = той самий браузерний вхід з login_hint
    # (нативний тихий вхід AccountManager видалено разом із CM).

    if-nez p1, :cond_s

    const-string p1, ""

    :cond_s
    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "st"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "st_prev"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v2, "st"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-direct {p0, p1, p2}, Lcom/fluxhelper/app/MainActivity;->openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method

.method private openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    # 3.5.59: відкрити auth.html у системному браузері (Custom Tab, якщо
    # встановлено, інакше дефолтний браузер — через openExternal).

    if-nez p1, :cond_a

    const-string p1, ""

    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "https://fluxhelper.pages.dev/auth.html#s="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "&oneclick=1&mobile=1"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_b

    const-string v1, "@"

    invoke-virtual {p2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_b

    const-string v1, "&login_hint="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->openExternal(Ljava/lang/String;)V

    return-void
.end method

.method private handleAuthUri(Landroid/net/Uri;)V
    .registers 9

    # 3.5.59: deep link від auth.html у браузері.
    # fluxhelper://auth?done=1          — пінг «відкрийся» (JS продовжить poll)
    # fluxhelper://auth?s=<st>&d=<json> — профіль Google: state звіряється
    #   з st/st_prev (захист від підробних intent), JSON → MainActivity$10
    #   → jsCall authOkStr(jsStr(d)). Схема com.googleusercontent.apps.*
    #   більше не обробляється — нативного обміну токена більше немає.

    if-eqz p1, :goto_ret

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :goto_ret

    const-string v1, "fluxhelper"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :goto_ret

    const-string v0, "done"

    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :chk_d

    const-string v0, "window.__fh&&window.__fh.authOk&&window.__fh.authOk({done:true})"

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    :chk_d
    const-string v0, "d"

    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :goto_ret

    const-string v1, "s"

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :goto_bad

    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "st"

    const-string v4, ""

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "st_prev"

    const-string v5, ""

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :try_prev

    goto :goto_ok

    :try_prev
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :goto_bad

    :goto_ok
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    new-instance v2, Lcom/fluxhelper/app/MainActivity$10;

    invoke-direct {v2, p0, v0}, Lcom/fluxhelper/app/MainActivity$10;-><init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception v2

    goto :goto_ok

    :goto_bad
    const-string v0, "window.__fh&&window.__fh.authErr&&window.__fh.authErr(\'Сесія входу застаріла — натисни «Увійти через Google» ще раз\')"

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    :goto_ret
    return-void
.end method

.method private cancelLoginTimers()V
    .registers 1

    # 3.5.59: нативних watchdog'ів більше немає (стежить JS у WebView);
    # метод лишено як no-op для існуючих викликів.

    return-void
.end method
'''

# додати нові методи В КІНЕЦЬ файлу (члени класу можуть іти в будь-якому порядку)
t = t.rstrip() + '\n' + NEW_METHODS + '\n'
open(MAIN, 'w', encoding='utf-8').write(t)
print('MainActivity.smali переписаний:', len(t), 'chars')

# ---------------------------------------------------------------- 2. внутрішні класи
for c in ['$3', '$8', '$8$1', '$9', '$10', '$11', '$12', '$13', '$14', '$15', '$16', '$16$1', '$17']:
    p = f'{AP}MainActivity{c}.smali'
    if os.path.exists(p):
        os.remove(p)
        print('видалено', os.path.basename(p))

NEW_10 = r'''.class Lcom/fluxhelper/app/MainActivity$10;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->handleAuthUri(Landroid/net/Uri;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;

.field private final synthetic val$payload:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$10;->val$payload:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    # 3.5.59: профіль із deep link (auth.html, mobile=1) -> authOkStr у JS.
    # Санітарна перевірка payload: JSON-об'єкт 10..8000 символів.

    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$10;->val$payload:Ljava/lang/String;

    if-eqz v0, :goto_bad

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0xa

    if-lt v1, v2, :goto_bad

    const/16 v2, 0x1f40

    if-gt v1, v2, :goto_bad

    const-string v2, "{"

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :goto_bad

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "window.__fh&&window.__fh.authOkStr&&window.__fh.authOkStr("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$3(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v1, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    :goto_bad
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v1, "window.__fh&&window.__fh.authErr&&window.__fh.authErr(\'Некоректні дані входу — натисни «Увійти через Google» ще раз\')"

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void
.end method
'''
open(AP + 'MainActivity$10.smali', 'w', encoding='utf-8').write(NEW_10)
print('новий MainActivity$10.smali записаний')

# ---------------------------------------------------------------- 3. access$ cleanup
tree_files = []
for root, dirs, files in os.walk('/home/z/my-project/work/src/dex59'):
    for f in files:
        if f.endswith('.smali'):
            tree_files.append(os.path.join(root, f))
code_all = '\n'.join(open(p, encoding='utf-8').read() for p in tree_files)

main_t = open(MAIN, encoding='utf-8').read()
removed = 0
for m in sorted(set(re.findall(r'\.method static synthetic (access\$\d+)\(', main_t)),
                key=lambda s: int(s.split('$')[1])):
    # межа слова: рахуємо 'access$N(' щоб access$1 не зловив access$10
    total = len(re.findall(re.escape(m) + r'\(', code_all))
    if total <= 1:  # лише оголошення
        pat = re.compile(r'\n\.method static synthetic ' + re.escape(m) + r'\(.*?\.end method\n', re.S)
        main_t, n = pat.subn('\n', main_t)
        if n:
            removed += 1
            print('видалено', m, '(немає посилань)')
open(MAIN, 'w', encoding='utf-8').write(main_t)
print('access$ видалено:', removed)
print('OK')
