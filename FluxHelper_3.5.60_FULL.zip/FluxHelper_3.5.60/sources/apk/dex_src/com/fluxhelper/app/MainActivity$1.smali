.class Lcom/fluxhelper/app/MainActivity$1;
.super Landroid/webkit/WebViewClient;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;)V
    .registers 2

    .line 132
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$1;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .registers 5

    .line 136
    :try_start_0
    iget-object p2, p0, Lcom/fluxhelper/app/MainActivity$1;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {p2}, Lcom/fluxhelper/app/MainActivity;->devInfoJson()Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_26

    .line 137
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    if-le v0, v1, :cond_26

    .line 138
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "window.__fhDevInfo="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ";"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_26} :catch_26

    .line 145
    :catch_26
    :cond_26
    :try_start_26
    iget-object p2, p0, Lcom/fluxhelper/app/MainActivity$1;->this$0:Lcom/fluxhelper/app/MainActivity;

    iget v0, p2, Lcom/fluxhelper/app/MainActivity;->lastInsTop:I

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$1;->this$0:Lcom/fluxhelper/app/MainActivity;

    iget v1, v1, Lcom/fluxhelper/app/MainActivity;->lastInsBot:I

    invoke-virtual {p2, p1, v0, v1}, Lcom/fluxhelper/app/MainActivity;->injectInsets(Landroid/webkit/WebView;II)V
    :try_end_31
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_31} :catch_31

    :catch_31
    return-void
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .registers 3

    const-string p1, "file://"

    .line 152
    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_a

    const/4 p1, 0x0

    return p1

    .line 155
    :cond_a
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity$1;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {p1, p2}, Lcom/fluxhelper/app/MainActivity;->openExternal(Ljava/lang/String;)V

    const/4 p1, 0x1

    return p1
.end method
