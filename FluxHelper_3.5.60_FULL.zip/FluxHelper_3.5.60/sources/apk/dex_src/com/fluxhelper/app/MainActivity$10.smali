.class Lcom/fluxhelper/app/MainActivity$10;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->handleAuthUri(Landroid/net/Uri;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;

.field private final synthetic val$payload:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$10;->val$payload:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    # 3.5.59: профіль із deep link (auth.html, mobile=1) -> authOkStr у JS.
    # Санітарна перевірка payload: JSON-об'єкт 10..8000 символів.

    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$10;->val$payload:Ljava/lang/String;

    if-eqz v0, :goto_bad

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0xa

    if-lt v1, v2, :goto_bad

    const/16 v2, 0x1f40

    if-gt v1, v2, :goto_bad

    const-string v2, "{"

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :goto_bad

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "window.__fh&&window.__fh.authOkStr&&window.__fh.authOkStr("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$3(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v1, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    :goto_bad
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$10;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v1, "window.__fh&&window.__fh.authErr&&window.__fh.authErr(\'Некоректні дані входу — натисни «Увійти через Google» ще раз\')"

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void
.end method
