.class public final Lcom/fluxhelper/app/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fluxhelper/app/R$drawable;,
        Lcom/fluxhelper/app/R$id;,
        Lcom/fluxhelper/app/R$layout;,
        Lcom/fluxhelper/app/R$mipmap;,
        Lcom/fluxhelper/app/R$raw;,
        Lcom/fluxhelper/app/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
