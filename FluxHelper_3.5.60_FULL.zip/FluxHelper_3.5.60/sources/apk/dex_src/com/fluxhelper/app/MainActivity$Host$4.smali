.class Lcom/fluxhelper/app/MainActivity$Host$4;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity$Host;->cfq(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/fluxhelper/app/MainActivity$Host;

.field private final synthetic val$str:Ljava/lang/String;

.field private final synthetic val$str2:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1073
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->val$str2:Ljava/lang/String;

    iput-object p3, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->val$str:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1075
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->val$str2:Ljava/lang/String;

    invoke-static {v0}, Lcom/fluxhelper/app/Cloud;->query(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "window.__fh&&window.__fh.cfqCb&&window.__fh.cfqCb(\""

    if-nez v0, :cond_27

    .line 1077
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->val$str:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\",0,null)"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    .line 1080
    :cond_27
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$4;->val$str:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\",200,"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void
.end method
