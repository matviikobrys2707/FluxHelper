.class Lcom/fluxhelper/app/MainActivity$Host$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity$Host;->requestNotifPerm()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/fluxhelper/app/MainActivity$Host;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity$Host;)V
    .registers 2

    .line 943
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    const-string v0, "np_asked"

    const-string v1, "android.permission.POST_NOTIFICATIONS"

    .line 946
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x21

    if-lt v2, v3, :cond_76

    .line 948
    :try_start_a
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/fluxhelper/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_17

    return-void

    .line 954
    :cond_17
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v2

    const-string v3, "fh"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Lcom/fluxhelper/app/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    .line 955
    invoke-interface {v2, v0, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 956
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x1

    invoke-interface {v2, v0, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-eqz v3, :cond_67

    .line 957
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->shouldShowRequestPermissionRationale(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_67

    .line 959
    new-instance v0, Landroid/content/Intent;

    const-string v2, "android.settings.APP_NOTIFICATION_SETTINGS"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "android.provider.extra.APP_PACKAGE"

    .line 960
    iget-object v3, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v3}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v3

    invoke-virtual {v3}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v2, 0x10000000

    .line 961
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 962
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_66
    .catchall {:try_start_a .. :try_end_66} :catchall_67

    return-void

    .line 967
    :catchall_67
    :cond_67
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$2;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v0

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0xb

    invoke-virtual {v0, v1, v2}, Lcom/fluxhelper/app/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    :cond_76
    return-void
.end method
