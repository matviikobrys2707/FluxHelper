.class public Lcom/fluxhelper/app/NotifReceiver;
.super Landroid/content/BroadcastReceiver;
.source "NotifReceiver.java"


# static fields
.field static final REQ_SNOOZE:I = 0x3ed

.field static final REQ_SNOOZE2:I = 0x3f0

.field static final REQ_TSNOOZE:I = 0x3ef

.field static final REQ_TSNOOZE2:I = 0x3f1


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 48
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static armDual(Landroid/content/Context;Landroid/app/AlarmManager;JLandroid/app/PendingIntent;Landroid/app/PendingIntent;)Z
    .registers 11

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 272
    :try_start_2
    new-instance v2, Landroid/content/Intent;

    const-class v3, Lcom/fluxhelper/app/MainActivity;

    invoke-direct {v2, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v3, 0x30000000

    .line 273
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v3, 0x7

    const/high16 v4, 0xc000000

    .line 274
    invoke-static {p0, v3, v2, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    .line 275
    new-instance v2, Landroid/app/AlarmManager$AlarmClockInfo;

    invoke-direct {v2, p2, p3, p0}, Landroid/app/AlarmManager$AlarmClockInfo;-><init>(JLandroid/app/PendingIntent;)V

    invoke-virtual {p1, v2, p4}, Landroid/app/AlarmManager;->setAlarmClock(Landroid/app/AlarmManager$AlarmClockInfo;Landroid/app/PendingIntent;)V
    :try_end_1d
    .catchall {:try_start_2 .. :try_end_1d} :catchall_1f

    move p0, v0

    goto :goto_23

    .line 278
    :catchall_1f
    :try_start_1f
    invoke-virtual {p1, p4}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V
    :try_end_22
    .catchall {:try_start_1f .. :try_end_22} :catchall_22

    :catchall_22
    move p0, v1

    .line 282
    :goto_23
    :try_start_23
    invoke-virtual {p1, v1, p2, p3, p5}, Landroid/app/AlarmManager;->setExactAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_27

    goto :goto_2c

    .line 286
    :catchall_27
    :try_start_27
    invoke-virtual {p1, v1, p2, p3, p5}, Landroid/app/AlarmManager;->setAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V
    :try_end_2a
    .catchall {:try_start_27 .. :try_end_2a} :catchall_2b

    goto :goto_2c

    :catchall_2b
    move v0, p0

    :goto_2c
    return v0
.end method

.method static armSnoozeAlarms(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Z
    .registers 16

    .line 236
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "fh.snooze-fire"

    .line 237
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "name"

    .line 238
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "time"

    .line 239
    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, ""

    if-nez p3, :cond_1c

    move-object v2, v1

    goto :goto_1d

    :cond_1c
    move-object v2, p3

    :goto_1d
    const-string v3, "url"

    .line 240
    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v2, 0x3ed

    const/high16 v3, 0xc000000

    .line 241
    invoke-static {p0, v2, v0, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v8

    const/16 v2, 0x3f0

    .line 242
    invoke-static {p0, v2, v0, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v9

    const-string v0, "alarm"

    .line 243
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Landroid/app/AlarmManager;

    if-nez v5, :cond_3d

    const/4 p0, 0x0

    return p0

    :cond_3d
    move-object v4, p0

    move-wide v6, p4

    .line 245
    invoke-static/range {v4 .. v9}, Lcom/fluxhelper/app/NotifReceiver;->armDual(Landroid/content/Context;Landroid/app/AlarmManager;JLandroid/app/PendingIntent;Landroid/app/PendingIntent;)Z

    move-result v0

    if-eqz v0, :cond_71

    .line 249
    :try_start_45
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v2, "sz_at"

    .line 250
    invoke-interface {p0, v2, p4, p5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p4, "sz_name"

    if-nez p1, :cond_58

    move-object p1, v1

    .line 251
    :cond_58
    invoke-interface {p0, p4, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "sz_t"

    if-nez p2, :cond_61

    move-object p2, v1

    .line 252
    :cond_61
    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "sz_u"

    if-nez p3, :cond_6a

    move-object p3, v1

    .line 253
    :cond_6a
    invoke-interface {p0, p1, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 254
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_71
    .catchall {:try_start_45 .. :try_end_71} :catchall_71

    :catchall_71
    :cond_71
    return v0
.end method

.method static cancelSnoozeAlarms(Landroid/content/Context;)V
    .registers 5

    :try_start_0
    const-string v0, "alarm"

    .line 314
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    if-nez v0, :cond_b

    return-void

    .line 316
    :cond_b
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "fh.snooze-fire"

    .line 317
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_17
    .catchall {:try_start_0 .. :try_end_17} :catchall_2b

    const/16 v2, 0x3ed

    const/high16 v3, 0xc000000

    .line 318
    :try_start_1b
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V
    :try_end_22
    .catchall {:try_start_1b .. :try_end_22} :catchall_22

    :catchall_22
    const/16 v2, 0x3f0

    .line 319
    :try_start_24
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V
    :try_end_2b
    .catchall {:try_start_24 .. :try_end_2b} :catchall_2b

    :catchall_2b
    return-void
.end method

.method static clearSnoozeState(Landroid/content/Context;)V
    .registers 2

    .line 326
    :try_start_0
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sz_at"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sz_name"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sz_t"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sz_u"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_23
    .catchall {:try_start_0 .. :try_end_23} :catchall_23

    :catchall_23
    return-void
.end method

.method private static lessonStarted(Ljava/lang/String;)Z
    .registers 6

    const/4 v0, 0x0

    if-eqz p0, :cond_40

    const/16 v1, 0x3a

    .line 332
    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    if-gez v1, :cond_c

    goto :goto_40

    :cond_c
    :try_start_c
    const-string v1, ":"

    .line 334
    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 335
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    .line 336
    aget-object v2, p0, v0

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    mul-int/lit8 v2, v2, 0x3c

    const/4 v3, 0x1

    aget-object p0, p0, v3

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    add-int/2addr v2, p0

    const/16 p0, 0xb

    .line 337
    invoke-virtual {v1, p0}, Ljava/util/Calendar;->get(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x3c

    const/16 v4, 0xc

    invoke-virtual {v1, v4}, Ljava/util/Calendar;->get(I)I

    move-result v1
    :try_end_3c
    .catchall {:try_start_c .. :try_end_3c} :catchall_40

    add-int/2addr p0, v1

    if-lt p0, v2, :cond_40

    return v3

    :catchall_40
    :cond_40
    :goto_40
    return v0
.end method

.method public static rearmSnooze(Landroid/content/Context;)V
    .registers 12

    const-string v0, ""

    .line 297
    :try_start_2
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "sz_at"

    const-wide/16 v3, 0x0

    .line 298
    invoke-interface {v1, v2, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v9

    cmp-long v2, v9, v3

    if-gtz v2, :cond_13

    return-void

    .line 300
    :cond_13
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-wide/16 v4, 0xfa0

    add-long/2addr v2, v4

    cmp-long v2, v9, v2

    if-gtz v2, :cond_22

    invoke-static {p0}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V

    return-void

    :cond_22
    const-string v2, "sz_name"

    .line 301
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v2, "sz_t"

    .line 302
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v2, "sz_u"

    .line 303
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-eqz v7, :cond_56

    const/16 v0, 0x3a

    .line 304
    invoke-virtual {v7, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_3f

    goto :goto_56

    .line 305
    :cond_3f
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v7, v6}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 306
    invoke-static {p0, v0}, Lcom/fluxhelper/app/Notifs;->isDone(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_51

    invoke-static {p0}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V

    return-void

    :cond_51
    move-object v5, p0

    .line 307
    invoke-static/range {v5 .. v10}, Lcom/fluxhelper/app/NotifReceiver;->armSnoozeAlarms(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Z

    goto :goto_59

    .line 304
    :cond_56
    :goto_56
    invoke-static {p0}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V
    :try_end_59
    .catchall {:try_start_2 .. :try_end_59} :catchall_59

    :catchall_59
    :goto_59
    return-void
.end method

.method private static scheduleSnooze(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 16

    const/4 v0, 0x0

    if-eqz p2, :cond_75

    const/16 v1, 0x3a

    .line 208
    invoke-virtual {p2, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    if-gez v1, :cond_c

    goto :goto_75

    .line 209
    :cond_c
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, p2, p1}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 210
    invoke-static {p0, v1}, Lcom/fluxhelper/app/Notifs;->snoozeUsed(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1c

    return v3

    .line 211
    :cond_1c
    invoke-static {p0, v1}, Lcom/fluxhelper/app/Notifs;->isDone(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_23

    return v0

    :cond_23
    :try_start_23
    const-string v2, ":"

    .line 213
    invoke-virtual {p2, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 214
    aget-object v4, v2, v0

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 215
    aget-object v2, v2, v3

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 216
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    const/16 v6, 0xb

    .line 217
    invoke-virtual {v5, v6, v4}, Ljava/util/Calendar;->set(II)V

    const/16 v4, 0xc

    .line 218
    invoke-virtual {v5, v4, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v2, 0xd

    .line 219
    invoke-virtual {v5, v2, v0}, Ljava/util/Calendar;->set(II)V

    const/16 v2, 0xe

    .line 220
    invoke-virtual {v5, v2, v0}, Ljava/util/Calendar;->set(II)V

    const/4 v2, -0x1

    .line 221
    invoke-virtual {v5, v4, v2}, Ljava/util/Calendar;->add(II)V

    .line 222
    invoke-virtual {v5}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v10

    .line 223
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    cmp-long v2, v10, v4

    if-gtz v2, :cond_66

    return v0

    :cond_66
    move-object v6, p0

    move-object v7, p1

    move-object v8, p2

    move-object v9, p3

    .line 227
    invoke-static/range {v6 .. v11}, Lcom/fluxhelper/app/NotifReceiver;->armSnoozeAlarms(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Z

    move-result p1

    if-nez p1, :cond_71

    return v0

    .line 228
    :cond_71
    invoke-static {p0, v1}, Lcom/fluxhelper/app/Notifs;->markSnoozeUsed(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_74
    .catchall {:try_start_23 .. :try_end_74} :catchall_75

    return v3

    :catchall_75
    :cond_75
    :goto_75
    return v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 19

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const-string v2, ""

    if-nez v1, :cond_a

    const/4 v3, 0x0

    goto :goto_e

    .line 56
    :cond_a
    invoke-virtual/range {p2 .. p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    :goto_e
    const-string v4, "fh.ignore"

    .line 57
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/16 v5, 0x7d2

    const/16 v6, 0x7d1

    const/16 v7, 0x7d3

    const-string v8, "notification"

    const-string v9, "time"

    const-string v10, "name"

    if-eqz v4, :cond_59

    .line 61
    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 62
    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 63
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v1, v2}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v1, :cond_3e

    .line 64
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x4

    if-lt v1, v3, :cond_3e

    invoke-static {v0, v2}, Lcom/fluxhelper/app/Notifs;->markDone(Landroid/content/Context;Ljava/lang/String;)V

    .line 65
    :cond_3e
    invoke-static {v0, v2}, Lcom/fluxhelper/app/Notifs;->markSnoozeUsed(Landroid/content/Context;Ljava/lang/String;)V

    .line 66
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/NotifReceiver;->cancelSnoozeAlarms(Landroid/content/Context;)V

    .line 67
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V

    .line 68
    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_58

    .line 70
    invoke-virtual {v0, v6}, Landroid/app/NotificationManager;->cancel(I)V

    .line 71
    invoke-virtual {v0, v5}, Landroid/app/NotificationManager;->cancel(I)V

    .line 72
    invoke-virtual {v0, v7}, Landroid/app/NotificationManager;->cancel(I)V

    :cond_58
    return-void

    :cond_59
    const-string v4, "fh.tignore"

    .line 76
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6d

    .line 79
    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_6c

    .line 80
    invoke-virtual {v0, v7}, Landroid/app/NotificationManager;->cancel(I)V

    :cond_6c
    return-void

    :cond_6d
    const-string v4, "fh.snooze"

    .line 83
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v11, 0x0

    const-string v12, "url"

    if-eqz v4, :cond_a9

    .line 89
    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 90
    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 91
    invoke-virtual {v1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 88
    invoke-static {v0, v2, v3, v1}, Lcom/fluxhelper/app/NotifReceiver;->scheduleSnooze(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    .line 96
    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/NotificationManager;

    if-eqz v2, :cond_96

    .line 97
    invoke-virtual {v2, v6}, Landroid/app/NotificationManager;->cancel(I)V

    invoke-virtual {v2, v5}, Landroid/app/NotificationManager;->cancel(I)V

    .line 99
    :cond_96
    :try_start_96
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v1, :cond_9f

    const-string v1, "\u2705 \u041d\u0430\u0433\u0430\u0434\u0443\u0432\u0430\u043d\u043d\u044f \u0437\u0430 1 \u0445\u0432\u0438\u043b\u0438\u043d\u0443 \u0437\u0430\u043f\u043b\u0430\u043d\u043e\u0432\u0430\u043d\u043e"

    goto :goto_a1

    :cond_9f
    const-string v1, "\u26a0\ufe0f \u041d\u0430\u0433\u0430\u0434\u0443\u0432\u0430\u043d\u043d\u044f \u043d\u0435 \u0437\u0430\u043f\u043b\u0430\u043d\u043e\u0432\u0430\u043d\u043e: \u0443\u0440\u043e\u043a \u043f\u043e\u0447\u0438\u043d\u0430\u0454\u0442\u044c\u0441\u044f \u043c\u0435\u043d\u0448 \u043d\u0456\u0436 \u0437\u0430 1 \u0445\u0432"

    :goto_a1
    invoke-static {v0, v1, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 102
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_a8
    .catchall {:try_start_96 .. :try_end_a8} :catchall_a8

    :catchall_a8
    return-void

    :cond_a9
    const-string v4, "fh.snooze-fire"

    .line 106
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_e3

    .line 115
    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 116
    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 117
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3, v2}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 118
    invoke-static {v3}, Lcom/fluxhelper/app/NotifReceiver;->lessonStarted(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_ce

    invoke-static {v0, v4}, Lcom/fluxhelper/app/Notifs;->markDone(Landroid/content/Context;Ljava/lang/String;)V

    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V

    return-void

    .line 119
    :cond_ce
    invoke-static {v0, v4}, Lcom/fluxhelper/app/Notifs;->isDone(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_d5

    return-void

    .line 120
    :cond_d5
    invoke-virtual {v1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v3, v1, v11}, Lcom/fluxhelper/app/Notifs;->showSnooze(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 121
    invoke-static {v0, v4}, Lcom/fluxhelper/app/Notifs;->markDone(Landroid/content/Context;Ljava/lang/String;)V

    .line 122
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/NotifReceiver;->clearSnoozeState(Landroid/content/Context;)V

    return-void

    :cond_e3
    const-string v4, "fh.tsnooze"

    .line 125
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const-string v13, "tsu"

    const-string v14, "tst"

    const-string v15, "tsn"

    const-string v5, "fh.tsnooze-fire"

    if-eqz v4, :cond_160

    .line 131
    :try_start_f3
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 132
    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v15, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 133
    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v14, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 134
    invoke-virtual {v1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v13, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 135
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_116
    .catchall {:try_start_f3 .. :try_end_116} :catchall_116

    .line 137
    :catchall_116
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/32 v3, 0xea60

    add-long v2, v1, v3

    .line 138
    new-instance v1, Landroid/content/Intent;

    const-class v4, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v1, v0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 139
    invoke-virtual {v1, v5}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v4, 0x3ef

    const/high16 v5, 0xc000000

    .line 140
    invoke-static {v0, v4, v1, v5}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v4

    const/16 v6, 0x3f1

    .line 141
    invoke-static {v0, v6, v1, v5}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    const-string v1, "alarm"

    .line 142
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/AlarmManager;

    .line 143
    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/app/NotificationManager;

    if-eqz v6, :cond_14a

    .line 144
    invoke-virtual {v6, v7}, Landroid/app/NotificationManager;->cancel(I)V

    .line 146
    :cond_14a
    :try_start_14a
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    const-string v7, "\u2705 \u0414\u0435\u043c\u043e-\u043d\u0430\u0433\u0430\u0434\u0443\u0432\u0430\u043d\u043d\u044f \u0437\u0430\u043f\u043b\u0430\u043d\u043e\u0432\u0430\u043d\u043e \u2014 \u043f\u0440\u0438\u0439\u0434\u0435 \u0437\u0430 1 \u0445\u0432\u0438\u043b\u0438\u043d\u0443"

    invoke-static {v6, v7, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    .line 148
    invoke-virtual {v6}, Landroid/widget/Toast;->show()V
    :try_end_157
    .catchall {:try_start_14a .. :try_end_157} :catchall_157

    :catchall_157
    if-nez v1, :cond_15a

    return-void

    :cond_15a
    move-object/from16 v0, p1

    .line 151
    invoke-static/range {v0 .. v5}, Lcom/fluxhelper/app/NotifReceiver;->armDual(Landroid/content/Context;Landroid/app/AlarmManager;JLandroid/app/PendingIntent;Landroid/app/PendingIntent;)Z

    return-void

    :cond_160
    const-string v4, "fh.expire"

    .line 154
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_185

    .line 158
    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_184

    const-string v2, "nid"

    .line 160
    invoke-virtual {v1, v2, v11}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    if-ne v1, v7, :cond_17c

    invoke-virtual {v0, v7}, Landroid/app/NotificationManager;->cancel(I)V

    goto :goto_184

    .line 161
    :cond_17c
    invoke-virtual {v0, v6}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v1, 0x7d2

    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->cancel(I)V

    :cond_184
    :goto_184
    return-void

    .line 165
    :cond_185
    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1ad

    .line 171
    :try_start_18b
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1, v15, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_193
    .catchall {:try_start_18b .. :try_end_193} :catchall_1a6

    .line 172
    :try_start_193
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3, v14, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_19b
    .catchall {:try_start_193 .. :try_end_19b} :catchall_1a4

    .line 173
    :try_start_19b
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v4

    invoke-interface {v4, v13, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_1a3
    .catchall {:try_start_19b .. :try_end_1a3} :catchall_1a8

    goto :goto_1a8

    :catchall_1a4
    move-object v3, v2

    goto :goto_1a8

    :catchall_1a6
    move-object v1, v2

    move-object v3, v1

    :catchall_1a8
    :goto_1a8
    const/4 v4, 0x1

    .line 175
    invoke-static {v0, v1, v3, v2, v4}, Lcom/fluxhelper/app/Notifs;->showSnooze(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-void

    .line 179
    :cond_1ad
    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 180
    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 182
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3, v2}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 183
    invoke-static {v0, v4}, Lcom/fluxhelper/app/Notifs;->isDone(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    .line 184
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->ensureChannel(Landroid/content/Context;)V

    .line 185
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->cleanupStale(Landroid/content/Context;)V

    if-nez v4, :cond_1d7

    const-string v4, "min"

    const/4 v5, 0x5

    .line 187
    invoke-virtual {v1, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v3, v4, v1}, Lcom/fluxhelper/app/Notifs;->show(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    .line 189
    :cond_1d7
    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->reschedule(Landroid/content/Context;)V

    return-void
.end method
