.class public final Lcom/fluxhelper/app/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fluxhelper/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final ic_notif:I = 0x7f010000

.field public static final notif_accent:I = 0x7f010001

.field public static final notif_btn_ignore:I = 0x7f010002

.field public static final notif_btn_join:I = 0x7f010003

.field public static final notif_btn_snooze:I = 0x7f010004

.field public static final notif_card:I = 0x7f010005

.field public static final splash:I = 0x7f010006

.field public static final splash_logo:I = 0x7f010007

.field public static final splash_logo_pad:I = 0x7f010008


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
