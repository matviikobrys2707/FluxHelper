.class public Lcom/fluxhelper/app/LoginKeepService;
.super Landroid/app/Service;
.source "LoginKeepService.java"


# static fields
.field private static final CH_ID:Ljava/lang/String; = "login_keep"

.field private static final NOTIF_ID:I = 0x7d1


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 20
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static start(Landroid/content/Context;)V
    .registers 4

    .line 27
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/fluxhelper/app/LoginKeepService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 28
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_11

    invoke-virtual {p0, v0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_14

    .line 29
    :cond_11
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_14
    .catchall {:try_start_0 .. :try_end_14} :catchall_14

    :catchall_14
    :goto_14
    return-void
.end method

.method public static stop(Landroid/content/Context;)V
    .registers 3

    .line 34
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/fluxhelper/app/LoginKeepService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_a
    .catchall {:try_start_0 .. :try_end_a} :catchall_a

    :catchall_a
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .registers 9

    .line 44
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/16 v0, 0x7d1

    :try_start_5
    const-string v1, "notification"

    .line 46
    invoke-virtual {p0, v1}, Lcom/fluxhelper/app/LoginKeepService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    .line 47
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_f
    .catchall {:try_start_5 .. :try_end_f} :catchall_5f

    const/4 v3, 0x1

    const-string v4, "\u0412\u0445\u0456\u0434 \u0443 FluxHelper"

    const-string v5, "login_keep"

    const/16 v6, 0x1a

    if-lt v2, v6, :cond_2f

    if-eqz v1, :cond_2f

    .line 48
    :try_start_1a
    new-instance v2, Landroid/app/NotificationChannel;

    invoke-direct {v2, v5, v4, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v7, "\u041f\u043e\u043a\u0430\u0437\u0443\u0454\u0442\u044c\u0441\u044f, \u043f\u043e\u043a\u0438 \u0442\u0440\u0438\u0432\u0430\u0454 \u0432\u0445\u0456\u0434 \u0447\u0435\u0440\u0435\u0437 Google"

    .line 50
    invoke-virtual {v2, v7}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const/4 v7, 0x0

    .line 51
    invoke-virtual {v2, v7}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    const/4 v7, 0x0

    .line 52
    invoke-virtual {v2, v7, v7}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    .line 53
    invoke-virtual {v1, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 55
    :cond_2f
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v1, v6, :cond_39

    .line 56
    new-instance v1, Landroid/app/Notification$Builder;

    invoke-direct {v1, p0, v5}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_3e

    .line 57
    :cond_39
    new-instance v1, Landroid/app/Notification$Builder;

    invoke-direct {v1, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    :goto_3e
    const v2, 0x108009b

    .line 58
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 59
    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const-string v4, "\u0417\u0430\u0447\u0435\u043a\u0430\u0439 \u2014 \u0456\u0434\u0435 \u043f\u0456\u0434\u0442\u0432\u0435\u0440\u0434\u0436\u0435\u043d\u043d\u044f \u0430\u043a\u0430\u0443\u043d\u0442\u0430 Google"

    .line 60
    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 61
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, -0x2

    .line 62
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 63
    invoke-virtual {v1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/fluxhelper/app/LoginKeepService;->startForeground(ILandroid/app/Notification;)V
    :try_end_5e
    .catchall {:try_start_1a .. :try_end_5e} :catchall_5f

    goto :goto_67

    .line 66
    :catchall_5f
    :try_start_5f
    new-instance v1, Landroid/app/Notification;

    invoke-direct {v1}, Landroid/app/Notification;-><init>()V

    invoke-virtual {p0, v0, v1}, Lcom/fluxhelper/app/LoginKeepService;->startForeground(ILandroid/app/Notification;)V
    :try_end_67
    .catchall {:try_start_5f .. :try_end_67} :catchall_67

    :catchall_67
    :goto_67
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 4

    const/4 p1, 0x2

    return p1
.end method
