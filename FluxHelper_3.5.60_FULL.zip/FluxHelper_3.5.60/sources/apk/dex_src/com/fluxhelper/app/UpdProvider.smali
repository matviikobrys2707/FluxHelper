.class public Lcom/fluxhelper/app/UpdProvider;
.super Landroid/content/ContentProvider;
.source "UpdProvider.java"


# static fields
.field public static final AUTHORITY:Ljava/lang/String; = "com.fluxhelper.app.upd"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 12
    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method

.method private apkFile()Ljava/io/File;
    .registers 4

    .line 41
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lcom/fluxhelper/app/UpdProvider;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v2, "update/update.apk"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 4

    const/4 p1, 0x0

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 2

    const-string p1, "application/vnd.android.package-archive"

    return-object p1
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public openFile(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    .line 46
    invoke-direct {p0}, Lcom/fluxhelper/app/UpdProvider;->apkFile()Ljava/io/File;

    move-result-object p1

    .line 47
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result p2

    if-eqz p2, :cond_11

    const/high16 p2, 0x10000000

    .line 50
    invoke-static {p1, p2}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    return-object p1

    .line 48
    :cond_11
    new-instance p1, Ljava/io/FileNotFoundException;

    const-string p2, "update apk not ready"

    invoke-direct {p1, p2}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 10

    const-string p1, "_size"

    const-string p3, "_display_name"

    if-nez p2, :cond_a

    .line 56
    filled-new-array {p3, p1}, [Ljava/lang/String;

    move-result-object p2

    .line 58
    :cond_a
    new-instance p4, Landroid/database/MatrixCursor;

    invoke-direct {p4, p2}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;)V

    .line 59
    invoke-direct {p0}, Lcom/fluxhelper/app/UpdProvider;->apkFile()Ljava/io/File;

    move-result-object p5

    .line 60
    array-length v0, p2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    .line 61
    :goto_17
    array-length v2, p2

    if-lt v1, v2, :cond_1e

    .line 70
    invoke-virtual {p4, v0}, Landroid/database/MatrixCursor;->addRow([Ljava/lang/Object;)V

    return-object p4

    .line 62
    :cond_1e
    aget-object v2, p2, v1

    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2b

    const-string v2, "FluxHelper-update.apk"

    .line 63
    aput-object v2, v0, v1

    goto :goto_4a

    .line 64
    :cond_2b
    aget-object v2, p2, v1

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_47

    .line 65
    invoke-virtual {p5}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_3e

    invoke-virtual {p5}, Ljava/io/File;->length()J

    move-result-wide v2

    goto :goto_40

    :cond_3e
    const-wide/16 v2, 0x0

    :goto_40
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    aput-object v2, v0, v1

    goto :goto_4a

    :cond_47
    const/4 v2, 0x0

    .line 67
    aput-object v2, v0, v1

    :goto_4a
    add-int/lit8 v1, v1, 0x1

    goto :goto_17
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 5

    const/4 p1, 0x0

    return p1
.end method
