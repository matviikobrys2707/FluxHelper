.class public final Lcom/fluxhelper/app/Cloud;
.super Ljava/lang/Object;
.source "Cloud.java"


# static fields
.field private static final ACC:Ljava/lang/String; = "fd6013c3a257c7759ff3c15fbb8ac002"

.field private static final CH:[Ljava/lang/String;

.field private static final DB:Ljava/lang/String; = "89424274-f50b-4931-838e-0d6f384bbc20"

.field private static tok:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const-string v0, "Ems0Hy8IPhVqEDYRaQ"

    const-string v1, "AqPTswaWs+aWs5Pz8="

    const-string v2, "OTwvLgVsFzQiMTA9DA"

    const-string v3, "ANFDBjEjw8DAg0LxYu"

    .line 19
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 15
    sput-object v0, Lcom/fluxhelper/app/Cloud;->CH:[Ljava/lang/String;

    const/4 v0, 0x0

    .line 23
    sput-object v0, Lcom/fluxhelper/app/Cloud;->tok:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static query(Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    const/4 v0, 0x0

    .line 52
    :try_start_1
    new-instance v1, Ljava/net/URL;

    const-string v2, "https://api.cloudflare.com/client/v4/accounts/fd6013c3a257c7759ff3c15fbb8ac002/d1/database/89424274-f50b-4931-838e-0d6f384bbc20/query"

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 53
    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_e} :catch_a2
    .catchall {:try_start_1 .. :try_end_e} :catchall_9b

    :try_start_e
    const-string v2, "POST"

    .line 54
    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/16 v2, 0x2ee0

    .line 55
    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v2, 0x4e20

    .line 56
    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v2, 0x1

    .line 57
    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    const-string v2, "Authorization"

    .line 58
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Bearer "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Lcom/fluxhelper/app/Cloud;->token()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "Content-Type"

    const-string v3, "application/json"

    .line 59
    invoke-virtual {v1, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    .line 61
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v2

    .line 62
    invoke-virtual {v2, p0}, Ljava/io/OutputStream;->write([B)V

    .line 63
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    .line 64
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p0

    const/16 v2, 0x190

    if-lt p0, v2, :cond_5c

    .line 65
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object p0

    goto :goto_60

    :cond_5c
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p0
    :try_end_60
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_60} :catch_a3
    .catchall {:try_start_e .. :try_end_60} :catchall_98

    :goto_60
    if-nez p0, :cond_68

    if-eqz v1, :cond_67

    .line 85
    :try_start_64
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_67} :catch_67

    :catch_67
    :cond_67
    return-object v0

    .line 69
    :cond_68
    :try_start_68
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v3, 0x2000

    new-array v3, v3, [B

    .line 72
    :goto_71
    invoke-virtual {p0, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, 0x0

    if-gtz v4, :cond_94

    .line 75
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    const-string p0, "UTF-8"

    .line 76
    invoke-virtual {v2, p0}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 77
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const v3, 0xdbba0

    if-le v2, v3, :cond_8e

    .line 78
    invoke-virtual {p0, v5, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0
    :try_end_8e
    .catch Ljava/lang/Exception; {:try_start_68 .. :try_end_8e} :catch_a3
    .catchall {:try_start_68 .. :try_end_8e} :catchall_98

    :cond_8e
    if-eqz v1, :cond_93

    .line 85
    :try_start_90
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_93
    .catch Ljava/lang/Exception; {:try_start_90 .. :try_end_93} :catch_93

    :catch_93
    :cond_93
    return-object p0

    .line 73
    :cond_94
    :try_start_94
    invoke-virtual {v2, v3, v5, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_97
    .catch Ljava/lang/Exception; {:try_start_94 .. :try_end_97} :catch_a3
    .catchall {:try_start_94 .. :try_end_97} :catchall_98

    goto :goto_71

    :catchall_98
    move-exception p0

    move-object v0, v1

    goto :goto_9c

    :catchall_9b
    move-exception p0

    :goto_9c
    if-eqz v0, :cond_a1

    .line 85
    :try_start_9e
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_a1
    .catch Ljava/lang/Exception; {:try_start_9e .. :try_end_a1} :catch_a1

    .line 87
    :catch_a1
    :cond_a1
    throw p0

    :catch_a2
    move-object v1, v0

    :catch_a3
    if-eqz v1, :cond_a8

    .line 85
    :try_start_a5
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_a8
    .catch Ljava/lang/Exception; {:try_start_a5 .. :try_end_a8} :catch_a8

    :catch_a8
    :cond_a8
    return-object v0
.end method

.method private static declared-synchronized token()Ljava/lang/String;
    .registers 7

    const-class v0, Lcom/fluxhelper/app/Cloud;

    monitor-enter v0

    .line 28
    :try_start_3
    sget-object v1, Lcom/fluxhelper/app/Cloud;->tok:Ljava/lang/String;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_47

    if-eqz v1, :cond_9

    .line 29
    monitor-exit v0

    return-object v1

    .line 31
    :cond_9
    :try_start_9
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 32
    sget-object v2, Lcom/fluxhelper/app/Cloud;->CH:[Ljava/lang/String;

    array-length v3, v2
    :try_end_11
    .catchall {:try_start_9 .. :try_end_11} :catchall_47

    const/4 v4, 0x0

    move v5, v4

    :goto_13
    if-lt v5, v3, :cond_3f

    .line 36
    :try_start_15
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 37
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 38
    array-length v3, v1

    :goto_23
    if-lt v4, v3, :cond_2c

    .line 41
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/fluxhelper/app/Cloud;->tok:Ljava/lang/String;

    goto :goto_3b

    .line 38
    :cond_2c
    aget-byte v5, v1, v4

    xor-int/lit8 v5, v5, 0x5a

    int-to-char v5, v5

    .line 39
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_34} :catch_37
    .catchall {:try_start_15 .. :try_end_34} :catchall_47

    add-int/lit8 v4, v4, 0x1

    goto :goto_23

    :catch_37
    :try_start_37
    const-string v1, ""

    .line 43
    sput-object v1, Lcom/fluxhelper/app/Cloud;->tok:Ljava/lang/String;

    .line 45
    :goto_3b
    sget-object v1, Lcom/fluxhelper/app/Cloud;->tok:Ljava/lang/String;
    :try_end_3d
    .catchall {:try_start_37 .. :try_end_3d} :catchall_47

    monitor-exit v0

    return-object v1

    .line 32
    :cond_3f
    :try_start_3f
    aget-object v6, v2, v5

    .line 33
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_44
    .catchall {:try_start_3f .. :try_end_44} :catchall_47

    add-int/lit8 v5, v5, 0x1

    goto :goto_13

    :catchall_47
    move-exception v1

    monitor-exit v0

    throw v1
.end method
