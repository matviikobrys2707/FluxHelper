.class public Lcom/fluxhelper/app/InstallStatusReceiver;
.super Landroid/content/BroadcastReceiver;
.source "InstallStatusReceiver.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 16
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 3

    if-nez p2, :cond_3

    return-void

    :cond_3
    :try_start_3
    const-string p1, "android.content.pm.extra.STATUS"

    .line 21
    invoke-virtual {p2, p1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_c

    return-void

    .line 22
    :cond_c
    invoke-static {p2}, Lcom/fluxhelper/app/MainActivity;->handleInstallStatusStatic(Landroid/content/Intent;)V
    :try_end_f
    .catchall {:try_start_3 .. :try_end_f} :catchall_f

    :catchall_f
    return-void
.end method
