.class Lcom/fluxhelper/app/MainActivity$7;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/webkit/ValueCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->onBackPressed()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/webkit/ValueCallback<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;)V
    .registers 2

    .line 812
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$7;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic onReceiveValue(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity$7;->onReceiveValue(Ljava/lang/String;)V

    return-void
.end method

.method public onReceiveValue(Ljava/lang/String;)V
    .registers 3

    const-string v0, "true"

    .line 815
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_9

    return-void

    .line 818
    :cond_9
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity$7;->this$0:Lcom/fluxhelper/app/MainActivity;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lcom/fluxhelper/app/MainActivity;->moveTaskToBack(Z)Z

    return-void
.end method
