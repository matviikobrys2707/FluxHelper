.class public final Lcom/fluxhelper/app/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fluxhelper/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final nBtns:I = 0x7f020000

.field public static final nIcon:I = 0x7f020001

.field public static final nJoin:I = 0x7f020002

.field public static final nSnooze:I = 0x7f020003

.field public static final nText:I = 0x7f020004

.field public static final nTime:I = 0x7f020005

.field public static final nTitle:I = 0x7f020006


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
