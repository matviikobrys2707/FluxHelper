.class Lcom/fluxhelper/app/MainActivity$Host$3;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity$Host;->openChannelSet(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/fluxhelper/app/MainActivity$Host;

.field private final synthetic val$cid:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;)V
    .registers 3

    .line 1043
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->val$cid:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 1047
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_32

    .line 1048
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.CHANNEL_NOTIFICATION_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.provider.extra.CHANNEL_ID"

    .line 1049
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->val$cid:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "android.provider.extra.APP_PACKAGE"

    .line 1050
    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v2

    invoke-virtual {v2}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v1, 0x10000000

    .line 1051
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 1052
    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v1}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_31
    .catchall {:try_start_0 .. :try_end_31} :catchall_32

    return-void

    .line 1056
    :catchall_32
    :cond_32
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$3;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity$Host;->openNotifSet()V

    return-void
.end method
