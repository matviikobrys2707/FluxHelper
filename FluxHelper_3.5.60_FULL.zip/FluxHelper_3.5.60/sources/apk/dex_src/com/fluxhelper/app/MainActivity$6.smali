.class Lcom/fluxhelper/app/MainActivity$6;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->fetchToFile(Ljava/lang/String;Ljava/lang/String;Z)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;)V
    .registers 2

    .line 517
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$6;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 520
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$6;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity;->tryInstall()V

    return-void
.end method
