.class public final Lcom/fluxhelper/app/Notifs;
.super Ljava/lang/Object;
.source "Notifs.java"


# static fields
.field static final CH:Ljava/lang/String; = "lesson_v4"

.field static final CH_MUTE:Ljava/lang/String; = "lesson_mute4"

.field static final NID:I = 0x7d1

.field static final REQ:I = 0x3e9

.field static final REQ2:I = 0x3ee

.field static final REQ_EXP:I = 0x3f5

.field static final REQ_EXP_T:I = 0x3f6

.field public static lastTestErr:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static calcAlarm(Landroid/content/Context;Lorg/json/JSONObject;JI)J
    .registers 14

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    :try_start_4
    if-eqz p1, :cond_9e

    const-string v2, "t"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_9e

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v8, 0x4

    if-lt v3, v8, :cond_9e

    const-string v3, "r60"

    const/4 v8, 0x0

    invoke-virtual {p1, v3, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4

    const-string v3, "at"

    const-wide/16 v7, 0x0

    invoke-virtual {p1, v3, v7, v8}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v5

    const/4 v3, 0x1

    add-int/lit8 v8, v4, -0x1

    if-nez v8, :cond_2f

    const-wide/16 v7, -0x15a0

    add-long v7, v5, v7

    int-to-long v3, v3

    goto :goto_35

    :cond_2f
    int-to-long v7, p4

    const-wide/16 v3, -0x15a0

    mul-long v7, v7, v3

    add-long/2addr v7, p2

    :goto_35
    cmp-long v3, v7, v0

    if-gtz v3, :cond_3c

    const-wide/16 v0, 0x0

    return-wide v0

    :cond_3c
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v3

    const-string v4, "n"

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v2, v4}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3}, Lcom/fluxhelper/app/Notifs;->isDone(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_53

    const-wide/16 v0, 0x0

    return-wide v0

    :cond_53
    const-string v3, "r60"

    const/4 v4, 0x0

    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    if-nez v3, :cond_5f

    goto :goto_6e

    :cond_5f
    const-wide/32 v7, 0x1d4c0

    sub-long v7, v0, v7

    cmp-long v3, v5, v7

    if-lez v3, :cond_69

    goto :goto_6e

    :cond_69
    cmp-long v3, p2, v0

    if-lez v3, :cond_9a

    return-wide p2

    :goto_6e
    cmp-long v3, v5, v0

    if-lez v3, :cond_73

    return-wide v5

    :cond_73
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v3

    const-string v4, "ln_d"

    const-string v7, ""

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9a

    const-string v4, "ln_t"

    const-string v7, ""

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9a

    const-wide/16 v0, 0x0

    return-wide v0

    :cond_9a
    const-wide/16 v3, 0x7d0

    add-long/2addr v0, v3

    return-wide v0

    :cond_9e
    return-wide p2
    :try_end_9f
    .catchall {:try_start_4 .. :try_end_9f} :catchall_9f

    :catchall_9f
    return-wide p2
.end method

.method private static cancelAlarms(Landroid/app/AlarmManager;Landroid/content/Context;)V
    .registers 5

    const/high16 v0, 0xc000000

    .line 271
    :try_start_2
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v1, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x3e9

    invoke-static {p1, v2, v1, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V
    :try_end_12
    .catchall {:try_start_2 .. :try_end_12} :catchall_12

    .line 272
    :catchall_12
    :try_start_12
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v1, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v2, 0x3ee

    invoke-static {p1, v2, v1, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V
    :try_end_22
    .catchall {:try_start_12 .. :try_end_22} :catchall_22

    :catchall_22
    return-void
.end method

.method public static cleanupStale(Landroid/content/Context;)V
    .registers 11

    const-string v0, ""

    .line 94
    :try_start_2
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "ln_d"

    .line 95
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "ln_t"

    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v2, :cond_a2

    .line 96
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    if-eqz v4, :cond_a2

    if-eqz v3, :cond_a2

    const-string v4, "^\\d{1,2}:\\d{2}$"

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_26

    goto/16 :goto_a2

    :cond_26
    const-string v4, ":"

    .line 97
    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 98
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    const/4 v6, 0x0

    .line 99
    aget-object v7, v4, v6

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/16 v8, 0xb

    invoke-virtual {v5, v8, v7}, Ljava/util/Calendar;->set(II)V

    const/4 v7, 0x1

    .line 100
    aget-object v4, v4, v7

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const/16 v8, 0xc

    invoke-virtual {v5, v8, v4}, Ljava/util/Calendar;->set(II)V

    const/16 v4, 0xd

    const/16 v8, 0x1e

    .line 101
    invoke-virtual {v5, v4, v8}, Ljava/util/Calendar;->set(II)V

    .line 102
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-virtual {v5}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v4

    cmp-long v2, v8, v4

    if-gez v2, :cond_6e

    goto :goto_6f

    :cond_6e
    move v6, v7

    :goto_6f
    if-nez v6, :cond_8a

    const-string v2, "ln_n"

    .line 105
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 106
    invoke-static {p0, v0, v3}, Lcom/fluxhelper/app/Notifs;->endMillisFor(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-lez v2, :cond_8a

    .line 107
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    cmp-long v0, v2, v0

    if-ltz v0, :cond_8a

    goto :goto_8b

    :cond_8a
    move v7, v6

    :goto_8b
    if-eqz v7, :cond_a2

    const-string v0, "notification"

    .line 110
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    if-eqz p0, :cond_a2

    const/16 v0, 0x7d1

    .line 111
    invoke-virtual {p0, v0}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v0, 0x7d2

    invoke-virtual {p0, v0}, Landroid/app/NotificationManager;->cancel(I)V
    :try_end_a1
    .catchall {:try_start_2 .. :try_end_a1} :catchall_a2

    nop

    :catchall_a2
    :cond_a2
    :goto_a2
    return-void
.end method

.method private static emojiFor(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const-string v0, "\ud83d\udcda"

    if-eqz p0, :cond_118

    .line 414
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_c

    goto/16 :goto_118

    .line 415
    :cond_c
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "\u0444\u0456\u0437\u043a\u0443"

    .line 416
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_115

    const-string v1, "\u0444\u0456\u0437"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2a

    const-string v2, "\u043a\u0443\u043b\u044c\u0442"

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_115

    :cond_2a
    const-string v2, "\u0441\u043f\u043e\u0440\u0442"

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_115

    const-string v2, "\u0437\u0434\u043e\u0440\u043e\u0432"

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3c

    goto/16 :goto_115

    :cond_3c
    const-string v2, "\u043c\u0430\u0442\u0435\u043c"

    .line 417
    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_112

    const-string v2, "\u0430\u043b\u0433\u0435\u0431\u0440"

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_112

    const-string v2, "\u0433\u0435\u043e\u043c\u0435\u0442\u0440"

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_56

    goto/16 :goto_112

    :cond_56
    const-string v2, "\u0456\u043d\u0444\u043e\u0440\u043c"

    .line 418
    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_61

    const-string p0, "\ud83d\udcbb"

    return-object p0

    :cond_61
    const-string v2, "\u0443\u043a\u0440"

    .line 419
    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_74

    const-string v3, "\u043b\u0456\u0442"

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_74

    const-string p0, "\ud83d\udcd7"

    return-object p0

    :cond_74
    const-string v3, "\u0430\u043d\u0433\u043b"

    .line 420
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_10f

    const-string v3, "\u043d\u0456\u043c"

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_86

    goto/16 :goto_10f

    :cond_86
    const-string v3, "\u0431\u0456\u043e\u043b"

    .line 421
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_10c

    const-string v3, "\u043f\u0440\u0438\u0440\u043e\u0434"

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_98

    goto/16 :goto_10c

    :cond_98
    const-string v3, "\u0433\u0435\u043e"

    .line 422
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_a3

    const-string p0, "\ud83c\udf0d"

    return-object p0

    :cond_a3
    const-string v3, "\u0456\u0441\u0442\u043e\u0440"

    .line 423
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_ae

    const-string p0, "\ud83c\udfdb\ufe0f"

    return-object p0

    :cond_ae
    const-string v3, "\u0445\u0456\u043c"

    .line 424
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_b9

    const-string p0, "\ud83e\uddea"

    return-object p0

    .line 425
    :cond_b9
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c2

    const-string p0, "\ud83e\uddf2"

    return-object p0

    :cond_c2
    const-string v1, "\u043c\u0438\u0441\u0442"

    .line 426
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_cd

    const-string p0, "\ud83c\udfa8"

    return-object p0

    :cond_cd
    const-string v1, "\u0442\u0440\u0443\u0434"

    .line 427
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_109

    const-string v1, "\u0442\u0435\u0445\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_de

    goto :goto_109

    :cond_de
    const-string v1, "\u043c\u0443\u0437"

    .line 428
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_e9

    const-string p0, "\ud83c\udfb5"

    return-object p0

    :cond_e9
    const-string v1, "\u0435\u0442\u0438\u043a"

    .line 429
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_f4

    const-string p0, "\ud83e\udd1d"

    return-object p0

    :cond_f4
    const-string v1, "\u0437\u0430\u0445\u0438\u0441\u0442"

    .line 430
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_ff

    const-string p0, "\ud83d\udee1\ufe0f"

    return-object p0

    .line 431
    :cond_ff
    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_108

    const-string p0, "\ud83d\udcd6"

    return-object p0

    :cond_108
    return-object v0

    :cond_109
    :goto_109
    const-string p0, "\ud83d\udee0\ufe0f"

    return-object p0

    :cond_10c
    :goto_10c
    const-string p0, "\ud83c\udf31"

    return-object p0

    :cond_10f
    :goto_10f
    const-string p0, "\ud83d\udd24"

    return-object p0

    :cond_112
    :goto_112
    const-string p0, "\ud83e\uddee"

    return-object p0

    :cond_115
    :goto_115
    const-string p0, "\u26bd"

    return-object p0

    :cond_118
    :goto_118
    return-object v0
.end method

.method static endMillisFor(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)J
    .registers 19

    move-object/from16 v0, p2

    const-string v1, ""

    const-string v2, ":"

    .line 121
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .line 124
    :try_start_a
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    .line 125
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v6

    const/4 v7, 0x0

    .line 126
    aget-object v8, v5, v7

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/16 v9, 0xb

    invoke-virtual {v6, v9, v8}, Ljava/util/Calendar;->set(II)V

    const/4 v8, 0x1

    .line 127
    aget-object v5, v5, v8

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/16 v10, 0xc

    invoke-virtual {v6, v10, v5}, Ljava/util/Calendar;->set(II)V

    const/16 v5, 0xd

    .line 128
    invoke-virtual {v6, v5, v7}, Ljava/util/Calendar;->set(II)V

    const/16 v11, 0xe

    .line 129
    invoke-virtual {v6, v11, v7}, Ljava/util/Calendar;->set(II)V

    .line 130
    invoke-virtual {v6}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v11
    :try_end_40
    .catchall {:try_start_a .. :try_end_40} :catchall_de

    const-wide/32 v13, 0x2932e0

    add-long/2addr v11, v13

    if-eqz p1, :cond_dd

    .line 131
    :try_start_46
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v13

    if-nez v13, :cond_4e

    goto/16 :goto_dd

    :cond_4e
    const/4 v13, 0x7

    .line 132
    invoke-virtual {v6, v13}, Ljava/util/Calendar;->get(I)I

    move-result v14

    add-int/lit8 v14, v14, 0x5

    rem-int/2addr v14, v13

    add-int/2addr v14, v8

    .line 133
    new-instance v13, Lorg/json/JSONArray;

    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v15

    const-string v5, "items"

    const-string v10, "[]"

    invoke-interface {v15, v5, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v13, v5}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move v5, v7

    .line 134
    :goto_69
    invoke-virtual {v13}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-lt v5, v10, :cond_71

    goto/16 :goto_e1

    .line 135
    :cond_71
    invoke-virtual {v13, v5}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    if-eqz v10, :cond_d6

    const-string v15, "dow"

    const/4 v8, -0x1

    .line 136
    invoke-virtual {v10, v15, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    if-eq v8, v14, :cond_82

    :goto_80
    const/4 v8, 0x1

    goto :goto_d6

    :cond_82
    const-string v8, "t"

    .line 137
    invoke-virtual {v10, v8, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_8f

    goto :goto_80

    :cond_8f
    const-string v0, "e"

    .line 138
    invoke-virtual {v10, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "^\\d{1,2}:\\d{2}$"

    .line 139
    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e1

    .line 140
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 141
    invoke-virtual {v6}, Ljava/util/Calendar;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Calendar;

    .line 142
    aget-object v2, v0, v7

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v9, v2}, Ljava/util/Calendar;->set(II)V

    const/4 v8, 0x1

    .line 143
    aget-object v0, v0, v8

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/16 v10, 0xc

    invoke-virtual {v1, v10, v0}, Ljava/util/Calendar;->set(II)V

    const/16 v15, 0xd

    .line 144
    invoke-virtual {v1, v15, v7}, Ljava/util/Calendar;->set(II)V

    .line 145
    invoke-virtual {v1}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0
    :try_end_cd
    .catchall {:try_start_46 .. :try_end_cd} :catchall_e1

    cmp-long v2, v0, v3

    if-lez v2, :cond_d2

    goto :goto_d5

    :cond_d2
    const-wide/16 v0, 0x7530

    add-long/2addr v0, v3

    :goto_d5
    return-wide v0

    :cond_d6
    :goto_d6
    const/16 v10, 0xc

    const/16 v15, 0xd

    add-int/lit8 v5, v5, 0x1

    goto :goto_69

    :cond_dd
    :goto_dd
    return-wide v11

    :catchall_de
    const-wide/16 v0, 0x0

    move-wide v11, v0

    :catchall_e1
    :cond_e1
    :goto_e1
    return-wide v11
.end method

.method public static ensureChannel(Landroid/content/Context;)V
    .registers 8

    const-string v0, "notification"

    .line 185
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 186
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_de

    if-nez v0, :cond_12

    goto/16 :goto_de

    :cond_12
    const/4 v1, 0x0

    .line 191
    :try_start_13
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "testch"

    const-string v4, ""

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 192
    invoke-virtual {v0}, Landroid/app/NotificationManager;->getNotificationChannels()Ljava/util/List;

    move-result-object v3

    if-eqz v3, :cond_51

    const/4 v4, 0x0

    .line 194
    :goto_26
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-lt v4, v5, :cond_2d

    goto :goto_51

    .line 195
    :cond_2d
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/NotificationChannel;

    if-eqz v5, :cond_3a

    .line 196
    invoke-virtual {v5}, Landroid/app/NotificationChannel;->getId()Ljava/lang/String;

    move-result-object v5

    goto :goto_3b

    :cond_3a
    move-object v5, v1

    :goto_3b
    if-eqz v5, :cond_4e

    const-string v6, "fh_test_"

    .line 197
    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_4e

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_49
    .catchall {:try_start_13 .. :try_end_49} :catchall_51

    if-nez v6, :cond_4e

    .line 198
    :try_start_4b
    invoke-virtual {v0, v5}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_4e
    .catchall {:try_start_4b .. :try_end_4e} :catchall_4e

    :catchall_4e
    :cond_4e
    add-int/lit8 v4, v4, 0x1

    goto :goto_26

    :catchall_51
    :cond_51
    :goto_51
    :try_start_51
    const-string v2, "lesson"

    .line 204
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_56
    .catchall {:try_start_51 .. :try_end_56} :catchall_56

    :catchall_56
    :try_start_56
    const-string v2, "lesson_v2"

    .line 205
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_5b
    .catchall {:try_start_56 .. :try_end_5b} :catchall_5b

    :catchall_5b
    :try_start_5b
    const-string v2, "lesson_mute"

    .line 206
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_60
    .catchall {:try_start_5b .. :try_end_60} :catchall_60

    :catchall_60
    :try_start_60
    const-string v2, "lesson_mute2"

    .line 207
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_65
    .catchall {:try_start_60 .. :try_end_65} :catchall_65

    :catchall_65
    :try_start_65
    const-string v2, "lesson_v3"

    .line 208
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_6a
    .catchall {:try_start_65 .. :try_end_6a} :catchall_6a

    :catchall_6a
    :try_start_6a
    const-string v2, "lesson_mute3"

    .line 209
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->deleteNotificationChannel(Ljava/lang/String;)V
    :try_end_6f
    .catchall {:try_start_6a .. :try_end_6f} :catchall_6f

    .line 211
    :catchall_6f
    new-instance v2, Landroid/app/NotificationChannel;

    const-string v3, "lesson_v4"

    const-string v4, "\u041f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0456\u0432"

    const/4 v5, 0x4

    invoke-direct {v2, v3, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v3, "\u0421\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u043d\u044f \u043f\u0440\u043e \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0443 \u0437\u0456 \u0437\u0432\u0443\u043a\u043e\u043c"

    .line 212
    invoke-virtual {v2, v3}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const/4 v3, 0x1

    .line 214
    :try_start_7f
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 215
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v6, "android.resource://"

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "/"

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/high16 p0, 0x7f050000

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    .line 216
    new-instance v4, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v4}, Landroid/media/AudioAttributes$Builder;-><init>()V

    const/4 v6, 0x5

    .line 217
    invoke-virtual {v4, v6}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v4

    .line 218
    invoke-virtual {v4, v5}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v4

    .line 219
    invoke-virtual {v4}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v4

    .line 216
    invoke-virtual {v2, p0, v4}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V
    :try_end_b7
    .catchall {:try_start_7f .. :try_end_b7} :catchall_b8

    goto :goto_bb

    .line 221
    :catchall_b8
    invoke-virtual {v2, v3}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 223
    :goto_bb
    invoke-virtual {v2, v3}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 224
    invoke-virtual {v2, v3}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    .line 225
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 227
    new-instance p0, Landroid/app/NotificationChannel;

    const-string v2, "lesson_mute4"

    const-string v4, "\u041f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0456\u0432 (\u0431\u0435\u0437 \u0437\u0432\u0443\u043a\u0443)"

    invoke-direct {p0, v2, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v2, "\u0421\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u043d\u044f \u043f\u0440\u043e \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0443 \u0431\u0435\u0437 \u0437\u0432\u0443\u043a\u0443"

    .line 228
    invoke-virtual {p0, v2}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 229
    invoke-virtual {p0, v1, v1}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    .line 230
    invoke-virtual {p0, v3}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 231
    invoke-virtual {p0, v3}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    .line 232
    invoke-virtual {v0, p0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    :cond_de
    :goto_de
    return-void
.end method

.method public static getLog(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    .line 729
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "notiflog"

    const-string v1, "[]"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static handleJson(Landroid/content/Context;Ljava/lang/String;)V
    .registers 14

    const-string v0, "items"

    const-string v1, "skip"

    const-string v2, "off"

    const-string v3, "snd"

    const-string v4, "min"

    const-string v5, "on"

    if-nez p1, :cond_10

    const-string p1, "{}"

    .line 240
    :cond_10
    :try_start_10
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x0

    .line 241
    invoke-virtual {v6, v5, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v7

    const/4 v8, 0x5

    .line 243
    invoke-virtual {v6, v4, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9

    const/4 v10, 0x1

    if-lt v9, v10, :cond_27

    const/16 v11, 0xf

    if-gt v9, v11, :cond_27

    move v8, v9

    .line 245
    :cond_27
    invoke-virtual {v6, v3, v10}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v9

    .line 246
    invoke-virtual {v6, v2, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p1

    .line 247
    invoke-virtual {v6, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v10

    .line 248
    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    .line 249
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11, v5, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5, v4, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4, v3, v9}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_4f} :catch_6e

    const-string v2, "[]"

    if-nez v10, :cond_55

    move-object v3, v2

    goto :goto_59

    .line 250
    :cond_55
    :try_start_55
    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v3

    :goto_59
    invoke-interface {p1, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    if-nez v6, :cond_60

    goto :goto_64

    .line 251
    :cond_60
    invoke-virtual {v6}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_64
    invoke-interface {p1, v0, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 252
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->reschedule(Landroid/content/Context;)V
    :try_end_6e
    .catch Ljava/lang/Exception; {:try_start_55 .. :try_end_6e} :catch_6e

    :catch_6e
    return-void
.end method

.method static isDone(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x0

    .line 69
    :try_start_1
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "dn_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_1b

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1b

    return p1

    :catchall_1b
    :cond_1b
    return v0
.end method

.method private static largeIcon(Landroid/content/Context;)Landroid/graphics/Bitmap;
    .registers 6

    .line 689
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/pm/ApplicationInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    .line 690
    instance-of v0, p0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v0, :cond_17

    .line 691
    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    .line 693
    :cond_17
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 694
    new-instance v1, Landroid/graphics/Canvas;

    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 695
    invoke-virtual {v1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {p0, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 696
    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_42} :catch_43

    return-object v0

    :catch_43
    const/4 p0, 0x0

    return-object p0
.end method

.method static lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const-string v0, ""

    if-nez p2, :cond_5

    move-object p2, v0

    .line 58
    :cond_5
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x18

    if-le v1, v2, :cond_12

    const/4 v1, 0x0

    invoke-virtual {p2, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    .line 59
    :cond_12
    new-instance v1, Ljava/lang/StringBuilder;

    if-nez p0, :cond_17

    move-object p0, v0

    :cond_17
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p0, "|"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez p1, :cond_26

    move-object p1, v0

    :cond_26
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static logNotif(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    const-string v0, "notiflog"

    .line 705
    :try_start_2
    new-instance v1, Lorg/json/JSONArray;

    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "[]"

    invoke-interface {v2, v0, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 706
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "ts"

    .line 707
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v2, v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string v3, "tm"

    .line 709
    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v5, "HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v5, Ljava/util/Date;

    invoke-direct {v5}, Ljava/util/Date;-><init>()V

    invoke-virtual {v4, v5}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-eqz p1, :cond_40

    .line 710
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_42

    :cond_40
    const-string p1, "\u0423\u0440\u043e\u043a"

    :cond_42
    const-string v3, "n"

    .line 713
    invoke-virtual {v2, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-nez p2, :cond_4b

    const-string p2, ""

    :cond_4b
    const-string p1, "s"

    .line 717
    invoke-virtual {v2, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 718
    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    .line 719
    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 p2, 0x0

    .line 720
    :goto_59
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge p2, v2, :cond_6e

    const/16 v2, 0x1d

    if-lt p2, v2, :cond_64

    goto :goto_6e

    .line 721
    :cond_64
    invoke-virtual {v1, p2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 p2, p2, 0x1

    goto :goto_59

    .line 723
    :cond_6e
    :goto_6e
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-virtual {p1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_81
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_81} :catch_81

    :catch_81
    return-void
.end method

.method static markDone(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 73
    :try_start_0
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "dn_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_1e
    .catchall {:try_start_0 .. :try_end_1e} :catchall_1e

    :catchall_1e
    return-void
.end method

.method static markSnoozeUsed(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 81
    :try_start_0
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "sn_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_1e
    .catchall {:try_start_0 .. :try_end_1e} :catchall_1e

    :catchall_1e
    return-void
.end method

.method static p(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .registers 3

    const-string v0, "fh"

    const/4 v1, 0x0

    .line 48
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method public static reschedule(Landroid/content/Context;)V
    .registers 26

    move-object/from16 v8, p0

    const-string v0, "alarm"

    .line 276
    invoke-virtual {v8, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Landroid/app/AlarmManager;

    if-nez v9, :cond_e

    return-void

    .line 278
    :cond_e
    invoke-static {v9, v8}, Lcom/fluxhelper/app/Notifs;->cancelAlarms(Landroid/app/AlarmManager;Landroid/content/Context;)V

    .line 279
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "on"

    const/4 v10, 0x0

    .line 280
    invoke-interface {v0, v1, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_1f

    return-void

    :cond_1f
    const-string v1, "min"

    const/4 v2, 0x5

    .line 281
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v11

    const-string v1, "off"

    .line 282
    invoke-interface {v0, v1, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    .line 283
    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    const-string v4, ""

    const-string v5, "[]"

    if-nez v1, :cond_5a

    .line 286
    :try_start_37
    new-instance v6, Lorg/json/JSONArray;

    const-string v7, "skip"

    invoke-interface {v0, v7, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move v7, v10

    .line 287
    :goto_43
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v12

    if-lt v7, v12, :cond_4a

    goto :goto_5a

    .line 288
    :cond_4a
    invoke-virtual {v6, v7, v4}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 289
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_57

    invoke-virtual {v3, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_57} :catch_5a

    :cond_57
    add-int/lit8 v7, v7, 0x1

    goto :goto_43

    .line 294
    :catch_5a
    :cond_5a
    :goto_5a
    :try_start_5a
    new-instance v6, Lorg/json/JSONArray;

    const-string v7, "items"

    invoke-interface {v0, v7, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v6, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 295
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    .line 297
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 298
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    move v5, v10

    :goto_73
    const/16 v7, 0x10

    const/4 v15, 0x1

    if-lt v5, v7, :cond_c9

    .line 324
    invoke-virtual {v14}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7f

    return-void

    .line 326
    :cond_7f
    new-instance v0, Lcom/fluxhelper/app/Notifs$1;

    invoke-direct {v0}, Lcom/fluxhelper/app/Notifs$1;-><init>()V

    invoke-static {v14, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 333
    invoke-virtual {v14, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/Object;

    .line 334
    aget-object v1, v0, v10

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    aget-object v0, v0, v15

    move-object v4, v0

    check-cast v4, Lorg/json/JSONObject;

    const/16 v6, 0x3e9

    const/4 v7, 0x1

    move-object/from16 v0, p0

    move-object v1, v9

    move v5, v11

    invoke-static/range {v0 .. v7}, Lcom/fluxhelper/app/Notifs;->scheduleOne(Landroid/content/Context;Landroid/app/AlarmManager;JLorg/json/JSONObject;IIZ)V

    .line 336
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v15, :cond_1e5

    .line 337
    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/Object;

    .line 338
    aget-object v1, v0, v10

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    aget-object v0, v0, v15

    move-object v4, v0

    check-cast v4, Lorg/json/JSONObject;

    const/16 v6, 0x3ee

    const/4 v7, 0x0

    move-object/from16 v0, p0

    move-object v1, v9

    move v5, v11

    invoke-static/range {v0 .. v7}, Lcom/fluxhelper/app/Notifs;->scheduleOne(Landroid/content/Context;Landroid/app/AlarmManager;JLorg/json/JSONObject;IIZ)V

    goto/16 :goto_1e5

    .line 300
    :cond_c9
    invoke-virtual {v0}, Ljava/util/Calendar;->clone()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Calendar;

    const/4 v2, 0x6

    .line 301
    invoke-virtual {v7, v2, v5}, Ljava/util/Calendar;->add(II)V

    if-nez v1, :cond_119

    .line 302
    invoke-virtual {v3}, Ljava/util/HashSet;->isEmpty()Z

    move-result v16

    if-nez v16, :cond_119

    .line 303
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v10, "%04d-%02d-%02d"

    const/4 v15, 0x3

    new-array v15, v15, [Ljava/lang/Object;

    move-object/from16 v19, v0

    const/4 v0, 0x1

    .line 304
    invoke-virtual {v7, v0}, Ljava/util/Calendar;->get(I)I

    move-result v18

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    const/16 v17, 0x0

    aput-object v18, v15, v17

    const/4 v0, 0x2

    invoke-virtual {v7, v0}, Ljava/util/Calendar;->get(I)I

    move-result v16

    const/16 v18, 0x1

    add-int/lit8 v16, v16, 0x1

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v15, v18

    const/4 v0, 0x5

    invoke-virtual {v7, v0}, Ljava/util/Calendar;->get(I)I

    move-result v20

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/16 v16, 0x2

    aput-object v0, v15, v16

    .line 303
    invoke-static {v2, v10, v15}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 305
    invoke-virtual {v3, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11b

    const/4 v10, 0x5

    goto :goto_12c

    :cond_119
    move-object/from16 v19, v0

    :cond_11b
    const/4 v0, 0x7

    .line 307
    invoke-virtual {v7, v0}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v10, 0x5

    add-int/2addr v2, v10

    rem-int/2addr v2, v0

    const/4 v0, 0x1

    add-int/2addr v2, v0

    const/4 v0, 0x0

    .line 308
    :goto_126
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v15

    if-lt v0, v15, :cond_134

    :goto_12c
    add-int/lit8 v5, v5, 0x1

    move v2, v10

    move-object/from16 v0, v19

    const/4 v10, 0x0

    goto/16 :goto_73

    .line 309
    :cond_134
    invoke-virtual {v6, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v15

    if-eqz v15, :cond_1cf

    const-string v10, "dow"

    move/from16 v20, v1

    const/4 v1, -0x1

    .line 310
    invoke-virtual {v15, v10, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    if-eq v1, v2, :cond_147

    goto/16 :goto_1d1

    :cond_147
    const-string v1, "t"

    .line 311
    invoke-virtual {v15, v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v10, ":"

    invoke-virtual {v1, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 312
    array-length v10, v1
    :try_end_154
    .catch Ljava/lang/Exception; {:try_start_5a .. :try_end_154} :catch_1e5

    move/from16 v21, v2

    const/4 v2, 0x2

    if-ge v10, v2, :cond_161

    move-object/from16 v22, v3

    move-object v10, v4

    const/4 v1, 0x1

    move v3, v2

    :goto_15e
    const/4 v2, 0x0

    goto/16 :goto_1d9

    .line 314
    :cond_161
    :try_start_161
    invoke-virtual {v7}, Ljava/util/Calendar;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Calendar;
    :try_end_167
    .catch Ljava/lang/Exception; {:try_start_161 .. :try_end_167} :catch_1d3

    const/4 v10, 0x0

    .line 315
    :try_start_168
    aget-object v22, v1, v10
    :try_end_16a
    .catch Ljava/lang/Exception; {:try_start_168 .. :try_end_16a} :catch_1c8

    :try_start_16a
    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10
    :try_end_172
    .catch Ljava/lang/Exception; {:try_start_16a .. :try_end_172} :catch_1d3

    move-object/from16 v22, v3

    const/16 v3, 0xb

    :try_start_176
    invoke-virtual {v2, v3, v10}, Ljava/util/Calendar;->set(II)V
    :try_end_179
    .catch Ljava/lang/Exception; {:try_start_176 .. :try_end_179} :catch_1d5

    const/4 v3, 0x1

    .line 316
    :try_start_17a
    aget-object v1, v1, v3
    :try_end_17c
    .catch Ljava/lang/Exception; {:try_start_17a .. :try_end_17c} :catch_1c5

    :try_start_17c
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    const/16 v3, 0xc

    invoke-virtual {v2, v3, v1}, Ljava/util/Calendar;->set(II)V
    :try_end_189
    .catch Ljava/lang/Exception; {:try_start_17c .. :try_end_189} :catch_1d5

    const/16 v1, 0xd

    const/4 v3, 0x0

    .line 317
    :try_start_18c
    invoke-virtual {v2, v1, v3}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xe

    .line 318
    invoke-virtual {v2, v1, v3}, Ljava/util/Calendar;->set(II)V
    :try_end_194
    .catch Ljava/lang/Exception; {:try_start_18c .. :try_end_194} :catch_1c1

    .line 319
    :try_start_194
    invoke-virtual {v2}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v1
    :try_end_198
    .catch Ljava/lang/Exception; {:try_start_194 .. :try_end_198} :catch_1d5

    const-wide/32 v23, 0xea60

    move-object v10, v4

    int-to-long v3, v11

    mul-long v3, v3, v23

    sub-long/2addr v1, v3

    move-object/from16 v3, v8

    move-object/from16 v4, v15

    invoke-static {v3, v4, v1, v2, v11}, Lcom/fluxhelper/app/Notifs;->calcAlarm(Landroid/content/Context;Lorg/json/JSONObject;JI)J

    move-result-wide v1

    cmp-long v3, v1, v12

    if-lez v3, :cond_1d6

    const/4 v3, 0x2

    :try_start_1ad
    new-array v4, v3, [Ljava/lang/Object;

    .line 320
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1
    :try_end_1b3
    .catch Ljava/lang/Exception; {:try_start_1ad .. :try_end_1b3} :catch_1bf

    const/4 v2, 0x0

    :try_start_1b4
    aput-object v1, v4, v2
    :try_end_1b6
    .catch Ljava/lang/Exception; {:try_start_1b4 .. :try_end_1b6} :catch_1bd

    const/4 v1, 0x1

    :try_start_1b7
    aput-object v15, v4, v1

    invoke-virtual {v14, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1bc
    .catch Ljava/lang/Exception; {:try_start_1b7 .. :try_end_1bc} :catch_1d9

    goto :goto_1d9

    :catch_1bd
    const/4 v1, 0x1

    goto :goto_1d9

    :catch_1bf
    const/4 v1, 0x1

    goto :goto_15e

    :catch_1c1
    move v2, v3

    move-object v10, v4

    const/4 v1, 0x1

    goto :goto_1d8

    :catch_1c5
    move v1, v3

    move-object v10, v4

    goto :goto_1d7

    :catch_1c8
    move-object/from16 v22, v3

    move v2, v10

    const/4 v1, 0x1

    const/4 v3, 0x2

    move-object v10, v4

    goto :goto_1d9

    :cond_1cf
    move/from16 v20, v1

    :goto_1d1
    move/from16 v21, v2

    :catch_1d3
    move-object/from16 v22, v3

    :catch_1d5
    move-object v10, v4

    :cond_1d6
    const/4 v1, 0x1

    :goto_1d7
    const/4 v2, 0x0

    :goto_1d8
    const/4 v3, 0x2

    :catch_1d9
    :goto_1d9
    add-int/lit8 v0, v0, 0x1

    move-object v4, v10

    move/from16 v1, v20

    move/from16 v2, v21

    move-object/from16 v3, v22

    const/4 v10, 0x5

    goto/16 :goto_126

    :catch_1e5
    :cond_1e5
    :goto_1e5
    return-void
.end method

.method static scheduleExpire(Landroid/content/Context;JI)V
    .registers 9

    :try_start_0
    const-string v0, "alarm"

    .line 163
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    if-nez v0, :cond_b

    return-void

    .line 165
    :cond_b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3a98

    add-long/2addr v1, v3

    cmp-long v3, p1, v1

    if-gez v3, :cond_17

    move-wide p1, v1

    .line 167
    :cond_17
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "fh.expire"

    .line 168
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string v2, "nid"

    .line 169
    invoke-virtual {v1, v2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v2, 0x7d3

    if-ne p3, v2, :cond_2f

    const/16 p3, 0x3f6

    goto :goto_31

    :cond_2f
    const/16 p3, 0x3f5

    :goto_31
    const/high16 v2, 0xc000000

    .line 170
    invoke-static {p0, p3, v1, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0
    :try_end_37
    .catchall {:try_start_0 .. :try_end_37} :catchall_3f

    const/4 p3, 0x0

    .line 172
    :try_start_38
    invoke-virtual {v0, p3, p1, p2, p0}, Landroid/app/AlarmManager;->setExactAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V
    :try_end_3b
    .catchall {:try_start_38 .. :try_end_3b} :catchall_3c

    goto :goto_3f

    .line 175
    :catchall_3c
    :try_start_3c
    invoke-virtual {v0, p3, p1, p2, p0}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V
    :try_end_3f
    .catchall {:try_start_3c .. :try_end_3f} :catchall_3f

    :catchall_3f
    :goto_3f
    return-void
.end method

.method private static scheduleOne(Landroid/content/Context;Landroid/app/AlarmManager;JLorg/json/JSONObject;IIZ)V
    .registers 12

    .line 344
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "n"

    const-string v2, "\u0423\u0440\u043e\u043a"

    .line 345
    invoke-virtual {p4, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "name"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "t"

    const-string v2, ""

    .line 346
    invoke-virtual {p4, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "time"

    invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "min"

    .line 347
    invoke-virtual {v0, v1, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string p5, "u"

    .line 348
    invoke-virtual {p4, p5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const-string p5, "url"

    invoke-virtual {v0, p5, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 p4, 0xc000000

    .line 349
    invoke-static {p0, p6, v0, p4}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p5

    if-eqz p7, :cond_53

    .line 352
    :try_start_39
    new-instance p6, Landroid/content/Intent;

    const-class p7, Lcom/fluxhelper/app/MainActivity;

    invoke-direct {p6, p0, p7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 p7, 0x30000000

    .line 353
    invoke-virtual {p6, p7}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 354
    new-instance p7, Landroid/app/AlarmManager$AlarmClockInfo;

    const/4 v0, 0x7

    invoke-static {p0, v0, p6, p4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    invoke-direct {p7, p2, p3, p0}, Landroid/app/AlarmManager$AlarmClockInfo;-><init>(JLandroid/app/PendingIntent;)V

    invoke-virtual {p1, p7, p5}, Landroid/app/AlarmManager;->setAlarmClock(Landroid/app/AlarmManager$AlarmClockInfo;Landroid/app/PendingIntent;)V
    :try_end_52
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_52} :catch_53

    return-void

    :catch_53
    :cond_53
    const/4 p0, 0x0

    .line 359
    :try_start_54
    invoke-virtual {p1, p0, p2, p3, p5}, Landroid/app/AlarmManager;->setExactAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V
    :try_end_57
    .catch Ljava/lang/SecurityException; {:try_start_54 .. :try_end_57} :catch_5c
    .catchall {:try_start_54 .. :try_end_57} :catchall_58

    goto :goto_5f

    .line 363
    :catchall_58
    :try_start_58
    invoke-virtual {p1, p0, p2, p3, p5}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    goto :goto_5f

    .line 361
    :catch_5c
    invoke-virtual {p1, p0, p2, p3, p5}, Landroid/app/AlarmManager;->setAndAllowWhileIdle(IJLandroid/app/PendingIntent;)V
    :try_end_5f
    .catchall {:try_start_58 .. :try_end_5f} :catchall_5f

    :catchall_5f
    :goto_5f
    return-void
.end method

.method public static show(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .registers 21

    move-object/from16 v13, p0

    move-object/from16 v14, p1

    move-object/from16 v15, p2

    const-string v0, "notification"

    .line 369
    invoke-virtual {v13, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/app/NotificationManager;

    if-eqz v1, :cond_107

    .line 370
    invoke-virtual {v1}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v0

    if-nez v0, :cond_19

    goto/16 :goto_107

    :cond_19
    const/4 v0, 0x1

    const/4 v2, 0x0

    :try_start_1b
    const-string v3, ":"

    .line 374
    invoke-virtual {v15, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 375
    aget-object v4, v3, v2

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    mul-int/lit8 v4, v4, 0x3c

    aget-object v3, v3, v0

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/2addr v4, v3

    .line 376
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v3

    const/16 v5, 0xb

    .line 377
    invoke-virtual {v3, v5}, Ljava/util/Calendar;->get(I)I

    move-result v5

    mul-int/lit8 v5, v5, 0x3c

    const/16 v6, 0xc

    invoke-virtual {v3, v6}, Ljava/util/Calendar;->get(I)I

    move-result v3
    :try_end_4a
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_4a} :catch_4e

    add-int/2addr v5, v3

    sub-int v3, v4, v5

    goto :goto_50

    :catch_4e
    move/from16 v3, p3

    :goto_50
    if-ltz v3, :cond_53

    goto :goto_54

    :cond_53
    move v3, v2

    :goto_54
    if-nez v3, :cond_59

    const-string v3, "\u043f\u043e\u0447\u0438\u043d\u0430\u0454\u0442\u044c\u0441\u044f \u0437\u0430\u0440\u0430\u0437"

    goto :goto_6c

    .line 384
    :cond_59
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "\u0447\u0435\u0440\u0435\u0437 "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " \u0445\u0432"

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 387
    :goto_6c
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lcom/fluxhelper/app/Notifs;->emojiFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " \u2014 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u043e "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " \u00b7 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 390
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v3, 0x5

    .line 395
    :try_start_af
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "min"

    invoke-interface {v6, v7, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3
    :try_end_b9
    .catchall {:try_start_af .. :try_end_b9} :catchall_b9

    .line 396
    :catchall_b9
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v15, v14}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-le v3, v0, :cond_cb

    .line 397
    invoke-static {v13, v6}, Lcom/fluxhelper/app/Notifs;->snoozeUsed(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_cb

    move v11, v0

    goto :goto_cc

    :cond_cb
    move v11, v2

    :goto_cc
    const/16 v2, 0x7d1

    const-string v3, "\u23f0 \u0421\u043a\u043e\u0440\u043e \u043f\u043e\u0447\u043d\u0435\u0442\u044c\u0441\u044f \u0443\u0440\u043e\u043a"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v12, 0x0

    move-object/from16 v0, p0

    move-object/from16 v6, p4

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    .line 403
    invoke-static/range {v0 .. v12}, Lcom/fluxhelper/app/Notifs;->showStd(Landroid/content/Context;Landroid/app/NotificationManager;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)I

    .line 404
    invoke-static/range {p0 .. p2}, Lcom/fluxhelper/app/Notifs;->logNotif(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 405
    :try_start_e1
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_d"

    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_t"

    invoke-interface {v0, v1, v15}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_n"

    if-nez v14, :cond_100

    const-string v2, ""

    move-object v14, v2

    :cond_100
    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_107
    .catchall {:try_start_e1 .. :try_end_107} :catchall_107

    :catchall_107
    :cond_107
    :goto_107
    return-void
.end method

.method public static showSnooze(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 22

    move-object/from16 v13, p0

    move-object/from16 v14, p2

    const-string v0, "notification"

    .line 656
    invoke-virtual {v13, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/app/NotificationManager;

    if-eqz v1, :cond_11d

    .line 657
    invoke-virtual {v1}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v0

    if-nez v0, :cond_17

    goto/16 :goto_11d

    .line 658
    :cond_17
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->ensureChannel(Landroid/content/Context;)V

    if-eqz p1, :cond_26

    .line 659
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_23

    goto :goto_26

    :cond_23
    move-object/from16 v15, p1

    goto :goto_29

    :cond_26
    :goto_26
    const-string v0, "\u0423\u0440\u043e\u043a"

    move-object v15, v0

    :goto_29
    const/4 v0, 0x0

    const/4 v2, 0x1

    :try_start_2b
    const-string v3, ":"

    .line 662
    invoke-virtual {v14, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 663
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v4

    .line 664
    aget-object v5, v3, v0

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    mul-int/lit8 v5, v5, 0x3c

    aget-object v3, v3, v2

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/2addr v5, v3

    const/16 v3, 0xb

    .line 665
    invoke-virtual {v4, v3}, Ljava/util/Calendar;->get(I)I

    move-result v3

    mul-int/lit8 v3, v3, 0x3c

    const/16 v6, 0xc

    invoke-virtual {v4, v6}, Ljava/util/Calendar;->get(I)I

    move-result v4
    :try_end_5a
    .catchall {:try_start_2b .. :try_end_5a} :catchall_5d

    add-int/2addr v3, v4

    sub-int/2addr v5, v3

    goto :goto_5e

    :catchall_5d
    move v5, v2

    :goto_5e
    if-gez v5, :cond_61

    goto :goto_62

    :cond_61
    move v0, v5

    :goto_62
    if-nez v0, :cond_67

    const-string v0, "\u043f\u043e\u0447\u0438\u043d\u0430\u0454\u0442\u044c\u0441\u044f \u0437\u0430\u0440\u0430\u0437"

    goto :goto_7f

    :cond_67
    if-ne v0, v2, :cond_6c

    const-string v0, "\u0447\u0435\u0440\u0435\u0437 1 \u0445\u0432\u0438\u043b\u0438\u043d\u0443"

    goto :goto_7f

    .line 669
    :cond_6c
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\u0447\u0435\u0440\u0435\u0437 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " \u0445\u0432"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 670
    :goto_7f
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v15}, Lcom/fluxhelper/app/Notifs;->emojiFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " \u2014 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u043e "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " (\u0442\u0435\u0441\u0442)"

    const-string v16, ""

    if-eqz p4, :cond_ac

    move-object v5, v4

    goto :goto_ae

    :cond_ac
    move-object/from16 v5, v16

    .line 671
    :goto_ae
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 670
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 672
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v15}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p4, :cond_cd

    goto :goto_cf

    :cond_cd
    move-object/from16 v4, v16

    :goto_cf
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    if-eqz p4, :cond_db

    const/16 v0, 0x7d3

    goto :goto_dd

    :cond_db
    const/16 v0, 0x7d1

    :goto_dd
    move v2, v0

    const-string v3, "\u041d\u0430\u0433\u0430\u0434\u0443\u0432\u0430\u043d\u043d\u044f \u043f\u0440\u043e \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0443 \u0437\u0430 \u043e\u0434\u043d\u0443 \u0445\u0432\u0438\u043b\u0438\u043d\u0443"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v0, p0

    move-object v4, v5

    move-object v5, v6

    move-object/from16 v6, p3

    move-object v7, v15

    move-object/from16 v8, p2

    move/from16 v12, p4

    .line 673
    invoke-static/range {v0 .. v12}, Lcom/fluxhelper/app/Notifs;->showStd(Landroid/content/Context;Landroid/app/NotificationManager;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)I

    if-nez p4, :cond_11d

    .line 679
    :try_start_f3
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_d"

    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_t"

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ln_n"

    if-nez v15, :cond_112

    move-object/from16 v2, v16

    goto :goto_113

    :cond_112
    move-object v2, v15

    :goto_113
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_11a
    .catchall {:try_start_f3 .. :try_end_11a} :catchall_11a

    .line 680
    :catchall_11a
    invoke-static {v13, v15, v14}, Lcom/fluxhelper/app/Notifs;->logNotif(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_11d
    :goto_11d
    return-void
.end method

.method private static showStd(Landroid/content/Context;Landroid/app/NotificationManager;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)I
    .registers 29

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    move-object/from16 v4, p6

    move-object/from16 v5, p7

    move-object/from16 v6, p8

    move/from16 v7, p12

    if-eqz p9, :cond_15

    move-object/from16 v8, p9

    goto :goto_20

    .line 498
    :cond_15
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->soundOn(Landroid/content/Context;)Z

    move-result v8

    if-eqz v8, :cond_1e

    const-string v8, "lesson_v4"

    goto :goto_20

    :cond_1e
    const-string v8, "lesson_mute4"

    .line 500
    :goto_20
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v10, 0x1a

    if-lt v9, v10, :cond_2c

    .line 501
    new-instance v9, Landroid/app/Notification$Builder;

    invoke-direct {v9, v0, v8}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_40

    .line 503
    :cond_2c
    new-instance v9, Landroid/app/Notification$Builder;

    invoke-direct {v9, v0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    if-eqz p9, :cond_36

    if-eqz p10, :cond_40

    goto :goto_3c

    .line 504
    :cond_36
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->soundOn(Landroid/content/Context;)Z

    move-result v8

    if-eqz v8, :cond_40

    :goto_3c
    const/4 v8, 0x3

    .line 505
    invoke-virtual {v9, v8}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    :cond_40
    :goto_40
    const/high16 v8, 0x7f010000

    .line 510
    invoke-virtual {v9, v8}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 511
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-virtual {v9, v10, v11}, Landroid/app/Notification$Builder;->setWhen(J)Landroid/app/Notification$Builder;

    const/4 v10, 0x1

    .line 512
    invoke-virtual {v9, v10}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    xor-int/lit8 v11, v7, 0x1

    .line 517
    invoke-virtual {v9, v11}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 518
    invoke-virtual {v9, v7}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    if-eqz v7, :cond_5d

    const-string v11, "event"

    goto :goto_5f

    :cond_5d
    const-string v11, "alarm"

    .line 519
    :goto_5f
    invoke-virtual {v9, v11}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    const/4 v11, 0x2

    .line 520
    :try_start_63
    invoke-virtual {v9, v11}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;
    :try_end_66
    .catchall {:try_start_63 .. :try_end_66} :catchall_66

    .line 521
    :catchall_66
    :try_start_66
    invoke-virtual {v9, v10}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;
    :try_end_69
    .catchall {:try_start_66 .. :try_end_69} :catchall_69

    :catchall_69
    const v11, -0x83c513

    const/4 v12, 0x0

    .line 522
    :try_start_6d
    invoke-virtual {v9, v11}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;

    invoke-virtual {v9, v12}, Landroid/app/Notification$Builder;->setColorized(Z)Landroid/app/Notification$Builder;
    :try_end_73
    .catchall {:try_start_6d .. :try_end_73} :catchall_73

    .line 524
    :catchall_73
    new-instance v11, Landroid/content/Intent;

    const-class v13, Lcom/fluxhelper/app/MainActivity;

    invoke-direct {v11, v0, v13}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v13, 0x30000000

    invoke-virtual {v11, v13}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    move-result-object v11

    const/4 v13, 0x7

    const/high16 v14, 0xc000000

    .line 523
    invoke-static {v0, v13, v11, v14}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    if-eqz v2, :cond_95

    .line 528
    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->length()I

    move-result v11

    if-lez v11, :cond_95

    invoke-virtual {v9, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :cond_95
    if-eqz v3, :cond_a0

    .line 529
    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_a0

    invoke-virtual {v9, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :cond_a0
    const/4 v2, 0x0

    if-eqz v3, :cond_10e

    .line 560
    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->length()I

    move-result v11

    if-lez v11, :cond_10e

    if-eqz v5, :cond_b4

    .line 563
    :try_start_ab
    invoke-virtual/range {p7 .. p7}, Ljava/lang/String;->length()I

    move-result v11

    if-nez v11, :cond_b2

    goto :goto_b4

    :cond_b2
    move-object v11, v5

    goto :goto_b6

    :cond_b4
    :goto_b4
    const-string v11, "\u0423\u0440\u043e\u043a"

    .line 564
    :goto_b6
    sget v13, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v15, 0x1c

    if-lt v13, v15, :cond_fd

    .line 565
    new-instance v13, Landroid/app/Person$Builder;

    invoke-direct {v13}, Landroid/app/Person$Builder;-><init>()V

    const-string v15, "\u0423\u0447\u0435\u043d\u044c"

    .line 566
    invoke-virtual {v13, v15}, Landroid/app/Person$Builder;->setName(Ljava/lang/CharSequence;)Landroid/app/Person$Builder;

    move-result-object v13

    const-string v15, "fh.me"

    invoke-virtual {v13, v15}, Landroid/app/Person$Builder;->setKey(Ljava/lang/String;)Landroid/app/Person$Builder;

    move-result-object v13

    invoke-virtual {v13}, Landroid/app/Person$Builder;->build()Landroid/app/Person;

    move-result-object v13

    .line 567
    new-instance v15, Landroid/app/Person$Builder;

    invoke-direct {v15}, Landroid/app/Person$Builder;-><init>()V

    .line 568
    invoke-virtual {v15, v11}, Landroid/app/Person$Builder;->setName(Ljava/lang/CharSequence;)Landroid/app/Person$Builder;

    move-result-object v11

    .line 569
    invoke-static/range {p0 .. p0}, Lcom/fluxhelper/app/Notifs;->largeIcon(Landroid/content/Context;)Landroid/graphics/Bitmap;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/drawable/Icon;->createWithBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;

    move-result-object v15

    invoke-virtual {v11, v15}, Landroid/app/Person$Builder;->setIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Person$Builder;

    move-result-object v11

    const-string v15, "fh.lesson"

    .line 570
    invoke-virtual {v11, v15}, Landroid/app/Person$Builder;->setKey(Ljava/lang/String;)Landroid/app/Person$Builder;

    move-result-object v11

    invoke-virtual {v11}, Landroid/app/Person$Builder;->build()Landroid/app/Person;

    move-result-object v11

    .line 571
    new-instance v15, Landroid/app/Notification$MessagingStyle;

    invoke-direct {v15, v13}, Landroid/app/Notification$MessagingStyle;-><init>(Landroid/app/Person;)V

    .line 572
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-virtual {v15, v3, v12, v13, v11}, Landroid/app/Notification$MessagingStyle;->addMessage(Ljava/lang/CharSequence;JLandroid/app/Person;)Landroid/app/Notification$MessagingStyle;

    goto :goto_109

    .line 574
    :cond_fd
    new-instance v15, Landroid/app/Notification$MessagingStyle;

    invoke-direct {v15, v11}, Landroid/app/Notification$MessagingStyle;-><init>(Ljava/lang/CharSequence;)V

    .line 575
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    invoke-virtual {v15, v3, v11, v12, v2}, Landroid/app/Notification$MessagingStyle;->addMessage(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)Landroid/app/Notification$MessagingStyle;

    .line 577
    :goto_109
    invoke-virtual {v9, v15}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;
    :try_end_10c
    .catchall {:try_start_ab .. :try_end_10c} :catchall_10e

    move v11, v10

    goto :goto_10f

    :catchall_10e
    :cond_10e
    const/4 v11, 0x0

    :goto_10f
    const-string v12, ""

    if-nez v11, :cond_122

    .line 582
    :try_start_113
    new-instance v11, Landroid/app/Notification$BigTextStyle;

    invoke-direct {v11}, Landroid/app/Notification$BigTextStyle;-><init>()V

    if-nez v3, :cond_11b

    move-object v3, v12

    :cond_11b
    invoke-virtual {v11, v3}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object v3

    invoke-virtual {v9, v3}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;
    :try_end_122
    .catchall {:try_start_113 .. :try_end_122} :catchall_122

    :catchall_122
    :cond_122
    const-string v3, "time"

    const-string v11, "name"

    const-string v13, "url"

    if-eqz v4, :cond_16b

    .line 588
    invoke-virtual/range {p6 .. p6}, Ljava/lang/String;->length()I

    move-result v15

    const/16 v2, 0x8

    if-le v15, v2, :cond_16b

    const-string v2, "http"

    invoke-virtual {v4, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16b

    .line 590
    :try_start_13a
    new-instance v2, Landroid/content/Intent;

    const-class v15, Lcom/fluxhelper/app/MainActivity;

    invoke-direct {v2, v0, v15}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v15, "fh.join"

    .line 591
    invoke-virtual {v2, v15}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 592
    invoke-virtual {v2, v13, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v5, :cond_14e

    .line 593
    invoke-virtual {v2, v11, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_14e
    if-eqz v6, :cond_153

    .line 594
    invoke-virtual {v2, v3, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_153
    if-eqz v7, :cond_15a

    const-string v15, "test"

    .line 595
    invoke-virtual {v2, v15, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :cond_15a
    const/high16 v15, 0x34000000

    .line 596
    invoke-virtual {v2, v15}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    if-eqz v7, :cond_164

    const/16 v15, 0x3f4

    goto :goto_166

    :cond_164
    const/16 v15, 0x3ea

    .line 597
    :goto_166
    invoke-static {v0, v15, v2, v14}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2
    :try_end_16a
    .catchall {:try_start_13a .. :try_end_16a} :catchall_16b

    goto :goto_16c

    :catchall_16b
    :cond_16b
    const/4 v2, 0x0

    :goto_16c
    if-eqz p11, :cond_1a8

    if-eqz v5, :cond_1a8

    .line 601
    invoke-virtual/range {p7 .. p7}, Ljava/lang/String;->length()I

    move-result v15

    if-lez v15, :cond_1a8

    if-eqz v6, :cond_1a8

    invoke-virtual/range {p8 .. p8}, Ljava/lang/String;->length()I

    move-result v15

    const/4 v10, 0x4

    if-lt v15, v10, :cond_1a8

    .line 603
    :try_start_17f
    new-instance v10, Landroid/content/Intent;

    const-class v15, Lcom/fluxhelper/app/NotifReceiver;

    invoke-direct {v10, v0, v15}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    if-eqz v7, :cond_18b

    const-string v15, "fh.tsnooze"

    goto :goto_18d

    :cond_18b
    const-string v15, "fh.snooze"

    .line 604
    :goto_18d
    invoke-virtual {v10, v15}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 605
    invoke-virtual {v10, v11, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 606
    invoke-virtual {v10, v3, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-nez v4, :cond_199

    move-object v4, v12

    .line 607
    :cond_199
    invoke-virtual {v10, v13, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v7, :cond_1a1

    const/16 v3, 0x3f7

    goto :goto_1a3

    :cond_1a1
    const/16 v3, 0x3ec

    .line 611
    :goto_1a3
    invoke-static {v0, v3, v10, v14}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v3
    :try_end_1a7
    .catchall {:try_start_17f .. :try_end_1a7} :catchall_1a8

    goto :goto_1a9

    :catchall_1a8
    :cond_1a8
    const/4 v3, 0x0

    :goto_1a9
    if-eqz v2, :cond_1b0

    const-string v4, "\u0417\u0430\u0439\u0442\u0438 \u043d\u0430 \u0443\u0440\u043e\u043a"

    .line 614
    invoke-virtual {v9, v8, v4, v2}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    :cond_1b0
    if-eqz v3, :cond_1b7

    const-string v2, "\u041d\u0430\u0433\u0430\u0434\u0430\u0442\u0438 \u0437\u0430 1 \u0445\u0432"

    .line 615
    invoke-virtual {v9, v8, v2, v3}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 619
    :cond_1b7
    :try_start_1b7
    invoke-virtual {v9}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v2

    move-object/from16 v3, p1

    invoke-virtual {v3, v1, v2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V
    :try_end_1c0
    .catch Ljava/lang/Exception; {:try_start_1b7 .. :try_end_1c0} :catch_1c2

    const/4 v2, 0x1

    goto :goto_1c3

    :catch_1c2
    const/4 v2, 0x0

    :goto_1c3
    const/4 v3, 0x1

    if-ne v2, v3, :cond_223

    if-eqz v7, :cond_21c

    if-nez v6, :cond_1cb

    move-object v6, v12

    :cond_1cb
    :try_start_1cb
    const-string v3, ":"

    .line 631
    invoke-virtual {v6, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 632
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v4

    const/4 v5, 0x0

    .line 633
    aget-object v6, v3, v5

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0xb

    invoke-virtual {v4, v6, v5}, Ljava/util/Calendar;->set(II)V

    const/4 v5, 0x1

    .line 634
    aget-object v3, v3, v5

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/16 v5, 0xc

    invoke-virtual {v4, v5, v3}, Ljava/util/Calendar;->set(II)V

    const/16 v3, 0xd

    const/4 v5, 0x0

    .line 635
    invoke-virtual {v4, v3, v5}, Ljava/util/Calendar;->set(II)V

    const/16 v3, 0xe

    .line 636
    invoke-virtual {v4, v3, v5}, Ljava/util/Calendar;->set(II)V

    .line 637
    invoke-virtual {v4}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v3
    :try_end_204
    .catchall {:try_start_1cb .. :try_end_204} :catchall_209

    const-wide/32 v5, 0x2932e0

    add-long/2addr v3, v5

    goto :goto_20b

    :catchall_209
    const-wide/16 v3, 0x0

    .line 639
    :goto_20b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    cmp-long v5, v3, v5

    if-gtz v5, :cond_220

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const-wide/32 v5, 0xea60

    add-long/2addr v3, v5

    goto :goto_220

    .line 641
    :cond_21c
    invoke-static {v0, v5, v6}, Lcom/fluxhelper/app/Notifs;->endMillisFor(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)J

    move-result-wide v3

    .line 643
    :cond_220
    :goto_220
    invoke-static {v0, v3, v4, v1}, Lcom/fluxhelper/app/Notifs;->scheduleExpire(Landroid/content/Context;JI)V

    :cond_223
    return v2
.end method

.method public static showTest(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Z)I
    .registers 21

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v0, ""

    .line 763
    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    const-string v0, "notification"

    move-object v3, p0

    .line 764
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Landroid/app/NotificationManager;

    const/4 v14, 0x0

    if-nez v4, :cond_1a

    const-string v0, "\u0441\u0438\u0441\u0442\u0435\u043c\u0430 \u0441\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"

    .line 765
    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    return v14

    .line 766
    :cond_1a
    invoke-virtual {v4}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v0

    if-nez v0, :cond_25

    const-string v0, "\u0441\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u043d\u044f \u0432\u0438\u043c\u043a\u043d\u0435\u043d\u043e \u0432 Android"

    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    return v14

    .line 767
    :cond_25
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->ensureChannel(Landroid/content/Context;)V

    if-eqz p5, :cond_2d

    const-string v0, "lesson_v4"

    goto :goto_2f

    :cond_2d
    const-string v0, "lesson_mute4"

    :goto_2f
    move-object v10, v0

    .line 769
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1a

    if-lt v0, v5, :cond_61

    .line 771
    :try_start_36
    invoke-virtual {v4, v10}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v0

    if-eqz v0, :cond_42

    .line 772
    invoke-virtual {v0}, Landroid/app/NotificationChannel;->getImportance()I

    move-result v0

    if-nez v0, :cond_61

    :cond_42
    const-string v0, "\u043a\u0430\u043d\u0430\u043b \u00ab\u041f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0456\u0432\u00bb \u0432\u0438\u043c\u043a\u043d\u0435\u043d\u043e"

    .line 773
    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;
    :try_end_46
    .catchall {:try_start_36 .. :try_end_46} :catchall_48

    const/4 v0, -0x1

    return v0

    :catchall_48
    move-exception v0

    .line 776
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "\u043a\u0430\u043d\u0430\u043b \u043d\u0435 \u0447\u0438\u0442\u0430\u0454\u0442\u044c\u0441\u044f: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    :cond_61
    if-eqz p1, :cond_6d

    .line 778
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_6a

    goto :goto_6d

    :cond_6a
    move-object/from16 v8, p1

    goto :goto_70

    :cond_6d
    :goto_6d
    const-string v0, "\u0423\u0440\u043e\u043a"

    move-object v8, v0

    :goto_70
    const/4 v0, 0x5

    if-eqz v1, :cond_7b

    const-string v5, "^\\d{1,2}:\\d{2}$"

    .line 781
    invoke-virtual {v1, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a2

    .line 782
    :cond_7b
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    const/16 v5, 0xc

    .line 783
    invoke-virtual {v1, v5, v0}, Ljava/util/Calendar;->add(II)V

    .line 784
    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/16 v7, 0xb

    invoke-virtual {v1, v7}, Ljava/util/Calendar;->get(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v1, v5}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v7, v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v5, "%02d:%02d"

    invoke-static {v6, v5, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    :cond_a2
    move-object v9, v1

    const/4 v1, 0x1

    if-lt v2, v1, :cond_ac

    const/16 v5, 0xf

    if-le v2, v5, :cond_ab

    goto :goto_ac

    :cond_ab
    move v0, v2

    .line 788
    :cond_ac
    :goto_ac
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v8}, Lcom/fluxhelper/app/Notifs;->emojiFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, " "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " \u2014 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u043e "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " \u00b7 \u0447\u0435\u0440\u0435\u0437 "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, " \u0445\u0432 (\u0442\u0435\u0441\u0442)"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 789
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v2, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v11, " \u00b7 "

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v5, "\u23f0 \u0421\u043a\u043e\u0440\u043e \u043f\u043e\u0447\u043d\u0435\u0442\u044c\u0441\u044f \u0443\u0440\u043e\u043a"

    if-le v0, v1, :cond_fe

    move v12, v1

    goto :goto_ff

    :cond_fe
    move v12, v14

    :goto_ff
    const/16 v0, 0x7d3

    const/4 v13, 0x1

    move-object v1, p0

    move-object v2, v4

    move v3, v0

    move-object v4, v5

    move-object v5, v7

    move-object/from16 v7, p4

    move/from16 v11, p5

    .line 798
    :try_start_10b
    invoke-static/range {v1 .. v13}, Lcom/fluxhelper/app/Notifs;->showStd(Landroid/content/Context;Landroid/app/NotificationManager;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)I

    move-result v0
    :try_end_10f
    .catchall {:try_start_10b .. :try_end_10f} :catchall_110

    return v0

    :catchall_110
    move-exception v0

    move-object v1, v0

    .line 800
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_128

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_123

    goto :goto_128

    .line 801
    :cond_123
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    goto :goto_130

    :cond_128
    :goto_128
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    .line 800
    :goto_130
    sput-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    return v14
.end method

.method static snoozeUsed(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x0

    .line 77
    :try_start_1
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "sn_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_1b

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1b

    return p1

    :catchall_1b
    :cond_1b
    return v0
.end method

.method static soundOn(Landroid/content/Context;)Z
    .registers 3

    .line 181
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->p(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "snd"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method static todayStr()Ljava/lang/String;
    .registers 5

    .line 63
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 64
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v2, 0x1

    .line 65
    invoke-virtual {v0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v4

    add-int/2addr v4, v2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x5

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v3, v2, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v2, "%04d-%02d-%02d"

    .line 64
    invoke-static {v1, v2, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
