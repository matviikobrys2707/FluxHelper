.class Lcom/fluxhelper/app/MainActivity$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;

.field private final synthetic val$wv16:Landroid/webkit/WebView;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;Landroid/webkit/WebView;)V
    .registers 3

    .line 177
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$2;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$2;->val$wv16:Landroid/webkit/WebView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .registers 6

    const/4 p1, 0x0

    .line 182
    :try_start_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_19

    .line 183
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v0

    invoke-static {}, Landroid/view/WindowInsets$Type;->displayCutout()I

    move-result v1

    or-int/2addr v0, v1

    invoke-virtual {p2, v0}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v0

    .line 184
    iget v1, v0, Landroid/graphics/Insets;->top:I
    :try_end_16
    .catchall {:try_start_1 .. :try_end_16} :catchall_22

    .line 185
    :try_start_16
    iget p1, v0, Landroid/graphics/Insets;->bottom:I
    :try_end_18
    .catchall {:try_start_16 .. :try_end_18} :catchall_23

    goto :goto_23

    .line 187
    :cond_19
    :try_start_19
    invoke-virtual {p2}, Landroid/view/WindowInsets;->getSystemWindowInsetTop()I

    move-result v1
    :try_end_1d
    .catchall {:try_start_19 .. :try_end_1d} :catchall_22

    .line 188
    :try_start_1d
    invoke-virtual {p2}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    move-result p1
    :try_end_21
    .catchall {:try_start_1d .. :try_end_21} :catchall_23

    goto :goto_23

    :catchall_22
    move v1, p1

    .line 191
    :catchall_23
    :goto_23
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$2;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput v1, v0, Lcom/fluxhelper/app/MainActivity;->lastInsTop:I

    .line 192
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$2;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput p1, v0, Lcom/fluxhelper/app/MainActivity;->lastInsBot:I

    .line 193
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$2;->this$0:Lcom/fluxhelper/app/MainActivity;

    iget-object v2, p0, Lcom/fluxhelper/app/MainActivity$2;->val$wv16:Landroid/webkit/WebView;

    invoke-virtual {v0, v2, v1, p1}, Lcom/fluxhelper/app/MainActivity;->injectInsets(Landroid/webkit/WebView;II)V

    .line 194
    invoke-virtual {p2}, Landroid/view/WindowInsets;->consumeSystemWindowInsets()Landroid/view/WindowInsets;

    move-result-object p1

    return-object p1
.end method
