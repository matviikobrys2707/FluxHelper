.class public Lcom/fluxhelper/app/MainActivity$Host;
.super Ljava/lang/Object;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fluxhelper/app/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "Host"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;


# direct methods
.method public constructor <init>(Lcom/fluxhelper/app/MainActivity;)V
    .registers 2

    .line 836
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;
    .registers 1

    .line 835
    iget-object p0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    return-object p0
.end method


# virtual methods
.method public canInstall()Z
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1116
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v2, 0x1

    if-ge v0, v1, :cond_8

    return v2

    .line 1120
    :cond_8
    :try_start_8
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/pm/PackageManager;->canRequestPackageInstalls()Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_12} :catch_13

    return v0

    :catch_13
    return v2
.end method

.method public cfq(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1073
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$4;

    invoke-direct {v1, p0, p2, p1}, Lcom/fluxhelper/app/MainActivity$Host$4;-><init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 1082
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public copy(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    if-eqz p1, :cond_18

    .line 897
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v1, "clipboard"

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    if-nez v0, :cond_f

    goto :goto_18

    :cond_f
    const-string v1, "FluxHelper"

    .line 900
    invoke-static {v1, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    :cond_18
    :goto_18
    return-void
.end method

.method public devInfo()Ljava/lang/String;
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1111
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity;->devInfoJson()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public fbDel(Ljava/lang/String;)Z
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "DELETE"

    const/4 v1, 0x0

    .line 1068
    invoke-static {v0, p1, v1}, Lcom/fluxhelper/app/FbWrite;->exec(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public fbPut(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "PUT"

    .line 1063
    invoke-static {v0, p1, p2}, Lcom/fluxhelper/app/FbWrite;->exec(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public getNotifLog()Ljava/lang/String;
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1106
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {v0}, Lcom/fluxhelper/app/Notifs;->getLog(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hasNotifPerm()Z
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 910
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_14

    .line 911
    invoke-virtual {v0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v0, 0x1

    return v0

    :cond_14
    const/4 v0, 0x0

    return v0
.end method

.method public login(Ljava/lang/String;)V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    :try_start_0
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    # invokes: Lcom/fluxhelper/app/MainActivity;->startGoogleLogin(Ljava/lang/String;)V
    invoke-static {v0, p1}, Lcom/fluxhelper/app/MainActivity;->access$0(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_0 .. :try_end_5} :catchall_6

    goto :goto_7

    :catchall_6
    move-exception v0

    :goto_7
    return-void
.end method

.method public loginLast(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    :try_start_0
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    # invokes: Lcom/fluxhelper/app/MainActivity;->loginLastDirect(Ljava/lang/String;Ljava/lang/String;)V
    invoke-static {v0, p1, p2}, Lcom/fluxhelper/app/MainActivity;->access$21(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_0 .. :try_end_5} :catchall_6

    goto :goto_7

    :catchall_6
    move-exception v0

    :goto_7
    return-void
.end method

.method public logout()V
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 865
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    # invokes: Lcom/fluxhelper/app/MainActivity;->googleLogout()V
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$1(Lcom/fluxhelper/app/MainActivity;)V

    return-void
.end method

.method public markLesson(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    if-eqz p1, :cond_1f

    .line 874
    :try_start_2
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1f

    if-eqz p2, :cond_1f

    const-string v0, "^\\d{1,2}:\\d{2}$"

    invoke-virtual {p2, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 875
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, p2, p1}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/fluxhelper/app/Notifs;->markDone(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1f
    .catchall {:try_start_2 .. :try_end_1f} :catchall_1f

    :catchall_1f
    :cond_1f
    return-void
.end method

.method public open(Ljava/lang/String;)V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    if-eqz p1, :cond_10

    const-string v0, "file://"

    .line 850
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    goto :goto_10

    .line 853
    :cond_b
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0, p1}, Lcom/fluxhelper/app/MainActivity;->openExternal(Ljava/lang/String;)V

    :cond_10
    :goto_10
    return-void
.end method

.method public openChannelSet(Ljava/lang/String;)V
    .registers 4

    .line 1043
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$3;

    invoke-direct {v1, p0, p1}, Lcom/fluxhelper/app/MainActivity$Host$3;-><init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public openInstallSettings()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1128
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$6;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$Host$6;-><init>(Lcom/fluxhelper/app/MainActivity$Host;)V

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public openNotifSet()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 921
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$1;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$Host$1;-><init>(Lcom/fluxhelper/app/MainActivity$Host;)V

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public prewarm()V
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 891
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    # invokes: Lcom/fluxhelper/app/MainActivity;->prewarmCred()V
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$2(Lcom/fluxhelper/app/MainActivity;)V

    return-void
.end method

.method public requestNotifPerm()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 943
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$2;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$Host$2;-><init>(Lcom/fluxhelper/app/MainActivity$Host;)V

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public setNotif(Ljava/lang/String;)V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 905
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {v0, p1}, Lcom/fluxhelper/app/Notifs;->handleJson(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public testNotif(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 20
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    move-object v1, p0

    const-string v0, "notification"

    const-string v2, ")"

    const-string v3, "\u041f\u041e\u041c\u0418\u041b\u041a\u0410 \u0442\u0435\u0441\u0442\u0443: "

    const-string v4, "typeof toast===\'function\'&&toast("

    const/4 v5, 0x5

    .line 986
    :try_start_a
    invoke-static/range {p3 .. p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6
    :try_end_16
    .catchall {:try_start_a .. :try_end_16} :catchall_17

    goto :goto_18

    :catchall_17
    move v6, v5

    :goto_18
    const/4 v7, 0x1

    if-lt v6, v7, :cond_22

    const/16 v8, 0xf

    if-le v6, v8, :cond_20

    goto :goto_22

    :cond_20
    move v12, v6

    goto :goto_23

    :cond_22
    :goto_22
    move v12, v5

    :goto_23
    :try_start_23
    const-string v5, "0"

    .line 988
    invoke-static/range {p4 .. p4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_32

    const/4 v5, 0x0

    move v14, v5

    goto :goto_33

    :cond_32
    move v14, v7

    .line 989
    :goto_33
    iget-object v5, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v5, v0}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/NotificationManager;

    if-eqz v5, :cond_10a

    .line 990
    invoke-virtual {v5}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v5

    if-nez v5, :cond_45

    goto/16 :goto_10a

    .line 1002
    :cond_45
    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v5

    const-wide v8, 0x41b7d783ff000000L    # 3.99999999E8

    mul-double/2addr v5, v8

    double-to-long v5, v5

    const-wide/32 v8, 0x23c34600

    add-long/2addr v5, v8

    .line 1003
    iget-object v9, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v10, "https://us05web.zoom.us/j/"

    invoke-direct {v8, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    invoke-static/range {v9 .. v14}, Lcom/fluxhelper/app/Notifs;->showTest(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Z)I

    move-result v5
    :try_end_6c
    .catchall {:try_start_23 .. :try_end_6c} :catchall_115

    const-string v6, "lesson_v4"

    const-string v8, "lesson_mute4"

    if-ne v5, v7, :cond_b5

    .line 1008
    :try_start_72
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_74
    .catchall {:try_start_72 .. :try_end_74} :catchall_115

    const/16 v7, 0x1a

    if-lt v5, v7, :cond_ac

    .line 1010
    :try_start_78
    iget-object v5, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v5, v0}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 1011
    iget-object v5, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {v5}, Lcom/fluxhelper/app/Notifs;->soundOn(Landroid/content/Context;)Z

    move-result v5

    if-eqz v5, :cond_8a

    move-object v5, v6

    goto :goto_8b

    :cond_8a
    move-object v5, v8

    :goto_8b
    invoke-virtual {v0, v5}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v0

    if-eqz v0, :cond_ac

    .line 1012
    invoke-virtual {v0}, Landroid/app/NotificationChannel;->getImportance()I

    move-result v0

    if-nez v0, :cond_ac

    .line 1013
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {v0}, Lcom/fluxhelper/app/Notifs;->soundOn(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_a0

    goto :goto_a1

    :cond_a0
    move-object v6, v8

    :goto_a1
    invoke-virtual {p0, v6}, Lcom/fluxhelper/app/MainActivity$Host;->openChannelSet(Ljava/lang/String;)V

    .line 1014
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v5, "typeof toast===\'function\'&&toast(\'\u0422\u0435\u0441\u0442 \u043f\u043e\u043a\u0430\u0437\u0430\u043d\u043e, \u0410\u041b\u0415 \u043a\u0430\u043d\u0430\u043b \u0443\u0440\u043e\u043a\u0456\u0432 \u0432\u0438\u043c\u043a\u043d\u0435\u043d\u043e \u2014 \u0443\u0432\u0456\u043c\u043a\u043d\u0438 \u00ab\u041f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0456\u0432\u00bb \u0443 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f\u0445\')"

    invoke-virtual {v0, v5}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V
    :try_end_ab
    .catchall {:try_start_78 .. :try_end_ab} :catchall_ac

    return-void

    .line 1021
    :catchall_ac
    :cond_ac
    :try_start_ac
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v5, "typeof toast===\'function\'&&toast(\'\u0422\u0435\u0441\u0442\u043e\u0432\u0435 \u0441\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u043d\u044f \u043d\u0430\u0434\u0456\u0441\u043b\u0430\u043d\u043e \u2014 \u0434\u0438\u0432\u0438\u0441\u044c \u0443 \u0448\u0442\u043e\u0440\u0446\u0456\')"

    invoke-virtual {v0, v5}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    goto/16 :goto_175

    :cond_b5
    const/4 v0, -0x1

    if-ne v5, v0, :cond_ce

    .line 1023
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-static {v0}, Lcom/fluxhelper/app/Notifs;->soundOn(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_c1

    goto :goto_c2

    :cond_c1
    move-object v6, v8

    .line 1024
    :goto_c2
    invoke-virtual {p0, v6}, Lcom/fluxhelper/app/MainActivity$Host;->openChannelSet(Ljava/lang/String;)V

    .line 1025
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v5, "typeof toast===\'function\'&&toast(\'\u041f\u041e\u041c\u0418\u041b\u041a\u0410: \u043a\u0430\u043d\u0430\u043b \u00ab\u041f\u043e\u0447\u0430\u0442\u043e\u043a \u0443\u0440\u043e\u043a\u0456\u0432\u00bb \u0432\u0438\u043c\u043a\u043d\u0435\u043d\u043e \u2014 \u0443\u0432\u0456\u043c\u043a\u043d\u0438 \u0439\u043e\u0433\u043e \u0456 \u043d\u0430\u0442\u0438\u0441\u043d\u0438 \u0442\u0435\u0441\u0442 \u0449\u0435 \u0440\u0430\u0437\')"

    invoke-virtual {v0, v5}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    goto/16 :goto_175

    .line 1027
    :cond_ce
    sget-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    if-eqz v0, :cond_de

    sget-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_db

    goto :goto_de

    .line 1028
    :cond_db
    sget-object v0, Lcom/fluxhelper/app/Notifs;->lastTestErr:Ljava/lang/String;

    goto :goto_e0

    :cond_de
    :goto_de
    const-string v0, "\u043d\u0435\u0432\u0456\u0434\u043e\u043c\u0430 \u043f\u043e\u043c\u0438\u043b\u043a\u0430"

    .line 1029
    :goto_e0
    iget-object v5, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " \u2014 \u043d\u0430\u0442\u0438\u0441\u043d\u0438 \u0442\u0435\u0441\u0442 \u0449\u0435 \u0440\u0430\u0437"

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    # invokes: Lcom/fluxhelper/app/MainActivity;->jsStr(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$3(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    goto :goto_175

    .line 994
    :cond_10a
    :goto_10a
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity$Host;->openNotifSet()V

    .line 995
    iget-object v0, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    const-string v5, "typeof toast===\'function\'&&toast(\'\u041f\u041e\u041c\u0418\u041b\u041a\u0410: \u0441\u043f\u043e\u0432\u0456\u0449\u0435\u043d\u043d\u044f \u0432\u0438\u043c\u043a\u043d\u0435\u043d\u043e \u0432 Android \u2014 \u0443\u0432\u0456\u043c\u043a\u043d\u0438 \u0457\u0445 \u0443 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f\u0445 \u0456 \u043d\u0430\u0442\u0438\u0441\u043d\u0438 \u0442\u0435\u0441\u0442 \u0449\u0435 \u0440\u0430\u0437\')"

    invoke-virtual {v0, v5}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V
    :try_end_114
    .catchall {:try_start_ac .. :try_end_114} :catchall_115

    return-void

    :catchall_115
    move-exception v0

    .line 1033
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_149

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v5, :cond_127

    goto :goto_149

    .line 1034
    :cond_127
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_151

    :cond_149
    :goto_149
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    .line 1035
    :goto_151
    iget-object v5, v1, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    # invokes: Lcom/fluxhelper/app/MainActivity;->jsStr(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$3(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    :goto_175
    return-void
.end method

.method public theme(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1089
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host$5;

    invoke-direct {v1, p0, p1}, Lcom/fluxhelper/app/MainActivity$Host$5;-><init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public upd(Ljava/lang/String;)V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1146
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0, p1}, Lcom/fluxhelper/app/MainActivity;->upd(Ljava/lang/String;)V

    return-void
.end method

.method public ver()Ljava/lang/String;
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 842
    :try_start_0
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;

    invoke-virtual {v1}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_13} :catch_14

    return-object v0

    :catch_14
    const-string v0, ""

    return-object v0
.end method
