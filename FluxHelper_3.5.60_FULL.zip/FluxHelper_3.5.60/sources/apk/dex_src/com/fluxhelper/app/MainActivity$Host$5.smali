.class Lcom/fluxhelper/app/MainActivity$Host$5;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity$Host;->theme(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/fluxhelper/app/MainActivity$Host;

.field private final synthetic val$str:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity$Host;Ljava/lang/String;)V
    .registers 3

    .line 1089
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host$5;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$Host$5;->val$str:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    :try_start_0
    const-string v0, "light"

    .line 1092
    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$5;->val$str:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 1093
    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$5;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v1}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v1

    invoke-virtual {v1}, Lcom/fluxhelper/app/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    if-eqz v0, :cond_1f

    const/16 v2, 0x2000

    goto :goto_20

    :cond_1f
    const/4 v2, 0x0

    :goto_20
    if-eqz v0, :cond_2a

    .line 1096
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v0, v3, :cond_2a

    or-int/lit8 v2, v2, 0x10

    .line 1097
    :cond_2a
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-ge v0, v3, :cond_32

    or-int/lit16 v2, v2, 0x700

    .line 1098
    :cond_32
    invoke-virtual {v1, v2}, Landroid/view/View;->setSystemUiVisibility(I)V
    :try_end_35
    .catchall {:try_start_0 .. :try_end_35} :catchall_35

    :catchall_35
    return-void
.end method
