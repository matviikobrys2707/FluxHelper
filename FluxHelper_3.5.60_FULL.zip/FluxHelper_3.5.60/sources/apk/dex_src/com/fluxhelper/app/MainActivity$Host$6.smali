.class Lcom/fluxhelper/app/MainActivity$Host$6;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity$Host;->openInstallSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/fluxhelper/app/MainActivity$Host;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity$Host;)V
    .registers 2

    .line 1128
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    const-string v0, "package:"

    .line 1133
    :try_start_2
    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v1}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v5}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v5

    invoke-virtual {v5}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v1, v2}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2c} :catch_2d

    goto :goto_63

    .line 1135
    :catch_2d
    :try_start_2d
    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v1}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v0

    invoke-virtual {v0}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-direct {v2, v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v1, v2}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_57} :catch_58

    goto :goto_63

    .line 1138
    :catch_58
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$Host$6;->this$1:Lcom/fluxhelper/app/MainActivity$Host;

    # getter for: Lcom/fluxhelper/app/MainActivity$Host;->this$0:Lcom/fluxhelper/app/MainActivity;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity$Host;->access$0(Lcom/fluxhelper/app/MainActivity$Host;)Lcom/fluxhelper/app/MainActivity;

    move-result-object v0

    const-string v1, "\u043d\u0435 \u0432\u0434\u0430\u043b\u043e\u0441\u044f \u0432\u0456\u0434\u043a\u0440\u0438\u0442\u0438 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f \u2014 \u0443\u0432\u0456\u0439\u0434\u0438 \u0432 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u0456 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f \u0437\u0430\u0441\u0442\u043e\u0441\u0443\u043d\u043a\u0443"

    invoke-virtual {v0, v1}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    :goto_63
    return-void
.end method
