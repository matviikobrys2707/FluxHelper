.class public Lcom/fluxhelper/app/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fluxhelper/app/MainActivity$Host;
    }
.end annotation


# static fields






.field static volatile SELF:Lcom/fluxhelper/app/MainActivity;




# instance fields
.field private volatile browserLoginUsed:Z


.field public lastInsBot:I

.field public lastInsTop:I

.field private volatile loginGen:I

.field private volatile loginInFlight:Z




.field private volatile pendingInstall:Z


.field private final uiHandler:Landroid/os/Handler;

.field private wv:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 51
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    .line 52
    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->pendingInstall:Z

    .line 74
    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    .line 75
    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    .line 76
    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    .line 77
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/fluxhelper/app/MainActivity;->uiHandler:Landroid/os/Handler;

    .line 82
    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->lastInsTop:I

    .line 83
    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->lastInsBot:I

    return-void
.end method

.method static synthetic access$0(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V
    .registers 2

    .line 1511
    invoke-direct {p0, p1}, Lcom/fluxhelper/app/MainActivity;->startGoogleLogin(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1(Lcom/fluxhelper/app/MainActivity;)V
    .registers 1

    .line 1917
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->googleLogout()V

    return-void
.end method











.method static synthetic access$2(Lcom/fluxhelper/app/MainActivity;)V
    .registers 1

    .line 1705
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->prewarmCred()V

    return-void
.end method


.method static synthetic access$21(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fluxhelper/app/MainActivity;->loginLastDirect(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method


.method static synthetic access$3(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    .line 269
    invoke-static {p0}, Lcom/fluxhelper/app/MainActivity;->jsStr(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method






.method static synthetic access$9(Lcom/fluxhelper/app/MainActivity;)Landroid/webkit/WebView;
    .registers 1

    .line 53
    iget-object p0, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    return-object p0
.end method

.method private authPrefs()Landroid/content/SharedPreferences;
    .registers 3

    const-string v0, "fh_auth"

    const/4 v1, 0x0

    .line 1366
    invoke-virtual {p0, v0, v1}, Lcom/fluxhelper/app/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0
.end method



.method private cleanupLegacyFiles()V
    .registers 6

    const/4 v0, 0x0

    .line 221
    :try_start_1
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    if-nez v0, :cond_8

    return-void

    .line 223
    :cond_8
    new-instance v1, Ljava/io/File;

    const-string v2, "update"

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 224
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-nez v0, :cond_16

    return-void

    .line 225
    :cond_16
    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_29

    .line 227
    array-length v2, v0

    const/4 v3, 0x0

    :goto_1e
    if-lt v3, v2, :cond_21

    goto :goto_29

    :cond_21
    aget-object v4, v0, v3
    :try_end_23
    .catchall {:try_start_1 .. :try_end_23} :catchall_2c

    .line 228
    :try_start_23
    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_26

    :catchall_26
    add-int/lit8 v3, v3, 0x1

    goto :goto_1e

    .line 231
    :cond_29
    :goto_29
    :try_start_29
    invoke-virtual {v1}, Ljava/io/File;->delete()Z
    :try_end_2c
    .catchall {:try_start_29 .. :try_end_2c} :catchall_2c

    :catchall_2c
    return-void
.end method






.method private googleLogout()V
    .registers 3

    .line 1918
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1920
    :try_start_f
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    const/4 v1, 0x0

    .line 1921
    invoke-virtual {v0, v1}, Landroid/webkit/CookieManager;->removeAllCookies(Landroid/webkit/ValueCallback;)V

    .line 1922
    invoke-virtual {v0, v1}, Landroid/webkit/CookieManager;->removeSessionCookies(Landroid/webkit/ValueCallback;)V

    .line 1923
    invoke-virtual {v0}, Landroid/webkit/CookieManager;->flush()V
    :try_end_1d
    .catchall {:try_start_f .. :try_end_1d} :catchall_1d

    :catchall_1d
    return-void
.end method


.method private handleInstallStatus(Landroid/content/Intent;)V
    .registers 5

    :try_start_0
    const-string v0, "android.content.pm.extra.STATUS"

    const/4 v1, 0x1

    .line 704
    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "android.content.pm.extra.STATUS_MESSAGE"

    .line 705
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_d
    .catchall {:try_start_0 .. :try_end_d} :catchall_3b

    const/4 v2, -0x1

    if-ne v0, v2, :cond_2b

    :try_start_10
    const-string v0, "android.intent.extra.INTENT"

    .line 709
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/content/Intent;
    :try_end_18
    .catchall {:try_start_10 .. :try_end_18} :catchall_19

    goto :goto_1a

    :catchall_19
    const/4 p1, 0x0

    :goto_1a
    if-eqz p1, :cond_2a

    const/high16 v0, 0x10000000

    .line 711
    :try_start_1e
    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    :try_end_21
    .catchall {:try_start_1e .. :try_end_21} :catchall_3b

    .line 712
    :try_start_21
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_24} :catch_25
    .catchall {:try_start_21 .. :try_end_24} :catchall_3b

    goto :goto_2a

    :catch_25
    :try_start_25
    const-string p1, "\u0442\u0435\u043b\u0435\u0444\u043e\u043d \u043d\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0432 \u0434\u0456\u0430\u043b\u043e\u0433 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u2014 \u0434\u043e\u0437\u0432\u043e\u043b\u044c \u00ab\u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u0437\u0430\u0441\u0442\u043e\u0441\u0443\u043d\u043a\u0456\u0432\u00bb \u0434\u043b\u044f FluxHelper \u0443 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f\u0445"

    .line 713
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    :cond_2a
    :goto_2a
    return-void

    :cond_2b
    if-nez v0, :cond_33

    const-string p1, "window.__fh&&window.__fh.dlDone()"

    .line 719
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    .line 722
    :cond_33
    invoke-static {v0, v1}, Lcom/fluxhelper/app/MainActivity;->installErrText(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V
    :try_end_3a
    .catchall {:try_start_25 .. :try_end_3a} :catchall_3b

    goto :goto_51

    :catchall_3b
    move-exception p1

    .line 724
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u043f\u043e\u043c\u0438\u043b\u043a\u0430 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    :goto_51
    return-void
.end method

.method static handleInstallStatusStatic(Landroid/content/Intent;)V
    .registers 2

    .line 698
    sget-object v0, Lcom/fluxhelper/app/MainActivity;->SELF:Lcom/fluxhelper/app/MainActivity;

    if-eqz v0, :cond_7

    .line 699
    invoke-direct {v0, p0}, Lcom/fluxhelper/app/MainActivity;->handleInstallStatus(Landroid/content/Intent;)V

    :cond_7
    return-void
.end method

.method private handleJoinIntent(Landroid/content/Intent;)V
    .registers 9

    const-string v0, "test"

    if-eqz p1, :cond_6e

    const-string v1, "fh.join"

    .line 239
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11

    goto :goto_6e

    :cond_11
    const-string v1, "url"

    .line 240
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_6e

    .line 241
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v4, 0x8

    if-ge v3, v4, :cond_22

    goto :goto_6e

    .line 243
    :cond_22
    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    .line 244
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->setIntent(Landroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v3, 0x0

    .line 250
    :try_start_2a
    invoke-virtual {p1, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    if-eq v4, v1, :cond_4b

    const-string v4, "name"

    .line 251
    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "time"

    invoke-virtual {p1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v4, :cond_4b

    if-eqz v5, :cond_4b

    .line 252
    invoke-static {}, Lcom/fluxhelper/app/Notifs;->todayStr()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5, v4}, Lcom/fluxhelper/app/Notifs;->lessonKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {p0, v4}, Lcom/fluxhelper/app/Notifs;->markDone(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_4b
    .catchall {:try_start_2a .. :try_end_4b} :catchall_4b

    :catchall_4b
    :cond_4b
    :try_start_4b
    const-string v4, "notification"

    .line 260
    invoke-virtual {p0, v4}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/NotificationManager;

    if-eqz v4, :cond_6b

    .line 262
    invoke-virtual {p1, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    if-ne p1, v1, :cond_61

    const/16 p1, 0x7d3

    invoke-virtual {v4, p1}, Landroid/app/NotificationManager;->cancel(I)V

    goto :goto_6b

    :cond_61
    const/16 p1, 0x7d1

    .line 263
    invoke-virtual {v4, p1}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 p1, 0x7d2

    invoke-virtual {v4, p1}, Landroid/app/NotificationManager;->cancel(I)V
    :try_end_6b
    .catchall {:try_start_4b .. :try_end_6b} :catchall_6b

    .line 266
    :catchall_6b
    :cond_6b
    :goto_6b
    invoke-virtual {p0, v2}, Lcom/fluxhelper/app/MainActivity;->openExternal(Ljava/lang/String;)V

    :cond_6e
    :goto_6e
    return-void
.end method

.method private static installErrText(ILjava/lang/String;)Ljava/lang/String;
    .registers 4

    if-eqz p1, :cond_17

    .line 732
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_17

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, " \u2014 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_19

    :cond_17
    const-string v0, ""

    :goto_19
    packed-switch p0, :pswitch_data_d0

    .line 751
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "\u041f\u043e\u043c\u0438\u043b\u043a\u0430 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f (\u043a\u043e\u0434 "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 749
    :pswitch_33
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u043d\u0435 \u0432\u0456\u0434\u043f\u043e\u0432\u0456\u0432 \u0432\u0447\u0430\u0441\u043d\u043e"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". \u0421\u043f\u0440\u043e\u0431\u0443\u0439 \u0449\u0435 \u0440\u0430\u0437"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_47
    if-eqz p1, :cond_66

    .line 741
    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1, p0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "DOWNGRADE"

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_66

    .line 742
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u041d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0456 \u0432\u0436\u0435 \u043d\u043e\u0432\u0456\u0448\u0430 \u0432\u0435\u0440\u0441\u0456\u044f \u2014 \u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0441\u0442\u0430\u0440\u0456\u0448\u0443 \u0437\u0430\u0431\u043e\u0440\u043e\u043d\u0435\u043d\u043e"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 743
    :cond_66
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u0412\u0435\u0440\u0441\u0456\u044f \u043d\u0435\u0441\u0443\u043c\u0456\u0441\u043d\u0430 \u0437 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e\u044e (\u0456\u043d\u0448\u0438\u0439 \u043f\u0456\u0434\u043f\u0438\u0441 \u0430\u0431\u043e \u0432\u0431\u0443\u0434\u043e\u0432\u0430\u043d\u0438\u0439 \u0437\u0430\u0441\u0442\u043e\u0441\u0443\u043d\u043e\u043a)"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". \u0412\u0438\u0434\u0430\u043b\u0438 FluxHelper \u0456 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u0438 \u0437\u0430\u043d\u043e\u0432\u043e"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 747
    :pswitch_7a
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043d\u044c\u043e \u043c\u0456\u0441\u0446\u044f \u043d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0456 \u0434\u043b\u044f \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 739
    :pswitch_89
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u041d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0456 \u0432\u0436\u0435 \u0441\u0442\u043e\u0457\u0442\u044c \u0456\u043d\u0448\u0438\u0439 \u0437\u0430\u0441\u0442\u043e\u0441\u0443\u043d\u043e\u043a \u0437 \u0446\u0438\u043c \u0456\u043c\u0435\u043d\u0435\u043c"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 745
    :pswitch_98
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u0424\u0430\u0439\u043b \u043e\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u043f\u043e\u0448\u043a\u043e\u0434\u0436\u0435\u043d\u0438\u0439"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". \u041d\u0430\u0442\u0438\u0441\u043d\u0438 \u00ab\u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0438\u00bb \u2014 \u0432\u0456\u043d \u0437\u0430\u0432\u0430\u043d\u0442\u0430\u0436\u0438\u0442\u044c\u0441\u044f \u0437\u0430\u043d\u043e\u0432\u043e"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 735
    :pswitch_ac
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u0412\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u0441\u043a\u0430\u0441\u043e\u0432\u0430\u043d\u043e"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". \u041d\u0430\u0442\u0438\u0441\u043d\u0438 \u00ab\u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0438\u00bb, \u0449\u043e\u0431 \u0441\u043f\u0440\u043e\u0431\u0443\u0432\u0430\u0442\u0438 \u0437\u043d\u043e\u0432\u0443"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 737
    :pswitch_c0
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u0437\u0430\u0431\u043b\u043e\u043a\u0443\u0432\u0430\u0432 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f (\u0447\u0430\u0441\u0442\u043e \u0446\u0435 Play Protect)"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_d0
    .packed-switch 0x2
        :pswitch_c0
        :pswitch_ac
        :pswitch_98
        :pswitch_89
        :pswitch_7a
        :pswitch_47
        :pswitch_33
    .end packed-switch
.end method

.method private installViaSession(Ljava/io/File;)V
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 665
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/pm/PackageManager;->getPackageInstaller()Landroid/content/pm/PackageInstaller;

    move-result-object v0

    .line 666
    new-instance v1, Landroid/content/pm/PackageInstaller$SessionParams;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Landroid/content/pm/PackageInstaller$SessionParams;-><init>(I)V

    .line 667
    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageInstaller$SessionParams;->setSize(J)V

    .line 668
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageInstaller;->createSession(Landroid/content/pm/PackageInstaller$SessionParams;)I

    move-result v1

    .line 669
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageInstaller;->openSession(I)Landroid/content/pm/PackageInstaller$Session;

    move-result-object v0

    .line 671
    :try_start_1d
    new-instance v8, Ljava/io/FileInputStream;

    invoke-direct {v8, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const-string v3, "FluxHelper.apk"

    const-wide/16 v4, 0x0

    .line 672
    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v6

    move-object v2, v0

    invoke-virtual/range {v2 .. v7}, Landroid/content/pm/PackageInstaller$Session;->openWrite(Ljava/lang/String;JJ)Ljava/io/OutputStream;

    move-result-object p1
    :try_end_2f
    .catchall {:try_start_1d .. :try_end_2f} :catchall_7a

    const/16 v2, 0x4000

    :try_start_31
    new-array v2, v2, [B

    .line 676
    :goto_33
    invoke-virtual {v8, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    if-gtz v3, :cond_6d

    .line 677
    invoke-virtual {v0, p1}, Landroid/content/pm/PackageInstaller$Session;->fsync(Ljava/io/OutputStream;)V
    :try_end_3c
    .catchall {:try_start_31 .. :try_end_3c} :catchall_72

    .line 679
    :try_start_3c
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_3c .. :try_end_3f} :catch_3f
    .catchall {:try_start_3c .. :try_end_3f} :catchall_7a

    .line 680
    :catch_3f
    :try_start_3f
    invoke-virtual {v8}, Ljava/io/InputStream;->close()V
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_42} :catch_42
    .catchall {:try_start_3f .. :try_end_42} :catchall_7a

    .line 682
    :catch_42
    :try_start_42
    new-instance p1, Landroid/content/Intent;

    const-class v2, Lcom/fluxhelper/app/InstallStatusReceiver;

    invoke-direct {p1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "com.fluxhelper.app.INSTALL_STATUS"

    .line 683
    invoke-virtual {p1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 685
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1f

    if-lt v2, v3, :cond_57

    const/high16 v2, 0xa000000

    goto :goto_59

    :cond_57
    const/high16 v2, 0x8000000

    .line 686
    :goto_59
    invoke-static {p0, v1, p1, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    .line 687
    invoke-virtual {p1}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageInstaller$Session;->commit(Landroid/content/IntentSender;)V
    :try_end_64
    .catchall {:try_start_42 .. :try_end_64} :catchall_7a

    .line 689
    :try_start_64
    invoke-virtual {v0}, Landroid/content/pm/PackageInstaller$Session;->close()V
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_67} :catch_67

    :catch_67
    const-string p1, "window.__fh&&window.__fh.dlDone()"

    .line 693
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    :cond_6d
    const/4 v4, 0x0

    .line 676
    :try_start_6e
    invoke-virtual {p1, v2, v4, v3}, Ljava/io/OutputStream;->write([BII)V
    :try_end_71
    .catchall {:try_start_6e .. :try_end_71} :catchall_72

    goto :goto_33

    :catchall_72
    move-exception v1

    .line 679
    :try_start_73
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_76
    .catch Ljava/lang/Exception; {:try_start_73 .. :try_end_76} :catch_76
    .catchall {:try_start_73 .. :try_end_76} :catchall_7a

    .line 680
    :catch_76
    :try_start_76
    invoke-virtual {v8}, Ljava/io/InputStream;->close()V
    :try_end_79
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_79} :catch_79
    .catchall {:try_start_76 .. :try_end_79} :catchall_7a

    .line 681
    :catch_79
    :try_start_79
    throw v1
    :try_end_7a
    .catchall {:try_start_79 .. :try_end_7a} :catchall_7a

    :catchall_7a
    move-exception p1

    .line 689
    :try_start_7b
    invoke-virtual {v0}, Landroid/content/pm/PackageInstaller$Session;->close()V
    :try_end_7e
    .catch Ljava/lang/Exception; {:try_start_7b .. :try_end_7e} :catch_7e

    .line 690
    :catch_7e
    throw p1
.end method

.method private static jsStr(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    if-nez p0, :cond_5

    const-string p0, "\"\""

    return-object p0

    .line 273
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    .line 274
    :goto_d
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x22

    if-lt v1, v2, :cond_1d

    .line 285
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 286
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 275
    :cond_1d
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v4, 0x5c

    if-eq v2, v3, :cond_2b

    if-eq v2, v4, :cond_2b

    const/16 v3, 0x27

    if-ne v2, v3, :cond_2e

    .line 277
    :cond_2b
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_2e
    const/16 v3, 0xa

    if-eq v2, v3, :cond_3b

    const/16 v3, 0xd

    if-ne v2, v3, :cond_37

    goto :goto_3b

    .line 282
    :cond_37
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_40

    :cond_3b
    :goto_3b
    const/16 v2, 0x20

    .line 280
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_40
    add-int/lit8 v1, v1, 0x1

    goto :goto_d
.end method

.method private static jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    if-eqz p1, :cond_41

    .line 1937
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_9

    goto :goto_41

    .line 1940
    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\""

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "\":\""

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "\\"

    const-string v2, "\\\\"

    invoke-virtual {p1, p0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "\\\""

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "\n"

    const-string v1, " "

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "\r"

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "\","

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_41
    :goto_41
    const-string p0, ","

    return-object p0
.end method


.method private static md5hex(Ljava/io/File;)Ljava/lang/String;
    .registers 5

    :try_start_0
    const-string v0, "MD5"

    .line 587
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    .line 588
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/16 p0, 0x4000

    new-array p0, p0, [B

    .line 591
    :goto_f
    invoke-virtual {v1, p0}, Ljava/io/FileInputStream;->read([B)I

    move-result v2

    const/4 v3, 0x0

    if-gtz v2, :cond_45

    .line 597
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    .line 598
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    .line 599
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 600
    :goto_22
    array-length v1, p0

    if-lt v3, v1, :cond_2a

    .line 604
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 601
    :cond_2a
    aget-byte v1, p0, v3

    shr-int/lit8 v1, v1, 0x4

    and-int/lit8 v1, v1, 0xf

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 602
    aget-byte v1, p0, v3

    and-int/lit8 v1, v1, 0xf

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_22

    .line 595
    :cond_45
    invoke-virtual {v0, p0, v3, v2}, Ljava/security/MessageDigest;->update([BII)V
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_48} :catch_49

    goto :goto_f

    :catch_49
    const/4 p0, 0x0

    return-object p0
.end method

.method private nativeAuthFail(Ljava/lang/String;)V
    .registers 4

    .line 1906
    :try_start_0
    invoke-static {p0}, Lcom/fluxhelper/app/LoginKeepService;->stop(Landroid/content/Context;)V
    :try_end_3
    .catchall {:try_start_0 .. :try_end_3} :catchall_3

    .line 1907
    :catchall_3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "window.__fh&&window.__fh.authErr&&window.__fh.authErr(\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\')"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void
.end method



.method private prewarmCred()V
    .registers 1

# 3.5.59: CM prewarm видалено разом із Credential Manager;
# стуб лишено для onCreate/Host.prewarm.

    return-void
.end method

.method private static randomHex(I)Ljava/lang/String;
    .registers 6

    .line 1928
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1929
    new-instance v1, Ljava/security/SecureRandom;

    invoke-direct {v1}, Ljava/security/SecureRandom;-><init>()V

    .line 1930
    new-array v2, p0, [B

    .line 1931
    invoke-virtual {v1, v2}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/4 v1, 0x0

    :goto_10
    if-lt v1, p0, :cond_17

    .line 1933
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 1932
    :cond_17
    aget-byte v3, v2, v1

    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%02x"

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_10
.end method

.method private static readText(Ljava/io/File;)Ljava/lang/String;
    .registers 5

    .line 537
    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 538
    new-instance p0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v1, 0x2000

    new-array v1, v1, [B

    .line 541
    :goto_e
    invoke-virtual {v0, v1}, Ljava/io/FileInputStream;->read([B)I

    move-result v2

    if-lez v2, :cond_19

    const/4 v3, 0x0

    .line 543
    invoke-virtual {p0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_e

    .line 545
    :cond_19
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V

    .line 546
    new-instance v0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const-string v1, "UTF-8"

    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_27} :catch_28

    return-object v0

    :catch_28
    const/4 p0, 0x0

    return-object p0
.end method

.method private static realModelName()Ljava/lang/String;
    .registers 5

    const-string v0, "ro.product.odm.marketname"

    const-string v1, "ro.product.system.marketname"

    const-string v2, "ro.product.marketname"

    const-string v3, "ro.product.vendor.marketname"

    .line 1952
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :goto_d
    const/4 v2, 0x4

    if-lt v1, v2, :cond_1e

    .line 1959
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    if-nez v0, :cond_17

    const-string v0, ""

    goto :goto_1d

    :cond_17
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    :goto_1d
    return-object v0

    .line 1954
    :cond_1e
    aget-object v2, v0, v1

    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity;->sysProp(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_36

    .line 1955
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    if-le v3, v4, :cond_36

    .line 1956
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_36
    add-int/lit8 v1, v1, 0x1

    goto :goto_d
.end method



.method private stateFromPrefs()Ljava/lang/String;
    .registers 4

    const-string v0, ""

    .line 1575
    :try_start_2
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "st"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_c} :catch_c

    :catch_c
    return-object v0
.end method


.method private static sysProp(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    :try_start_0
    const-string v0, "android.os.SystemProperties"

    .line 1945
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "get"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Class;

    const-class v3, Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1f} :catch_20

    return-object p0

    :catch_20
    const-string p0, ""

    return-object p0
.end method



.method private static validApk(Ljava/io/File;Ljava/lang/String;)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p0, :cond_5b

    .line 557
    :try_start_3
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_5b

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v1

    const-wide/32 v3, 0xc350

    cmp-long v1, v1, v3

    if-ltz v1, :cond_5b

    .line 558
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 559
    invoke-virtual {v1}, Ljava/io/FileInputStream;->read()I

    move-result v2

    .line 560
    invoke-virtual {v1}, Ljava/io/FileInputStream;->read()I

    move-result v3

    .line 561
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    const/16 v1, 0x50

    if-ne v2, v1, :cond_5b

    const/16 v1, 0x4b

    if-ne v3, v1, :cond_5b

    .line 563
    new-instance v1, Ljava/util/zip/ZipFile;

    invoke-direct {v1, p0}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V

    const-string v2, "AndroidManifest.xml"

    .line 564
    invoke-virtual {v1, v2}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v2

    const/4 v3, 0x1

    if-eqz v2, :cond_3c

    move v2, v3

    goto :goto_3d

    :cond_3c
    move v2, v0

    .line 565
    :goto_3d
    invoke-virtual {v1}, Ljava/util/zip/ZipFile;->close()V

    if-nez v2, :cond_43

    return v0

    :cond_43
    if-eqz p1, :cond_5a

    .line 569
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x20

    if-ne v1, v2, :cond_5a

    .line 570
    invoke-static {p0}, Lcom/fluxhelper/app/MainActivity;->md5hex(Ljava/io/File;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_59

    .line 571
    invoke-virtual {p0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_57} :catch_5b

    if-nez p0, :cond_5a

    :cond_59
    return v0

    :cond_5a
    return v3

    :catch_5b
    :cond_5b
    return v0
.end method


.method private static webZoomUrl(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    :cond_4
    :try_start_4
    const-string v1, "app.zoom.us/wc/"

    .line 782
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_d

    return-object p0

    :cond_d
    const-string v1, "/(?:j|wc)/(\\d{5,})(?:/join)?"

    .line 785
    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 786
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-nez v2, :cond_1e

    return-object p0

    :cond_1e
    const/4 v2, 0x1

    .line 789
    invoke-virtual {v1, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    const-string v3, "[?&]pwd=([^&]+)"

    .line 790
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    .line 791
    invoke-virtual {v3}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    if-eqz v4, :cond_37

    invoke-virtual {v3, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    .line 792
    :cond_37
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "https://app.zoom.us/wc/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 793
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/join?ref_from=launch"

    .line 794
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v0, :cond_57

    .line 796
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "&pwd="

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_59

    :cond_57
    const-string v0, ""

    .line 800
    :goto_59
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "&fromPWA=1"

    .line 801
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 802
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_65
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_65} :catch_65

    :catch_65
    return-object p0
.end method


# virtual methods
.method devInfoJson()Ljava/lang/String;
    .registers 14

    const-string v0, " GB"

    const-string v1, ""

    .line 1171
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "{"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1173
    :try_start_b
    invoke-static {}, Lcom/fluxhelper/app/MainActivity;->realModelName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "model"

    .line 1174
    invoke-static {v5, v4}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "brand"

    .line 1175
    sget-object v6, Landroid/os/Build;->BRAND:Ljava/lang/String;

    invoke-static {v5, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "name"

    .line 1176
    invoke-static {v5, v4}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "manufacturer"

    .line 1177
    sget-object v5, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-static {v4, v5}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "device"

    .line 1178
    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    invoke-static {v4, v5}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "product"

    .line 1179
    sget-object v5, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    invoke-static {v4, v5}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_4d
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_4d} :catch_4d

    :catch_4d
    :try_start_4d
    const-string v4, "os"

    .line 1183
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Android "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v6, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " (SDK "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ")"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_75
    .catch Ljava/lang/Exception; {:try_start_4d .. :try_end_75} :catch_75

    :catch_75
    const/4 v4, 0x1

    :try_start_76
    const-string v5, "cpu"

    .line 1187
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1f

    if-lt v6, v7, :cond_8e

    sget-object v6, Landroid/os/Build;->SOC_MODEL:Ljava/lang/String;

    if-eqz v6, :cond_8e

    sget-object v6, Landroid/os/Build;->SOC_MODEL:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-gt v6, v4, :cond_8b

    goto :goto_8e

    :cond_8b
    sget-object v6, Landroid/os/Build;->SOC_MODEL:Ljava/lang/String;

    goto :goto_90

    :cond_8e
    :goto_8e
    sget-object v6, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    :goto_90
    invoke-static {v5, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_97
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_97} :catch_97

    :catch_97
    const/4 v5, 0x0

    :try_start_98
    const-string v6, "board"

    .line 1191
    sget-object v7, Landroid/os/Build;->BOARD:Ljava/lang/String;

    invoke-static {v6, v7}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1192
    sget-object v6, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    if-nez v6, :cond_a9

    move-object v6, v1

    goto :goto_bc

    .line 1195
    :cond_a9
    sget-object v6, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/16 v7, 0x5a

    if-le v6, v7, :cond_ba

    sget-object v6, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    invoke-virtual {v6, v5, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    goto :goto_bc

    :cond_ba
    sget-object v6, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    :goto_bc
    const-string v7, "fingerprint"

    .line 1197
    invoke-static {v7, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_c5
    .catch Ljava/lang/Exception; {:try_start_98 .. :try_end_c5} :catch_c5

    .line 1201
    :catch_c5
    :try_start_c5
    new-instance v6, Landroid/app/ActivityManager$MemoryInfo;

    invoke-direct {v6}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    const-string v7, "activity"

    .line 1202
    invoke-virtual {p0, v7}, Lcom/fluxhelper/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/app/ActivityManager;

    if-eqz v7, :cond_114

    .line 1204
    invoke-virtual {v7, v6}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    .line 1205
    iget-wide v6, v6, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    long-to-double v6, v6

    const-wide/high16 v8, 0x41c0000000000000L    # 5.36870912E8

    div-double/2addr v6, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v6

    long-to-double v6, v6

    const-wide/high16 v8, 0x4000000000000000L    # 2.0

    div-double/2addr v6, v8

    const-string v8, "ram"

    .line 1206
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    cmpl-double v10, v6, v10

    if-nez v10, :cond_f7

    double-to-long v6, v6

    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    goto :goto_fb

    :cond_f7
    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v6

    :goto_fb
    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v8, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_114
    .catch Ljava/lang/Exception; {:try_start_c5 .. :try_end_114} :catch_114

    .line 1211
    :catch_114
    :cond_114
    :try_start_114
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v6

    if-lez v6, :cond_13d

    const-string v7, "cores"

    .line 1213
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v8, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, " \u044f\u0434\u0435\u0440"

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v7, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_13d
    .catch Ljava/lang/Exception; {:try_start_114 .. :try_end_13d} :catch_13d

    .line 1218
    :catch_13d
    :cond_13d
    :try_start_13d
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    iget v6, v6, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 1219
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v7, v7, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 1220
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v8

    iget v8, v8, Landroid/util/DisplayMetrics;->density:F

    if-gt v7, v6, :cond_15e

    move v7, v6

    :cond_15e
    const-string v9, "screen"

    .line 1225
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v10, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, "\u00d7"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, " (@"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/high16 v6, 0x41200000    # 10.0f

    mul-float/2addr v8, v6

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v7

    int-to-float v7, v7

    div-float/2addr v7, v6

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v6, "x)"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v9, v6}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_196
    .catch Ljava/lang/Exception; {:try_start_13d .. :try_end_196} :catch_196

    .line 1229
    :catch_196
    :try_start_196
    invoke-static {}, Landroid/os/Environment;->getDataDirectory()Ljava/io/File;

    move-result-object v6

    if-eqz v6, :cond_1ca

    const-string v7, "storage"

    .line 1231
    new-instance v8, Ljava/lang/StringBuilder;

    new-instance v9, Landroid/os/StatFs;

    invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9}, Landroid/os/StatFs;->getTotalBytes()J

    move-result-wide v9

    const-wide/32 v11, 0x40000000

    div-long/2addr v9, v11

    invoke-static {v9, v10}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v8, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_1ca
    .catch Ljava/lang/Exception; {:try_start_196 .. :try_end_1ca} :catch_1ca

    .line 1236
    :catch_1ca
    :cond_1ca
    :try_start_1ca
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v6, "device_name"

    invoke-static {v0, v6}, Landroid/provider/Settings$Global;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1ed

    .line 1237
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v6

    if-le v6, v4, :cond_1ed

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v6, 0x3c

    if-ge v4, v6, :cond_1ed

    const-string v4, "devname"

    .line 1238
    invoke-static {v4, v0}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_1ed
    .catch Ljava/lang/Exception; {:try_start_1ca .. :try_end_1ed} :catch_1ed

    :catch_1ed
    :cond_1ed
    :try_start_1ed
    const-string v0, "locale"

    .line 1243
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_1fe
    .catch Ljava/lang/Exception; {:try_start_1ed .. :try_end_1fe} :catch_1fe

    .line 1247
    :catch_1fe
    :try_start_1fe
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v4, "android_id"

    invoke-static {v0, v4}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_222

    .line 1248
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x4

    if-lt v4, v6, :cond_222

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v6, 0x20

    if-gt v4, v6, :cond_222

    const-string v4, "aid"

    .line 1249
    invoke-static {v4, v0}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_222
    .catch Ljava/lang/Exception; {:try_start_1fe .. :try_end_222} :catch_222

    .line 1254
    :catch_222
    :cond_222
    :try_start_222
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    if-eqz v0, :cond_22f

    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    array-length v0, v0

    if-lez v0, :cond_22f

    .line 1255
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    aget-object v1, v0, v5

    :cond_22f
    const-string v0, "arch"

    .line 1257
    invoke-static {v0, v1}, Lcom/fluxhelper/app/MainActivity;->jsonPair(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_238
    .catch Ljava/lang/Exception; {:try_start_222 .. :try_end_238} :catch_238

    .line 1260
    :catch_238
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ",+}"

    const-string v2, "}"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "{,"

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 1261
    invoke-virtual {v0, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_251

    return-object v0

    .line 1264
    :cond_251
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


.method public fetchToFile(Ljava/lang/String;Ljava/lang/String;Z)Z
    .registers 23

    move-object/from16 v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 442
    :try_start_4
    new-instance v3, Ljava/net/URL;

    move-object/from16 v4, p1

    invoke-direct {v3, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    check-cast v3, Ljava/net/HttpURLConnection;
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_11} :catch_125

    const/16 v4, 0x3a98

    .line 443
    :try_start_13
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const v4, 0xea60

    .line 444
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v4, 0x1

    .line 445
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 446
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->connect()V

    .line 447
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v5

    const/16 v6, 0xc8

    if-eq v5, v6, :cond_2f

    .line 448
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    return v1

    .line 451
    :cond_2f
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getContentLength()I

    move-result v5

    int-to-long v5, v5

    .line 452
    new-instance v7, Ljava/io/BufferedInputStream;

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 453
    invoke-virtual {v0, v2}, Lcom/fluxhelper/app/MainActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    if-nez v2, :cond_47

    .line 455
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    return v1

    .line 458
    :cond_47
    new-instance v8, Ljava/io/File;

    const-string v9, "update"

    invoke-direct {v8, v2, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 459
    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    .line 460
    new-instance v2, Ljava/io/File;
    :try_end_53
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_53} :catch_124

    const-string v9, "update.apk"

    if-eqz p3, :cond_5a

    :try_start_57
    const-string v10, "update_b64.json"

    goto :goto_5b

    :cond_5a
    move-object v10, v9

    :goto_5b
    invoke-direct {v2, v8, v10}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 461
    new-instance v10, Ljava/io/FileOutputStream;

    invoke-direct {v10, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/16 v11, 0x4000

    new-array v11, v11, [B

    const/4 v14, -0x1

    const-wide/16 v15, 0x0

    .line 466
    :goto_6a
    invoke-virtual {v7, v11}, Ljava/io/BufferedInputStream;->read([B)I

    move-result v12

    if-gtz v12, :cond_e7

    .line 480
    invoke-virtual {v10}, Ljava/io/FileOutputStream;->flush()V

    .line 481
    invoke-virtual {v10}, Ljava/io/FileOutputStream;->close()V

    .line 482
    invoke-virtual {v7}, Ljava/io/BufferedInputStream;->close()V

    .line 483
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    if-eqz p3, :cond_c6

    .line 488
    invoke-static {v2}, Lcom/fluxhelper/app/MainActivity;->readText(Ljava/io/File;)Ljava/lang/String;

    move-result-object v5

    .line 489
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    if-eqz v5, :cond_c5

    .line 490
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v2
    :try_end_8b
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_8b} :catch_124

    const/16 v6, 0x3e8

    if-ge v2, v6, :cond_90

    goto :goto_c5

    .line 493
    :cond_90
    :try_start_90
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v5, "b64"

    const-string v7, ""

    invoke-virtual {v2, v5, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_9d
    .catch Ljava/lang/Exception; {:try_start_90 .. :try_end_9d} :catch_c5

    .line 497
    :try_start_9d
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5
    :try_end_a1
    .catch Ljava/lang/Exception; {:try_start_9d .. :try_end_a1} :catch_124

    if-ge v5, v6, :cond_a4

    return v1

    .line 500
    :cond_a4
    :try_start_a4
    invoke-static {v2, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2
    :try_end_a8
    .catch Ljava/lang/Exception; {:try_start_a4 .. :try_end_a8} :catch_c5

    if-eqz v2, :cond_c5

    .line 504
    :try_start_aa
    array-length v5, v2

    const v6, 0xc350

    if-ge v5, v6, :cond_b1

    goto :goto_c5

    .line 505
    :cond_b1
    new-instance v5, Ljava/io/FileOutputStream;

    new-instance v6, Ljava/io/File;

    invoke-direct {v6, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v5, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 506
    invoke-virtual {v5, v2}, Ljava/io/FileOutputStream;->write([B)V

    .line 507
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->flush()V

    .line 508
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    goto :goto_c6

    :catch_c5
    :cond_c5
    :goto_c5
    return v1

    .line 510
    :cond_c6
    :goto_c6
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object/from16 v13, p2

    .line 511
    invoke-static {v2, v13}, Lcom/fluxhelper/app/MainActivity;->validApk(Ljava/io/File;Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_d7

    .line 512
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    return v1

    :cond_d7
    const-string v2, "window.__fh&&window.__fh.dlProg(100)"

    .line 515
    invoke-virtual {v0, v2}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    .line 516
    iput-boolean v4, v0, Lcom/fluxhelper/app/MainActivity;->pendingInstall:Z

    .line 517
    new-instance v2, Lcom/fluxhelper/app/MainActivity$6;

    invoke-direct {v2, v0}, Lcom/fluxhelper/app/MainActivity$6;-><init>(Lcom/fluxhelper/app/MainActivity;)V

    invoke-virtual {v0, v2}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return v4

    :cond_e7
    move-object/from16 v13, p2

    .line 470
    invoke-virtual {v10, v11, v1, v12}, Ljava/io/FileOutputStream;->write([BII)V

    move-object/from16 p1, v2

    int-to-long v1, v12

    add-long/2addr v15, v1

    const-wide/16 v1, 0x0

    cmp-long v12, v5, v1

    if-lez v12, :cond_11f

    const-wide/16 v17, 0x64

    mul-long v17, v17, v15

    .line 473
    div-long v1, v17, v5

    long-to-int v1, v1

    if-eq v1, v14, :cond_11f

    if-ltz v1, :cond_11f

    const/16 v2, 0x64

    if-ge v1, v2, :cond_11f

    .line 475
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v12, "window.__fh&&window.__fh.dlProg("

    invoke-direct {v2, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v12, ")"

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V
    :try_end_11b
    .catch Ljava/lang/Exception; {:try_start_aa .. :try_end_11b} :catch_124

    move-object/from16 v2, p1

    move v14, v1

    goto :goto_121

    :cond_11f
    move-object/from16 v2, p1

    :goto_121
    const/4 v1, 0x0

    goto/16 :goto_6a

    :catch_124
    move-object v2, v3

    :catch_125
    if-eqz v2, :cond_12a

    .line 527
    :try_start_127
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_12a
    .catch Ljava/lang/Exception; {:try_start_127 .. :try_end_12a} :catch_12a

    :catch_12a
    :cond_12a
    const/4 v1, 0x0

    return v1
.end method

.method public injectInsets(Landroid/webkit/WebView;II)V
    .registers 6

    .line 88
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "(function(){try{var d=document.documentElement.style,z=window.devicePixelRatio||1;d.setProperty(\'--fh-sat\',Math.round("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "/z)+\'px\');d.setProperty(\'--fh-sab\',Math.round("

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "/z)+\'px\');document.documentElement.setAttribute(\'data-ins\',\'1\');}catch(e){}})();"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_1f
    .catchall {:try_start_0 .. :try_end_1f} :catchall_1f

    :catchall_1f
    return-void
.end method

.method public jsCall(Ljava/lang/String;)V
    .registers 3

    if-eqz p1, :cond_21

    const-string v0, "__fh.authOk"

    .line 335
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_12

    const-string v0, "__fh.authErr"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_21

    .line 336
    :cond_12
    :try_start_12
    invoke-static {p0}, Lcom/fluxhelper/app/LoginKeepService;->stop(Landroid/content/Context;)V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_15} :catch_15

    :catch_15
    const/4 v0, 0x0

    .line 338
    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    .line 339
    iget v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    .line 340
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->cancelLoginTimers()V

    .line 342
    :cond_21
    new-instance v0, Lcom/fluxhelper/app/MainActivity$4;

    invoke-direct {v0, p0, p1}, Lcom/fluxhelper/app/MainActivity$4;-><init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public jsErr(Ljava/lang/String;)V
    .registers 5

    .line 353
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "window.__fh&&window.__fh.dlErr(\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-nez p1, :cond_c

    const-string p1, "\u043f\u043e\u043c\u0438\u043b\u043a\u0430"

    goto :goto_1a

    :cond_c
    const-string v1, "\'"

    const-string v2, " "

    .line 354
    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "\\"

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    :goto_1a
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\')"

    .line 355
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void
.end method


.method public onBackPressed()V
    .registers 4

    .line 810
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    if-eqz v0, :cond_f

    .line 812
    new-instance v1, Lcom/fluxhelper/app/MainActivity$7;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$7;-><init>(Lcom/fluxhelper/app/MainActivity;)V

    const-string v2, "(window.__fh&&window.__fh.back)?(!!window.__fh.back()):false"

    invoke-virtual {v0, v2, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    goto :goto_12

    .line 822
    :cond_f
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :goto_12
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    .line 94
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 95
    sput-object p0, Lcom/fluxhelper/app/MainActivity;->SELF:Lcom/fluxhelper/app/MainActivity;

    .line 103
    :try_start_5
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/fluxhelper/app/MainActivity;->handleJoinIntent(Landroid/content/Intent;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_c} :catch_c

    .line 114
    :catch_c
    :try_start_c
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->cleanupLegacyFiles()V
    :try_end_f
    .catchall {:try_start_c .. :try_end_f} :catchall_f

    .line 115
    :catchall_f
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v0, 0x0

    .line 120
    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 121
    invoke-virtual {p1, v0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 122
    new-instance p1, Landroid/webkit/WebView;

    invoke-direct {p1, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    .line 123
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    .line 124
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    const/4 v1, 0x1

    .line 125
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 126
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 127
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 128
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 129
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    .line 130
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    .line 131
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    const-string v1, "#050508"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 132
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$1;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$1;-><init>(Lcom/fluxhelper/app/MainActivity;)V

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 159
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    new-instance v1, Lcom/fluxhelper/app/MainActivity$Host;

    invoke-direct {v1, p0}, Lcom/fluxhelper/app/MainActivity$Host;-><init>(Lcom/fluxhelper/app/MainActivity;)V

    const-string v2, "AndroidHost"

    invoke-virtual {p1, v1, v2}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    const-string v1, "file:///android_asset/www/index.html"

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 161
    :try_start_60
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-eqz p1, :cond_6f

    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    goto :goto_70

    :cond_6f
    const/4 p1, 0x0

    :goto_70
    invoke-direct {p0, p1}, Lcom/fluxhelper/app/MainActivity;->handleAuthUri(Landroid/net/Uri;)V
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_60 .. :try_end_73} :catch_73

    .line 162
    :catch_73
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    const/16 v1, 0x100

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->setSystemUiVisibility(I)V

    .line 163
    iget-object p1, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->setContentView(Landroid/view/View;)V

    .line 170
    :try_start_7f
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    .line 171
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_8d

    .line 172
    invoke-virtual {p1, v0}, Landroid/view/Window;->setDecorFitsSystemWindows(Z)V

    goto :goto_96

    .line 174
    :cond_8d
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x700

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 176
    :goto_96
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    .line 177
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v1, Lcom/fluxhelper/app/MainActivity$2;

    invoke-direct {v1, p0, v0}, Lcom/fluxhelper/app/MainActivity$2;-><init>(Lcom/fluxhelper/app/MainActivity;Landroid/webkit/WebView;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V
    :try_end_a4
    .catchall {:try_start_7f .. :try_end_a4} :catchall_a4

    .line 201
    :catchall_a4
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->prewarmCred()V

    .line 202
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->ensureChannel(Landroid/content/Context;)V

    .line 203
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->reschedule(Landroid/content/Context;)V

    .line 207
    :try_start_ad
    invoke-static {p0}, Lcom/fluxhelper/app/NotifReceiver;->rearmSnooze(Landroid/content/Context;)V
    :try_end_b0
    .catchall {:try_start_ad .. :try_end_b0} :catchall_b0

    :catchall_b0
    return-void
.end method

.method protected onDestroy()V
    .registers 2

    .line 828
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;

    if-eqz v0, :cond_7

    .line 830
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 832
    :cond_7
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .registers 3

    .line 325
    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    .line 326
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->setIntent(Landroid/content/Intent;)V

    if-eqz p1, :cond_d

    .line 327
    :try_start_8
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    invoke-direct {p0, v0}, Lcom/fluxhelper/app/MainActivity;->handleAuthUri(Landroid/net/Uri;)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_11} :catch_11

    .line 329
    :catch_11
    :try_start_11
    invoke-direct {p0, p1}, Lcom/fluxhelper/app/MainActivity;->handleJoinIntent(Landroid/content/Intent;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_14} :catch_14

    :catch_14
    return-void
.end method

.method protected onResume()V
    .registers 5

    .line 291
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const-string v0, "window.__fh&&window.__fh.installCheck&&window.__fh.installCheck()"

    .line 292
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    .line 295
    :try_start_8
    invoke-static {p0}, Lcom/fluxhelper/app/Notifs;->cleanupStale(Landroid/content/Context;)V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_b

    .line 300
    :catchall_b

    :cond_26
    iget-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->pendingInstall:Z

    if-eqz v0, :cond_50

    const/4 v0, 0x0

    .line 315
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_38

    .line 316
    new-instance v0, Ljava/io/File;

    const-string v2, "update/update.apk"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :cond_38
    if-eqz v0, :cond_50

    .line 317
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_50

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v0

    const-wide/32 v2, 0xc350

    cmp-long v0, v0, v2

    if-gtz v0, :cond_4c

    goto :goto_50

    .line 320
    :cond_4c
    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->tryInstall()V

    nop

    :cond_50
    :goto_50
    return-void
.end method

.method public openExternal(Ljava/lang/String;)V
    .registers 6

    const-string v0, "android.intent.action.VIEW"

    if-eqz p1, :cond_3b

    .line 756
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x6

    if-ge v1, v2, :cond_c

    goto :goto_3b

    :cond_c
    const/high16 v1, 0x10000000

    .line 760
    :try_start_e
    new-instance v2, Landroid/content/Intent;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v2, v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 761
    invoke-virtual {v2, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 762
    invoke-virtual {p0, v2}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_1d} :catch_1e

    goto :goto_3b

    .line 764
    :catch_1e
    invoke-static {p1}, Lcom/fluxhelper/app/MainActivity;->webZoomUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_3b

    .line 765
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0xa

    if-le v2, v3, :cond_3b

    .line 767
    :try_start_2c
    new-instance v2, Landroid/content/Intent;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v2, v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 768
    invoke-virtual {v2, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 769
    invoke-virtual {p0, v2}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_3b} :catch_3b

    :catch_3b
    :cond_3b
    :goto_3b
    return-void
.end method

.method public tryInstall()V
    .registers 7

    const/4 v0, 0x0

    .line 611
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_e

    .line 612
    new-instance v0, Ljava/io/File;

    const-string v2, "update/update.apk"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :cond_e
    if-eqz v0, :cond_bc

    .line 613
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_18

    goto/16 :goto_bc

    .line 618
    :cond_18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const/4 v3, 0x1

    if-lt v1, v2, :cond_5b

    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/pm/PackageManager;->canRequestPackageInstalls()Z

    move-result v1

    if-nez v1, :cond_5b

    .line 619
    iput-boolean v3, p0, Lcom/fluxhelper/app/MainActivity;->pendingInstall:Z

    .line 621
    :try_start_2b
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "package:"

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/fluxhelper/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    const-string v0, "\u0414\u043e\u0437\u0432\u043e\u043b\u044c \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u2014 \u0456 \u043e\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u043f\u0440\u043e\u0434\u043e\u0432\u0436\u0438\u0442\u044c\u0441\u044f"

    .line 622
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_54} :catch_55

    return-void

    :catch_55
    const-string v0, "\u0434\u043e\u0437\u0432\u043e\u043b\u044c \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u0437\u0430\u0441\u0442\u043e\u0441\u0443\u043d\u043a\u0456\u0432 \u0443 \u043d\u0430\u043b\u0430\u0448\u0442\u0443\u0432\u0430\u043d\u043d\u044f\u0445"

    .line 625
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    return-void

    :cond_5b
    const/4 v1, 0x0

    .line 629
    iput-boolean v1, p0, Lcom/fluxhelper/app/MainActivity;->pendingInstall:Z

    .line 639
    :try_start_5e
    invoke-direct {p0, v0}, Lcom/fluxhelper/app/MainActivity;->installViaSession(Ljava/io/File;)V
    :try_end_61
    .catchall {:try_start_5e .. :try_end_61} :catchall_62

    return-void

    :catchall_62
    move-exception v0

    .line 642
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_6e

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    goto :goto_72

    :cond_6e
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_72
    const-string v2, "content://com.fluxhelper.app.upd/apk"

    .line 645
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    .line 647
    :try_start_78
    new-instance v4, Landroid/content/Intent;

    const-string v5, "android.intent.action.INSTALL_PACKAGE"

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v5, "application/vnd.android.package-archive"

    .line 648
    invoke-virtual {v4, v2, v5}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    const v2, 0x10000001

    .line 649
    invoke-virtual {v4, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 650
    invoke-virtual {p0, v4}, Lcom/fluxhelper/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_8d
    .catch Ljava/lang/Exception; {:try_start_78 .. :try_end_8d} :catch_8e

    goto :goto_8f

    :catch_8e
    move v3, v1

    :goto_8f
    if-eqz v3, :cond_97

    const-string v0, "window.__fh&&window.__fh.dlDone()"

    .line 655
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    goto :goto_bb

    .line 657
    :cond_97
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "\u043d\u0435 \u0432\u0434\u0430\u043b\u043e\u0441\u044f \u0432\u0456\u0434\u043a\u0440\u0438\u0442\u0438 \u0432\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u044e\u0432\u0430\u0447"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz v0, :cond_af

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " \u2014 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_b1

    :cond_af
    const-string v0, ""

    :goto_b1
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    :goto_bb
    return-void

    :cond_bc
    :goto_bc
    const-string v0, "\u0444\u0430\u0439\u043b \u043e\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f \u043d\u0435 \u0437\u043d\u0430\u0439\u0434\u0435\u043d\u043e"

    .line 614
    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    return-void
.end method

.method public upd(Ljava/lang/String;)V
    .registers 12
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    const-string v0, "versions/release/"

    const/4 v1, 0x0

    if-eqz p1, :cond_77

    const-string v2, "\"v\"\\s*:\\s*\"([^\"]+)\""

    .line 363
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    .line 364
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_1b

    invoke-virtual {v2, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_1c

    :cond_1b
    move-object v2, v1

    :goto_1c
    const-string v3, "\"repo\"\\s*:\\s*\"([^\"]+)\""

    .line 365
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    .line 366
    invoke-virtual {v3}, Ljava/util/regex/Matcher;->find()Z

    move-result v5

    if-eqz v5, :cond_31

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_32

    :cond_31
    move-object v3, v1

    :goto_32
    const-string v5, "\"p\"\\s*:\\s*\"([^\"]+)\""

    .line 367
    invoke-static {v5}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    .line 368
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-eqz v6, :cond_47

    invoke-virtual {v5, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    goto :goto_48

    :cond_47
    move-object v5, v0

    :goto_48
    const-string v6, "versions/beta/"

    .line 369
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_56

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_57

    :cond_56
    move-object v0, v5

    :cond_57
    const-string v5, "\"md5\"\\s*:\\s*\"([0-9a-fA-F]{32})\""

    .line 370
    invoke-static {v5}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    .line 371
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result v5

    if-eqz v5, :cond_72

    invoke-virtual {p1, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p1

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    move-object v1, p1

    :cond_72
    move-object v6, v0

    move-object v9, v1

    move-object v7, v2

    move-object v8, v3

    goto :goto_7b

    :cond_77
    move-object v6, v0

    move-object v7, v1

    move-object v8, v7

    move-object v9, v8

    :goto_7b
    if-eqz v7, :cond_9d

    if-eqz v8, :cond_9d

    const/16 p1, 0x2f

    .line 378
    invoke-virtual {v8, p1}, Ljava/lang/String;->indexOf(I)I

    move-result p1

    if-gez p1, :cond_88

    goto :goto_9d

    :cond_88
    const-string p1, "window.__fh&&window.__fh.dlProg(0)"

    .line 381
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    .line 382
    new-instance p1, Ljava/lang/Thread;

    new-instance v0, Lcom/fluxhelper/app/MainActivity$5;

    move-object v4, v0

    move-object v5, p0

    invoke-direct/range {v4 .. v9}, Lcom/fluxhelper/app/MainActivity$5;-><init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 434
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    goto :goto_a2

    :cond_9d
    :goto_9d
    const-string p1, "\u043d\u0435\u043a\u043e\u0440\u0435\u043a\u0442\u043d\u0456 \u0434\u0430\u043d\u0456 \u043e\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u044f"

    .line 379
    invoke-virtual {p0, p1}, Lcom/fluxhelper/app/MainActivity;->jsErr(Ljava/lang/String;)V

    :goto_a2
    return-void
.end method

.method private startGoogleLogin(Ljava/lang/String;)V
    .registers 5

    # 3.5.59: вхід — ЛИШЕ системний браузер. state від JS зберігається
    # (st = новий, st_prev = попередній для толерантності до двох вкладок),
    # далі openWebLoginCore відкриває auth.html у браузері. Ніякого
    # Credential Manager, ніяких нативних обмінів токена.

    if-nez p1, :cond_s

    const-string p1, ""

    :cond_s
    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "st"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "st_prev"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v2, "st"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-direct {p0, p1, v0}, Lcom/fluxhelper/app/MainActivity;->openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method

.method private loginLastDirect(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    # 3.5.59: плитка «нещодавно» = той самий браузерний вхід з login_hint
    # (нативний тихий вхід AccountManager видалено разом із CM).

    if-nez p1, :cond_s

    const-string p1, ""

    :cond_s
    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "st"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "st_prev"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v2, "st"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/fluxhelper/app/MainActivity;->loginGen:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-direct {p0, p1, p2}, Lcom/fluxhelper/app/MainActivity;->openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method

.method private openWebLoginCore(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    # 3.5.59: відкрити auth.html у системному браузері (Custom Tab, якщо
    # встановлено, інакше дефолтний браузер — через openExternal).

    if-nez p1, :cond_a

    const-string p1, ""

    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "https://fluxhelper.pages.dev/auth.html#s="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "&oneclick=1&mobile=1"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_b

    const-string v1, "@"

    invoke-virtual {p2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_b

    const-string v1, "&login_hint="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/fluxhelper/app/MainActivity;->browserLoginUsed:Z

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->openExternal(Ljava/lang/String;)V

    return-void
.end method

.method private handleAuthUri(Landroid/net/Uri;)V
    .registers 9

    # 3.5.59: deep link від auth.html у браузері.
    # fluxhelper://auth?done=1          — пінг «відкрийся» (JS продовжить poll)
    # fluxhelper://auth?s=<st>&d=<json> — профіль Google: state звіряється
    #   з st/st_prev (захист від підробних intent), JSON → MainActivity$10
    #   → jsCall authOkStr(jsStr(d)). Схема com.googleusercontent.apps.*
    #   більше не обробляється — нативного обміну токена більше немає.

    if-eqz p1, :goto_ret

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :goto_ret

    const-string v1, "fluxhelper"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :goto_ret

    const-string v0, "done"

    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :chk_d

    const-string v0, "window.__fh&&window.__fh.authOk&&window.__fh.authOk({done:true})"

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    return-void

    :chk_d
    const-string v0, "d"

    invoke-virtual {p1, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :goto_ret

    const-string v1, "s"

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :goto_bad

    :try_start_0
    invoke-direct {p0}, Lcom/fluxhelper/app/MainActivity;->authPrefs()Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "st"

    const-string v4, ""

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "st_prev"

    const-string v5, ""

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :try_prev

    goto :goto_ok

    :try_prev
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :goto_bad

    :goto_ok
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/fluxhelper/app/MainActivity;->loginInFlight:Z

    new-instance v2, Lcom/fluxhelper/app/MainActivity$10;

    invoke-direct {v2, p0, v0}, Lcom/fluxhelper/app/MainActivity$10;-><init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Lcom/fluxhelper/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception v2

    goto :goto_ok

    :goto_bad
    const-string v0, "window.__fh&&window.__fh.authErr&&window.__fh.authErr(\'Сесія входу застаріла — натисни «Увійти через Google» ще раз\')"

    invoke-virtual {p0, v0}, Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V

    :goto_ret
    return-void
.end method

.method private cancelLoginTimers()V
    .registers 1

    # 3.5.59: нативних watchdog'ів більше немає (стежить JS у WebView);
    # метод лишено як no-op для існуючих викликів.

    return-void
.end method

