.class Lcom/fluxhelper/app/MainActivity$4;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/fluxhelper/app/MainActivity;->jsCall(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/fluxhelper/app/MainActivity;

.field private final synthetic val$str:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/fluxhelper/app/MainActivity;Ljava/lang/String;)V
    .registers 3

    .line 342
    iput-object p1, p0, Lcom/fluxhelper/app/MainActivity$4;->this$0:Lcom/fluxhelper/app/MainActivity;

    iput-object p2, p0, Lcom/fluxhelper/app/MainActivity$4;->val$str:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 345
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$4;->this$0:Lcom/fluxhelper/app/MainActivity;

    # getter for: Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$9(Lcom/fluxhelper/app/MainActivity;)Landroid/webkit/WebView;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 346
    iget-object v0, p0, Lcom/fluxhelper/app/MainActivity$4;->this$0:Lcom/fluxhelper/app/MainActivity;

    # getter for: Lcom/fluxhelper/app/MainActivity;->wv:Landroid/webkit/WebView;
    invoke-static {v0}, Lcom/fluxhelper/app/MainActivity;->access$9(Lcom/fluxhelper/app/MainActivity;)Landroid/webkit/WebView;

    move-result-object v0

    iget-object v1, p0, Lcom/fluxhelper/app/MainActivity$4;->val$str:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    :cond_14
    return-void
.end method
