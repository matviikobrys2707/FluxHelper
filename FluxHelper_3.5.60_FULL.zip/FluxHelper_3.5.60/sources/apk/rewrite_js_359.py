#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3.5.59: JS-частиа переписування входу.

ui.js (iphone/ + website-src/, однакові файли):
  • authStart ANDROID-гілка: браузер як ЄДИНИЙ шлях (без rescue20/guard-убивств);
  • authErr: без нативного rescue (натива більше не обмінює токени);
  • window.__fh.authOkStr: профіль із deep link (JSON-рядок від MainActivity$10).

auth.html (repo_pub):
  • mobile=1: sessionStorage-прапор переживає OAuth-редирект;
  • finishOk: deep link fluxhelper://auth?s=<st>&d=<profile> (головний канал)
    + резервний done=1 пінг + кнопка «Повернутися у FluxHelper»;
  • ПК/heartbeat-канал (PORT) не зачеплений.
"""
import re, sys

UI_FILES = [
    '/home/z/my-project/work/repo_pub/iphone/ui.js',
    '/home/z/my-project/work/lite55/apk/website-src/ui.js',
]
AUTH = '/home/z/my-project/work/repo_pub/auth.html'

def sub1(t, pat, rep, label, flags=re.S):
    t2, n = re.subn(pat, rep, t, count=1, flags=flags)
    assert n == 1, f'{label}: replaced {n}'
    print('OK', label)
    return t2

# ================================================================ ui.js
for path in UI_FILES:
    t = open(path, encoding='utf-8').read()

    # --- 1. ANDROID-гілка authStart (від if до return перед веб-гілкою)
    pat_start = r'  if \(ANDROID && !window\.FH_WEB\) \{.*?\n  \}\n  try \{ AndroidHost\.login\(st\); authPollDb\(st\); \}'
    new_start = '''  if (ANDROID && !window.FH_WEB) {
    /* 3.5.59: НОВИЙ ВХІД — системний браузер як єдиний шлях. Натива
       (AndroidHost.login/loginLast) відкриває auth.html#s=<st>&mobile=1
       у браузері; профіль повертається deep link'ом fluxhelper://auth
       (миттєво) або через authPollDb (poll auth_cb у D1, резерв).
       Нативного Credential Manager більше немає — сам він і був причиною
       зависання «Заходимо в акаунт…» у 3.5.52–3.5.58. */
    const agBtn59 = byId('agGo');
    const spinOn59 = function () {
      try { if (agBtn59) agBtn59.disabled = true; } catch (eD59) {}
      setAgStat('<span class="spin"></span>Відкриваю Google…');
    };
    const spinOff59 = function () {
      try { if (agBtn59) agBtn59.disabled = false; } catch (eE59) {}
    };
    try {
      window.__fhAgSpin47 = spinOff59;
      spinOn59();
      /* канал завершення №1 (резерв): poll auth_cb у D1 — живий, поки
         застосунок відкритий, завершує вхід сам, коли браузер допише профіль */
      try { authPollDb(st); } catch (eP59) {}
      /* головний шлях: системний браузер (Custom Tab / дефолтний браузер) */
      if (hintEmail && typeof AndroidHost.loginLast === 'function') {
        AndroidHost.loginLast(st, String(hintEmail));
      } else {
        AndroidHost.login(st);
      }
      /* м'який сторож: 100с — прибрати спінер і дозволити повторний тап;
         poll при цьому НЕ гаситься (агState живий до завершення/таймауту) */
      (function (stW59) {
        let n59 = 0;
        const iv59 = setInterval(function () {
          n59 += 5;
          if (agState !== stW59 || ACC.user) { clearInterval(iv59); return; }
          if (n59 === 100) {
            spinOff59();
            try { setAgStat('Завершуй вхід у Google у браузері — застосунок увійде сам, коли все буде готово. Якщо браузер закрився — натисни ще раз.'); } catch (eS59) {}
          }
          if (n59 >= 660) {
            clearInterval(iv59);
            if (agState === stW59 && !ACC.user) {
              spinOff59();
              try { setAgStat('Час входу вийшов. Натисни «Увійти через Google» ще раз.', 'err'); } catch (eT59) {}
            }
          }
        }, 5000);
      })(st);
    } catch (eNat59) {
      spinOff59();
      agState = '';
      try { localStorage.removeItem('fh_auth_state'); } catch (eLR59) {}
      setAgStat('Не вдалося відкрити вхід. Спробуй ще раз.', 'err');
    }
    return;
  }
  try { AndroidHost.login(st); authPollDb(st); }'''
    t = sub1(t, pat_start, new_start, path + ': authStart ANDROID')

    # --- 2. authErr без rescue
    pat_err = r'  authErr: function \(m\) \{.*?\n  \},\n  notifFired:'
    new_err = '''  authErr: function (m) {
    /* 3.5.59: натива більше не обмінює токени, rescue-гілки не потрібні.
       Явна помилка (наприклад, браузер не відкрився) = чистий стан + повідомлення. */
    const m59 = String(m || '');
    try { fhLog('aerr', m59.slice(0, 60)); } catch (eL59) {}
    try { if (ANDROID && !window.FH_WEB && AG_HINT52) chipFailTick(AG_HINT52); } catch (eC59) {}
    agState = '';
    try { if (typeof window.__fhAgSpin47 === 'function') window.__fhAgSpin47(); } catch (eSE59) {}
    const gb59 = byId('agGo'); if (gb59) gb59.disabled = false;
    setAgStat(m59 || 'Не вдалося підтвердити вхід', 'err');
  },
  authOkStr: function (s) {
    /* 3.5.59: профіль із deep link fluxhelper://auth?d=<json> (натива → jsCall).
       Нормалізуємо до того самого вигляду, що й poll-канал (d1Take). */
    try {
      const u59 = JSON.parse(String(s || ''));
      if (u59 && u59.sub) {
        window.__fh.authOk({
          sub: String(u59.sub),
          name: String(u59.name || 'Користувач'),
          email: String(u59.email || ''),
          pic: String(u59.picture || u59.pic || ''),
          fid: u59.fid ? String(u59.fid) : undefined
        });
      }
    } catch (e59) {}
  },
  notifFired:'''
    t = sub1(t, pat_err, new_err, path + ': authErr+authOkStr')

    open(path, 'w', encoding='utf-8').write(t)
    print('ui.js оновлений:', path)

# ================================================================ auth.html
t = open(AUTH, encoding='utf-8').read()

# 1. MOBILE-прапор після розбору hash
pat_m = r"(  var STATE = h\.s \|\| \(GH \? \(h\.state \|\| ''\) : ''\), PORT = h\.p \|\| '', HINT = h\.h \|\| '';\n)"
rep_m = r"""\1
  /* 3.5.59: режим МОБІЛЬНОГО входу (deep link назад у застосунок).
     Прапор переживає OAuth-редирект через sessionStorage (та сама вкладка). */
  var MOBILE = false;
  try { MOBILE = sessionStorage.getItem('fh_m') === '1'; } catch (eM59) {}
  if (h.mobile === '1') { MOBILE = true; try { sessionStorage.setItem('fh_m', '1'); } catch (eM59b) {} }
"""
t = sub1(t, pat_m, rep_m, 'auth.html: MOBILE flag')

# 2. кнопка повернення в done-боксі
pat_btn = r"(    <h2>Все готово!</h2>\n    <p class=\"ag-sub\" id=\"doneSub\">)"
rep_btn = r"""\1
    <button class="ag-go" id="backBtn" type="button" style="display:none;margin-top:14px">Повернутися у FluxHelper</button>
"""
t = sub1(t, pat_btn, rep_btn, 'auth.html: backBtn')

# 3. finishOk: deep link із профілем
pat_fin = r"    /\* 3\.5\.56: авто-повернення в застосунок \(лінія іншого ІІ\) — ТІЛЬКИ Android:.*?\n    \}, 500\);\n  \}"
new_fin = '''    /* 3.5.59: повернення в застосунок.
       MOBILE (deep link із профілем, головний канал): застосунок отримує
       профіль одразу (fluxhelper://auth?s=<state>&d=<json>), D1-запис лишається
       резервом для poll. tok/rtok НЕ передаємо: довжина URL, і застосунку вони
       не потрібні (fid уже в профілі, синхронізація йде без токена).
       Без MOBILE — стара поведінка: пінг done=1. */
    if (MOBILE && prof && prof.sub) {
      var d59 = {
        sub: String(prof.sub),
        name: String(prof.name || ''),
        email: String(prof.email || ''),
        picture: String(prof.picture || ''),
        fid: String(prof.fid || '')
      };
      var dl59 = 'fluxhelper://auth?s=' + encodeURIComponent(STATE) +
        '&d=' + encodeURIComponent(JSON.stringify(d59));
      var bb = document.getElementById('backBtn');
      if (bb) {
        bb.style.display = 'flex';
        bb.onclick = function () { try { location.href = dl59; } catch (eB59) { } };
      }
      if (/Android/i.test(navigator.userAgent)) {
        setTimeout(function () { try { location.href = dl59; } catch (eD59) { } }, 400);
        /* резервний пінг (стара поведінка): прокидає застосунок, якщо перший
           deep link браузер проковтнув — poll у застосунку донесе профіль із D1 */
        setTimeout(function () { try { location.href = 'fluxhelper://auth?done=1'; } catch (eP59) { } }, 2400);
      }
    } else if (/Android/i.test(navigator.userAgent)) {
      setTimeout(function () { try { location.href = 'fluxhelper://auth?done=1'; } catch (e59c) { } }, 500);
    }
  }'''
t = sub1(t, pat_fin, new_fin, 'auth.html: finishOk deep link')

open(AUTH, 'w', encoding='utf-8').write(t)
print('auth.html оновлений:', AUTH)
print('ALL OK')
