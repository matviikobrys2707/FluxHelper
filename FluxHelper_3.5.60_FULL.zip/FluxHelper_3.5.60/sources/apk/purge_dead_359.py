#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3.5.59: видалення мертвої бібліотеки Credential Manager з dex.

Після переписування входу код застосунку (com/fluxhelper) більше НЕ
посилається на androidx.credentials / googleid / gms fido / identity /
kotlin-корутини. Цей скрипт будує граф посилань класів (зі smali) і
визначає досяжні класи від коренів com/fluxhelper/**. Все недосяжне
(мертва бібліотека) переноситься в work/src/dex59_dead/ (бекап).
"""
import os, re, shutil, sys

SRC = '/home/z/my-project/work/src/dex59'
DEAD = '/home/z/my-project/work/src/dex59_dead'

if os.path.exists(DEAD):
    shutil.rmtree(DEAD)
os.makedirs(DEAD)

# клас → файл
cls2file = {}
for root, dirs, files in os.walk(SRC):
    for f in files:
        if f.endswith('.smali'):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, SRC)
            # дескриптор із шляху: com/fluxhelper/app/X.smali → Lcom/fluxhelper/app/X;
            desc = 'L' + rel[:-6] + ';'
            cls2file[desc] = p

print('класів у дереві:', len(cls2file))

# посилання кожного класу
TYPE_RE = re.compile(r'L[a-zA-Z0-9_$\-]+(?:/[a-zA-Z0-9_$\-]+)*;')
refs = {}
for desc, p in cls2file.items():
    t = open(p, encoding='utf-8', errors='replace').read()
    s = set()
    for m in TYPE_RE.findall(t):
        if m != desc:
            s.add(m)
    refs[desc] = s

roots = [c for c in cls2file if c.startswith('Lcom/fluxhelper/')]
print('коренів (застосунок):', len(roots))

keep = set()
stack = list(roots)
while stack:
    c = stack.pop()
    if c in keep or c not in cls2file:
        continue
    keep.add(c)
    stack.extend(refs.get(c, ()))

dead = [c for c in cls2file if c not in keep]
print('досяжних:', len(keep), '| мертвих:', len(dead))

# розподіл мертвих за пакетами (для звіту)
from collections import Counter
pkg = Counter('/'.join(c[1:].split('/')[:-1]) for c in dead)
for k, v in pkg.most_common(12):
    print(f'  {v:5d}  {k}')

moved = 0
for c in dead:
    p = cls2file[c]
    rel = os.path.relpath(p, SRC)
    dst = os.path.join(DEAD, rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.move(p, dst)
    moved += 1
print('перенесено в бекап:', moved)

# прибирання порожніх каталогів
for root, dirs, files in os.walk(SRC, topdown=False):
    if not os.listdir(root) and root != SRC:
        os.rmdir(root)

# верифікація: у дереві, що лишилось, НЕМАЄ посилань на видалені класи
alive = set(cls2file[c] for c in keep)
bad = 0
for p in alive:
    t = open(p, encoding='utf-8', errors='replace').read()
    for m in TYPE_RE.findall(t):
        if m in cls2file and m not in keep:
            print('DANGLING REF:', p, '->', m)
            bad += 1
print('dangling refs:', bad)
sys.exit(1 if bad else 0)
