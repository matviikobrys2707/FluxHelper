#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.60 (versionCode 30560).

КРАШ-ФИКС 3.5.59: classes.dex містив посилання на видалене поле
MainActivity->credLock (iput-object у <init>) БЕЗ оголошення поля —
NoSuchFieldError на кожному запуску (краш «Відправити звіт»).
Фікс: блок видалено; dex зібрано ЗАНОВО з dex_src (smali 2.5.2) і
перевірено трьома способами (checker, baksmali-diff, grep).
База: shipped 3.5.59 APK. AXML 30560 / 3.5.60. Решта — без змін.
"""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/download/FluxHelper/FluxHelper_3.5.59.apk'
DEX    = '/tmp/build60/classes60.dex'
OUTDIR = '/home/z/my-project/work/build360'
BT     = '/home/z/my-project/work/android/bt34/android-14'
KEYS   = 'fluxhelper.keystore.OFFICIAL-6871F0 (файл ключа не публікується)'

os.makedirs(OUTDIR, exist_ok=True)
UNSIGNED = f'{OUTDIR}/FluxHelper_360_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_360_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper_360.apk'

def zlib_read(apk, name):
    with zipfile.ZipFile(apk) as z:
        return z.read(name)

assert os.path.exists(DEX), 'classes60.dex не зібрано!'
assert os.path.getsize(DEX) > 50_000, 'dex підозріло малий'
assert os.path.exists(f'{BT}/zipalign') and os.path.exists(f'{BT}/lib/apksigner.jar')

# захист від повторення бити 3.5.59: у новому dex НЕМАЄ credLock ніде
dexbytes = open(DEX, 'rb').read()
assert b'credLock' not in dexbytes, 'credLock досі в dex!'

with zipfile.ZipFile(BASE) as z:
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue  # стара підписа
    if n == 'AndroidManifest.xml':
        ax = bytearray(zlib_read(BASE, n))
        vc_old = (30559).to_bytes(4, 'little'); vc_new = (30560).to_bytes(4, 'little')
        i = ax.find(vc_old); assert i > 0, 'versionCode 30559 not found'
        ax[i:i+4] = vc_new
        vn_old = '3.5.59'.encode('utf-16-le'); vn_new = '3.5.60'.encode('utf-16-le')
        j = ax.find(vn_old); assert j > 0, 'versionName 3.5.59 not found'
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0, 'versionName duplicated!'
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: versionCode 30560, versionName 3.5.60')
    elif n == 'classes.dex':
        zf.writestr(n, dexbytes, compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: classes60.dex,', len(dexbytes), 'bytes')
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:600])
assert '6871f0d5' in r.stdout.lower().replace('\n', ''), 'SHA-1 mismatch!'

with zipfile.ZipFile(SIGNED) as z:
    d = z.read('classes.dex')
assert hashlib.md5(d).hexdigest() == hashlib.md5(dexbytes).hexdigest(), \
    'dex всередині APK не збігається!'
print('dex-in-apk md5 OK')

with zipfile.ZipFile(SIGNED) as z:
    ax = z.read('AndroidManifest.xml')
assert (30560).to_bytes(4, 'little') in ax and '3.5.60'.encode('utf-16-le') in ax
print('AXML-in-apk version OK')

with zipfile.ZipFile(SIGNED) as z:
    ujs = z.read('assets/www/ui.js').decode('utf-8')
assert 'authOkStr' in ujs, 'ui.js втратив новий вхід!'
print('asset ui.js: браузерний вхід на місці')

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
