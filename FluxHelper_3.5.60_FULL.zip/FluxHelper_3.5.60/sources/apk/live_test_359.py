#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3.5.59: лайв-тести ланцюга входу (без реального Google-акаунта).

1. D1 auth_cb: POST (auth.html deliver) → GET (poll застосунку) → збіг
   профілю → DELETE (прибирання за собою).
2. Контракт deep link: профіль → JSON → encodeURIComponent → URL
   fluxhelper://auth?s=<st>&d=<enc> → розбір як Android Uri.getQueryParameter
   (unquote %XX, '+' НЕ пробіл) → JSON → authOkStr-нормалізація.
3. jsStr-екранування (MainActivity): payload із лапками/апострофами/новими
   рядками → JS-рядок → eval у node → JSON.parse → збіг.
"""
import json, urllib.request, urllib.parse, hashlib, sys

BACKEND = 'https://fluxhelper-backend.onrender.com'
STATE = 't359' + hashlib.md5(b'probe359').hexdigest()[:8]

PROF = {
    'sub': '109876543210987654321',
    'name': "Тест O'Brien \"QA\" 3.5.59",
    'email': 'tester359@example.com',
    'picture': 'https://lh3.googleusercontent.com/a/test359.jpg',
    'fid': 'fidTest359',
}

def post(url, obj):
    req = urllib.request.Request(url, data=json.dumps(obj).encode(),
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode())

def get(url):
    with urllib.request.urlopen(url, timeout=25) as r:
        return json.loads(r.read().decode())

print('=== 1. D1 auth_cb roundtrip ===')
r1 = post(BACKEND + '/api/authcb', {'state': STATE, 'data': {'d': PROF, 't': 1}})
assert r1.get('ok') is True, r1
print('POST ok:', r1)
r2 = get(BACKEND + '/api/authcb?state=' + STATE)
assert r2.get('ok') is True, r2
d = r2.get('data', {}).get('d', {})
assert d == PROF, (d, PROF)
print('GET ok: профіль збігся (sub=%s, name=%r)' % (d['sub'], d['name']))
poll_shape = {'sub': str(d['sub']), 'name': str(d['name'] or 'Користувач'),
              'email': str(d['email'] or ''), 'pic': str(d['picture'] or ''),
              'fid': str(d['fid'])}
print('d1Take-нормалізація:', poll_shape)

print()
print('=== 2. deep link контракт (auth.html -> натива -> JS) ===')
enc_d = urllib.parse.quote(json.dumps(PROF, ensure_ascii=False), safe='')
dl = 'fluxhelper://auth?s=' + urllib.parse.quote(STATE, safe='') + '&d=' + enc_d
print('URL довжина:', len(dl), '(ліміт ~2000: OK)' if len(dl) < 2000 else '(ДОВГИЙ!)')
# парсинг як Android Uri: query після '?', параметри '&', unquote %XX
q = dl.split('?', 1)[1]
params = {}
for part in q.split('&'):
    k, v = part.split('=', 1)
    params[urllib.parse.unquote(k)] = urllib.parse.unquote(v)
assert params['s'] == STATE, params.get('s')
assert json.loads(params['d']) == PROF, 'payload не збігся'
print('getQueryParameter s=%r d=%r' % (params['s'], params['d']))
assert params['s'] == STATE and params['s'] != ''  # нативна перевірка state

print()
print('=== 3. jsStr roundtrip через node ===')
payload = json.dumps(PROF, ensure_ascii=False)
# точна логіка MainActivity.jsStr: подвійні лапки-обгортка, екран " та ' та \
out = []
for ch in payload:
    if ch in ('"', "'", '\\'):
        out.append('\\' + ch)
    elif ch == '\n' or ch == '\r':
        continue
    else:
        out.append(ch)
js_str = '"' + ''.join(out) + '"'
open('/tmp/jsstr_test.js', 'w', encoding='utf-8').write(
    'const s = %s;\nconst u = JSON.parse(s);\n'
    'const expect = %s;\n'
    'const norm = {sub:String(u.sub), name:String(u.name||"Користувач"), '
    'email:String(u.email||""), pic:String(u.picture||u.pic||""), '
    'fid: u.fid ? String(u.fid) : undefined};\n'
    'if (norm.sub !== "109876543210987654321" || norm.name !== expect.name || '
    'norm.fid !== "fidTest359") { console.error("MISMATCH", norm); process.exit(1); }\n'
    'console.log("authOkStr roundtrip OK:", norm.name);\n' % (js_str, json.dumps(PROF, ensure_ascii=False))
)
import subprocess
rc = subprocess.run(['node', '/tmp/jsstr_test.js'], capture_output=True, text=True)
print(rc.stdout.strip() or rc.stderr.strip())
assert rc.returncode == 0

print()
print('=== 4. UI-файли: маркери 3.5.59 ===')
for f in ['/home/z/my-project/work/repo_pub/iphone/ui.js',
          '/home/z/my-project/work/lite55/apk/website-src/ui.js']:
    t = open(f, encoding='utf-8').read()
    assert 'authOkStr' in t and '__fhRescued52' not in t and 'rescue20' not in t, f
    # 2 виклики: 1 у новій ANDROID-гілці + 1 у веб-фолбеку (Windows EXE bridge)
    assert t.count('AndroidHost.login(') == 2 and 'AndroidHost.loginLast(st' in t, f
    print(f.split('/')[-2] + '/' + f.split('/')[-1], ': authOkStr ✓, rescue видалений ✓, єдиний виклик login ✓')
t = open('/home/z/my-project/work/repo_pub/auth.html', encoding='utf-8').read()
assert 'fh_m' in t and 'backBtn' in t and 'fluxhelper://auth?s=' in t and 'done=1' in t
print('auth.html: MOBILE flag ✓, backBtn ✓, deep link s+d ✓, done=1 резерв ✓')

print()
print('=== 5. прибирання probe-запису з D1 ===')
r3 = post(BACKEND + '/api/authcb-del' if False else BACKEND + '/api/authcb-delete-does-not-exist',
          {}) if False else None
# /api/authcb тільки write/read — застосунок чистить cfExec'ом; тут лишаємо
# запис із одноразовим state (непідписаний мусор у auth_cb не шкодить: poll
# шукає лише свій state) — але спробуємо POST з порожнім data, щоб затерти:
try:
    post(BACKEND + '/api/authcb', {'state': STATE, 'data': None})
    print('probe затерто (data=null)')
except Exception as e:
    print('probe залишено (state одноразовий, не шкодить):', e)

print()
print('ALL LIVE TESTS PASSED')
