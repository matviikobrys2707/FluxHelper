FluxHelper 3.5.59 (beta) — ПОВНИЙ ПАКЕТ
=========================================
Дата: 17.11.2026 · GitHub main: 4e58c17 · Канал: beta

У пакеті — ВСЕ САМЕ ПОТРІБНЕ по версії 3.5.59: готові застосунки, джерела сайту
гілки main, АКТУАЛЬНІ smali-джерела APK після повного переписування Google-входу
(31 клас замість 5318) та скрипти збірки.

СКЛАД ПАКЕТА
------------
app/
  FluxHelper_3.5.59.apk — Android, versionCode 30559, офіційний підпис
                          SHA-1 6871f0d5fadac10933492095bd322d4bf81a8373
                          (dex 67 КБ — Credential Manager і мертві бібліотеки видалено)
  FluxHelper_3.5.59.exe — Windows, розмір 1:1 як у попередніх (піднято тільки номер версії)
changelog.txt           — що нового у 3.5.59 (переписаний з нуля Google-вхід)
latest.json             — маніфест бета-каналу (apk_md5/exe_md5 для перевірки оновлень)
website/                — джерела сайту 3.5.59 (29 файлів):
  index.html (головна), auth.html (вхід Google; mobile=1 → deep link
  fluxhelper://auth?s=&d=), _headers (CSP), main/ (спільна версія), iphone/
  (ui.js з новою ANDROID-гілкою входу + authOkStr), mac/, b/, manifest.json,
  latest.json (release-канал), іконки
sources/apk/            — АКТУАЛЬНІ smali-джерела APK 3.5.59: dex_src (31 класів —
  повний склад classes.dex після purge), інструменти smali/baksmali 2.5.2
  (antlr-runtime-3.5.2.jar, baksmali-2.5.2.jar, dexlib2-2.5.2.jar, guava-14.0.jar, jcommander-1.82.jar, jsr305-3.0.2.jar, smali-2.5.2.jar, util-2.5.2.jar),
  build_apk_359.py (збірка), rewrite_auth_359.py (переписування входу),
  purge_dead_359.py (reachability-очистка мертвих класів), rewrite_js_359.py,
  live_test_359.py (лайв-тести ланцюга входу).
  Увесь classes.dex 3.5.59 — це 31 класів com/fluxhelper/**: більше НІЯКИХ
  androidx.credentials / googleid / gms fido / kotlin-корутин у dex немає.
sources/exe/            — patch_exe_359.py (EXE не перезбирається —
  тільки same-length патч номера версії 3.5.58 → 3.5.59)

ЯК ВСТАНОВИТИ
-------------
Android: перекиньте app/FluxHelper_3.5.59.apk на телефон і відкрийте → дозвольте
  встановлення. Ставиться ПОВЕРХ будь-якої 3.5.x (підпис той самий, дані не губляться).
Windows: запустіть app/FluxHelper_3.5.59.exe.
Сайт: https://fluxhelper.pages.dev (бета — перемикач «Бета-версії» в профілі адміна).

ПЕРЕВІРКА ЦІЛІСНОСТІ
--------------------
md5/sha256 ключових файлів — у HASHES.txt. Контрольні md5:
  APK = c8a3a535756fa71cee228eb9e77f2364
  EXE = 40e8a7b9d9f1c900baa04e73d2889211
Якщо суми збігаються — файли справжні (офіційна збірка).

БЕЗПЕКА
-------
Пароль keystore у build_apk_359.py ВИЛУЧЕНО (замінено на ***REMOVED***),
бо пакет публічний. Файл ключа fluxhelper.keystore.OFFICIAL-6871F0 до пакета
не входить; пароль зберігається у приватному репозиторії FluxHelper_SRC.
