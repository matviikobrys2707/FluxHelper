#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка FluxHelper beta 3.5.59 (versionCode 30559).
База: 3.5.58 APK. ПОВНЕ переписування Google-входу (з нуля):
  • classes.dex — 5287 мертвих класів CM/GMS/kotlin ВИДАЛЕНО (dex 5.96MB → 67KB):
    - androidx Credential Manager (430 класів) + googleid + gms fido/identity;
    - нативний обмін токена (verifyIdToken/fbExchange/AccountManager) — джерело
      зависання «Заходимо в акаунт…»;
    - нативні watchdog'и ($3/$11).
  • НОВИЙ вхід (єдиний шлях — системний браузер):
    - startGoogleLogin/loginLastDirect → openWebLoginCore →
      auth.html#s=<st>&oneclick=1&mobile=1 у браузері;
    - handleAuthUri: deep link fluxhelper://auth?s=<st>&d=<json> → MainActivity$10
      → jsCall authOkStr (state звіряється зі st/st_prev);
    - резервний канал — poll auth_cb у D1 (cfExec) як і було.
  • assets/www/ui.js — нова ANDROID-гілка authStart (браузер-першість,
    м'який сторож, без rescue), authErr без rescue, новий authOkStr.
  • assets/www/index.html — оновлений (ui.js?v=3559).
  • AXML versionCode 30559 / versionName 3.5.59.
"""
import zipfile, subprocess, hashlib, os, sys

BASE   = '/home/z/my-project/work/repo_pub/versions/beta/3.5.58/FluxHelper.apk'
DEX    = '/tmp/classes59.dex'
OUTDIR = '/home/z/my-project/work/build359'
BT     = '/home/z/my-project/work/android/bt34/android-14'
KEYS   = 'fluxhelper.keystore.OFFICIAL-6871F0 (файл ключа не публікується)'
UIJS   = '/home/z/my-project/work/lite55/apk/website-src/ui.js'
INDEX  = '/home/z/my-project/work/repo_pub/iphone/index.html'

os.makedirs(OUTDIR, exist_ok=True)
UNSIGNED = f'{OUTDIR}/FluxHelper_359_unsigned.apk'
ALIGNED  = f'{OUTDIR}/FluxHelper_359_aligned.apk'
SIGNED   = f'{OUTDIR}/FluxHelper_359.apk'

def zlib_read(apk, name):
    with zipfile.ZipFile(apk) as z:
        return z.read(name)

assert os.path.exists(DEX), 'classes59.dex не зібрано!'
assert os.path.getsize(DEX) > 50_000, 'dex підозріло малий'
assert os.path.exists(f'{BT}/zipalign') and os.path.exists(f'{BT}/lib/apksigner.jar')
uijs = open(UIJS, 'rb').read()
index = open(INDEX, 'rb').read().replace(b'ui.js?v=3559', b'ui.js?v=3559')
assert b'authOkStr' in uijs, 'ui.js без нового входу!'

with zipfile.ZipFile(BASE) as z:
    names = z.namelist()

if os.path.exists(UNSIGNED): os.remove(UNSIGNED)
zf = zipfile.ZipFile(UNSIGNED, 'w', zipfile.ZIP_DEFLATED)
for n in names:
    if n.startswith('META-INF/'):
        continue  # стара підписа
    if n == 'AndroidManifest.xml':
        ax = bytearray(zlib_read(BASE, n))
        vc_old = (30558).to_bytes(4, 'little'); vc_new = (30559).to_bytes(4, 'little')
        i = ax.find(vc_old); assert i > 0, 'versionCode 30558 not found'
        ax[i:i+4] = vc_new
        vn_old = '3.5.58'.encode('utf-16-le'); vn_new = '3.5.59'.encode('utf-16-le')
        j = ax.find(vn_old); assert j > 0, 'versionName 3.5.58 not found'
        ax[j:j+len(vn_old)] = vn_new
        assert ax.find(vn_old) < 0, 'versionName duplicated!'
        zf.writestr(n, bytes(ax), compress_type=zipfile.ZIP_DEFLATED)
        print('AXML: versionCode 30559, versionName 3.5.59')
    elif n == 'classes.dex':
        zf.writestr(n, open(DEX, 'rb').read(), compress_type=zipfile.ZIP_DEFLATED)
        print('DEX: classes59.dex,', os.path.getsize(DEX), 'bytes')
    elif n == 'assets/www/ui.js':
        zf.writestr(n, uijs, compress_type=zipfile.ZIP_DEFLATED)
        print('ASSET: ui.js — новий браузерний вхід')
    elif n == 'assets/www/index.html':
        zf.writestr(n, index, compress_type=zipfile.ZIP_DEFLATED)
        print('ASSET: index.html — ui.js?v=3559')
    else:
        with zipfile.ZipFile(BASE) as z2:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_STORED if n == 'resources.arsc' else zipfile.ZIP_DEFLATED
            zf.writestr(zi, z2.read(n), compress_type=zi.compress_type)
zf.close()
print('unsigned:', os.path.getsize(UNSIGNED))

for f in (ALIGNED, SIGNED):
    if os.path.exists(f): os.remove(f)

r = subprocess.run([f'{BT}/zipalign', '-f', '4', UNSIGNED, ALIGNED], capture_output=True, text=True)
if r.returncode != 0: print(r.stdout, r.stderr); sys.exit(1)
print('zipalign OK')

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'sign',
                    '--ks', KEYS, '--ks-pass', 'pass:***REMOVED***',
                    '--ks-key-alias', 'fluxhelper', '--out', SIGNED, ALIGNED],
                   capture_output=True, text=True)
print('sign rc=', r.returncode, r.stderr[:300] if r.returncode else '')
if r.returncode != 0: sys.exit(1)

r = subprocess.run(['java', '-jar', f'{BT}/lib/apksigner.jar', 'verify', '--print-certs', SIGNED],
                   capture_output=True, text=True)
print(r.stdout[:600])
assert '6871f0d5' in r.stdout.lower().replace('\n', ''), 'SHA-1 mismatch!'

with zipfile.ZipFile(SIGNED) as z:
    d = z.read('classes.dex')
assert hashlib.md5(d).hexdigest() == hashlib.md5(open(DEX, 'rb').read()).hexdigest(), \
    'dex всередині APK не збігається!'
print('dex-in-apk md5 OK')

with zipfile.ZipFile(SIGNED) as z:
    ax = z.read('AndroidManifest.xml')
assert (30559).to_bytes(4, 'little') in ax and '3.5.59'.encode('utf-16-le') in ax
print('AXML-in-apk version OK')

with zipfile.ZipFile(SIGNED) as z:
    ujs = z.read('assets/www/ui.js').decode('utf-8')
assert 'authOkStr' in ujs and '__fhRescued52' not in ujs
print('asset ui.js: новий вхід OK')

data = open(SIGNED, 'rb').read()
print('SIGNED:', SIGNED, len(data), 'bytes')
print('md5:', hashlib.md5(data).hexdigest())
print('sha256:', hashlib.sha256(data).hexdigest())
